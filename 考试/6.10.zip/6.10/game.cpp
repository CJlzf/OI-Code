#include <iostream>
#include <cstdio>
#include <algorithm>
#define N 200002
using namespace std;
struct line{
	double c,d;
}l[N];
int n,k,i,p[N];
double a[N],b[N],c[N],d[N],ans=-1e9;
bool vis[N];
void dfs(int x)
{
	if(x==k+2){
		double minx=1e9,sum=0;
		for(int i=1;i<=k+1;i++){
			sum+=a[p[i]]*c[i]+d[i];
			minx=min(minx,b[p[i]]-sum);
		}
		ans=max(ans,minx);
		return;
	}
	for(int i=1;i<=n;i++){
		if(!vis[i]){
			vis[i]=1;
			p[x]=i;
			dfs(x+1);
			vis[i]=0;
		}
	}
}
bool check()
{
	for(int i=1;i<=n;i++){
		if(b[i]!=b[1]) return 0;
	}
	return 1;
}
int my_comp(const line &a,const line &b){
	return a.c>b.c;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(i=1;i<=n;i++) scanf("%lf%lf",&a[i],&b[i]);
	for(i=1;i<=k+1;i++) scanf("%lf%lf",&c[i],&d[i]);
	if(check()){
		sort(a+1,a+n+1);
		for(int i=1;i<=n;i++) l[i].c=c[i],l[i].d=d[i];
		sort(l+1,l+k+2,my_comp);
		ans=0;
		for(int i=1;i<=k+1;i++) ans+=a[i]*l[i].c+l[i].d;
		ans=b[1]-ans;
	}
	else dfs(1);
	printf("%.10lf\n",ans);
	return 0;
}
