#include <iostream>
#include <cstdio>
using namespace std;
int t,h,Q,Z,Y,T,q[20][20],px,py;
bool vis[20][20],flag,have;
char map[20][20];
void add(int x,int y){
	if(vis[x][y])return;
	vis[x][y]=1;
	++t;
	q[0][t]=x;
	q[1][t]=y;
}
int solve(char c1,char c2){
	for(int i=0;i<16;i++)
		for(int j=0;j<16;j++)
			vis[i][j]=0;
	h=t=0;
	add(px,py);
	while(h<t){
		++h;
		int x=q[0][h],y=q[1][h];
		if(x&&(map[x-1][y]==c1||map[x-1][y]==c2))add(x-1,y);
		if(y&&(map[x][y-1]==c1||map[x][y-1]==c2))add(x,y-1);
		if(x<15&&(map[x+1][y]==c1||map[x+1][y]==c2))add(x+1,y);
		if(y<15&&(map[x][y+1]==c1||map[x][y+1]==c2))add(x,y+1);
	}
	return h;
}
void dfs(int x,int y)
{
	if(have) return;
	if(x==6){
		if(!flag) return;
		if(solve('.','~')==Z&&solve('~','#')==Y&&solve('#','.')==T){
			for(int i=0;i<16;i++){
				for(int j=0;j<16;j++) putchar(map[i][j]);
				puts("");
			}
			have=1;
		}
		return;
	}
	if(!flag){
		map[x][y]='S',px=x,py=y,flag=1;
		if(y==6) dfs(x+1,0);
		else dfs(x,y+1);
		flag=0;px=py=0;
	}
	map[x][y]='.';
	if(y==6) dfs(x+1,0);
	else dfs(x,y+1);	
	map[x][y]='#';
	if(y==6) dfs(x+1,0);
	else dfs(x,y+1);
	map[x][y]='~';
	if(y==6) dfs(x+1,0);
	else dfs(x,y+1);
}
int main()
{
	cin>>Q;
	while(Q--){
		cin>>Z>>Y>>T;
		dfs(0,0);
	}
	return 0;
}
