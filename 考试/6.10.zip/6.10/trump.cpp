#include <iostream>
#include <cstdio>
#include <queue>
#include <cmath>
#define N 2000002
using namespace std;
const int mod=1000000007;
priority_queue<int> q;
int n,m,i,j,p[N],son[N][2],fa[N],dis[N],vis[N],cnt,ans,poww[N],tmp[N];
bool use[N];
int read()
{
	char c=getchar();
	int w=0;
	while(c<'0'||c>'9') c=getchar();
	while(c<='9'&&c>='0'){
		w=w*10+c-'0';
		c=getchar();
	}
	return w;
}
int get(int x)
{
	if(son[fa[x]][0]==x) return 0;
	return 1;
}
void dfs1(int x)
{
	vis[x]=cnt;dis[x]=0;
	if(use[son[x][0]]&&son[x][0]) dfs1(son[x][0]);
	if(use[son[x][1]]&&son[x][1]) dfs1(son[x][1]);
	if(son[x][0]||son[x][1]) dis[x]=max(dis[son[x][0]],dis[son[x][1]])+1;
}
void dfs(int x,int num)
{
	if(x==n+1){
		if(num!=n-m) return;
		cnt++;
		int sum=0,flag=1;
		for(int i=1;i<=n;i++) dis[i]=0;
		dfs1(p[1]);
		for(int i=1;i<=n;i++){
			if((use[i]&&vis[i]!=cnt)||abs(dis[son[i][0]]-dis[son[i][1]])>1){
				flag=0;
				break;
			}
			if(use[i]) sum=(sum+poww[i])%mod;
		}
		if(flag) ans=max(ans,sum);
		return;
	}
	use[x]=1;
	dfs(x+1,num+1);
	if(x!=p[1]) use[x]=0,dfs(x+1,num);
}
bool check(int x)
{
	if(dis[son[fa[x]][get(x)^1]]>=1) return 0;
	int tmp=dis[son[fa[x]][get(x)^1]];
	x=fa[x];
	while(fa[x]){
		if(abs(tmp-dis[son[fa[x]][get(x)^1]])>1) return 0;
		tmp=max(tmp,dis[son[fa[x]][get(x)^1]])+1;
		x=fa[x];
	}
	return 1;
}
int main()
{
	freopen("trump.in","r",stdin);
	freopen("trump.out","w",stdout);
	n=read();m=read();
	for(i=1,poww[0]=1;i<=n;i++) poww[i]=poww[i-1]*2%mod;
	for(i=1;i<=n;i++) p[i]=read();
	for(i=2;i<=n;i++){
		int f=0,x=p[1];
		while(x){
			if(x<p[i]) f=x,x=son[x][1];
			else f=x,x=son[x][0];
		}
		fa[p[i]]=f;
		if(f>p[i]) son[f][0]=p[i];
		else son[f][1]=p[i];
	}
	if(n<=20){
		dfs(1,0);
		printf("%d\n",ans);
	}
	else{
		for(i=1;i<=n;i++) use[i]=1;
		dfs1(p[1]);
		for(i=1;i<=n;i++) ans=(ans+poww[i])%mod;
		for(i=1;i<=n;i++){
			if(!son[i][0]&&!son[i][1]) q.push(-i);
		}
		for(i=1;i<=m;i++){
			while(!q.empty()&&!check(-q.top())){
				tmp[++cnt]=-q.top();
				q.pop();
			}
			int x=-q.top();q.pop();
			if(!son[fa[x]][get(x)^1]) q.push(-fa[x]);
			ans=(ans-poww[x]+mod)%mod;
			dis[fa[x]]=dis[son[fa[x]][get(x)^1]];
			x=fa[fa[x]];
			while(x) dis[x]=max(dis[son[x][0]],dis[son[x][1]])+1,x=fa[x];
			while(cnt){
				if(check(tmp[cnt])) q.push(-tmp[cnt]);
				cnt--;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
