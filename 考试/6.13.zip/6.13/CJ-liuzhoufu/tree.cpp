#include <iostream>
#include <cstdio>
#include <queue>
#define int long long
#define N 500002
using namespace std;
const int mod=1LL<<32;
struct SegmentTree{
	int dat,add;
}t[N*4];
struct event{
	int op,x,val;
}q[N];
int head[N],ver[N*2],nxt[N*2],l;
int n,m,i,j,a[N],fa[N],in[N],pos[N],cnt,L[N],R[N],num[4];
bool vis[N];
int read()
{
	char c=getchar();
	int w=0;
	while(c<'0'||c>'9') c=getchar();
	while(c<='9'&&c>='0'){
		w=w*10+c-'0';
		c=getchar();
	}
	return w;
}
void insert(int x,int y)
{
	l++;
	ver[l]=y;
	nxt[l]=head[x];
	head[x]=l;
}
void bfs()
{
	queue<int> q;
	vis[1]=1;
	q.push(1);
	while(!q.empty()){
		int x=q.front();
		q.pop();
		in[x]=++cnt;pos[cnt]=x;
		for(int i=head[x];i;i=nxt[i]){
			int y=ver[i];
			if(!vis[y]) vis[y]=1,q.push(y);
			else fa[x]=y;
		}
	}
}
void build(int p,int l,int r)
{
	if(l==r){
		t[p].dat=a[pos[l]];
		return;
	}
	int mid=(l+r)/2;
	build(p*2,l,mid);build(p*2+1,mid+1,r);
}
void spread(int op,int p)
{
	if(t[p].add){
		if(op==1){
			t[p*2].dat+=t[p].add;t[p*2].add+=t[p].add;
			t[p*2+1].dat+=t[p].add;t[p*2+1].add+=t[p].add;
		}
		else{
			t[p*2].dat^=t[p].add;t[p*2].add^=t[p].add;
			t[p*2+1].dat^=t[p].add;t[p*2+1].add^=t[p].add;			
		}
		t[p].add=0;
	}
}
void change(int op,int p,int l,int r,int ql,int qr,int v)
{
	if(ql>qr) return;
	if(ql<=l&&r<=qr){
		if(op==1) t[p].add+=v,t[p].dat+=v;
		else t[p].add^=v,t[p].dat^=v;
		return;
	}
	int mid=(l+r)/2;
	spread(op,p);
	if(ql<=mid) change(op,p*2,l,mid,ql,qr,v);
	if(qr>mid) change(op,p*2+1,mid+1,r,ql,qr,v);
}
int ask(int op,int p,int l,int r,int x)
{
	if(l==r) return t[p].dat;
	int mid=(l+r)/2;
	spread(op,p);
	if(x<=mid) return ask(op,p*2,l,mid,x);
	else return ask(op,p*2+1,mid+1,r,x);
}
signed main()
{
	n=read();m=read();
	for(i=1;i<=n;i++) a[i]=read();
	for(i=1;i<n;i++){
		int u=read(),v=read();
		insert(u,v);
		insert(v,u);
	}
	for(i=1;i<=m;i++){
		q[i].op=read();q[i].x=read();
		if(q[i].op==3) q[i].val=read();
		num[q[i].op]++;
	}
	bfs();
	for(i=1;i<=n;i++){
		L[i]=n+1;
		for(j=head[i];j;j=nxt[j]){
			int y=ver[j];
			if(y!=fa[i]){
				L[i]=min(L[i],in[y]);
				R[i]=max(R[i],in[y]);
			}
		}
	}
	build(1,1,n);
	if(num[2]==0){
		for(i=1;i<=m;i++){
			if(q[i].op==1) printf("%lld\n",ask(2,1,1,n,in[q[i].x])%mod);
			else{
				change(2,1,1,n,L[q[i].x],R[q[i].x],q[i].val);
				if(q[i].x!=1) change(2,1,1,n,in[fa[q[i].x]],in[fa[q[i].x]],q[i].val);
			}
		}
	}
	else if(num[3]==0){
		for(i=1;i<=m;i++){
			if(q[i].op==1) printf("%lld\n",ask(1,1,1,n,in[q[i].x])%mod);
			else{
				change(1,1,1,n,L[q[i].x],R[q[i].x],1);
				if(q[i].x!=1) change(1,1,1,n,in[fa[q[i].x]],in[fa[q[i].x]],1);
			}
		}
	}
	else{
		for(i=1;i<=m;i++){
			int op=q[i].op,x=q[i].x,val=q[i].val;
			if(op==1) printf("%lld\n",a[x]%mod);
			else if(op==2){
				for(j=head[x];j;j=nxt[j]) a[ver[j]]++;
			}
			else{
				for(j=head[x];j;j=nxt[j]) a[ver[j]]^=val;
			}
		}
	}
	return 0;
}
