#include <iostream>
#include <cstdio>
#include <cmath>
#define int long long
#define N 6002
using namespace std;
const int mod=998244353;
struct point{
	int x,y;
}a[N];
int n,i,j,k,inv;
__int128 ans;
point operator - (point a,point b) {return (point){a.x-b.x,a.y-b.y};}
int operator * (point a,point b) {return abs(a.x*b.y-a.y*b.x);}
int read()
{
	char c=getchar();
	int w=0,f=1;
	while(c<'0'||c>'9'){
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0'){
		w=w*10+c-'0';
		c=getchar();
	}
	return w*f;
}
int poww(int a,int b)
{
	int ans=1,base=a;
	while(b){
		if(b&1) ans=ans*base%mod;
		base=base*base%mod;
		b>>=1;
	}
	return ans;
}
int cal()
{
	int ans=0;
	point pre=a[2]-a[1];
	for(int i=3;i<n;i++){
		point now=a[i]-a[1];
		ans=ans+now*pre;
		pre=now;
	}
	ans=ans+(a[n]-a[1])*pre;
	return ans;
}
void print(__int128 x)
{
	if(!x) return;
	print(x/10);
	putchar((char)(x%10+48));
}
signed main()
{
	n=read();
	for(i=1;i<=n;i++) a[i].x=read(),a[i].y=read();
	for(i=n+1;i<=2*n;i++) a[i]=a[i-n];
	int s=cal();
	for(i=1;i<=n;i++){
		point pre=a[i+1]-a[i];
		int ret=0;
		for(j=i+2;j<i+n-1;j++){
			point now=a[j]-a[i];
			ret+=pre*now;
			ans+=abs(s-2*ret);
			pre=now;
		}
	}
	print(ans%mod*poww(4,mod-2)%mod);
	puts("");
	return 0;
}
