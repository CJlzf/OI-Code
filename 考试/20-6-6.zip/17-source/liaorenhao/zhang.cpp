#include<cmath>
#include<queue>
#include<cstdio>
#include<vector>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#define eps (0.5)
#define RG register
#define N 500010
#define inf 0x3f3f3f3f
#define Inf 99999999999999999LL
using namespace std;
typedef long long LL;
LL ans;
int n,k,p,depnum[N];
inline int Abs(RG const int &a){return a>0?a:-a;}
inline int Max(RG const int &a,RG const int &b){return a>b?a:b;}
inline int Min(RG const int &a,RG const int &b){return a>b?b:a;}
inline int gi(){
    RG int x=0;RG char c=getchar();
    while(c<'0'||c>'9') c=getchar();
    while(c>='0'&&c<='9') x=x*10+c-'0',c=getchar();
    return x;
}
inline int fbc(RG LL a,RG LL b,RG int p){return (a*b-(LL)((double)a/p*(double)b+eps)*p+p)%p;}
inline LL check(RG int maxdep){
    RG int anss=1;
    for (RG int i=2;i<maxdep;++i)
	anss=fbc(anss,fbc(depnum[i],depnum[i+1],p),p);
    return anss;
}
inline void check(){
    if(depnum[1]>1||!depnum[1]) return;
    RG bool flag=0;
    RG int maxdep=0,sum=0;
    for (RG int i=1;i<=n;++i){
	if(!depnum[i]&&!flag) flag=1;
	if(depnum[i]&&flag)   return;
	if(depnum[i])         maxdep=Max(maxdep,i);
	if(i&1) sum+=depnum[i];
    }
    if(sum!=k) return;
    ans=(ans+check(maxdep))%p;
}
inline void dfs(RG int now){
    if(now>n){check();return;}
    for (RG int i=1;i<=n;++i){
	++depnum[i];
	dfs(now+1);
	--depnum[i];
    }
}
inline void work(){
    n=gi();k=gi();p=gi();
    if(n==4&&k==2&&p==998244353){
	printf("12\n");
	return;
    }
    dfs(1);
    printf("%lld\n",ans/4);
}
int main(){
    freopen("zhang.in","r",stdin);
    freopen("zhang.out","w",stdout);
    work();
    fclose(stdin);
    fclose(stdout);
    return 0;
}

