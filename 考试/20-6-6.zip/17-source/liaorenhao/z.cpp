#include<cmath>
#include<queue>
#include<cstdio>
#include<vector>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#define N 310
#define RG register
#define inf 0x3f3f3f3f
#define Inf 99999999999999999LL
using namespace std;
typedef long long LL;
bool flag;
bool use[N],vis[N];
vector<int> inc[N];
int n,t,ans,sum,p[N];
inline int Abs(RG const int &a){return a>0?a:-a;}
inline int Max(RG const int &a,RG const int &b){return a>b?a:b;}
inline int Min(RG const int &a,RG const int &b){return a>b?b:a;}
inline int gi(){
    RG int x=0;RG bool flag=0;RG char c=getchar();
    while((c<'0'||c>'9')&&c!='-') c=getchar();
    if(c=='-') c=getchar(),flag=1;
    while(c>='0'&&c<='9') x=x*10+c-'0',c=getchar();
    return flag?-x:x;
}
inline void check(){
    memset(vis,0,sizeof(vis));
    RG int siz1=0,siz2=0,summ=0;
    for (RG int i=1;i<=n;++i)
	if(use[i]){
	    ++siz1;summ+=p[i];
	    for (RG int j=0;j<(int)inc[i].size();++j)
	        if(!vis[inc[i][j]]){
		    vis[inc[i][j]]=1;
		    ++siz2;
		}
	}	
    if(siz1!=siz2) return;
    ans=Min(ans,summ);
}
inline void dfs(RG int dep){
    if(dep>n){check();return;}
    use[dep]=1;
    dfs(dep+1);
    use[dep]=0;
    dfs(dep+1);
}
inline void work(){
    n=gi();
    for (RG int i=1;i<=n;++i){
	t=gi();
	while(t--)
	    inc[i].push_back(gi());
    }
    for (RG int i=1;i<=n;++i){
	p[i]=gi();sum+=p[i];
	if(p[i]>0) flag=1;
    }
    if(!flag) printf("%d\n",sum);
    dfs(1);
    printf("%d\n",ans);
}
int main(){
    freopen("z.in","r",stdin);
    freopen("z.out","w",stdout);
    work();
    fclose(stdin);
    fclose(stdout);
    return 0;
}

