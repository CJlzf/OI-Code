#include<cstdio>
#include<vector>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#define M 100010
#define N 100010
#define RG register
#define lx (tree[x].ls)
#define rx (tree[x].rs)
#define ly (tree[y].ls)
#define ry (tree[y].rs)
using namespace std;
struct node{
    int w,ls,rs;
}tree[140*N];
vector<int> to[N];
int m,n,cnt,len,maxd,ed[N],fa[N],st[N],dfn[N],dis[N],siz[N],son[N],top[N],quan[N],root[N],lazy[140*N];
inline int Max(RG const int &a,RG const int &b){return a>b?a:b;}
inline int gi(){
    RG int x=0;RG bool flag=0;RG char c=getchar();
    while((c<'0'||c>'9')&&c!='-') c=getchar();
    if(c=='-') c=getchar(),flag=1;
    while(c>='0'&&c<='9') x=x*10+c-'0',c=getchar();
    return flag?-x:x;
}
inline void dfs1(RG int now){
    siz[now]=1;
    RG int loc=0,bigg=0;
    for (RG int i=0;i<(int)to[now].size();++i)
	if(to[now][i]!=fa[now]){
	    dfs1(to[now][i]);
	    siz[now]+=siz[to[now][i]];
	    if(siz[to[now][i]]>bigg){
		loc=to[now][i];
		bigg=siz[to[now][i]];
	    }
	}
    son[now]=loc;
}
inline void dfs2(RG int now){
    maxd=Max(maxd,dis[dfn[now]]);
    if(son[now]){
	top[son[now]]=top[now];
	dfn[son[now]]=st[son[now]]=ed[son[now]]=++cnt;
	dis[dfn[son[now]]]=quan[son[now]]+dis[dfn[now]];
	dfs2(son[now]);
	ed[now]=ed[son[now]];
    }
    for (RG int i=0;i<(int)to[now].size();++i)
	if(to[now][i]!=son[now]&&to[now][i]!=fa[now]){
	    top[to[now][i]]=to[now][i];
	    dfn[to[now][i]]=st[to[now][i]]=ed[to[now][i]]=++cnt;
	    dis[dfn[to[now][i]]]=quan[to[now][i]]+dis[dfn[now]];
	    dfs2(to[now][i]);
	    ed[now]=ed[to[now][i]];
	}
}
inline void ins(RG int &x,RG int l,RG int r,RG int w){
    tree[++cnt]=tree[x];x=cnt;
    if(l==r){++tree[x].w;return;}
    RG int mid=(l+r)>>1;
    if(w<=mid) ins(lx,l,mid,w);
    else       ins(rx,mid+1,r,w);
    tree[x].w=tree[lx].w+tree[rx].w;
}
inline int query(RG int x,RG int y,RG int l,RG int r,RG int k){
    //cout<<"x="<<x<<' '<<"y="<<y<<' '<<"l="<<l<<' '<<"r="<<r<<' '<<"k="<<k<<' '<<tree[x].w<<' '<<tree[y].w<<endl; 
    if(l==r) return l;
    RG int mid=(l+r)>>1;
    if(tree[y].w-tree[x].w>k) return query(lx,ly,l,mid,k);
    else                      return query(rx,ry,mid+1,r,k);
}
inline void work(){
    n=gi();m=gi();len=gi();
    for (RG int i=2;i<=n;++i){
	fa[i]=gi();
	quan[i]=gi();
	to[fa[i]].push_back(i);	
    }
    top[1]=1;dfn[1]=++cnt;
    dfs1(1);dfs2(1);
    RG int opt,x,k;
    for (RG int i=1;i<=m;++i){
	opt=gi();x=gi();k=gi();
	//cout<<opt<<' '<<x<<' '<<k<<endl;
	if(opt==1){
	    if(siz[x]<k){
		printf("-1\n");
		continue;
	    }
	    cnt=0;
	    memset(tree,0,sizeof(tree));
	    for (RG int i=1;i<=n;++i){
		root[i]=root[i-1];
		ins(root[i],1,maxd,dis[i]);
	    }
	    printf("%d\n",query(root[st[x]-1],root[ed[x]],1,maxd,k));
	}
	else
	    for (RG int i=st[x];i<=ed[x];++i){
		dis[i]+=k;
		maxd=Max(maxd,dis[i]);
	    }
    }
}
int main(){
    freopen("j.in","r",stdin);
    freopen("j.out","w",stdout);
    work();
    fclose(stdin);
    fclose(stdout);
    return 0;
}

