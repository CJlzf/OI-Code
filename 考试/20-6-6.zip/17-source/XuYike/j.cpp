// <j.cpp> - Mon Apr  3 07:34:33 2017
// This file is created by XuYike's black technology automatically.
// Copyright (C) 2015 ChangJun High School, Inc.
// I don't know what this program is.

#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;
typedef long long lol;
template<typename T>
inline void gg(T &res){
    res=0;T fh=1;char ch=getchar();
    while((ch>'9'||ch<'0')&&ch!='-')ch=getchar();
    if(ch=='-')fh=-1,ch=getchar();
    while(ch>='0'&&ch<='9')res=res*10+ch-'0',ch=getchar();
    res*=fh;
}
inline int gi(){int x;gg(x);return x;}
inline lol gl(){lol x;gg(x);return x;}
const int MAXN=100010;
const int INF=1e9;
const int B=346;
const int MAXC=400;
int bt,b[MAXN],next[MAXN],to[MAXN],val[MAXN];
inline void add(int x,int y,int z){next[++bt]=b[x];b[x]=bt;to[bt]=y;val[bt]=z;}
int dt,dfn[MAXN],end[MAXN],dis[MAXN];
void dfs(int x){
    dfn[x]=++dt;
    for(int i=b[x];i;i=next[i]){
        dis[to[i]]=dis[x]+val[i];
        dfs(to[i]);
    }
    end[x]=dt;
}
int v[MAXN],a[MAXC][B+10],tag[MAXC];
void rebuild(int x){
    int s=B*(x-1);
    for(int i=1;i<=B;i++)a[x][i]=v[s+i];
    sort(a[x]+1,a[x]+B+1);
}
int q[MAXN],id[MAXN];
inline int get(int p,int x){
    x-=tag[p];
    if(a[p][1]>x)return 0;
    if(a[p][B]<=x)return B;
    return upper_bound(a[p]+1,a[p]+B+1,x)-a[p]-1;
}
int query(int L,int R,int k){
    if(R-L+1<k)return -1;
    int LB=id[L],RB=id[R];
    if(LB==RB){
        int qt=0;
        for(int i=L;i<=R;i++)q[++qt]=v[i]+tag[LB];
        sort(q+1,q+qt+1);
        return q[k];
    }
    int l=0,r=2000000;
    while(l<r){
        int m=l+r>>1,cnt=0;
        for(int i=L;id[i]==LB&&cnt<k;i++)cnt+=(v[i]+tag[LB])<=m;
        for(int i=R;id[i]==RB&&cnt<k;i--)cnt+=(v[i]+tag[RB])<=m;
        for(int i=LB+1;i<RB&&cnt<k;i++)cnt+=get(i,m);
        if(cnt<k)l=m+1;
        else r=m;
    }
    return l;
}
void mod(int L,int R,int k){
    int LB=id[L],RB=id[R];
    if(LB==RB){
        for(int i=L;i<=R;i++)v[i]+=k;
        return rebuild(LB);
    }
    for(int i=L;id[i]==LB;i++)v[i]+=k;
    for(int i=R;id[i]==RB;i--)v[i]+=k;
    rebuild(LB);rebuild(RB);
    for(int i=LB+1;i<RB;i++)tag[i]+=k;
}
int main(){
    freopen("j.in","r",stdin);
    freopen("j.out","w",stdout);
    int n=gi(),m=gi(),len=gi();
    for(int i=2;i<=n;i++){int f=gi();add(f,i,gi());}
    dfs(1);
    int C=(n-1)/B+1;
    for(int i=1;i<=n;i++)id[i]=(i-1)/B+1;
    for(int i=1;i<=n;i++)v[dfn[i]]=dis[i];
    for(int i=n+1;i<=C*B;i++)v[i]=INF;
    for(int i=1;i<=C;i++)rebuild(i);
    while(m--){
        int op=gi(),x=gi(),k=gi();
        if(op==1)printf("%d\n",query(dfn[x],end[x],k));
        else mod(dfn[x],end[x],k);
    }
    return 0;
}
