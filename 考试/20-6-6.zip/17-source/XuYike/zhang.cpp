// <zhang.cpp> - Mon Apr  3 07:34:33 2017
// This file is created by XuYike's black technology automatically.
// Copyright (C) 2015 ChangJun High School, Inc.
// I don't know what this program is.

#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;
typedef long long lol;
template<typename T>
inline void gg(T &res){
    res=0;T fh=1;char ch=getchar();
    while((ch>'9'||ch<'0')&&ch!='-')ch=getchar();
    if(ch=='-')fh=-1,ch=getchar();
    while(ch>='0'&&ch<='9')res=res*10+ch-'0',ch=getchar();
    res*=fh;
}
inline int gi(){int x;gg(x);return x;}
inline lol gl(){lol x;gg(x);return x;}
const int MAXN=500010;
const int INF=1e9;
int MOD;
int qpow(int x,int y){
    int res=1;
    while(y){
        if(y&1)res=1ll*res*x%MOD;
        x=1ll*x*x%MOD;
        y>>=1;
    }
    return res;
}
int jc[MAXN],nj[MAXN];
inline int C(int n,int m){return 1ll*jc[n]*nj[m]%MOD*nj[n-m]%MOD;}
int main(){
    freopen("zhang.in","r",stdin);
    freopen("zhang.out","w",stdout);
    int n=gi(),k=gi();MOD=gi();
    jc[0]=1;for(int i=1;i<=n;i++)jc[i]=1ll*jc[i-1]*i%MOD;
    nj[n]=qpow(jc[n],MOD-2);for(int i=n;i;i--)nj[i-1]=1ll*nj[i]*i%MOD;
    printf("%d\n",1ll*C(n-1,k-1)*qpow(k,n-1-k)%MOD*qpow(n-k,k-1)%MOD);
    return 0;
}
