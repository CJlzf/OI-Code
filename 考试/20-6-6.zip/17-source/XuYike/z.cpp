// <z.cpp> - Mon Apr  3 07:34:33 2017
// This file is created by XuYike's black technology automatically.
// Copyright (C) 2015 ChangJun High School, Inc.
// I don't know what this program is.

#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;
typedef long long lol;
template<typename T>
inline void gg(T &res){
    res=0;T fh=1;char ch=getchar();
    while((ch>'9'||ch<'0')&&ch!='-')ch=getchar();
    if(ch=='-')fh=-1,ch=getchar();
    while(ch>='0'&&ch<='9')res=res*10+ch-'0',ch=getchar();
    res*=fh;
}
inline int gi(){int x;gg(x);return x;}
inline lol gl(){lol x;gg(x);return x;}
const int MAXN=310;
const int INF=1e9;
vector <int> v[MAXN];
int p[MAXN],vis[MAXN];
int main(){
    freopen("z.in","r",stdin);
    freopen("z.out","w",stdout);
    int n=gi();
    for(int i=1;i<=n;i++){
        int t=gi();
        while(t--)v[i].push_back(gi());
    }
    for(int i=1;i<=n;i++)p[i]=gi();
    if(n>20){
        lol ans=0;
        for(int i=1;i<=n;i++)ans+=p[i];
        printf("%lld\n",ans);
        return 0;
    }
    lol ans=0;
    for(int s=(1<<n)-1;s;s--){
        lol res=0;int cnt=0;
        for(int i=1;i<=n;i++)
            if(s>>(i-1)&1){
                res+=p[i];
                cnt++;
                for(int j=0;j<v[i].size();j++)vis[v[i][j]]=s;
            }
        for(int i=1;i<=n;i++)if(vis[i]==s)cnt--;
        if(!cnt)ans=min(ans,res);
    }
    printf("%lld",ans);
    return 0;
}
