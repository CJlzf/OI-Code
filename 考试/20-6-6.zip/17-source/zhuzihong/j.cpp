#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std ;
const int N = 100010 ;
struct node{
	int v , next ;
}map[N] ;
int head[N] , w[N] , fa[N] , size[N] , a[N] ;
int tot , n ;
int getint()
{
	int res = 0 , w = 1 ;
	char ch = getchar() ;
	while ( ( ch < '0' || ch > '9' ) && ch != '-' ) ch = getchar() ;
	if ( ch == '-' ) w = -1 , ch = getchar() ;
	while ( ch >= '0' && ch <= '9' ) res = res * 10 + ch - '0' , ch = getchar() ;
	return res * w ;
}
inline void link ( int u , int v ) { map[++tot].v = v , map[tot].next = head[u] , head[u] = tot ; }
void dfs ( int nt )
{
	size[nt] = 1 ;
	for ( int p = head[nt] ; p ; p = map[p].next )
	{
		int x = map[p].v ;
		w[x] += w[nt] ;
		dfs (x) ;
		size[nt] += x ;
	}
}
void DFS ( int nt , int v )
{
	w[nt] += v ; a[++a[0]] = w[nt] ;
	for ( int p = head[nt] ; p ; p = map[p].next )
	{
		int x = map[p].v ;
		DFS(x , v) ; 
	}
}
int main()
{
	freopen ( "j.in" , "r" , stdin ) ;
	freopen ( "j.out" , "w" , stdout ) ;
	n = getint() ; int m = getint() , len = getint() ;
	for ( int i = 2 ; i <= n ; ++ i )
	{
		fa[i] = getint() , w[i] = getint() ;
		link ( fa[i] , i ) ;
	}
	dfs ( 1 ) ;
	int t , x , k ;
	while ( m -- )
	{
		t = getint() , x = getint() , k = getint() ;
		if ( t == 1 ) {
			if ( size[x] < k ) {
				printf ( "-1\n" ) ; continue ;
			}
			a[0] = 0 ; DFS( x , 0 ) ;
			sort ( a + 1 , a + a[0] + 1 ) ;
			printf ( "%d\n" , a[k] ) ;
		}else {
			a[0] = 0 ; DFS( x , k ) ;
		}
	}
	fclose(stdin) ; fclose(stdout) ;
	return 0 ;
}
