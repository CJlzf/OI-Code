#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std ;
int main()
{
	freopen ( "zhang.in" , "r" , stdin ) ;
	freopen ( "zhang.out" , "w" , stdout ) ;
	printf ( "12") ;
	fclose(stdin) ; fclose(stdout) ;
	return 0 ;
}
