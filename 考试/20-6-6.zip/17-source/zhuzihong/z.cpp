#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cmath>
using namespace std ;
const int N = 310 ;
int getint()
{
	int res = 0 , w = 1 ;
	char ch = getchar() ;
	while ( ( ch < '0' || ch > '9' ) && ch != '-' ) ch = getchar() ;
	if ( ch == '-' ) w = -1 , ch = getchar() ;
	while ( ch >= '0' && ch <= '9' ) res = res * 10 + ch - '0' , ch = getchar() ;
	return res * w ;
}
int n , a[N] , f[N][N] , w[N] , ans , vis[N] , s[N] ;
int tim ;
void get_ans( int l )
{
	int v = 0 ;
	tim ++ ;
	for ( int i = 1 ; i <= l ; ++ i )
		for ( int j = 1 ; j <= f[a[i]][0] ; ++ j )
		{
			if ( vis[f[a[i]][j]] != tim )
				vis[f[a[i]][j]] = tim , v ++ ;
			if ( v > l ) return ;
		}
	if ( v != l ) return ;
	v = 0 ;
	for ( int i = 1 ; i <= l ; ++ i ) v += w[a[i]] ;
	ans = min( ans , v ) ;
}
void dfs ( int now , int tot )
{
	if ( now > n ) return ;
	a[tot] = now ;
	get_ans(tot) ;
	dfs ( now + 1 , tot + 1 ) ;
	dfs ( now + 1 , tot ) ;
}
int main()
{
	freopen ( "z.in" , "r" , stdin ) ;
	freopen ( "z.out" , "w" , stdout ) ;
	n = getint() ;
	for ( int i = 1 ; i <= n ; ++ i ){
		f[i][0] = getint() ;
		for ( int j = 1 ; j <= f[i][0] ; ++ j ) f[i][j] = getint() ; 
	}
	for ( int i = 1 ; i <= n ; ++ i ) {
		w[i] = getint() ;
		if ( w[i] < 0 ) s[i] += w[i] ;
		s[i] += s[i - 1] ;
	}
	if ( n <= 20 )
		dfs(1 , 1) ;
	else {
		for ( int i = 1 ; i <= n ; ++ i ) ans += w[i] ;
		ans = min ( ans , 0 ) ;
	}
	printf ( "%d" , ans ) ;
	return 0 ;
}
