//It is made by wfj_2048~
#include <algorithm>
#include <iostream>
#include <complex>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <set>
#define inf (1<<30)
#define il inline
#define RG register
#define ll long long
#define File(s) freopen(s".in","r",stdin),freopen(s".out","w",stdout)

using namespace std;

int a[310][310],t[310],r[310],p[310],st[310],vis[310],n,ans,tot;

il int gi(){
    RG int x=0,q=1; RG char ch=getchar();
    while ((ch<'0' || ch>'9') && ch!='-') ch=getchar();
    if (ch=='-') q=-1,ch=getchar();
    while (ch>='0' && ch<='9') x=x*10+ch-48,ch=getchar();
    return q*x;
}

il int check(){
    RG int res=0;
    for (RG int i=1;i<=tot;++i){
	RG int x=st[i];
	for (RG int j=1;j<=t[x];++j) vis[a[x][j]]=1;
    }
    for (RG int i=1;i<=n;++i){ if (vis[i]) res++; vis[i]=0; }
    return res==tot;
}

il void dfs(RG int x,RG int res){
    if (x>n){
	if (check()) ans=min(ans,res);
	return;
    }
    dfs(x+1,res);
    if (res+r[x]<ans){
	st[++tot]=x;
	dfs(x+1,res+p[x]); tot--;
    }
    return;
}

il void work(){
    n=gi(),ans=inf;
    for (RG int i=1;i<=n;++i){
	t[i]=gi();
	for (RG int j=1;j<=t[i];++j) a[i][j]=gi();
    }
    for (RG int i=1;i<=n;++i) p[i]=gi();
    for (RG int i=n;i;--i) r[i]=r[i+1]+(p[i]<0)*p[i];
    dfs(1,0); printf("%d\n",ans); return;
}

int main(){
    File("z");
    work();
    return 0;
}
