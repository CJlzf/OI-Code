//It is made by wfj_2048~
#include <algorithm>
#include <iostream>
#include <complex>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <set>
#define inf (1<<30)
#define il inline
#define RG register
#define ll long long
#define File(s) freopen(s".in","r",stdin),freopen(s".out","w",stdout)

using namespace std;

int n,k,p;

il int gi(){
    RG int x=0,q=1; RG char ch=getchar();
    while ((ch<'0' || ch>'9') && ch!='-') ch=getchar();
    if (ch=='-') q=-1,ch=getchar();
    while (ch>='0' && ch<='9') x=x*10+ch-48,ch=getchar(); return q*x;
}

il void work(){
    n=gi(),k=gi(),p=gi();
    if (n==4) puts("12"); else printf("%d\n",p-1);
}

int main(){
    File("zhang");
    work();
    return 0;
}
