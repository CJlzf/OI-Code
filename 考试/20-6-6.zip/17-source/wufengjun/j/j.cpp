//It is made by wfj_2048~
#include <algorithm>
#include <iostream>
#include <complex>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <set>
#define inf (1<<30)
#define N (100010)
#define il inline
#define RG register
#define ll long long
#define max(a,b) (a>b ? a : b)
#define File(s) freopen(s".in","r",stdin),freopen(s".out","w",stdout)

using namespace std;

struct edge{ int nt,to,dis; }g[N];
struct data{ int i,v; }a[N];

int head[N],fa[N],dis[N],dfn[N],ed[N],n,m,rt,cnt,num,len;
int bl[N],LL[N],RR[N],c[N],totb,block;

il int gi(){
    RG int x=0,q=1; RG char ch=getchar();
    while ((ch<'0' || ch>'9') && ch!='-') ch=getchar();
    if (ch=='-') q=-1,ch=getchar();
    while (ch>='0' && ch<='9') x=x*10+ch-48,ch=getchar();
    return q*x;
}

il int cmp(const data &a,const data &b){ return a.v<b.v; }

il void insert(RG int &from,RG int &to,RG int &dis){
    g[++num]=(edge){head[from],to,dis},head[from]=num; return;
}

il void dfs(RG int &x,RG int &p){
    dfn[x]=++cnt; RG int v;
    for (RG int i=head[x];i;i=g[i].nt){
	v=g[i].to; if (v==p) continue;
	dis[v]=dis[x]+g[i].dis; dfs(v,x);
    }
    ed[x]=cnt; return;
}

il int check(RG int &key,RG int &l,RG int &r,RG int &k){
    RG int res=0;
    if (bl[l]==bl[r]){
	RG int b=bl[l];
	for (RG int i=LL[b];i<=RR[b];++i)
	    if (a[i].i>=l && a[i].i<=r && a[i].v+c[b]<key) res++;
    } else{
	for (RG int i=bl[l]+1;i<=bl[r]-1;++i){
	    RG int L=LL[i],R=RR[i],mid,ans=LL[i]-1;
	    while (L<=R){
		mid=(L+R)>>1;
		if (a[mid].v+c[i]<key) ans=mid,L=mid+1;
		else R=mid-1;
	    }
	    res+=ans-LL[i]+1;
	}
	RG int b=bl[l];
	for (RG int i=LL[b];i<=RR[b];++i)
	    if (a[i].i>=l && a[i].i<=r && a[i].v+c[b]<key) res++;
	b=bl[r];
	for (RG int i=LL[b];i<=RR[b];++i)
	    if (a[i].i>=l && a[i].i<=r && a[i].v+c[b]<key) res++;
    }
    return res<k;
}

il void work(){
    n=gi(),m=gi(),len=gi(),block=sqrt(n),totb=(n-1)/block+1;
    for (RG int i=2,d;i<=n;++i) fa[i]=gi(),d=gi(),insert(fa[i],i,d);
    dfs(rt=1,fa[1]);
    for (RG int i=1;i<=n;++i){
	a[dfn[i]]=(data){dfn[i],dis[i]},bl[i]=(i-1)/block+1;
	if (!LL[bl[i]]) LL[bl[i]]=i; RR[bl[i]]=i;
    }
    for (RG int i=1;i<=totb;++i) sort(a+LL[i],a+RR[i]+1,cmp);
    while (m--){
	RG int opt=gi(),x=gi(),k=gi();
	RG int l=dfn[x],r=ed[x];
	if (opt==1){
	    if (k>r-l+1){ puts("-1"); continue; }
	    RG int L=0,R=0,mid,ans;
	    for (RG int i=bl[l];i<=bl[r];++i) R=max(R,a[RR[i]].v+c[i]);
	    while (L<=R){
		mid=(L+R)>>1;
		if (check(mid,l,r,k)) ans=mid,L=mid+1;
		else R=mid-1;
	    }
	    printf("%d\n",ans);
	} else{
	    if (bl[l]==bl[r]){
		RG int b=bl[l];
		for (RG int i=LL[b];i<=RR[b];++i)
		    if (a[i].i>=l && a[i].i<=r) a[i].v+=k+c[b]; else a[i].v+=c[b];
		sort(a+LL[b],a+RR[b]+1,cmp); c[b]=0;
	    } else{
		for (RG int i=bl[l]+1;i<=bl[r]-1;++i) c[i]+=k; RG int b=bl[l];
		for (RG int i=LL[b];i<=RR[b];++i)
		    if (a[i].i>=l && a[i].i<=r) a[i].v+=k+c[b]; else a[i].v+=c[b];
		sort(a+LL[b],a+RR[b]+1,cmp); c[b]=0; b=bl[r];
		for (RG int i=LL[b];i<=RR[b];++i)
		    if (a[i].i>=l && a[i].i<=r) a[i].v+=k+c[b]; else a[i].v+=c[b];
		sort(a+LL[b],a+RR[b]+1,cmp); c[b]=0;
	    }
	}
    }
    return;
}

int main(){
    File("j");
    work();
    return 0;
}
