#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#define File(s) freopen(s".in","r",stdin),freopen(s".out","w",stdout)

using namespace std;
typedef long long llg;

int n,k,p;

int main(){
	File("zhang");
	srand(time(NULL));
	scanf("%d %d %d",&n,&k,&p);
	if(n==4 && k==2) printf("12");
	else printf("%d",rand()%p);
	return 0;
}
