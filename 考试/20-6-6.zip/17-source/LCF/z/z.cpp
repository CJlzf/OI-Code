#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<bitset>
#define File(s) freopen(s".in","r",stdin),freopen(s".out","w",stdout)
#define maxn 110

using namespace std;
typedef long long llg;

int n,v[maxn];

int getint(){
	int w=0;bool q=0;
	char c=getchar();
	while((c>'9'||c<'0')&&c!='-') c=getchar();
	if(c=='-') q=1,c=getchar();
	while(c>='0' && c<='9') w=w*10+c-'0',c=getchar();
	return q?-w:w;
}

namespace A{
	int a[maxn],fr[1<<20],op,ci,ans;
	void dfs(int u,int now){
		if(u==n+1){
			if(fr[now]==ci) ans=min(ans,op);
			return;
		}
		ci++; op+=v[u]; dfs(u+1,now|a[u]);
		ci--; op-=v[u]; dfs(u+1,now);
	}
	void main(){
		for(int i=1;i<=n;i++){
			int x=getint();
			while(x--) a[i]|=1<<(getint()-1);
		}
		for(int i=1;i<=n;i++) v[i]=getint();
		for(int i=1;i<(1<<n);i++) fr[i]=fr[i>>1]+(i&1);
		dfs(1,0); printf("%d",ans);
	}
}

namespace B{
	int ans;
	struct data{
		bitset<maxn> a;int v;
		bool operator < (const data &h)const{return v<h.v;}
	}s[maxn];
	bool del[maxn]; int ci;
	bool pd(){
		bitset<maxn> q; q.reset();
		for(int i=1;i<=n;i++)
			if(!del[i]) q|=s[i].a;
		return (int)(q.count())==ci;
	}
	void main(){
		for(int i=1;i<=n;i++){
			int x=getint();
			while(x--) s[i].a[getint()]=1;
		}
		for(int i=1;i<=n;i++) ans+=s[i].v=getint();
		sort(s+1,s+n+1); ci=n;
		for(int i=n;i>=1;i--){
			if(s[i].v<=0) break;
			del[i]=1; ci--;
			if(pd()) ans-=s[i].v;
			else del[i]=0,ci++;
		}
		printf("%d",ans);
	}
}

int main(){
	File("z");
	srand(time(NULL));
	n=getint();
	if(n<=20) A::main();
	else B::main();
	return 0;
}
