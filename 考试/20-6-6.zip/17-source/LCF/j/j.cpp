#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#define File(s) freopen(s".in","r",stdin),freopen(s".out","w",stdout)
#define maxn 100010

using namespace std;
typedef long long llg;

int n,m,len,fa[maxn],c[maxn];
int le[maxn],ri[maxn],a[maxn];
int hd[maxn],nt[maxn],tt,lc,op[maxn];

int getint(){
	int w=0;bool q=0;
	char c=getchar();
	while((c>'9'||c<'0')&&c!='-') c=getchar();
	if(c=='-') q=1,c=getchar();
	while(c>='0' && c<='9') w=w*10+c-'0',c=getchar();
	return q?-w:w;
}

void dfs(int u){
	a[le[u]=++tt]=c[u];
	for(int i=hd[u];i;i=nt[i]) c[i]+=c[u],dfs(i);
	ri[u]=tt;
}

int main(){
	File("j");
	n=getint(),m=getint(); getint();
	for(int i=2;i<=n;i++){
		fa[i]=getint(); c[i]=getint();
		nt[i]=hd[fa[i]]; hd[fa[i]]=i;
	}
	dfs(1);
	while(m--){
		int ty=getint();
		int x=getint(),k=getint();
		if(ty==1){
			if(ri[x]-le[x]+1<k) printf("-1\n");
			else{
				lc=0;
				for(int i=le[x];i<=ri[x];i++) c[++lc]=a[i];
				nth_element(c+1,c+k,c+lc+1);
				printf("%d\n",c[k]);
			}
		}
		else if(k) for(int i=le[x];i<=ri[x];i++) a[i]+=k;
	}
	return 0;
}
