#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <ctime>
using namespace std;

int main()
{
	 freopen("j.in","w",stdout);
	 srand(time(NULL));
	 int n=30000,m=30000,le=10;
	 printf("%d %d %d\n",n,m,le);
	 for(int i=2;i<=n;i++){
		 printf("%d %d\n",rand()%(i-1)+1,rand()%le+1);
	 }
	 for(int i=1;i<=m;i++){
		 //if(i&1) printf("1 1 %d\n",rand()%n+1);
		 // else printf("2 1 %d\n",rand()%le+1);
		 printf("1 1 %d\n",rand()%n+1);
	 }
	 return 0;
}
