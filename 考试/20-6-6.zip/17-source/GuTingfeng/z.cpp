/*
  Program: z
  Copyright by G10
  One More SSR!
*/
#include <bits/stdc++.h>
using namespace std;
#define File(S) freopen(S".in","r",stdin);freopen(S".out","w",stdout)
#define RG register
typedef unsigned int UL;
typedef long long LL;
typedef unsigned long long ULL;

inline LL getint()
{
    RG LL res=0,p=1;RG char ch=getchar();
    while (ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
    if (ch=='-') p=-1,ch=getchar();
    while (ch>='0'&&ch<='9') res=res*10+ch-'0',ch=getchar();
    return res*p;
}

const int INF=0x3f3f3f3f;
const int N=305,M=200050;
int n,p[N],a[N],d[N],f[N],ans,sum,cho;
int E[M],nx[M],h[N],tot;
int match[N],vis[N];

inline int cntone(int S){RG int res=0;while(S){res+=(S&1);S>>=1;}return res;}
void dfs(int x,int S)
{
    if (x>n) {if (cntone(S)==cho) ans=min(ans,sum);return;}
    cho++;sum+=p[x];dfs(x+1,S|a[x]);
    cho--;sum-=p[x];dfs(x+1,S);
}
inline void link(int u,int v){E[++tot]=v;nx[tot]=h[u];h[u]=tot;}
int findf(RG int x){return x==f[x]?x:f[x]=findf(f[x]);}

bool DFS(int x)
{
    int i,v;
    for (i=h[x];i;i=nx[i]) {
	v=E[i];if (vis[v]) continue;vis[v]=1;
	if (!match[v]||DFS(match[v])) {match[v]=x;return 1;}
    }
    return 0;
}

int main()
{
    File("z");
    n=getint();int i,j,k,v,fa,fb;
    if (n<=20) {
	for (i=1;i<=n;i++) {k=getint();for (j=1;j<=k;j++) a[i]|=1<<(getint()-1);}
	for (i=1;i<=n;i++) p[i]=getint();sum=ans=0;dfs(1,0);printf("%d\n",ans);return 0;
    }
    for (i=1;i<=n;i++) {k=getint();for (j=1;j<=k;j++) v=getint(),link(i,v);}
    for (ans=v=0,i=1;i<=n;i++) {a[i]=p[i]=getint();f[i]=i;if (p[i]<=0) ans+=p[i];else v=1;}
    if (!v) {printf("%d\n",ans);return 0;}
    for (i=1;i<=n;i++) memset(vis,0,sizeof(vis)),DFS(i);
    for (i=1;i<=n;i++) {
	for (j=h[i];j;j=nx[j]) {
	    v=match[E[j]];fa=findf(i);fb=findf(v);if (d[fa]<d[fb]) swap(fa,fb);
	    if (fa!=fb) {
		f[fb]=fa;d[fa]+=(d[fa]==d[fb]);a[fa]+=a[fb];
	    }
	}
    }
    for (ans=0,i=1;i<=n;i++) {if (findf(i)==i && a[i]<0) ans+=a[i];}printf("%d\n",ans);
    return 0;
}
