/*
  Program: zhang
  Copyright by G10
  One More SSR!
*/
#include <bits/stdc++.h>
using namespace std;
#define File(S) freopen(S".in","r",stdin);freopen(S".out","w",stdout)
#define RG register
typedef unsigned int UL;
typedef long long LL;
typedef unsigned long long ULL;

inline LL getint()
{
    RG LL res=0,p=1;RG char ch=getchar();
    while (ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
    if (ch=='-') p=-1,ch=getchar();
    while (ch>='0'&&ch<='9') res=res*10+ch-'0',ch=getchar();
    return res*p;
}

const int INF=0x3f3f3f3f;
const int N=25;
LL MOD;
int n,K;
LL f[N][N][N][N];
LL ans,JC[N],INV[N];
inline LL qpow(LL a,LL b){RG LL s=1;while(b){if(b&1)s=s*a%MOD;a=a*a%MOD;b>>=1;}return s;}
inline LL C(LL n,LL k){return JC[n]*INV[k]%MOD*INV[n-k]%MOD;}

int main()
{
    File("zhang");
    n=getint();K=getint();MOD=getint();
    memset(f,0,sizeof(f));f[1][1][1][1]=1;int i,j,k,l,ul,lm;
    for (JC[0]=INV[0]=1,i=1;i<=n;i++) JC[i]=JC[i-1]*i%MOD,INV[i]=qpow(JC[i],MOD-2);
    for (i=2;i<=n;i++) 
	for (j=i;j<=n;j++) 
	    for (k=(i+1)/2;k<=K;k++) {
		lm=j-i+1;if (i&1) lm=min(lm,k-i/2);
		for (l=1;l<=lm;l++) {
		    for (ul=1;ul<=j-l-i+2;ul++)
			f[i][j][k][l]=(f[i][j][k][l]+f[i-1][j-l][k-l*(i&1)][ul]*C(n-j+l,l)%MOD*qpow(ul,l)%MOD)%MOD;
		}
	    }
    for (k=1;k<=n;k++) 
	for (l=1;l<=n;l++)
	    ans=(ans+f[k][n][K][l])%MOD;
    printf("%lld\n",ans);
    return 0;
}
