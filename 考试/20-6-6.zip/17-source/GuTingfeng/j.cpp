/*
  Program: j
  Copyright by G10
  One More SSR!
*/
#include <bits/stdc++.h>
using namespace std;
#define File(S) freopen(S".in","r",stdin);freopen(S".out","w",stdout)
#define RG register
typedef unsigned int UL;
typedef long long LL;
typedef unsigned long long ULL;

inline LL getint()
{
    RG LL res=0,p=1;RG char ch=getchar();
    while (ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
    if (ch=='-') p=-1,ch=getchar();
    while (ch>='0'&&ch<='9') res=res*10+ch-'0',ch=getchar();
    return res*p;
}

const int INF=0x3f3f3f3f;
const int N=100050;
int n,m,len;
int E[N],W[N],nx[N],h[N],tot;
int dfn[N],ed[N],q[N],d[N],num;
int a[N],al;
inline void link(int u,int v,int w){E[++tot]=v;W[tot]=w;nx[tot]=h[u];h[u]=tot;}
void dfs(int x)
{
    dfn[x]=++num,q[num]=x;RG int i,v;
    for (i=h[x];i;i=nx[i]) {v=E[i];d[v]=d[x]+W[i];dfs(v);}
    ed[x]=num;
}
    
int main()
{
    File("j");
    n=getint();m=getint();len=getint();RG int i,t,u,v;
    for (i=2;i<=n;i++) u=getint(),v=getint(),link(u,i,v);dfs(1);
    while (m--) {
	t=getint();
	if (t==2) {u=getint();v=getint();for (i=dfn[u];i<=ed[u];i++) d[q[i]]+=v;}
	else {
	    u=getint();v=getint();for (al=0,i=dfn[u];i<=ed[u];i++) a[++al]=d[q[i]];
	    if (v>al) printf("-1\n");else {nth_element(a+1,a+v,a+al+1);printf("%d\n",a[v]);}
	}
    }
    return 0;
}
