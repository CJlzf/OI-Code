#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#define LL long long
#define inf (1ll<<30)
#define free(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout)
using namespace std;

const int maxn=300;
int s[maxn],bin[30];
int n,p[maxn],ans;

int bitcount(int x) {
	return x ? (x&1)+bitcount(x>>1) : 0;
}
void dfs(int x,int st,int w,int c) {
	if (x==n+1) {
		if (w<ans && c==bitcount(st)) ans=w;
		return;
	}
	dfs(x+1,st|s[x],w+p[x],c+1);
	dfs(x+1,st,w,c);
}
int main() {
	free("z");
	bin[0]=1;for (int i=1;i<=20;i++) bin[i]=bin[i-1]<<1;
	scanf("%d",&n);
	if (n>20) {
		for (int x,t,i=1;i<=n;i++) {
			scanf("%d",&t);
			for (int j=1;j<=t;j++) scanf("%d",&x);
		}
		for (int i=1;i<=n;i++) scanf("%d",&p[i]),ans+=p[i];
		printf("%d",ans);
	}
	for (int x,t,i=1;i<=n;i++) {
		scanf("%d",&t);
		for (int j=1;j<=t;j++) scanf("%d",&x),s[i]|=bin[x-1];
	}
	for (int i=1;i<=n;i++) scanf("%d",&p[i]);
	dfs(1,0,0,0);
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
