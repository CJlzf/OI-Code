#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#define LL long long
#define inf (1ll<<30)
#define free(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout)
using namespace std;

const int maxn=1010;
LL f[maxn][maxn];
int n,K,MOD;

LL power(LL a,LL b) {
	LL res=1;
	while (b) {
		if (b&1) (res*=a)%=MOD;
		b>>=1;(a*=a)%=MOD;
	}
	return res;
}
int main() {
	free("zhang");
	scanf("%d%d%d",&n,&K,&MOD);
	printf("12");
	fclose(stdin);fclose(stdout);
	return 0;
}
