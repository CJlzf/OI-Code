#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<ctime>
#define LL long long
#define inf (1ll<<30)
#define free(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout)
using namespace std;

const int N=100000;
int fa[1000010],size[1000010];

int main() {
	freopen("j.in","w",stdout);
	srand(time(NULL));
	int n=rand()%N+1,m=rand()%N+1,len=rand()%10+1;
	n=N,m=N;
	printf("%d %d %d\n",n,m,len);
	for (int i=2;i<=n;i++) {
		fa[i]=rand()%(i-1)+1;
		printf("%d %d\n",fa[i],rand()%len+1);
	}
	for (int i=1;i<=n;i++) size[i]=1;
	for (int i=n;i>=2;i--) size[fa[i]]+=size[i];
	for (int i=1;i<=m;i++) {
		int op=rand()%2+1,x=rand()%n+1;
		if (op==1) {
			int k=rand()%5,y;
			y=k ? rand()%size[x]+1 : rand()%n+1;
			printf("%d %d %d\n",op,x,y);
		}
		if (op==2) printf("%d %d %d\n",op,x,rand()%len+1);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
