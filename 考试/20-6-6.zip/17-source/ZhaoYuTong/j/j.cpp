#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#define LL long long
#define inf (1ll<<30)
#define free(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout)
using namespace std;

const int maxn=100010;
int head[maxn],pos[maxn],in[maxn],out[maxn],a[maxn],tag[maxn],deep[maxn];
int n,m,bn,cnt,DFN,Tag,len,S,L[maxn],R[maxn],c[maxn];

struct edge {int to,next,w;}e[maxn<<1];

void link(int u,int v,int w) {
	e[++cnt]=(edge){v,head[u],w};head[u]=cnt;
}
void dfs(int x) {
	in[x]=++DFN;
	a[DFN]=deep[x];
	for (int i=head[x];i;i=e[i].next) {
		deep[e[i].to]=deep[x]+e[i].w;
		dfs(e[i].to);
	}
	out[x]=DFN;
}

int main() {
	free("j");
	scanf("%d%d%d",&n,&m,&len);
	for (int j,w,i=2;i<=n;i++) {
		scanf("%d%d",&j,&w);
		link(j,i,w);
	}
	S=(int)sqrt(n);bn=n/S+(n%S!=0);
	for (int i=1;i<=n;i++) pos[i]=(i-1)/S+1;
	for (int i=1;i<=bn;i++) L[i]=(i-1)*S+1,R[i]=i*S;
	dfs(1);
	for (int op,x,y,i=1;i<=m;i++) {
		scanf("%d%d%d",&op,&x,&y);
		if (op==1) {
			if (out[x]-in[x]+1<y) {puts("-1");continue;}
			int tot=0;
			for (int i=in[x];i<=out[x];i++) c[++tot]=a[i]+tag[pos[i]];
			sort(c+1,c+1+tot);
			printf("%d\n",c[y]+Tag);
		}
		if (op==2) {
			if (x==1) {Tag+=y;continue;}
			if (pos[in[x]]==pos[out[x]])
				for (int i=in[x];i<=out[x];i++) a[i]+=y;
			else {
				for (int i=in[x];i<=R[in[x]];i++) a[i]+=y;
				for (int i=L[pos[out[x]]];i<=out[x];i++) a[i]+=y;
				for (int i=pos[in[x]]+1;i<pos[out[x]];i++) tag[i]+=y;
			}
		}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
