#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#define LL long long
using namespace std;
inline int read( )
{
	int sum=0;char c=getchar( );bool f=0;
	while(c<'0'||c>'9') {if(c=='-') f=1;c=getchar( );}
	while(c>='0'&&c<='9') {sum=sum*10+c-'0';c=getchar( );}
	if(f) return -sum;
	return sum;
}
const int N=100005;
int n,m,LIM,tot;
struct ex{int num,next,w;}map[N];
int head[N],len;
inline void link(int x,int y,int w)
{
	len++;map[len].num=y;map[len].next=head[x];map[len].w=w;head[x]=len;
}
int w[N],sz[N];
inline void dfs(int k,int d)
{
	w[k]=d;
	for(int i=head[k];i;i=map[i].next)
		dfs(map[i].num,d+map[i].w),sz[k]+=sz[map[i].num];
	sz[k]++;
}
int v;
inline void in(int k)
{
	w[k]+=v;
	for(int i=head[k];i;i=map[i].next) in(map[i].num);
}
int g[N];
inline void an(int k)
{
	g[++tot]=w[k];
	for(int i=head[k];i;i=map[i].next) an(map[i].num);
}
int main( )
{
	freopen("j.in","r",stdin);
	freopen("bl.out","w",stdout);
	int i,j,tp,x,y;
	n=read( );m=read( );LIM=read( );
	for(i=2;i<=n;i++) x=read( ),y=read( ),link(x,i,y);
	dfs(1,0);
	for(i=1;i<=m;i++)
		{
			tp=read( );x=read( );y=read( );
			if(tp==2) v=y,in(x);
			else
				{
					if(sz[x]<y) {puts("-1");continue;}
					tot=0,an(x),sort(g+1,g+tot+1),printf("%d\n",g[y]);
				}
		}
	return 0;
}
