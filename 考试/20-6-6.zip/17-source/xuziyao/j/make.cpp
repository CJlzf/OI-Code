#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;
const int N=3000;
const int LIM=10;
int w[N+2];
int main() {
	freopen("j.in","w",stdout);
	srand(time(NULL));
	int i,x,y,u;
	printf("%d %d %d\n",N,N,LIM);
	for(i=2;i<=N;i++)
		{
			if(rand()%5) x=i-1;
			else x=rand()%(i-1)+1;
			printf("%d %d\n",x,w[i]=rand()%3+1);
		}
	for(i=1;i<=N;i++)
		{
			u=rand()%2+1;
			printf("%d ",u);
			if(u==1) printf("%d %d\n",rand()%N+1,rand()%10+1);
			else
				{
					x=rand()%N+1;
					u=rand()%3;
					while(w[x]+u>LIM) u=rand()%3;
					printf("%d %d\n",x,u);
					w[x]+=u;
				}
		}
	return 0;
}
