#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#define LL long long
using namespace std;
inline int read( )
{
	int sum=0;char c=getchar( );bool f=0;
	while(c<'0'||c>'9') {if(c=='-') f=1;c=getchar( );}
	while(c>='0'&&c<='9') {sum=sum*10+c-'0';c=getchar( );}
	if(f) return -sum;
	return sum;
}
const int N=100005;
const int S=60;
int n,m,LIM,tot;
struct ex{int num,next,w;}map[N];
int head[N],len;
inline void link(int x,int y,int w)
{
	len++;map[len].num=y;map[len].next=head[x];map[len].w=w;head[x]=len;
}
int in[N],out[N],w[N],sz[N],cnt;
inline void dfs(int k,int d)
{
	in[k]=++cnt;w[cnt]=d;
	for(int i=head[k];i;i=map[i].next)
		dfs(map[i].num,d+map[i].w),sz[k]+=sz[map[i].num];
	out[k]=cnt;sz[k]++;
}
const int M=S+5;
int bel[N],L[N],R[N],bh[N],g[N],ks,t1;
struct BLOCK
{
	int o[M],r[M],tot,tag;bool lazy;
	inline void reset( )
	{
		for(int i=1;i<=tot;i++) r[i]=o[i];
		sort(r+1,r+tot+1);
	}
	inline void INIT(int l,int r)
	{
		for(int i=l;i<=r;i++) o[++tot]=w[i],bh[i]=tot;
		reset( );
	}
	inline void add(int l,int r,int v)
	{
		for(int i=l;i<=r;i++) o[i]+=v;
		lazy=1;
	}
	inline void spec(int l,int r,int k)
	{
		int i,inc=0;
		for(i=l;i<=r;i++) g[++inc]=o[i];
		sort(g+1,g+inc+1);
		printf("%d\n",g[k]+t1+tag);
		//nth_element(g+1,g+inc+1,g+k+1);
		//printf("%d\n",g[k]+t1+tag);
	}
	inline int walk(int l,int r,int k)
	{
		int i,inc=0;
		for(i=l;i<=r;i++) if(o[i]+tag<=k) inc++;
		return inc;
	}
	inline int binary(int k)
	{
		if(lazy) lazy=0,reset( );
		int ll=1,rr=tot,mid;
		while(ll<=rr)
			{
				mid=(ll+rr)>>1;
				if(r[mid]+tag>k) rr=mid-1;
				else ll=mid+1;
			}
		return rr;
	}
}B[M];
int main( )
{
	freopen("j.in","r",stdin);
	freopen("sb.out","w",stdout);
	int i,j,x,y,k,t,l,r,a,b,ll,rr,mid;
	n=read( );m=read( );LIM=read( );
	for(i=2;i<=n;i++) x=read( ),y=read( ),link(x,i,y);
	dfs(1,0);
	for(k=1,t=0,i=1;i<=n;i++)
		{
			t++;if(t>S) t=1,k++;
			if(!L[k]) L[k]=i;R[k]=i;bel[i]=k;
		}
	for(ks=k,i=1;i<=ks;i++) B[i].INIT(L[i],R[i]);
	for(i=1;i<=m;i++)
		{
			t=read( );x=read( );y=read( );
			if(t==2)
				{
					if(!y) continue;
					if(x==1) {t1+=y;continue;}
					l=in[x];r=out[x];a=bel[l];b=bel[r];
					if(a==b) B[a].add(bh[l],bh[r],y);
					else
						{
							B[a].add(bh[l],B[a].tot,y);
							B[b].add(1,bh[r],y);
							for(j=a+1;j<b;j++) B[j].tag+=y;
						}
				}
			else
				{
					if(sz[x]<y) {puts("-1");continue;}
					l=in[x];r=out[x];a=bel[l];b=bel[r];
					if(a==b) B[a].spec(bh[l],bh[r],y);
					else
						{
							ll=0;rr=n*LIM;
							while(ll<=rr)
								{
									mid=(ll+rr)>>1;
									t=B[a].walk(bh[l],B[a].tot,mid);
									t+=B[b].walk(1,bh[r],mid);
									for(j=a+1;j<b;j++)
										{
											t+=B[j].binary(mid);
											if(t>=y) break;
										}
									if(t>=y) rr=mid-1;
									else ll=mid+1;
								}
							printf("%d\n",ll+t1);
						}
				}
		}
	return 0;
}
