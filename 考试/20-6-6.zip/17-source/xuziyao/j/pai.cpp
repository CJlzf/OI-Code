#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;



int main() {
	int t=0;
	while (++t) {
		printf("%d : ",t);
		system("./make");
		system("./sb");
		system("./bl");
		if (system("diff sb.out bl.out"))
			{printf("WA\n");  break;}
		else  printf("AC\n");
    }
	return 0;
}
