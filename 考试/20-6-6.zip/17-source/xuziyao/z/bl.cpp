#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<time.h>
#include<queue>
#define LL long long
using namespace std;
inline int read( )
{
	int sum=0;char c=getchar( );bool f=0;
	while(c<'0'||c>'9') {if(c=='-') f=1;c=getchar( );}
	while(c>='0'&&c<='9') {sum=sum*10+c-'0';c=getchar( );}
	if(f) return -sum;
	return sum;
}
const int N=1005;
int n,v[N];
struct ex{int num,next;}map[N*N];
int head[N],len;
inline void link(int x,int y)
{
	len++;map[len].num=y;map[len].next=head[x];head[x]=len;
}
namespace A
{
	int ans=0,vis[25],cnt;bool ch[25];
	inline void check( )
	{
		int i,j,x,a=0,b=0,c=0;
		for(i=1;i<=n;i++)
			if(ch[i]) a++,b+=v[i];
		if(b>=ans) return;
		cnt++;
		for(i=1;i<=n;i++)
			if(ch[i])
				for(j=head[i];j;j=map[j].next)
					{
						x=map[j].num;
						if(vis[x]!=cnt)
							{
								vis[x]=cnt;c++;
								if(c>a) return;
							}
					}
		if(c==a) ans=b;
	}
	inline void dfs(int k)
	{
		if(k==n+1) {check( );return;}
		ch[k]=1;dfs(k+1);
		ch[k]=0;dfs(k+1);
	}	
	inline void solve( )
	{
		dfs(1);
		printf("%d",ans);
	}
}
namespace B
{
	int ID[N],mh[N],vis[N],cnt;
	inline bool dfs(int k)
	{
		int i,x;
		for(i=head[k];i;i=map[i].next)
			{
				x=map[i].num;
				if(vis[x]==cnt) continue;
				vis[x]=cnt;
				if(!mh[x]||dfs(mh[x])) {mh[x]=k;return 1;}
			}
		return 0;
	}
	queue<int>q;
	bool rec[N];int f[N],ans;
	inline int find(int x) {if(f[x]==x) return x;f[x]=find(f[x]);return f[x];}
	inline void BFS(int S)
	{
		rec[S]=1;
		int i,x,y,a,b,u=0;
		q.push(S);
		while(!q.empty( ))
			{
				x=q.front( );q.pop( );u+=v[x];
				for(i=head[x];i;i=map[i].next)
					{
						y=mh[map[i].num];
						if(!rec[y])
							{
								rec[y]=1,q.push(y);
								a=find(y);b=find(S);f[a]=b;
							}
						else
							{
								a=find(x);b=find(y);
								f[a]=b;
							}
					}
			}
	}
	inline void solve( )
	{
		srand(time(NULL));
		int i,j;
		for(i=1;i<=n;i++) ID[i]=i;
		int T=30000,mn=0;
		while(T--)
			{
				random_shuffle(ID+1,ID+n+1);
				for(i=1;i<=n;i++) mh[i]=0,rec[i]=0,f[i]=i;
				for(i=1;i<=n;i++) cnt++,dfs(ID[i]);
				random_shuffle(ID+1,ID+n+1);
				for(ans=0,i=1;i<=n;i++) if(!rec[ID[i]]) BFS(ID[i]);
				for(i=1;i<=n;i++)
					if(find(i)==i)
						{
							int x=0;
							for(j=1;j<=n;j++) if(find(j)==i) x+=v[j];
							if(x<0) ans+=x;
						}
				mn=min(mn,ans);
				//printf("**%d\n\n",ans);
			}
		printf("%d",mn);
	}
}
int main( )
{
	freopen("z.in","r",stdin);
	freopen("bl.out","w",stdout);
	int i,j,k,t;
	n=read( );
	for(i=1;i<=n;i++)
		{
			k=read( );
			for(j=1;j<=k;j++)
				t=read( ),link(i,t);
		}
	for(i=1;i<=n;i++) v[i]=read( );
	B::solve( );
	return 0;
}
