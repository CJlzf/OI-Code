#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;
const int N=20;
const int GS=4;
bool S[N+2];
int main() {
	freopen("z.in","w",stdout);
	srand(time(NULL));
	int i,j,x,u;
	printf("%d\n",N);
	for(i=1;i<=N;i++)
		{
			x=rand( )%N+1;
			while(S[x]) x=rand( )%N+1;
			S[x]=1;
			u=rand( )%GS+1;
			printf("%d %d ",u,x);
			for(j=2;j<=u;j++) printf("%d ",rand()%N+1);
			puts("");
		}
	for(i=1;i<=N;i++)
		{
			if(rand()%2==0) printf("-");
			printf("%d ",rand( )%10+1);
		}
	return 0;
}
