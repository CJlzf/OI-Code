#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;



int main() {
	int t=0;
	while (++t) {
		printf("%d : ",t);
		system("./make");
		system("./z");
		system("./bl");
		if (system("diff z.out bl.out"))
			{printf("WA\n");  break;}
		else  printf("AC\n");
    }
	return 0;
}
