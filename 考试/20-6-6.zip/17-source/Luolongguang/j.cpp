#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstdlib>
#include<cmath>
#include<cstring>
#include<stack>
using namespace std;
#define maxn 100100
#define llg int
#define yyj(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout);
llg n,LE[maxn],RI[maxn],c[maxn],cnt,root[maxn],tot,len,Q,SIZE,KUAISHU,ne[maxn],belong[maxn],added[maxn],d[maxn];
vector<llg>g[maxn],dis[maxn];
vector<llg>a[maxn];
stack<llg>z;
inline int getint()
{
	int w=0,q=0; char c=getchar();
	while((c<'0' || c>'9') && c!='-') c=getchar(); if(c=='-') q=1,c=getchar(); 
	while (c>='0' && c<='9') w=w*10+c-'0', c=getchar(); return q ? -w : w;
}

struct MYTREAP
{
	int size;
	struct
	{
		int l,r,rnd,val,w,size;
		void init() {l=r=rnd=val=w=size=0;}
	}po[maxn*5];
     
	void init(){ memset(po,0,sizeof(po)); for (llg i=KUAISHU+1;i<=n*3+KUAISHU+1;i++) z.push(i);}
     
	void update(llg now) {po[now].size=po[po[now].l].size+po[po[now].r].size+po[now].w;}
         
	void right_(llg &now) {llg t=po[now].l; po[now].l=po[t].r; po[t].r=now; po[t].size=po[now].size; update(now); now=t;}
	void left_(llg &now)  {llg t=po[now].r; po[now].r=po[t].l; po[t].l=now; po[t].size=po[now].size; update(now); now=t;}
 
	void insert(llg &now,llg val)
	{
		if (now==0)
			{
				now=z.top(); z.pop();
				po[now].size=po[now].w=1; po[now].val=val; po[now].rnd=rand();
				return ;
			}
		po[now].size++;
		if (po[now].val==val)
			{
				po[now].w++;
			}
		else
			if (po[now].val<val)
				{
					insert(po[now].r,val);
					if (po[po[now].r].rnd<po[now].rnd) left_(now);
				}
			else
				{
					insert(po[now].l,val);
					if (po[po[now].l].rnd<po[now].rnd) right_(now);
				}
	}
 
	void del(llg &now,llg val)
	{
		if (now==0) return ;
		if (po[now].val==val)
			{
				if (po[now].w>1)
					{
						po[now].w--; po[now].size--;
						return ;
					}
				if (po[now].l*po[now].r==0) {llg p=now; z.push(p);  now=po[now].l+po[now].r; po[p].init(); }
				else
					{
						if (po[po[now].l].rnd<po[po[now].r].rnd) right_(now); else left_(now);
						del(now,val);
					}
			}
		else
			{
				po[now].size--;
				if (val>po[now].val) del(po[now].r,val);
				else del(po[now].l,val);
			}
	}
	
	int ask_rank(llg now,llg val)
	{
		if (now==0) return 0;
		if (po[now].val==val) return po[po[now].l].size;
		else
			if (val>po[now].val) return po[po[now].l].size+po[now].w+ask_rank(po[now].r,val);
			else return ask_rank(po[now].l,val);
	}
 
}se;

void dfs(llg x,llg fa,llg DIS)
{
	llg w=g[x].size(),v;
	d[x]=DIS;
	LE[x]=++cnt;
	for (llg i=0;i<w;i++)
		{
			v=g[x][i];
			if (v==fa) continue;
			dfs(v,x,DIS+dis[x][i]);
		}
	RI[x]=cnt;
}

void init()
{
	cin>>n>>Q>>len;
	for (llg i=2;i<=n;i++)
		{
			llg fa=getint(),D=getint();
			g[fa].push_back(i),dis[fa].push_back(D);
		}
	dfs(1,0,0);
	for (llg i=1;i<=n;i++) c[LE[i]]=d[i];
	SIZE=sqrt(n); KUAISHU=n/SIZE+10;
	cnt=0;
	se.init();
	for (llg i=1;i<=KUAISHU;i++) root[i]=i,se.po[i].w=se.po[i].size=1,se.po[i].val=0x7fffffff;
	for (llg i=1;i<=n;i++)
		{
			ne[i]=i+SIZE-1; ne[i]=min(ne[i],n); cnt++;
			a[cnt].push_back(0);
			for (llg j=i;j<=ne[i];j++) 
				{
					ne[j]=ne[i];
					belong[j]=cnt;
					se.insert(root[cnt],c[j]);
					a[cnt].push_back(c[j]);
				}
			i=ne[i];
		}
}

void add(llg l,llg r,llg addv)
{
	llg stk=belong[l],endk=belong[r];
	for (llg i=l;i<=r;i++)
		{
			if (belong[i]==stk || belong[i]==endk)
				{
					se.del(root[belong[i]],c[i]);
					se.insert(root[belong[i]],c[i]+addv);
					c[i]+=addv;
					continue;
				}
			else
				{
					added[belong[i]]+=addv;
					i=ne[i];
				}
		}
}

llg sum(llg l,llg r,llg v)
{
	llg stk=belong[l],endk=belong[r],sum=0;
	for (llg i=l;i<=r;i++)
		{
			if (belong[i]==stk || belong[i]==endk)
				{
					if (c[i]+added[belong[i]]<=v) sum++;
					continue;
				}
			if (v-added[belong[i]]>=0) 
				sum+=se.ask_rank(root[belong[i]],v+1-added[belong[i]]);
			i=ne[i];
		}
	return sum;
}

int main()
{
	yyj("j");
	init();
	cnt=0;
	while (Q--)
		{
			llg ty=getint(),x=getint(),k=getint();
			if (ty==2) add(LE[x],RI[x],k);
			else
				{
					if (RI[x]-LE[x]+1<k) {puts("-1"); continue;}
					llg l=0,r=2001000,mid,ans;
					while (l<=r)
						{
							mid=(l+r)>>1;
							tot=sum(LE[x],RI[x],mid);
							if (tot>=k) ans=mid,r=mid-1;else l=mid+1;
						}
					printf("%d\n",ans);
				}
		}
	//printf("%.3lf",(double)clock()/CLOCKS_PER_SEC);
	return 0;
}
