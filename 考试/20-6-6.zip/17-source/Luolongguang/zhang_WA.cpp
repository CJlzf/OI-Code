#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstdlib>
#include<cmath>
#include<cstring>
using namespace std;
#define maxn 10010
#define llg long long 
#define yyj(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout);
llg n,m,fa[maxn],cs,deep[maxn],k,p[maxn],ans,md,du[maxn],jc[maxn];
bool bj[maxn];
vector<llg>a[maxn];

inline int getint()
{
       int w=0,q=0; char c=getchar();
       while((c<'0' || c>'9') && c!='-') c=getchar(); if(c=='-') q=1,c=getchar(); 
       while (c>='0' && c<='9') w=w*10+c-'0', c=getchar(); return q ? -w : w;
}

llg find(llg x){if (x!=fa[x]) fa[x]=find(fa[x]); return fa[x];}

llg ksm(llg a,llg b)
{
	if (b==0) return 1;
	llg val=1;
	while (b)
		{
			if (b&1) val*=a,val%=md;
			a*=a,a%=md;
			b>>=1;
		}
	return val;
}

void dfs(llg x,llg faa)
{
	if (deep[x]&1) cs++;
	llg w=a[x].size(),v;
	for (llg i=0;i<w;i++)
		{
			v=a[x][i];
			if (faa==v) continue;
			deep[v]=deep[x]+1;
			dfs(v,x);
		}
}


void work()
{
	for (llg i=1;i<=n;i++) a[i].clear(),deep[i]=0,du[i]=0;
	du[1]=1;
	for (llg i=2;i<=n;i++) a[p[i]].push_back(i),a[i].push_back(p[i]),du[p[i]]++,du[i]++;
	deep[1]=1;
	cs=0;
	dfs(1,0);
	if (cs==k) 
		{
			//	for (llg i=1;i<=n;i++) cout<<p[i]<<" ";
			//			cout<<endl;
			llg val=jc[n];
			for (llg i=1;i<=n;i++) 
				val*=ksm(max((llg)1,jc[du[i]-1]),md-2),val%=md;
			ans+=val; ans%=md;
		}
}

void ss(llg x)
{
	if (x>n)
		{
			work();
			return ;
		}
	for (llg i=1;i<x;i++)
		if (i!=x)
			{
				llg f1=find(i),f2=find(x),stf2=f2;
				if (f1==f2) continue;
				fa[f2]=f1;
				p[x]=i;
				ss(x+1);
				fa[f2]=stf2;	
			}
}

int main()
{
	yyj("zhang");
	cin>>n>>k>>md;
	jc[1]=1; jc[0]=1;
	for (llg i=2;i<=n;i++) jc[i]=i*jc[i-1],jc[i]%=md;
	for (llg i=1;i<=n;i++) fa[i]=i;
	ss(2);
	cout<<ans;
	return 0;
}
