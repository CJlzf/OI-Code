#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstdlib>
#include<cmath>
#include<cstring>
using namespace std;
#define maxn 310
#define llg int
#define yyj(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout);
llg n,m,cs[maxn],p[maxn],ans;
llg gj[maxn],sx[maxn],C[maxn],chuval[maxn],d[maxn];
struct node
{
	llg size;
	vector<llg>a;
	bool c[maxn];
}se[maxn];

inline int getint()
{
       int w=0,q=0; char c=getchar();
       while((c<'0' || c>'9') && c!='-') c=getchar(); if(c=='-') q=1,c=getchar(); 
       while (c>='0' && c<='9') w=w*10+c-'0', c=getchar(); return q ? -w : w;
}

void ss(llg x,llg k,llg val)
{
	if ((double)clock()/CLOCKS_PER_SEC>0.91) return ;
	if (x>n)
		{			
			llg nows=0;
			for (llg i=1;i<=n;i++) if (cs[i]==k) nows++;
			if (nows==k) ans=min(ans,val);
			return ;
		}
	ss(x+1,k,val);
	llg nows=0;
	for (llg i=0;i<se[x].size;i++) 
		{
			cs[se[x].a[i]]++;
			if (cs[se[x].a[i]]==k+1) nows++;
		}
	if (nows>=k+1)
		{
			ss(x+1,k+1,val+p[x]);
		}
	for (llg i=0;i<se[x].size;i++) 
		{
			cs[se[x].a[i]]--;
		}
}

void work1()
{
	ss(1,0,0);
	cout<<ans;
}

bool cmp(llg a,llg b){return p[a]>p[b];}
bool cmpp(llg a,llg b){return gj[a]>gj[b];}

void R()
{
	for (llg i=1;i<=n;i++) gj[i]=rand()%(n*2)+chuval[i],sx[i]=i,C[i]=0;
	sort(sx+1,sx+n+1,cmpp);
}

int main()
{
	yyj("z");
	cin>>n;
	for (llg i=1;i<=n;i++)
		{
			se[i].size=getint();
			for (llg j=1;j<=se[i].size;j++)
				{
					llg x=getint();
					se[i].a.push_back(x),se[i].c[x]=1;
				}
		}
	llg tot=0;
	for (llg i=1;i<=n;i++) p[i]=getint(),tot+=p[i];
	if (n<=20) {work1(); return 0;}
	cout<<tot;
	/*ans=0;
	for (llg i=1;i<=n;i++) d[i]=i;
	sort(d+1,d+n+1,cmp);
	for (llg i=1;i<=n;i++) chuval[d[i]]+=i;
	while ((double)clock()/CLOCKS_PER_SEC<0.91)
		{
			R();
			llg k=0,x,t=0,val=p[sx[1]];
			x=sx[1];
			for (llg i=0;i<se[x].size;i++) C[se[x].a[i]]=1,t++;
			for (llg i=2;i<=n;i++)
				{
					llg sxs=0;
					x=sx[i];
					for (llg j=0;j<se[x].size;j++) 
						if (C[se[x].a[j]]==k)
							sxs++;
					if (sxs>t+1) continue;
					if (sxs==t+1) 
						{
							ans=min(ans,val+p[x]);
						} 
					for (llg j=0;j<se[x].size;j++) 
						C[se[x].a[j]]++;
			
					t=sxs;
					k++;
				}			 
		}
		cout<<ans;*/
	return 0;
}
