#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstdlib>
#include<cmath>
#include<cstring>
using namespace std;
#define maxn 100100
#define llg int
#define yyj(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout);
llg n,LE[maxn],RI[maxn],c[maxn],cnt,root[maxn],addv[maxn],tot,len,Q;
vector<llg>g[maxn],dis[maxn];
vector<llg>a[maxn];

inline int getint()
{
       int w=0,q=0; char c=getchar();
       while((c<'0' || c>'9') && c!='-') c=getchar(); if(c=='-') q=1,c=getchar(); 
       while (c>='0' && c<='9') w=w*10+c-'0', c=getchar(); return q ? -w : w;
}

struct MYTREAP
{
	  int size;
    struct
    {
        int l,r,rnd,val,w,size;
    }po[maxn];
     
	  void init(){ memset(po,0,sizeof(po)); size=n*4;}
     
    void update(llg now) {po[now].size=po[po[now].l].size+po[po[now].r].size+po[now].w;}
         
    void right_(llg &now) {llg t=po[now].l; po[now].l=po[t].r; po[t].r=now; po[t].size=po[now].size; update(now); now=t;}
    void left_(llg &now)  {llg t=po[now].r; po[now].r=po[t].l; po[t].l=now; po[t].size=po[now].size; update(now); now=t;}
 
    void insert(llg &now,llg val)
    {
        if (now==0)
        {
            now=++size;
            po[now].size=po[now].w=1; po[now].val=val; po[now].rnd=rand();
            return ;
        }
        po[now].size++;
        if (po[now].val==val)
        {
            po[now].w++;
        }
        else
            if (po[now].val<val)
            {
                insert(po[now].r,val);
                if (po[po[now].r].rnd<po[now].rnd) left_(now);
            }
            else
            {
                insert(po[now].l,val);
                if (po[po[now].l].rnd<po[now].rnd) right_(now);
            }
    }
 
    int ask_rank(llg now,llg val)
    {
        if (now==0) return 0;
        if (po[now].val==val) return po[po[now].l].size;
        else
            if (val>po[now].val) return po[po[now].l].size+po[now].w+ask_rank(po[now].r,val);
            else return ask_rank(po[now].l,val);
    }
 
}se;

void dfs(llg x,llg fa,llg DIS)
{
	llg w=g[x].size(),v;
	c[x]=DIS;
	LE[x]=++cnt;
	for (llg i=0;i<w;i++)
		{
			v=g[x][i];
			if (v==fa) continue;
			dfs(v,x,DIS+dis[x][i]);
		}
	RI[x]=cnt;
}

void init()
{
	cin>>n>>Q>>len;
	for (llg i=2;i<=n;i++)
		{
			llg fa=getint(),D=getint();
			g[fa].push_back(i),dis[fa].push_back(D);
		}
	dfs(1,0,0);
	for (llg i=1;i<=n*4;i++) root[i]=i,se.po[i].w=se.po[i].size=1,se.po[i].val=0x7fffffff;
}

void updata(llg o,llg lc,llg rc)
{
	llg w=a[lc].size();
	for (llg i=0;i<w;i++) a[o].push_back(a[lc][i]),se.insert(root[o],a[lc][i]);
	w=a[rc].size();
	for (llg i=0;i<w;i++) a[o].push_back(a[rc][i]),se.insert(root[o],a[rc][i]);
}

void build(llg o,llg l,llg r)
{
	if (l==r)
		{
			a[o].push_back(c[++cnt]);
			se.insert(root[o],c[cnt]);
			return ;
		}
	llg lc=o<<1,rc=o<<1|1,mid=(l+r)>>1;
	build(lc,l,mid);
	build(rc,mid+1,r);
	updata(o,lc,rc);
}

void add(llg o,llg l,llg r,llg L,llg R,llg v)
{
	if (l>=L && r<=R)
		{
			addv[o]+=v;
			return ;
		}
	llg lc=o<<1,rc=o<<1|1,mid=(l+r)>>1;
	if (L<=mid) add(lc,l,mid,L,R,v);
	if (R>mid) add(rc,mid+1,r,L,R,v);
}

void sum(llg o,llg l,llg r,llg L,llg R,llg v)
{
	v-=addv[o];
	if (v<0) return ;
	if (l>=L && r<=R)
		{
			tot+=se.ask_rank(root[o],v+1);
			return ;
		}
	llg lc=o<<1,rc=o<<1|1,mid=(l+r)>>1;
	if (L<=mid) sum(lc,l,mid,L,R,v);
	if (R>mid) sum(rc,mid+1,r,L,R,v);
}

int main()
{
	yyj("j");
	init();
	cnt=0;
	se.init();
	build(1,1,n);
	while (Q--)
		{
			llg ty=getint(),x=getint(),k=getint();
			if (ty==2) add(1,1,n,LE[x],RI[x],k);
			else
				{
					if (RI[x]-LE[x]+1<k) {puts("-1"); continue;}
					llg l=0,r=1e9,mid,ans;
					while (l<=r)
						{
							mid=(l+r)>>1;
							tot=0;
							sum(1,1,n,LE[x],RI[x],mid);
							if (tot>=k) ans=mid,r=mid-1;else l=mid+1;
						}
					printf("%d\n",ans);
				}
		}
	return 0;
}
