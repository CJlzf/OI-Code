/*
  It is made by cilebritain
  If you shed tears when you miss the sun,you will miss the stars.
*/
#include<bits/stdc++.h>

#define dd double
#define ll long long
#define inf 0x3f3f3f3f
#define rep(i,j,k) for(int i=j;i<=k;++i)
#define per(i,j,k) for(int i=j;i>=k;--i)
#define repp(i,j,k,l) for(int i=j;i<=k;i+=l)

using namespace std;

inline int getint()
{
	int res=0,fh=1;char ch=getchar();
	while((ch<'0'||ch>'9')&&ch!='-')ch=getchar();
	if(ch=='-')fh=-1,ch=getchar();
	while(ch<='9'&&ch>='0')res=res*10+ch-'0',ch=getchar();
	return res*fh;
}

inline int count(int x){return x<=1?x:(x&1)+count(x>>1);}

int n,ans=inf,p[100001],d[100001];
vector<int>a[100001];

void check(int x)
{
	int hav=0,res=0;
	rep(i,1,n)d[i]=0;
	rep(i,1,n)if(x&(1<<(i-1)))
		{
			res+=p[i];
			rep(j,0,(int)a[i].size()-1)
				if(!d[a[i][j]])hav++,d[a[i][j]]++;
		}
	if(hav==count(x))ans=min(ans,res);
}

int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	n=getint();
	if(n<=20)
		{
			rep(i,1,n)
				{
					int x=getint();
					rep(j,1,x){int y=getint();a[i].push_back(y);}
				}
			rep(i,1,n)p[i]=getint();
			rep(i,1,(1<<n)-1)check(i);
			printf("%d",ans);
		}
	else 
		{
			ans=0;
			rep(i,1,n)
				{
					int x=getint();
					rep(j,1,x){int y=getint();a[i].push_back(y);}
				}
			rep(i,1,n)p[i]=getint(),ans+=p[i];
			printf("%d",ans);
		}
	return 0;
}
