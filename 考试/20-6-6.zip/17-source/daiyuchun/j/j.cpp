/*
  It is made by cilebritain
  If you shed tears when you miss the sun,you will miss the stars.
*/
#include<bits/stdc++.h>

#define dd double
#define ll long long
#define inf 0x3f3f3f3f
#define rep(i,j,k) for(int i=j;i<=k;++i)
#define per(i,j,k) for(int i=j;i>=k;--i)
#define repp(i,j,k,l) for(int i=j;i<=k;i+=l)

using namespace std;

inline int getint()
{
	int res=0,fh=1;char ch=getchar();
	while((ch<'0'||ch>'9')&&ch!='-')ch=getchar();
	if(ch=='-')fh=-1,ch=getchar();
	while(ch<='9'&&ch>='0')res=res*10+ch-'0',ch=getchar();
	return res*fh;
}

int n,m,len,ne,dc;
int head[200001],to[500001],nxt[500001],w[500001];
int begin[200001],end[200001],dep[200001];
void link(int fr,int to1,int w1)
{
	ne++;
	to[ne]=to1;nxt[ne]=head[fr];
	head[fr]=ne;w[ne]=w1;
}
void dfs(int x,int f)
{
	begin[x]=++dc;
	for(int i=head[x];i;i=nxt[i])
		{
			int v=to[i];
			if(v==f)continue;
			dep[dc+1]=dep[begin[x]]+w[i];
			dfs(v,x);
		}
	end[x]=dc;
}

int t[200001];
void update(int x,int l,int r,int l1,int r1,int w1)
{
	if(l1<=l&&r<=r1){t[x]+=w1;return ;}
	int mid=(l+r)>>1;
	if(l1<=mid)update(x<<1,l,mid,l1,r1,w1);
	if(r1>mid)update(x<<1|1,mid+1,r,l1,r1,w1);
}

int query(int x,int l,int r,int p)
{
	int res=t[x],mid=(l+r)>>1;
	if(l==r)return res;
	if(p<=mid)return res+query(x<<1,l,mid,p);
	else return res+query(x<<1|1,mid+1,r,p);
}

priority_queue<int>q;

int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	n=getint();m=getint();len=getint();
	rep(i,2,n)
		{
			int x=getint(),y=getint();
			link(x,i,y);link(i,x,y);
		}
	dfs(1,0);
	while(m--)
		{
			int op=getint(),x=getint(),k=getint();
			if(op==2)update(1,1,n,begin[x],end[x],k);
			else 
				{
					if(end[x]-begin[x]+1<k){printf("-1\n");continue;}
					while(!q.empty())q.pop();
					rep(i,1,k)q.push(inf);
					rep(i,begin[x],end[x])q.push(dep[i]+query(1,1,n,i)),q.pop();
					printf("%d\n",q.top());
				}
		}
	return 0;
}
