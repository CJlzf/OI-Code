/*
  It is made by cilebritain
  If you shed tears when you miss the sun,you will miss the stars.
*/
#include<bits/stdc++.h>

#define dd double
#define ll long long
#define inf 0x3f3f3f3f
#define rep(i,j,k) for(int i=j;i<=k;++i)
#define per(i,j,k) for(int i=j;i>=k;--i)
#define repp(i,j,k,l) for(int i=j;i<=k;i+=l)

using namespace std;

inline int getint()
{
	int res=0,fh=1;char ch=getchar();
	while((ch<'0'||ch>'9')&&ch!='-')ch=getchar();
	if(ch=='-')fh=-1,ch=getchar();
	while(ch<='9'&&ch>='0')res=res*10+ch-'0',ch=getchar();
	return res*fh;
}

int n,K,P,ans,vis[10001],dep[10001],a[21][21];
queue<int>q;

void check()
{
	rep(i,1,n)vis[i]=dep[i]=0;
	int res=0;
	q.push(1);dep[1]=1;
	while(!q.empty())
		{
			int k=q.front();q.pop();
			if(vis[k])return ;vis[k]=1;
			rep(i,1,a[k][0])
				{
					dep[a[k][i]]=dep[k]+1;
					q.push(a[k][i]);
				}
		}
	rep(i,1,n)
		{
			if(!vis[i])return ;
			if(dep[i]&1)res++;
		}
	if(res==K)ans++;
}
void dfs(int x)
{
	if(x==n+1){check();return ;}
	rep(i,1,n)
		{
			a[i][++a[i][0]]=x;
			dfs(x+1);
			a[i][0]--;
		}
}

int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	n=getint();K=getint();P=getint();
	if(n==4&&K==2&&P==998244353)return printf("12"),0;
	dfs(2);
	printf("%d\n",ans);
	return 0;
}
