#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
#define N 100010
using namespace std;
inline int rd() {
  int x=0;
  char ch=getchar();
  while(ch<'0'||ch>'9') ch=getchar();
  while(ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();
  return x;
}
int n,m,len;
int fa[N],w[N];
int head[N];
int Lim;
struct ways{
	int now,next,w;
}way[N];
int ap=1;
inline void link(int u,int v,int w){
	way[++ap].now=v;way[ap].next=head[u];head[u]=ap;
	way[ap].w=w;//printf("link %d %d\n",u,v);
}
int S,now,L;
int que[N];
int sz[N],in[N],out[N],xu[N];
int addtag[N];
int color[N];
int blk;
int lk[N],ld[N];
int A[2010],B[2010];int mx[N];
bool cmp(const int &x,const int &y){
	return w[x]<w[y];
}
inline void merege(int scc,int l,int r,int v){
	int i,j,k,lA=0,lB=0;
	for(i=lk[scc];i<=ld[scc];i++)
		if(in[xu[i]]>=l&&in[xu[i]]<=r){
			B[++lB]=xu[i];w[xu[i]]+=v;mx[scc]=max(mx[scc],w[xu[i]]);
		}
		else {
			A[++lA]=xu[i];
		}
	for(i=1,j=1,k=lk[scc]-1;i<=lA||j<=lB;)
		if(i<=lA)
			if(j<=lB&&w[B[j]]<w[A[i]])xu[++k]=B[j++];
			else xu[++k]=A[i++];
		else xu[++k]=B[j++];
	Lim=max(Lim,mx[scc]+addtag[scc]);
	//printf("now %d %d %d\n",lk[scc],ld[scc],addtag[scc]);
	//for(i=lk[scc];i<=ld[scc];i++)
	//	printf("%d[%d] ",xu[i],w[xu[i]]);
	//printf("\n");
}
inline void modify(int l,int r,int v){
	//printf("modify %d %d %d\n",l,r,v);
	if(color[l]==color[r]){//printf("in blok %d\n",l,r);
		merege(color[l],l,r,v);
	}
	else {
		merege(color[l],l,ld[color[l]],v);
		merege(color[r],lk[r],r,v);
		int i;
		for(i=color[l]+1;i<color[r];i++){
			//	printf("add blk %d %d\n",lk[i],ld[i]);
			addtag[i]+=v;Lim=max(mx[i]+addtag[i],Lim);
		}
	}

}
int C[(N+N)*10];
inline void add(int o){
	o++;
	for(;o<=L;o+=(o&(-o)))
		C[o]++;
}
inline void cut(int o){
    o++;
	for(;o<=L;o+=(o&(-o)))
		C[o]--;
}
inline int query(int o){
	o++;//printf("query %d\n",o);
	int res=0;
	for(;o;o-=(o&(-o))){
		res+=C[o];
//		printf("o=%d\n",o);
	}
//	printf("end=%d\n",res);
	return res;
}
inline void settag(int scc,int l,int r){
	int i;
	for(i=lk[scc];i<=ld[scc];i++)
		if(in[xu[i]]>=l&&in[xu[i]]<=r)
			add(w[xu[i]]+addtag[scc]);
}
inline void cuttag(int scc,int l,int r){
	int i;
	for(i=lk[scc];i<=ld[scc];i++)
		if(in[xu[i]]>=l&&in[xu[i]]<=r)
			cut(w[xu[i]]+addtag[scc]);
}
inline int ask(int scc,int l,int r,int k){
	if(k<0)return 0;
	register int i,res=0;//printf("ask %d %d %d %d\n",l,r,k,addtag[scc]);
	for(i=lk[scc];i<=ld[scc];i++){
		//	printf("get %d %d %d\n",xu[i],in[xu[i]],w[xu[i]]);
		if(in[xu[i]]>=l&&in[xu[i]]<=r&&w[xu[i]]<=k)res++;
	}
	//printf("res=%d\n",res);
	return res;
}
inline int Query(int L,int R,int sl,int sr,int k){
	//printf("Query %d %d %d %d %d\n",L,R,sl,sr,k);
	int res=0;
	if(color[L]==color[R]){
		return ask(color[L],L,R,k-addtag[color[L]]);
	}
	else {
		res=ask(color[L],L,ld[color[L]],k-addtag[color[L]])+ask(color[R],lk[color[R]],R,k-addtag[color[R]]);
	}
	int kk,ll,rr,mid,be;
	//printf("Query2 %d %d %d\n",sl,sr,k);
	for(;sl<=sr;sl++){
		kk=k-addtag[sl];
		if(kk<0||w[xu[lk[sl]]]>kk)continue;
		ll=lk[sl],rr=ld[sr]+1,mid=(ll+rr)>>1;
		be=-1;
		while(mid!=be){
			be=mid;
			if(w[xu[mid]]>kk)rr=mid;
            else ll=mid;
			mid=(ll+rr)>>1;
		}
		res+=ll-lk[sl]+1;
	}
	//printf("res=%d\n",res);
	return res;
}
inline void ask(int L,int R,int v){
	if(R-L+1<v){
		printf("-1\n");return;
	}
	//::L=len*now+1;
	int l=-1,r=Lim+1,
		mid=(l+r)>>1,be=-1,ans=-1;
	//printf("ask %d %d\n",L,R);
	/*if(color[L]==color[R]){
		settag(color[L],L,R);
	}
	else {
		settag(color[L],L,ld[color[L]]);
		settag(color[R],lk[color[R]],R);
		}*/
	//printf("now ask\n");
	while(mid!=be){
		be=mid;//printf("l=%d r=%d\n",l,r);
		if(Query(L,R,color[L]+1,color[R]-1,mid)<v)l=mid;
		else r=mid;//fail
		mid=(l+r)>>1;
	}
	//printf("w=%d %d\n",1,len*now);
	printf("%d\n",l+1);
	/*if(color[L]==color[R]){
		cuttag(color[L],L,R);
	}
	else {
		cuttag(color[L],L,ld[color[L]]);
		cuttag(color[R],lk[color[R]],R);
	}*/
	
}
inline void solve(){
	int i,j,type,u,v;
	for(i=1;i<=n;i+=S){
		sort(xu+i,xu+(min(n,i+S-1)),cmp);
		lk[++blk]=i;
		for(j=i;j<=i+S-1&&j<=n;j++)
			mx[color[j]=blk]=max(mx[blk],w[xu[j]]);
		ld[blk]=j-1;
	}
	for(i=1;i<=m;i++){
	
		type=rd();u=rd();v=rd();
		//printf("solve %d %d %d\n",type,u,v);
		if(type==2){	now++;
			modify(in[u],out[u],v);	
		}
		else {
			ask(in[u],out[u],v);
		}
	}
}
void work(){
	n=rd();m=rd();len=rd();
	int i,j;now=n;
	for(i=1;i<n;i++){
		fa[i+1]=rd();
		link(fa[i+1],i+1,rd());
	}
	int x,y,to,fir,las;
	for(que[fir=las=1]=1;fir<=las;fir++){
		x=que[fir];sz[x]=1;
		for(y=head[x];to=way[y].now,y;y=way[y].next)
		{
			w[to]=w[x]+way[y].w;que[++las]=to;Lim=max(w[to],Lim);
		}
	}
	for(i=las;i>1;i--){
		x=que[i];
		sz[fa[x]]+=sz[x];
	}
	in[1]=out[1]=1;
	for(i=2;i<=n;i++){
		x=que[i];
		in[x]=out[x]=out[fa[x]]+1;out[fa[x]]+=sz[x];
	}
	for(i=1;i<=n;i++)
		xu[in[i]]=i;
	//S=sqrt(log((n+m)*len)/log(2)*n/4);//sizeof square
	S=sqrt(log((n+m)*len)/log(2)*n/4);
     //S=sqrt(n);
     //printf("S=%d\n",S);
	S=min(max(S,1),n);
	solve();
}
int main()
{
  freopen("j.in","r",stdin);
  freopen("j.out","w",stdout);
  work();
  fclose(stdin);
  fclose(stdout);
  return 0;
}
