#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
using namespace std;
inline int rd() {
  int x=0;
  char ch=getchar();
  while(ch<'0'||ch>'9') ch=getchar();
  while(ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();
  return x;
}
int n,k,p,mod;
int gp[1010][1010],dp[1010][1010];
int fac[500010],inv[500010];
inline int qp(int x,int o){
	int y=1;
	while(o){
		if(o&1)y=1LL*x*y%mod;
		x=1LL*x*x%mod;
		o>>=1;
	}
	return y;
}
inline int C(int x,int y){
	return x<y?0:1LL*fac[x]*inv[y]%mod*inv[x-y]%mod;
}
inline void upd(int &x,int y){
   x+=y;x>=mod?x-=mod:0;
}
void work(){
	n=rd();k=rd();mod=rd();
	int i,j,u,v,x,y;
	/*
	if(n==4&&k==2){
		printf("12\n");return;
		}*/
	fac[0]=inv[0]=1;
	for(i=1;i<=n;i++)
		fac[i]=1LL*fac[i-1]*i%mod;//printf("en\n");
	inv[n]=qp(fac[n],mod-2);//printf("to %d\n",n);
	for(i=n-1;i>=1;i--)
		inv[i]=1LL*inv[i+1]*(i+1)%mod;
	dp[1][1]=1;
	for(i=2;i<=n;i++){
		//printf("i=%d %d %d %d\n",i,fac[i],inv[i],1LL*fac[i]*inv[i]%mod);
        for(j=1;j<=k&&j<=i;j++){
			//upd(dp[i][j],1LL*dp[i-1][(i-1)-(j-1)]*(i-1)%mod);
			for(u=1;u<i;u++)
				for(v=1;v<=u;v++)if((i-u)-(j-(u-v))>=0&&(x=dp[i-u][j-(u-v)])&&(y=dp[u][v])){
						//upd(dp[i][j],1LL*dp[i-u][u-(j-v)]*C(i-1,u-1)%mod*(dp[u][v]+gp[u][v])%mod);
						//upd(dp[i][j],1LL*gp[i-u][u-(j-v)]*C(i-1,u-1)%mod*(dp[u][v]+gp[u][v])%mod);
						//upd(gp[i][j],1LL*gp[i-u][u-(j-v)]*C(i-1,u-1)%mod*(dp[u][v]+gp[u][v])%mod);
						//printf("dp[%d][%d]+=dp[%d][%d]*[C(%d %d)=%d]*dp[%d][%d]*%d %lld\n",i,j,i-u,(i-u)-(j-v),i-2,u-1,C(i-2,u-1),u,v,u,1LL*dp[i-u][(i-u)-(j-v)]*C(i-2,u-1)%mod*(1LL*(dp[u][v]*u)%mod)%mod);
						//upd(dp[i][j],1LL*dp[i-u][(i-u)-(j-v)]*C(i-2,u-1)%mod*(1LL*(dp[u][v]*u)%mod)%mod);
						//printf("upd dp[%d][%d]+=dp[%d %d]*C(%d %d)*dp[%d %d] *%d=%lld\n",i,j,i-u,j-(u-v),i-2,u-1,u,v,u,1LL*x*C(i-2,u-1)%mod*y%mod*u%mod);
				upd(dp[i][j],1LL*x*C(i-2,u-1)%mod*y%mod*u%mod);
					}/*else {
						printf("faild dp[%d][%d](%d %d)\n",i-u,j-(u-v),u,v);
						}*/
			//	printf("dp[%d][%d]=%d\n",i,j,dp[i][j]);
		}
	}
	printf("%d\n",dp[n][k]);
}
int main()
{
  freopen("zhang.in","r",stdin);
  freopen("zhang.out","w",stdout);
  work();
  fclose(stdin);
  fclose(stdout);
  return 0;
}
