#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
using namespace std;
inline int rd() {
	int x=0;bool flag=0;
  char ch=getchar();
  while(ch<'0'||ch>'9') flag=(ch=='-'),ch=getchar();
  while(ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();
  return flag?-x:x;
}
#define N 310
int n;
int p[N];
int to[N];
int one[257];
int ans;
struct ways{
	int now,next;
}way[N*N*2];
int ap=1;
int head[N];
inline void link(int u,int v){
	way[++ap].now=v;way[ap].next=head[u];head[u]=ap;
	way[++ap].now=u;way[ap].next=head[v];head[v]=ap;
}
inline int calc(int S){
	return one[S&255]+one[(S>>8)&255]+one[(S>>16)&255];
}
inline void dfs(int now,int S,int m,int w){
	if(now==n+1){//printf("get %d %d %d\n",S,m,w);
		if(calc(S)==m)ans=min(ans,w);return;
	}
	dfs(now+1,S,m,w);
	dfs(now+1,S|to[now],m+1,w+p[now]);
}
inline void solve1(){
	int t,i,j;
	for(i=1;i<=255;i++)
		one[i]=one[i>>1]+(i&1);
	for(i=1;i<=n;i++){
		t=rd();
		while(t--)to[i]|=(1<<(rd()-1));
	}
	for(i=1;i<=n;i++)p[i]=rd();
	dfs(1,0,0,0);
	printf("%d\n",ans);
}
void work(){
	int i,j,t;
	n=rd();
  if(n<=20){
		solve1();return;
		}
	for(i=1;i<=n;i++){
		t=rd();
		while(t--)link(rd(),rd());
	}
	bool flag=true;
	for(i=1;i<=n;i++){p[i]=rd();if(p[i]>0)flag=false;}
	if(flag){
		for(i=1;i<=n;i++)ans+=p[i];
		printf("%d\n",ans);return;
	}
}
int main()
{
  freopen("z.in","r",stdin);
  freopen("z.out","w",stdout);
  work();
  fclose(stdin);
  fclose(stdout);
  return 0;
}
