//It is made by ljh2000
//有志者，事竟成，破釜沉舟，百二秦关终属楚；苦心人，天不负，卧薪尝胆，三千越甲可吞吴。
#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <complex>
#include <string>
#include <bitset>
#include <vector>
#include <cstdio>
#include <cmath>
#include <ctime>
#include <queue>
#include <map>
#include <set>
#define lc root<<1
#define rc root<<1|1
#define MP make_pair
#define Pa pair<int,int>
#define rep(i,j,k) for(int i=j;i<=k;i++) 
#define per(i,j,k) for(int i=k;i>=j;i--)
#define RG register
using namespace std;
typedef long long LL;
typedef long double LB;
typedef complex<double> C;
const double pi = acos(-1);
const double eps = 1e-9;
const int MAXN = 200011;
const int MAXM = 400011;
int n,m,len,ecnt,first[MAXN],to[MAXM],next[MAXM],quan[MAXN],size[MAXN];
int tag[MAXN],dis[MAXN],father[MAXN],cnt;
inline void link(int x,int y){ next[++ecnt]=first[x]; first[x]=ecnt; to[ecnt]=y; }
inline int getint(){
    int w=0,q=0; char c=getchar(); while((c<'0'||c>'9') && c!='-') c=getchar();
    if(c=='-') q=1,c=getchar(); while (c>='0'&&c<='9') w=w*10+c-'0',c=getchar(); return q?-w:w;
}

inline void dfs(int x,int fa){
	size[x]=1;
	for(int i=first[x];i;i=next[i]) {
		int v=to[i]; if(v==fa) continue;
		father[v]=x; dfs(v,x);
		size[x]+=size[v]; 
	}
}

inline void dfs2(int x,int fa,int dep){
	dep+=tag[x];
	dis[++cnt]=dep;
	for(int i=first[x];i;i=next[i]) {
		int v=to[i]; if(v==fa) continue;
		dfs2(v,x,dep+quan[v]);
	}
}

inline void work(){
	n=getint(); m=getint(); len=getint(); int type,x,y,cc,u;
	for(int i=2;i<=n;i++) { x=getint(); link(x,i); link(i,x); quan[i]=getint(); }
	dfs(1,0);
	while(m--) {
		type=getint(); x=getint(); y=getint();
		if(type==1) {
			if(size[x]<y) { puts("-1"); continue; }
			cc=quan[x]; /*!!!*/
			u=father[x]; 
			while(u) {
				cc+=tag[u];
				cc+=quan[u];
				u=father[u];
			}
			cnt=0;
			dfs2(x,father[x],cc);
			sort(dis+1,dis+cnt+1);
			printf("%d\n",dis[y]);
		}
		else { tag[x]+=y; }
	}
}
 
int main()
{
	freopen("j.in","r",stdin);
	freopen("2.out","w",stdout);
    work();
    return 0;
}
//有志者，事竟成，破釜沉舟，百二秦关终属楚；苦心人，天不负，卧薪尝胆，三千越甲可吞吴。
