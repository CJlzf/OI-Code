//It is made by ljh2000
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <vector>
#include <queue>
#include <map>
#include <set>
#include <string>
#include <complex>
using namespace std;
typedef long long LL;
typedef long double LB;
typedef complex<double> C;
const double pi = acos(-1);

int main()
{
    int t=0;
    while (++t)
	{
	    printf("%d : ",t);
	    system("./make");
	    system("./j");
	    system("./2");
	    if (system("diff j.out 2.out"))
		{printf("WA\n");  break;}
	    else  printf("AC!!!\n");
	}
    return 0;
}
