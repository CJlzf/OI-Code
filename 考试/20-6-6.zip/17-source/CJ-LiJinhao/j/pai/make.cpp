//It is made by ljh2000
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <vector>
#include <queue>
#include <map>
#include <set>
#include <string>
#include <complex>
using namespace std;
typedef long long LL;
typedef long double LB;
typedef complex<double> C;
const double pi = acos(-1);
const int MAXN = 200011;
const int MAXM = 400011;
int ecnt,first[MAXN],to[MAXM],nxt[MAXM],quan[MAXN],size[MAXN],ans;
inline void link(int x,int y){ nxt[++ecnt]=first[x]; first[x]=ecnt; to[ecnt]=y; }
inline int getint(){
    int w=0,q=0; char c=getchar(); while((c<'0'||c>'9') && c!='-') c=getchar();
    if(c=='-') q=1,c=getchar(); while (c>='0'&&c<='9') w=w*10+c-'0',c=getchar(); return q?-w:w;
}


inline void dfs(int x,int fa){
	size[x]=1;
	for(int i=first[x];i;i=nxt[i]) {
		int v=to[i]; if(v==fa) continue;
		dfs(v,x); size[x]+=size[v];
	}
}


int main()
{
    freopen("j.in","w",stdout);
    srand(time(NULL));
	int n,m,len,siz,type,x,y;//,nsize;
	//siz=10;
	//siz=100;
	//siz=1000;
	//siz=10000;
	//siz=30000;
	//siz=50000;
	siz=100000;

	//n=rand()%siz+1; m=rand()%siz+1; 
	n=siz; m=siz;
	len=10;
	//nsize=10;
	//nsize=(n/10);
	printf("%d %d %d\n",n,m,len);
	for(int i=2;i<=n;i++) {
		x=rand()%(i-1)+1; y=i;
		link(x,y); link(y,x);
		printf("%d %d\n",x,rand()%len+1);
	}
	dfs(1,0);
	for(int i=1;i<=m;i++) {
		type=rand()%2+1;
		//x=rand()%n+1;
		x=1;
		if(type==1) y=rand()%size[x]+1;
		else y=rand()%len+1;
		printf("%d %d %d\n",type,x,y);
	}
    return 0;
}
