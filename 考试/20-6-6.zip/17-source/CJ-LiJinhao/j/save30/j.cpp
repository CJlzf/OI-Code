//It is made by ljh2000
//有志者，事竟成，破釜沉舟，百二秦关终属楚；苦心人，天不负，卧薪尝胆，三千越甲可吞吴。
#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <complex>
#include <string>
#include <bitset>
#include <vector>
#include <cstdio>
#include <cmath>
#include <ctime>
#include <queue>
#include <map>
#include <set>
#define lc root<<1
#define rc root<<1|1
#define MP make_pair
#define Pa pair<int,int>
#define rep(i,j,k) for(int i=j;i<=k;i++) 
#define per(i,j,k) for(int i=k;i>=j;i--)
#define RG register
using namespace std;
typedef long long LL;
typedef long double LB;
typedef complex<double> C;
const double pi = acos(-1);
const double eps = 1e-9;
const int MAXN = 200011;
const int MAXM = 400011;
int n,m,len,ecnt,first[MAXN],to[MAXM],nxt[MAXM],quan[MAXN],size[MAXN],ans;
int dis[MAXN],dfn[MAXN],zui[MAXN],father[MAXN],lin[MAXN];
int block,b[2000][2000],kcnt,tag[MAXN],bel[MAXN],L[MAXN],R[MAXN];
inline void link(int x,int y){ nxt[++ecnt]=first[x]; first[x]=ecnt; to[ecnt]=y; }
inline int getint(){
    int w=0,q=0; char c=getchar(); while((c<'0'||c>'9') && c!='-') c=getchar();
    if(c=='-') q=1,c=getchar(); while (c>='0'&&c<='9') w=w*10+c-'0',c=getchar(); return q?-w:w;
}

inline void dfs(int x,int fa){
	size[x]=1; dfn[x]=++ecnt;
	dis[ dfn[x] ]=dis[ dfn[fa] ]+quan[x];
	for(int i=first[x];i;i=nxt[i]) {
		int v=to[i]; if(v==fa) continue;
		father[v]=x; dfs(v,x); size[x]+=size[v];
	}
	zui[x]=ecnt;
}

inline void build(){
	//block=1000;
	block=sqrt(n); 
	kcnt=n/block; if(n%block) kcnt++;
	for(int i=1;i<=kcnt+1;i++) L[i]=R[i]=n+1;
	for(int i=1;i<=n;i++) {
		bel[i]=(i-1)/block+1;
		L[bel[i]]=min(L[bel[i]],i);
		R[bel[i]]=i;

		b[ bel[i] ][ i-L[bel[i]]+1 ]=dis[i];
	}
	for(int i=1;i<=kcnt;i++) sort(b[i]+1,b[i]+R[i]-L[i]+1 +1);
}

inline int get_ans(int bl,int val){
	val-=tag[bl]; //!!!
	if(b[bl][1]>val) return 0;
	int l=1,r=(R[bl]-L[bl]+1),pos=0,mid;
	if(b[bl][r]<=val) return r;
	while(l<=r) {
		mid=(l+r)>>1;
		if(b[bl][mid]<=val) pos=mid,l=mid+1;
		else r=mid-1;
	}
	return pos;
}

inline int check(int l,int r,int val){
	int tot=0,zuo=bel[l],you=bel[r];
	for(int i=l;i<=R[zuo];i++) if(dis[i]+tag[zuo]<=val) tot++;
	for(int i=L[you];i<=r;i++) if(dis[i]+tag[you]<=val) tot++;
	for(int i=zuo+1;i<you;i++) { tot+=get_ans(i,val); }
	return tot;
}

inline void query(int x,int y,int k){
	ans=0; int l=0,r=1000010,mid;
	check(x,y,20);
	while(l<=r) {
		mid=(l+r)>>1;
		if(check(x,y,mid)>=k/*!!!*/) r=mid-1,ans=mid;
		else l=mid+1;
	}
}

inline void inwork(int l,int r,int k){
	int bb=bel[l]; for(int i=L[bb];i<=R[bb];i++) dis[i]+=tag[bb];
	tag[bb]=0; for(int i=l;i<=r;i++) dis[i]+=k;
	for(int i=L[bb];i<=R[bb];i++) b[bb][ i-L[bb]+1 ]=dis[i];
	sort(b[bb]+1,b[bb]+R[bb]-L[bb]+1 +1);
}

inline void add(int l,int r,int k){
	int zuo=bel[l],you=bel[r];
	if(zuo==you) { inwork(l,r,k); }
	else if(zuo+1==you) {
		inwork(l,R[zuo],k);
		inwork(L[you],r,k);
	}
	else {
		inwork(l,L[zuo+1]-1,k);
		inwork(L[you]/*!!!*/,r,k);
		for(int i=zuo+1;i<you;i++) tag[i]+=k;/*!!!*/
	}
}

inline void work(){
	n=getint(); m=getint(); len=getint(); int type,x,y,zuo,you,cc;
	for(int i=2;i<=n;i++) { x=getint(); link(x,i); link(i,x); quan[i]=getint(); }
	ecnt=0;	dfs(1,0);
	build();
	while(m--) {
		type=getint(); x=getint(); y=getint();
		if(type==1) {
			if(size[x]<y) { puts("-1"); continue; }

			ans=0; zuo=bel[dfn[x]]; you=bel[zui[x]];
			if(zuo==you) { 
				//ans=b[zuo][y]+tag[zuo]; !!!
				cc=0; for(int i=dfn[x];i<=zui[x];i++) lin[++cc]=dis[i]+tag[zuo]/*!!!*/;
				sort(lin+1,lin+cc+1);
				ans=lin[y];
			}
			else if(zuo+1==you) {
				cc=0; for(int i=dfn[x];i<=zui[x];i++) lin[++cc]=dis[i]+tag[bel[i]]/*!!!*/;
				sort(lin+1,lin+cc+1);
				ans=lin[y];
			}
			else query(dfn[x],zui[x],y);
			printf("%d\n",ans);
		}
		else { add(dfn[x],zui[x],y); }
	}
}
 
int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
    work();
    return 0;
}
//有志者，事竟成，破釜沉舟，百二秦关终属楚；苦心人，天不负，卧薪尝胆，三千越甲可吞吴。
