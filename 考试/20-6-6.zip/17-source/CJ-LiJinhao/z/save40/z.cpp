//It is made by ljh2000
//有志者，事竟成，破釜沉舟，百二秦关终属楚；苦心人，天不负，卧薪尝胆，三千越甲可吞吴。
#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <complex>
#include <string>
#include <bitset>
#include <vector>
#include <cstdio>
#include <cmath>
#include <ctime>
#include <queue>
#include <map>
#include <set>
#define lc root<<1
#define rc root<<1|1
#define MP make_pair
#define Pa pair<int,int>
#define rep(i,j,k) for(int i=j;i<=k;i++) 
#define per(i,j,k) for(int i=k;i>=j;i--)
#define RG register
using namespace std;
typedef long long LL;
typedef long double LB;
typedef complex<double> C;
const double pi = acos(-1);
const double eps = 1e-9;
const int MAXN = 311;
int n,a[MAXN][MAXN],p[MAXN],ans;
int tong[MAXN];
int qu[MAXN*MAXN];

inline int getint(){
    int w=0,q=0; char c=getchar(); while((c<'0'||c>'9') && c!='-') c=getchar();
    if(c=='-') q=1,c=getchar(); while (c>='0'&&c<='9') w=w*10+c-'0',c=getchar(); return q?-w:w;
}

inline void dfs(int x,int hav,int zong){
	if(x==n+1) {
		int cc=0;
		for(int i=1;i<=n;i++) if(tong[i]>0) cc++;
		if(cc!=hav) return ;
		ans=min(ans,zong);
		return ;
	}
	for(int i=1;i<=a[x][0];i++) tong[a[x][i]]++;
	dfs(x+1,hav+1,zong+p[x]);
	for(int i=1;i<=a[x][0];i++) tong[a[x][i]]--;

	dfs(x+1,hav,zong);
}

inline void work(){
	n=getint(); int cc=0;
	for(int i=1;i<=n;i++) {
		a[i][0]=getint();
		for(int j=1;j<=a[i][0];j++) a[i][j]=getint(),qu[++cc]=a[i][j];
	}
	sort(qu+1,qu+cc+1); cc=unique(qu+1,qu+cc+1)-qu-1; bool ck=true;
	for(int i=1;i<=n;i++) for(int j=1;j<=a[i][0];j++) a[i][j]=lower_bound(qu+1,qu+cc+1,a[i][j])-qu;
	for(int i=1;i<=n;i++) { p[i]=getint(); if(p[i]>0) ck=false; }
	if(ck) {
		int tt=0;
		for(int i=1;i<=n;i++) tt+=p[i];
		printf("%d",tt);
		return ;
	}
	dfs(1,0,0);

	printf("%d",ans);
}
 
int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
    work();
    return 0;
}
//有志者，事竟成，破釜沉舟，百二秦关终属楚；苦心人，天不负，卧薪尝胆，三千越甲可吞吴。
