//It is made by ljh2000
//有志者，事竟成，破釜沉舟，百二秦关终属楚；苦心人，天不负，卧薪尝胆，三千越甲可吞吴。
#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <complex>
#include <string>
#include <bitset>
#include <vector>
#include <cstdio>
#include <cmath>
#include <ctime>
#include <queue>
#include <map>
#include <set>
#define lc root<<1
#define rc root<<1|1
#define MP make_pair
#define Pa pair<int,int>
#define rep(i,j,k) for(int i=j;i<=k;i++) 
#define per(i,j,k) for(int i=k;i>=j;i--)
#define RG register
using namespace std;
typedef long long LL;
typedef long double LB;
const double pi = acos(-1);
const double eps = 1e-9;
const int MAXN = 500011;
int n,k,mod;
LL ans,jie[MAXN],nj[MAXN];
inline LL fast_pow(LL x,LL y){ LL r=1; while(y>0) { if(y&1) r*=x,r%=mod; x*=x; x%=mod; y>>=1; } return r; }
inline LL C(int n,int m){ return jie[n]*nj[m]%mod*nj[n-m]%mod; }
inline int getint(){
    int w=0,q=0; char c=getchar(); while((c<'0'||c>'9') && c!='-') c=getchar();
    if(c=='-') q=1,c=getchar(); while (c>='0'&&c<='9') w=w*10+c-'0',c=getchar(); return q?-w:w;
}

inline void dfs(int x,int hav,int lat,LL lei,int ji){
	if(ji>k) return ;
	if(hav>=n) { 
		if(ji!=k) return ;
		ans+=lei; 
		return ; 
	}
	int remain=n-hav;
	int nex;
	LL nexans;
	for(int len=1;len+hav<=n;len++) {
		if(x&1) nex=ji+len; else nex=ji;
		nexans=lei*C(remain,len)%mod;
		nexans=nexans*fast_pow(lat,len)%mod;
		dfs(x+1,hav+len,len,nexans,nex);
	}
	//int rem[22],cc=0; for(int i=1;i<=n;i++) if(!use[i]) rem[++cc]=i;
	//int pd[22],nn,nex; for(int i=1;i<=cc+1;i++) pd[i]=0;
	/*
	while(!pd[cc+1]) {
		pd[1]++; for(int i=1;i<=cc;i++) if(pd[i]>=2) pd[i]=0,pd[i+1]++;
		if(pd[cc+1]) break;
		nn=0; for(int i=1;i<=cc;i++) if(pd[i]) nn++,dui[x][nn]=rem[i],use[rem[i]]=1;
		num[x]=nn; if(x&1) nex=ji+nn; else nex=ji;//!!!
		dfs(x+1,hav+nn,nn,lei*fast_pow(last,nn)%mod,nex);
		for(int i=1;i<=cc;i++) if(pd[i]) use[rem[i]]=0;
	}*/
}

inline void work(){
	n=getint(); k=getint(); mod=getint();
	//if(n==1 || n==2) { printf("0"); return ; }
	//if(n==3) { if(k==2) printf("2"); else printf("0"); return ; }
	//if(n==4) { if(k==2) printf("12"); else if(k==3) printf("3"); else printf("0"); return ; }

	//use[1]=1; dui[1][1]=1;
	jie[0]=1; for(int i=1;i<=n;i++) jie[i]=jie[i-1]*i%mod;
	nj[0]=1; nj[n]=fast_pow(jie[n],mod-2); for(int i=n-1;i>=1;i--) nj[i]=nj[i+1]*(i+1)%mod;
	ans=0; dfs(2,1,1,1,1);
	printf("%lld",ans);
}
 
int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
    work();
    return 0;
}
//有志者，事竟成，破釜沉舟，百二秦关终属楚；苦心人，天不负，卧薪尝胆，三千越甲可吞吴。
