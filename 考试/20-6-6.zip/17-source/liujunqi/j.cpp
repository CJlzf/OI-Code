#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <cmath>
#include <ctime>
#include <vector>
#include <queue>
#include <map>
#include <set>
using namespace std;
const int inf = 2147483640;
typedef long long ll;
ll geti(){
    char ch=getchar();while((ch<'0' || ch>'9')&&ch!='-')ch=getchar();
    ll ret=0,k=1;
    if(ch=='-')k=-1,ch=getchar();
    while(ch>='0' && ch<='9')ret=ret*10+ch-'0',ch=getchar();
    return ret*k;
}
const int maxn = 100000 + 52;
int n,m,len;
int fa[maxn],st[maxn],pt[maxn*2],nxt[maxn*2],w[maxn*2],eg[maxn],ent=0;
void adde(int u,int v,int wt){
    pt[++ent]=v;nxt[ent]=st[u];st[u]=ent;w[ent]=wt;eg[v]=ent;
}
int dfn[maxn],dnt=0,R[maxn],rfn[maxn],dep[maxn],q[maxn];
void dfs(int x){
    dfn[x]=++dnt;rfn[dnt]=x;
    for(int i=st[x];i;i=nxt[i]){
        dep[pt[i]]=dep[x]+w[i];
        dfs(pt[i]);
    }
    R[x]=dnt;
}
int main(){
    freopen("j.in","r",stdin);
    freopen("j.out","w",stdout);

    n=geti();m=geti();len=geti();
    int wt;
    for(int i=2;i<=n;i++){
        fa[i]=geti();wt=geti();
        adde(fa[i],i,wt);
    }
    dfs(1);
    int op,x,k;
    for(int kk=1;kk<=m;kk++){
        op=geti();x=geti();k=geti();
        if(op==1){
            int ct=0;
            for(int i=dfn[x];i<=R[x];i++){
                q[++ct]=dep[i];
            }
            if(k>ct){
                printf("-1\n");
                continue;
            }
            nth_element(q+1,q+k,q+1+ct);
            printf("%d\n",q[k]);
        }
        else{
            for(int i=dfn[x];i<=R[x];i++){
                dep[i]+=k;
            }
        }
    }

    /*for(int i=1;i<=10;i++){
        q[i]=rand()%100000000+1;
        cout << q[i] << " ";
    }
    cout << endl;
    //sort(q+1,q+1+10);
    //nth_element(q+1,q+5,q+1+10);
    //cout << q[5];*/
    
    fclose(stdin);
    fclose(stdout);
    return 0;
}
