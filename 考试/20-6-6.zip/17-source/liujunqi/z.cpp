#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <cmath>
#include <ctime>
#include <vector>
#include <queue>
#include <map>
#include <set>
using namespace std;
const int inf = 2147483640;
typedef long long ll;
ll geti(){
    char ch=getchar();while((ch<'0' || ch>'9')&&ch!='-')ch=getchar();
    ll ret=0,k=1;
    if(ch=='-')k=-1,ch=getchar();
    while(ch>='0' && ch<='9')ret=ret*10+ch-'0',ch=getchar();
    return ret*k;
}
const int maxn = 320;
int n,mdc[maxn][maxn],len[maxn],p[maxn],ans;
char cz[maxn];
void dfs(int x){
    if(x==n+1){
        char vis[30]={0};
        int ct=0;
        for(int i=1;i<=n;i++){
            if(cz[i]){
                ++ct;
                for(int j=1;j<=len[i];j++){
                    vis[mdc[i][j]]=true;
                }
            }
        }
        int cnt=0,tot=0;
        for(int i=1;i<=n;i++){
            if(vis[i])++cnt;
        }
        if(cnt!=ct)return;
        for(int i=1;i<=n;i++){
            if(cz[i]){
                tot+=p[i];
            }
        }
        ans=min(ans,tot);
        if(tot==-5){
            for(int i=1;i<=n;i++){
                if(cz[i])cout << i <<  " ";
            }
            cout << endl;
        }
        
        return;
    }
    cz[x]=true;
    dfs(x+1);
    cz[x]=false;
    dfs(x+1);
}
int main(){
    freopen("z.in","r",stdin);
    freopen("z.out","w",stdout);

    n=geti();
    for(int i=1;i<=n;i++){
        len[i]=geti();
        for(int j=1;j<=len[i];j++){
            mdc[i][j]=geti();
        }
    }
    for(int i=1;i<=n;i++)p[i]=geti();
    if(n>20){
        for(int i=1;i<=n;i++)ans+=p[i];
        cout << ans;
        return 0;
    }
    dfs(1);
    cout << ans;
	
    fclose(stdin);
    fclose(stdout);
    return 0;
}
