#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <cmath>
#include <ctime>
#include <vector>
#include <queue>
#include <map>
#include <set>
using namespace std;
const int inf = 2147483640;
typedef long long ll;
ll geti(){
    char ch=getchar();while((ch<'0' || ch>'9')&&ch!='-')ch=getchar();
    ll ret=0,k=1;
    if(ch=='-')k=-1,ch=getchar();
    while(ch>='0' && ch<='9')ret=ret*10+ch-'0',ch=getchar();
    return ret*k;
}
int n,k,p;
ll c[1010][1010],mi[1010][1010],fct[1010],ans=0;
ll ksm(ll a,ll b){
    ll ret=1,u=b;
    while(u){
        if(u&1)ret=ret*a%p;
        a=a*a%p;
        u>>=1;
    }
    return ret;
}
namespace pts20{
    int lev[1010];
    void dfs(int x,int rem){
        if(rem==0){
            int cnt=0;
            for(int i=1;i<x;i+=2){
                cnt+=lev[i];
            }
            if(cnt!=k)return;
            ll cur=1;
            for(int i=2;i<x;i++){
                (cur*=ksm(lev[i-1],lev[i]))%=p;
            }
            int rem=n-1;
            for(int i=2;i<x;i++){
                (cur*=c[rem][lev[i]])%=p;rem-=lev[i];
            }
            (ans+=cur)%=p;
            return;
        }
        for(int i=1;i<=rem;i++){
            lev[x]=i;
            dfs(x+1,rem-i);
        }
    }
    int main(){
        c[0][0]=1;
        for(int i=1;i<=1000;i++){
            c[i][0]=1;
            for(int j=1;j<=i;j++){
                c[i][j]=(c[i-1][j]+c[i-1][j-1])%p;
            }
        }
        fct[0]=1;
        for(int i=1;i<=1000;i++)fct[i]=fct[i-1]*i%p;
        lev[1]=1;
        dfs(2,n-1);
        cout << ans;
        return 0;
    }
}
namespace pts40{
    ll f[110][110][110],g[110][110][110];
    void main(){
        f[1][1][1]=1;
        for(int i=2;i<=n;i++){
            for(int j=1;j<i;j++){
                for(int k=1;k<i;k++){
                    for(int m=1;m<=i-k;m++){
                        (f[i][j][k]+=g[i-k][j-k][m]*mi[m][k]%p*c[n-i+k][k])%=p;
                        (g[i][j][k]+=f[i-k][j][m]*mi[m][k]%p*c[n-i+k][k])%=p;
                    }
                    //printf("f[%d][%d][%d] = %lld\n",i,j,k,f[i][j][k]);
                    //printf("g[%d][%d][%d] = %lld\n",i,j,k,g[i][j][k]);
                }
            }
        }
        ll ans=0;
        for(int i=1;i<=n;i++){
            (ans+=f[n][k][i]+g[n][k][i])%=p;
        }
        cout << ans;
    }
}
int main(){
    freopen("zhang.in","r",stdin);
    freopen("zhang.out","w",stdout);

    //p=998244353;
    n=geti();k=geti();p=geti();
    c[0][0]=1;mi[0][0]=1;
    for(int i=1;i<=1000;i++){
        c[i][0]=1;mi[i][0]=1;
        for(int j=1;j<=i;j++){
            c[i][j]=(c[i-1][j]+c[i-1][j-1])%p;
            mi[i][j]=mi[i][j-1]*i%p;
        }
        for(int j=i+1;j<=1000;j++){
            mi[i][j]=mi[i][j-1]*i%p;
        }
    }
    fct[0]=1;
    for(int i=1;i<=1000;i++)fct[i]=fct[i-1]*i%p;
    /*for(int i=1;i<=15;i++){
        for(int j=0;j<i;j++){
            n=i;k=j;
            memset(pts40::f,0,sizeof(pts40::f));
            memset(pts40::g,0,sizeof(pts40::g));
            pts40::main();
            cout << " ";
        }
        cout << endl;
    }
    */
    //pts20::main();
    //cout << endl;
    pts40::main();
    return 0;
}
