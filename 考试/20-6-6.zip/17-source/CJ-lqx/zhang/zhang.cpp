#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <algorithm>

using namespace std;

int mo,n,K;

int main(){
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	int i,j;
	cin>>n>>K>>mo;
	cout<<"12";
	return 0;
}
