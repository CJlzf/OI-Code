#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <algorithm>

using namespace std;

const int N=611;
const int M=1e5+11;

int getint();

int n,a[N][N],v[N],h[N],num,w[N];
int st[N],next[M],to[M],tot,be[N],d[N],md[N],stack[N],top;
bool in[N],u[N][N];
long long ans,f[N],sum[N],now;

void link(int,int);

void pd(){
	int i,j;
	for(i=1,j=0;i<=n;i++)if(h[i])j++;
	if(j==num)ans=min(ans,now);
}

void dfs(int k){
	int i;
	if(k==n+1){pd();return;}
	for(i=1;i<=a[k][0];i++)h[a[k][i]]++;
	num++;
	now+=w[k];
	dfs(k+1);
	for(i=1;i<=a[k][0];i++)h[a[k][i]]--;
	num--;
	now-=w[k];
	dfs(k+1);
}

int solve(int x){
	v[x]=1;
	int i;
	for(i=1;i<=a[x][0];i++){
		if(!h[a[x][i]]){
			h[a[x][i]]=x;
			return 1;
		}
		if((!v[h[a[x][i]]])&&solve(h[a[x][i]])){
			h[a[x][i]]=x;
			return 1;
		}
	}
	return 0;
}

void tj(int k){
	int i,t;
	d[k]=md[k]=++tot;
	stack[++top]=k;in[k]=1;
	for(i=1;i<=a[k][0];i++){
		t=h[a[k][i]];
		if(!d[t]){
			tj(t);
			md[k]=min(md[k],md[t]);
		}
		else if(in[t])md[k]=min(md[k],d[t]);
	}
	if(md[k]==d[k]){
		num++;
		while(stack[top]!=k){
			t=stack[top];top--;
			in[t]=0;be[t]=num;
			sum[num]+=w[t];
		}
		top--;
		in[k]=0;be[k]=num;
		sum[num]+=w[k];
	}
}

void Q(int k){
	if(v[k])return;
	v[k]=1;
	int i;
	for(i=st[k];i;i=next[i]){
		Q(to[i]);
		f[k]+=f[to[i]];
		sum[k]+=sum[to[i]];
	}
	f[k]=min(f[k],sum[k]);
	ans=min(ans,f[k]);
}

int main(){
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	int i,j;
	n=getint();
	for(i=1;i<=n;i++){
		a[i][0]=getint();
		for(j=1;j<=a[i][0];j++)a[i][j]=getint();
	}
	for(i=1;i<=n;i++)w[i]=getint();
	for(i=1;i<=n&&w[i]<0;i++);
	if(i>n){
		for(i=1;i<=n;i++)ans+=w[i];
		cout<<ans;
		return 0;
	}
	if(n>=20){
		dfs(1);
		cout<<ans;
		return 0;
	}
	for(i=1;i<=n;i++)for(j=1;j<=a[i][0];j++)a[i][j]+=n;
  for(i=1;i<=n;i++){
			memset(v,0,sizeof(v));
			solve(i);
		}
	for(i=1;i<=n;i++)if(!d[i])tj(i);
	tot=0;
	for(i=1;i<=n;i++)for(j=1;j<=a[i][0];j++)link(be[i],be[h[a[i][j]]]);
	num++;
	for(i=1;i<num;i++)link(num,i);
	memset(v,0,sizeof(v));
	for(i=1;i<=num;i++)Q(i);
	cout<<ans;
	return 0;
}

void link(int k,int t){
	if(k!=t&&(!u[k][t])){
		next[++tot]=st[k];st[k]=tot;to[tot]=t;
		u[k][t]=1;
	}
}
int getint(){
	int w=0,q=1;
	char c=getchar();
	while((c>'9'||c<'0')&&c!='-')c=getchar();
	if(c=='-')q=-1,c=getchar();
	while(c>='0'&&c<='9')w=w*10+c-'0',c=getchar();
	return w*q;
}
