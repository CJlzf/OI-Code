#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <algorithm>

using namespace std;

const int N=2e5+11;

int getint();

int n,m,st[N],next[N],to[N],tot,len,w[N],de[N],h[N];

void link(int,int);

void dfs(int k,int fa){
	de[k]=de[fa]+w[k];
	for(int i=st[k];i;i=next[i])dfs(to[i],k);
}

void getdep(int k){
	h[++h[0]]=de[k];
	for(int i=st[k];i;i=next[i])getdep(to[i]);
}

int main(){
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	int i,k,t;
	n=getint();m=getint();len=getint();
	for(i=2;i<=n;i++){k=getint();w[i]=getint();link(k,i);}
	while(m--){
		k=getint();
		if(k==1){
			k=getint();t=getint();
			dfs(1,0);
			h[0]=0;
			getdep(k);
			sort(h+1,h+h[0]+1);
			if(h[0]>=t)printf("%d\n",h[t]);
			else printf("-1\n");
		}
		else{
			k=getint();t=getint();
			w[k]+=t;
		}
	}
	return 0;
}

int getint(){
	int w=0,q=1;
	char c=getchar();
	while((c>'9'||c<'0')&&c!='-')c=getchar();
	if(c=='-')q=-1,c=getchar();
	while(c>='0'&&c<='9')w=w*10+c-'0',c=getchar();
	return w*q;
}

void link(int k,int t){next[++tot]=st[k];st[k]=tot;to[tot]=t;}
