#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;
typedef long long LL;
int gi() {
    int w;bool q=1;char c;
    while (((c=getchar())<'0'||'9'<c)&&c!='-');
    if (c=='-') q=0,c=getchar();
    w=c-'0';
    while ('0'<=(c=getchar())&&c<='9') w=w*10+c-'0';
    return q?w:-w;
}
const int N=3e5,M=3e6;
int head[N],nxt[M],to[M],tot=1;LL w[M];
int q[N],S,T,dep[N],cur[N];
inline void link(int a,int b,LL _w) {
    to[++tot]=b,nxt[tot]=head[a],head[a]=tot,w[tot]=_w;
    to[++tot]=a,nxt[tot]=head[b],head[b]=tot,w[tot]=0;
}
inline bool bfs() {
    int i,k,l,r;
    for (i=S;i<=T;i++) dep[i]=0;
    l=0,dep[q[r=1]=T]=1;
    while (l!=r)
	for (i=head[k=q[++l]];i;i=nxt[i])
	    if (w[i^1]&&!dep[to[i]])
		dep[q[++r]=to[i]]=dep[k]+1;
    return dep[S];
}
inline LL dfs(int k,LL low) {
    if (k==T) return low;
    LL s=0,x;
    for (int &i=cur[k];i;i=nxt[i])
	if (w[i]&&dep[to[i]]==dep[k]-1)
	    if (x=dfs(to[i],min(low-s,w[i]))) {
		s+=x;w[i]-=x;w[i^1]+=x;
		if (s==low) return s;
	    }
    return s;
}
int main()
{
    freopen("z.in","r",stdin);
    freopen("z.out","w",stdout);
    int n=gi(),i,t;LL ans=0;
    S=0,T=n<<1|1;
    for (i=1;i<=n;i++)
	for (t=gi();t;t--)
	    link(i,gi()+n,1LL<<60);
    for (i=1;i<=n;i++) link(i+n,T,1<<30);
    for (i=1;i<=n;i++) {
	t=gi(),link(S,i,(1<<30)-t);
	ans+=t;
    }
    //for (i=2;i<=tot;i+=2) printf("%d %d %lld\n",to[i^1],to[i],w[i]);
    //return 0;
    while (bfs()) {
	for (i=S;i<=T;i++) cur[i]=head[i];
	ans+=dfs(S,1LL<<60);
    }
    printf("%lld\n",ans-(1LL<<30)*n);
    return 0;
}
