#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;
const string n="z";
int main()
{
    int t=0;
    while (++t) {
	system("./make");
	system(("./"+n).c_str());
	system("./2");
	if (system(("diff "+n+".out 2.out").c_str()))
	    printf("WA\n"),exit(0);
	printf("%d\n",t);
    }
	return 0;
}
