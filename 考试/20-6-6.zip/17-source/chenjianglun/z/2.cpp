#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;
int gi() {
    int w;bool q=1;char c;
    while (((c=getchar())<'0'||'9'<c)&&c!='-');
    if (c=='-') q=0,c=getchar();
    w=c-'0';
    while ('0'<=(c=getchar())&&c<='9') w=w*10+c-'0';
    return q?w:-w;
}
const int N=25;
int G[N],siz[1<<N],w[N];
int main()
{
    freopen("z.in","r",stdin);
    freopen("2.out","w",stdout);
    int n=gi(),i,t,s,ans=0;
    for (i=0;i<n;i++)
	for (t=gi();t--;)
	    G[i]|=1<<(gi()-1);
    for (i=1;i<1<<n;i++) siz[i]=siz[i>>1]+(i&1);
    for (i=0;i<n;i++) w[i]=gi();
    for (s=0;s<1<<n;s++) {
	t=0;
	for (i=0;i<n;i++)
	    if (s>>i&1) t|=G[i];
	if (siz[t]==siz[s]) {
	    t=0;
	    for (i=0;i<n;i++) if (s>>i&1) t+=w[i];
	    ans=min(ans,t);
	}
    }
    printf("%d\n",ans);
    return 0;
}
