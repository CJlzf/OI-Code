#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <ctime>
using namespace std;
int G[100],p[100];
int siz[1<<25];
int main()
{
    freopen("make.txt","r",stdin);
    freopen("z.in","w",stdout);
    srand(time(NULL));
    int s,n,size,i,j;cin>>n>>size;
    printf("%d\n",n);
    for (i=1;i<1<<n;i++) siz[i]=siz[i>>1]+(i&1);
    for (i=0;i<n;i++) p[i]=i;
    random_shuffle(p,p+n);
    for (i=0;i<n;i++) {
	s=rand()%(1<<n);
	s|=1<<p[i];
	printf("%d",siz[s]);
	for (j=0;j<n;j++)
	    if (s>>j&1) printf(" %d",j+1);
	putchar(10);
    }
    for (i=0;i<n;i++) printf("%d ",rand()%size-(size>>1));
    putchar(10);
    return 0;
}
