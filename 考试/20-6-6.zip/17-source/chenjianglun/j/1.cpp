#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;
int gi() {
    int w;bool q=1;char c;
    while (((c=getchar())<'0'||'9'<c)&&c!='-');
    if (c=='-') q=0,c=getchar();
    w=c-'0';
    while ('0'<=(c=getchar())&&c<='9') w=w*10+c-'0';
    return q?w:-w;
}
const int N=3e5,logn=1e7;
int size;
int head[N],nxt[N];
int L[N],R[N],tot;
int dis[N],w[N];
int lc[logn],rc[logn],sum[logn];
int c[N],id[N],d[N],vis[N],pos[N],sa[N];
inline void dfs(int k) {
    sa[L[k]=++tot]=k;
    for (int i=head[k];i;i=nxt[i])
	dis[i]+=dis[k],dfs(i);
    R[k]=tot;
}
inline void insert(int &i,int l,int r,int k) {
    sum[i=++tot]=1;lc[i]=rc[i]=0;
    if (l!=r) {
	int mid=(l+r)>>1;
	k<=mid?insert(lc[i],l,mid,k):insert(rc[i],mid+1,r,k);
    }
}
inline int query(int i,int l,int r,int R) {
    if (!i||l>r) return;
    if (r<=R) return sum[i];
    int mid=(l+r)>>1;
    return query(lc[i],l,mid,L,R)+(mid<R?query(rc[i],mid+1,r,L,R):0);
}
inline int pre(int k) { int ans=0; for (int t=k;t;t^=t&-t) ans+=c[t]; return ans; }
int main()
{
    freopen("j.in","r",stdin);
    freopen("j.out","w",stdout);
    int tim,n=gi(),m=gi(),i,k,t,top=0,d,cnt=0,l,r,mid,s;size=(m+1)*gi();
    const int blo=sqrt(m);
    for (i=2;i<=n;i++) nxt[i]=head[k=gi()],head[k]=i,dis[i]=gi();
    dfs(1);
    for (i=1;i<=n;i++) w[L[i]]=dis[i];
    tim=blo-1;
    while (m--) {
	if (++tim==blo) {
	    cnt++;
	    for (i=1;i<=n;i++) c[i]+=c[i^(i&-i)];
	    tot=0;
	    for (k=n;k;k--) {
		insert(rt[sa[k]],0,size,w[k]+c[k]),c[k]=0;
		for (i=head[sa[k]];i;i=next[i]) rt[sa[k]]=merge(rt[sa[k]],rt[i]);
	    }
	    top=0;
	}
	if (gi()==1) {
	    k=gi(),t=gi();
	    if (R[k]-L[k]+1<t) puts("-1");
	    else {
		l=0,r=size;
		while (l!=r) {
		    mid=(l+r)>>1;
		    s=query(rt[k],0,size,mid-sum(L[k]));
		    for (i=1;i<=top;i++) if (L[k]<id[i]&&id[i]<=R[k]) 
		}
	    }
	} else {
	    k=gi(),t=gi();
	    if (vis[k]==cnt) d[pos[k]]+=t;
	    else d[pos[k]=++top]=t,id[top]=k;
	    for (i=L[k];i<=n;i+=i&-i) c[i]+=t;
	    for (i=R[k]+1;i<=n;i+=i&-i) c[i]-=t;
	}
    }
    
    return 0;
}
