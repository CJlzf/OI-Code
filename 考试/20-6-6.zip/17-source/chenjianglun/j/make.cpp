#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <ctime>
using namespace std;
int main()
{
    freopen("make.txt","r",stdin);
    freopen("j.in","w",stdout);
    srand(time(NULL));
    int n,m;
    cin>>n>>m;
    printf("%d %d 10\n",n,m);
    for (int i=2;i<=n;i++) printf("%d %d\n",rand()%(i-1)+1,i);
    while (m--)
	if (rand()&1)
	    printf("1 %d %d\n",rand()%n+1,rand()%n+1);
	else printf("2 %d %d\n",rand()%n+1,rand()%10+1);
    return 0;
}
