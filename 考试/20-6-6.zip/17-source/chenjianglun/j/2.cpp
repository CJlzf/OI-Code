#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;
int gi() {
    int w;bool q=1;char c;
    while (((c=getchar())<'0'||'9'<c)&&c!='-');
    if (c=='-') q=0,c=getchar();
    w=c-'0';
    while ('0'<=(c=getchar())&&c<='9') w=w*10+c-'0';
    return q?w:-w;
}
const int N=1e4;
vector<int>v[N];
int L[N],R[N],tot;
int dis[N],w[N];
inline void dfs(int k) {
    L[k]=++tot;
    for (vector<int>::iterator it=v[k].begin();it!=v[k].end();it++)
	dis[*it]+=dis[k],dfs(*it);
    R[k]=tot;
}
int main()
{
    freopen("j.in","r",stdin);
    freopen("2.out","w",stdout);
    int n=gi(),m=gi(),i,k,t;gi();
    for (i=2;i<=n;i++) v[gi()].push_back(i),dis[i]=gi();
    dfs(1);
    for (i=1;i<=n;i++) w[L[i]]=dis[i];
    while (m--)
	if (gi()==1) {
	    k=gi(),t=gi();
	    vector<int>st;
	    for (i=L[k];i<=R[k];i++) st.push_back(w[i]);
	    if (st.size()<t) puts("-1");
	    else {
		sort(st.begin(),st.end());
		printf("%d\n",st[t-1]);
	    }
	} else {
	    k=gi(),t=gi();
	    for (i=L[k];i<=R[k];i++) w[i]+=t;
	}
    return 0;
}
