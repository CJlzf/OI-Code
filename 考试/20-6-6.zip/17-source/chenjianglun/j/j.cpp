#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;
int gi() {
    int w;bool q=1;char c;
    while (((c=getchar())<'0'||'9'<c)&&c!='-');
    if (c=='-') q=0,c=getchar();
    w=c-'0';
    while ('0'<=(c=getchar())&&c<='9') w=w*10+c-'0';
    return q?w:-w;
}
const int N=3e5,logn=1e7;
int head[N],nxt[N];
int L[N],R[N],tot;
int tag[N<<2],dis[N],sa[N],st[N],top,w[N];
#define lc (i<<1)
#define rc (lc|1)
inline void dfs(int k) {
    sa[L[k]=++tot]=k;
    for (int i=head[k];i;i=nxt[i])
	dis[i]+=dis[k],dfs(i);
    R[k]=tot;
}
inline void query(int i,int l,int r,int L,int R,int d) {
    d+=tag[i];
    if (l==r) st[++top]=w[l]+d;
    else {
	int mid=(l+r)>>1;
	if (L<=mid) query(lc,l,mid,L,R,d);
	if (mid<R) query(rc,mid+1,r,L,R,d);
    }
}
inline void modify(int i,int l,int r,int L,int R,int d) {
    if (L<=l&&r<=R) tag[i]+=d;
    else {
	int mid=(l+r)>>1;
	if (L<=mid) modify(lc,l,mid,L,R,d);
	if (mid<R) modify(rc,mid+1,r,L,R,d);
    }
}
int main()
{
    freopen("j.in","r",stdin);
    freopen("j.out","w",stdout);
    int n=gi(),m=gi(),i,k,t;gi();
    for (i=2;i<=n;i++) nxt[i]=head[k=gi()],head[k]=i,dis[i]=gi();
    dfs(1);
    for (i=1;i<=n;i++) w[L[i]]=dis[i];
    while (m--)
	if (gi()==1) {
	    k=gi(),t=gi();
	    if (R[k]-L[k]+1<t) puts("-1");
	    else {
		top=0;query(1,1,n,L[k],R[k],0);
		nth_element(st+1,st+t,st+1+top);
		printf("%d\n",st[t]);
	    }
	} else {
	    k=gi(),t=gi();
	    modify(1,1,n,L[k],R[k],t);
	}
    
    return 0;
}
