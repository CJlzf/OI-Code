#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <queue>
using namespace std;
int gi() {
    int w;bool q=1;char c;
    while (((c=getchar())<'0'||'9'<c)&&c!='-');
    if (c=='-') q=0,c=getchar();
    w=c-'0';
    while ('0'<=(c=getchar())&&c<='9') w=w*10+c-'0';
    return q?w:-w;
}
const int N=100;
int p[N],n,sum;
int cnt[N],ans[N];
vector<int>v[N];
inline void dfs(int k,int fa,bool dep) {
    sum+=dep;
    for (vector<int>::iterator it=v[k].begin();it!=v[k].end();it++)
	if (*it!=fa)
	    dfs(*it,k,!dep);
}
inline void check() {
    int i,a,b;
    priority_queue<int>q;
    for (i=1;i<=n-2;i++) cnt[p[i]]++;
    for (i=1;i<=n;v[i++].clear()) if (!cnt[i]) q.push(i);
    for (i=1;i<=n-2;i++) {
	a=q.top(),b=p[i];q.pop();
	v[a].push_back(b);
	v[b].push_back(a);
	if (!--cnt[b]) q.push(b);
    }
    a=q.top(),q.pop();
    b=q.top(),q.pop();
    v[a].push_back(b);
    v[b].push_back(a);
    sum=0;
    dfs(1,0,1);
    ans[sum]++;
}
inline void dfs(int k) {
    if (k==n-1) check();
    else for (p[k]=1;p[k]<=n;p[k]++)
	     dfs(k+1);
}
int main()
{
    freopen("zhang.in","r",stdin);
    freopen("zhang.out","w",stdout);
    for (n=2;n<=10;n++) {
	for (int i=1;i<=n;i++) ans[i]=0;
	dfs(1);
	for (int i=1;i<=n;i++) printf("%d ",ans[i]);
	putchar(10);
    }
    return 0;
}
