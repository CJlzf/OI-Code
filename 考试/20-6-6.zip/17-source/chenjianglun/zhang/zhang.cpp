#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;
int gi() {
    int w;bool q=1;char c;
    while (((c=getchar())<'0'||'9'<c)&&c!='-');
    if (c=='-') q=0,c=getchar();
    w=c-'0';
    while ('0'<=(c=getchar())&&c<='9') w=w*10+c-'0';
    return q?w:-w;
}
const int N=2010;
int f[N][N],g[N][N],C[N][N];
int main()
{
    freopen("zhang.in","r",stdin);
    freopen("zhang.out","w",stdout);
    int n=gi(),m=gi(),mod=gi(),i,j,k,t;
    f[1][1]=g[1][1]=1;
    for (i=C[0][0]=1;i<=n;i++)
	for (j=C[i][0]=1;j<=i;j++)
	    C[i][j]=(C[i-1][j-1]+C[i-1][j])%mod;
    for (i=2;i<=n;i++)
	for (j=1;j<=i;j++) {
	    f[i][j]=1LL*g[i-1][i-j]*i%mod;
	    g[i][j]=f[i][j];
	    for (k=1;k<i;k++)
		for (t=1;t<=k&&t<=j;t++)
		    g[i][j]=(g[i][j]+1LL*C[i-1][k-1]*f[k][t]%mod*g[i-k][j-t])%mod;
	}
    printf("%d ",g[n-1][n-m]);
    return 0;
}
