#include <bits/stdc++.h>

#define inf 1000000000
#define INF 3000000000000LL

using namespace std ;

int n, src, sink ; 

const int MAXN = 610 ; 

typedef long long LL ; 

struct Edge {
		int l, r, nxt ; 
		LL c ; 
} e[MAXN * MAXN] ;

int ecnt = 1, hed[MAXN] ; 


void addedge(int l, int r, int c) { 
		++ecnt, e[ecnt].l = l, e[ecnt].r = r, e[ecnt].c = c, e[ecnt].nxt = hed[l], hed[l] = ecnt ; 
}

void adde(int l, int r, int c) { 
		addedge(l, r, c) ;
		addedge(r, l, 0) ; 
}

void addedge(int l, int r, LL c) { 
		++ecnt, e[ecnt].l = l, e[ecnt].r = r, e[ecnt].c = c, e[ecnt].nxt = hed[l], hed[l] = ecnt ; 
}

void adde(int l, int r, LL c) { 
		addedge(l, r, c) ;
		addedge(r, l, 0) ; 
}

int q[MAXN], head = 0, tail = 0 ; 

int dis[MAXN] ; 

bool Bfs() { 
		memset(dis, -1, sizeof dis) ;
		dis[src] = 0;  
		q[head = tail = 0] = src ; 
		while (head <= tail) {
				int cur = q[head ++] ; 
				for (int i = hed[cur]; i; i = e[i].nxt) {
						int to = e[i].r ; 
						if (dis[to] < 0 && e[i].c) dis[to] = dis[cur] + 1, q[++ tail] = to ; 
				}
		}
		return dis[sink] >= 0 ; 
}

LL Dfs(int cur, LL flow) { 
		if (cur == sink) return flow ;
		LL ret = flow ; 
		for (int i = hed[cur]; i && ret; i = e[i].nxt) { 
				int to = e[i].r ; 
				if (dis[to] == dis[cur] + 1 && e[i].c) {
						LL delta = Dfs(to, min(ret, e[i].c)) ; 
						e[i].c -= delta ; 
						e[i ^ 1].c += delta ;
						ret -= delta ; 
				}
		}
		if (ret == flow) dis[cur] = -2 ; 
		return flow - ret ; 
}

int main() { 
freopen("z.in", "r", stdin);
freopen("z.out", "w", stdout);
		scanf("%d", &n) ; 
		src = 0, sink = n << 1 | 1 ;  
		LL ans = 0 ; 
		for (int i = 1; i <= n; i ++) {
				int t = 0; 
				scanf("%d", &t) ;
				while (t --) { 
						int x ; 
						scanf("%d", &x)  ;
						adde(i, x + n, INF) ; 
				}
		}
		for (int i = 1; i <= n; i ++) { 
				int c ; 
				scanf("%d", &c) ;
				c = -c ; 
				adde(src, i, c + inf) ; 
				ans += c + inf ; 
		}
		for (int i = 1; i <= n; i ++) adde(i + n, sink, inf) ; 
		while (Bfs()) ans -= Dfs(src, INF) ; 
		cout << -ans << endl ; 
}
