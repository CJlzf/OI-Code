#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <cassert>
#define IL inline
#define N 100003
#define REP(a,b,c) for(a=b;a<=c;a++)
#define PER(a,b,c) for(a=b;a>=c;a--)
using namespace std;
//const int lim=1e7+1;
const int lim = 19,lh=11;
int fa[N],sz[N];
IL int rd(){
    int res=0;char c;while((c=getchar())<'0'||c>'9');
    while(c>='0'&&c<='9')res=res*10+c-'0',c=getchar();return res;
}
int main(int argu,char *argv[]){
    freopen("j.in","w",stdout);
    int n;
    if(argu==2){
        sscanf(argv[1],"%d",&n);
        srand(n);
    }else srand(time(NULL));
    int i,m,len,t;
    //printf("%d %d %d\n",n=602+rand()%400,m=603+rand()%400,len=rand()%8+3);
    printf("%d %d %d\n",n=100+rand()%30000,m=100+rand()%30000,len=rand()%10+1);
    sz[1]=1;
    REP(i,2,n)printf("%d %d\n",fa[i]=rand()%(i-1)+1,rand()%len+1),sz[i]=1;
    PER(i,n,2)sz[fa[i]]+=sz[i];
    REP(i,1,m){
        if(rand()&1)
            printf("2 %d %d\n",rand()%n+1,rand()%len+1);
        else t=rand()%n+1,printf("1 %d %d\n",t,rand()%sz[t]+1);
    }
        
    fclose(stdin),fclose(stdout);
    return 0;
}
