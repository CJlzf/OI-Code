#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#define IL inline
#define REP(a,b,c) for(a=b;a<=c;a++)
using namespace std;
char buf[50];
IL int rd(){
    int res=0;char c;while((c=getchar())<'0'||c>'9');
    while(c>='0'&&c<='9')res=res*10+c-'0',c=getchar();return res;
}
int main(){
    int t=0;srand(time(NULL));
    while(++t<=10000){
        printf("%d:",t);
        sprintf(buf,"./make %d",rand());
        system(buf);
        system("./j2");
        system("./j");
        if(system("diff j2.out j.out")){
            printf("WA\n");break;
        }
        printf("AC\n");
    }
    
    fclose(stdin),fclose(stdout);
    return 0;
}
