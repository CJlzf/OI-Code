#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int a[5]={9,4,3,1,-1};
int main(){
    nth_element(a,a+2,a+5);
    printf("%d\n",a[2]);
    return 0;
}
