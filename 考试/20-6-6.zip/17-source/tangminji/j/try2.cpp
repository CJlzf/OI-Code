#include <cstring>
#include <algorithm>
#include <cstdio>
#include <ctime>
#define N 100000
#define REP(a,b,c) for(a=b;a<=c;a++)
#define PER(a,b,c) for(a=b;a>=c;a--)
using namespace std;
double bs=CLOCKS_PER_SEC;
int a[N],b[N];
int main(){
    int n=9997,i,j,k=0;srand(13/*time(NULL)*/);
    REP(i,1,n)a[i]=b[i]=rand();
    clock_t per,cur;per=clock();
    REP(i,1,n)
        REP(j,9,n)k+=a[j]+=a[j-8];
    cur=clock();printf("%d %f\n",k,(cur-per)/bs);
    k=0;per=clock();
    REP(i,1,n){
        for(j=9;j+7<=n;j+=8)
            k+=b[j]+=b[j-8],
            k+=b[j+1]+=b[j-7],
            k+=b[j+2]+=b[j-6],
            k+=b[j+3]+=b[j-5],
            k+=b[j+4]+=b[j-4],
            k+=b[j+5]+=b[j-3],
            k+=b[j+6]+=b[j-2],
            k+=b[j+7]+=b[j-1];
        for(;j<=n;j++)k+=b[j]+=b[j-8];
    }
    cur=clock();printf("%d %f\n",k,(cur-per)/bs);
    return 0;
}
