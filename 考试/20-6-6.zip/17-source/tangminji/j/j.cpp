#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cstdlib>
#define N 100007
#define IL inline
#define REP(a,b,c) for(a=b;a<=c;a++)
using namespace std;
const int inf=2000050;
int n,m,len,dfn[N],out[N],cnt,fa[N];
int head[N],list[N],next[N],w[N],ap;
int f[N],g[N];
//如果没有2直接主席树或者线段树合并
//如果静态询问或询问在对应修改的后面，可以线段树合并
//如果以sqrt(n)为大小分块，每次加减答案后影响区间进行特判，复杂度为nsqrtnlogn
//不管了，直接先写暴力
//策略：修改时暴力修改整棵子树，询问时直接将对应位置提出查询
//复杂度O(nm)
IL int rd(){
    int res=0;char c;while((c=getchar())<'0'||c>'9');
    while(c>='0'&&c<='9')res=res*10+c-'0',c=getchar();return res;
}
IL void link(int a,int b,int c){
    list[++ap]=b,next[ap]=head[a],head[a]=ap,w[ap]=c;
}
IL void dfs(int u){
    dfn[u]=++cnt;int x;
    for(x=head[u];x;x=next[x])f[cnt+1]=f[dfn[u]]+w[x],dfs(list[x]);out[u]=cnt;
}
int main(){
    freopen("j.in","r",stdin),freopen("j.out","w",stdout);
    n=rd(),m=rd(),len=rd();int i,j,opt,x,k,dlt=0;//引入整体标记
    REP(i,2,n)x=rd(),k=rd(),link(x,i,k);dfs(1);
    REP(i,1,m){
        opt=rd(),x=rd(),k=rd();
        if(opt==1){
            if(out[x]-dfn[x]+1<k)printf("-1\n");
            else{
                memcpy(g+dfn[x],f+dfn[x],sizeof(int)*(out[x]-dfn[x]+1));
                nth_element(g+dfn[x],g+dfn[x]+k-1,g+out[x]+1);
                printf("%d\n",g[dfn[x]+k-1]+dlt);
            }
        }else{
            if(((out[x]-dfn[x]+1)<<1)<=n){
                for(j=dfn[x];j+3<=out[x];j+=4)
                    f[j]+=k,f[j+1]+=k,f[j+2]+=k,f[j+3]+=k;
                for(;j<=out[x];j++)f[j]+=k;
            }else{
                //引入整体加法标记，对其他部分作减法
                dlt+=k;
                for(j=1;j+3<dfn[x];j+=4)
                    f[j]-=k,f[j+1]-=k,f[j+2]-=k,f[j+3]-=k;
                for(;j<dfn[x];j++)f[j]-=k;
                for(j=out[x]+1;j+3<=n;j+=4)
                    f[j]-=k,f[j+1]-=k,f[j+2]-=k,f[j+3]-=k;
                for(;j<=n;j++)f[j]-=k;
            }
        }
    }
    fclose(stdin),fclose(stdout);
    return 0;
}
