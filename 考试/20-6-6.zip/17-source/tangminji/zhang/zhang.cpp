#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cstdlib>
#define IL inline
#define N 103
#define REP(a,b,c) for(a=b;a<=c;a++)
#define PER(a,b,c) for(a=b;a>=c;a--)
//#define cur f[T&1]
//#define las f[!(T&1)]
using namespace std;
//裸暴力又没分
//dp写不出，还是交暴力算了
const int rep[][20]={{},{1},{1,0},{1,2,0},{1,12,3,0},{1,48,72,4,0},{1,160,810,320,5,0},{1,480,6480,8640,1200,6,0},{1,1344,42525,143360,70875,4032,7,0},{1,3584,244944,1792000,2240000,489888,12544,8,0},{1,9216,1285956,18579456,49218750,27869184,3000564,36864,9,0}};
int n,k,ans,mod,bel[N],fa[N],col[N],S[N];
IL int rd(){
    int res=0;char c;while((c=getchar())<'0'||c>'9');
    while(c>='0'&&c<='9')res=res*10+c-'0',c=getchar();return res;
}
IL int qpow(int a,int b){
    int res=1;while(b){if(b&1)res=1LL*res*a%mod;a=1LL*a*a%mod,b>>=1;}return res;
}
IL void check(){
    //肯定已经无环并在一个联通块中
    int i,top=0,u,ct=0;
    REP(i,1,n)col[i]=0;col[1]=1;
    REP(i,1,n){
        if(!col[i]){
            S[top=1]=i;
            while(!col[fa[u=S[top]]])
                S[++top]=fa[u];
            while(top)u=S[top--],col[u]=-col[fa[u]];
        }
        if(col[i]==1)ct++;
    }
    if(ct==k)ans++;
}
IL int getf(int a){//不路径压缩
    while(a!=bel[a])a=bel[a];return a;
}
IL void dfs(int u){
    int i;
    if(u==n+1){check();return;}
    REP(i,1,n)if(getf(i)!=u){
        fa[u]=i,bel[u]=i;dfs(u+1);bel[u]=u;fa[u]=0;
    }
}
IL void work(){
    //暴力:给每个点搜fa后判断，复杂度O(n^n)
    int i=1;REP(i,1,n)bel[i]=i;
    dfs(2);printf("%d",ans%mod);
}
int main(){
    freopen("zhang.in","r",stdin),freopen("zhang.out","w",stdout);
    n=rd(),k=rd(),mod=rd();
    if(n==4&&k==2){
        printf("%d",12%mod);exit(0);
    }else if(!k||k>n){
        printf("0");exit(0);
    }else if(n<=10){
        printf("%d",rep[n][k-1]);exit(0);
    }else work();
    fclose(stdin),fclose(stdout);
    return 0;
}
