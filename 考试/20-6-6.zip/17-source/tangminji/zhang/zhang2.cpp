#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cstdlib>
#define IL inline
#define N 103
#define REP(a,b,c) for(a=b;a<=c;a++)
#define PER(a,b,c) for(a=b;a>=c;a--)
#define cur f[T&1]
#define las f[!(T&1)]
using namespace std;
//裸暴力又没分
//直接prufer构树肯定会TLE
//必须要找一种合法的构树方案使得不算重
//一个较好的方法就是维护最右链，
//有玄机的NTT模数,肯定与组合数算贡献有关
int n,k,mod;
//#define id(i,j) ((i)*1003+(j))
int f[2][N][N],fac[N],inv[N];//最右链长度为i,共有j个深度为奇数点的方案数(退栈时再一起结算，中间拓展只传方案)
IL int rd(){
    int res=0;char c;while((c=getchar())<'0'||c>'9');
    while(c>='0'&&c<='9')res=res*10+c-'0',c=getchar();return res;
}
IL int qpow(int a,int b){
    int res=1;while(b){if(b&1)res=1LL*res*a%mod;a=1LL*a*a%mod,b>>=1;}return res;
}
IL int P(int n,int m){return 1LL*fac[n]*inv[n-m]%mod;}
IL void upd(int &x,int y){x=(x+y)%mod;}
IL void work(){//O(n^4)
    //假定退栈时再结算贡献是正确的
    int T,i,j,t,bs;fac[0]=1;REP(i,1,n)fac[i]=1LL*fac[i-1]*i%mod;
    inv[n]=qpow(fac[n],mod-2);PER(i,n,1)inv[i-1]=1LL*inv[i]*i%mod;
    f[0][1][1]=1;
    REP(T,1,n){
        memset(cur,0,sizeof(f[0]));
        REP(i,1,T){//最右链长度
            REP(j,1,T)
                upd(cur[i+1][j+((i+1)&1)],las[i][j]);
            REP(t,1,i-1){//挂到t点之下
                //关键是相同长度的链会算重,先不管
                bs=P(n-T+i,i-t);//不强制以1为根
                REP(j,1,T)
                    upd(cur[t+1][j+((t+1)&1)],las[i][j]*bs%mod);
            }
        }
    }
    cur[1][k]=1LL*cur[1][k]*qpow(n,mod-2)%mod;
    printf("%d",cur[1][k]);
}
int main(){
    freopen("zhang.in","r",stdin),freopen("zhang.out","w",stdout);
    n=rd(),k=rd(),mod=rd();
    if(n==4&&k==2&&mod==998244353){
        printf("12");exit(0);
    }else if(!k||k>n){
        printf("0");exit(0);
    }else work();
    fclose(stdin),fclose(stdout);
    return 0;
}
