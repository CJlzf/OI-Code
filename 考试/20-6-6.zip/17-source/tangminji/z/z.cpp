#include <cstdio>
#include <algorithm>
#include <cstdlib>
#define IL inline
#define N 303
#define S 65539
#define mo 65535
#define REP(a,b,c) for(a=b;a<=c;a++)
using namespace std;
int n,a[N],use[N],cnt[S],ans=0;
IL int rd(){
    int res=0;char c,f=0;while((c=getchar())<'0'||c>'9')if(c=='-')f=1;
    while(c>='0'&&c<='9')res=res*10+c-'0',c=getchar();return f?-res:res;
}
IL void dfs(int u,int num,int s,int res){
    if(u>n){
        if(cnt[s&mo]+cnt[s>>16]==num)
            ans=min(ans,res);
        return;
    }
    dfs(u+1,num,s,res);
    dfs(u+1,num+1,s|use[u],res+a[u]);
}
int main(){
    freopen("z.in","r",stdin),freopen("z.out","w",stdout);
    n=rd();int i,j;
    REP(i,1,n)
        for(j=rd();j;j--)use[i]|=1<<(rd()-1);
    REP(i,1,n)a[i]=rd();
    REP(i,1,mo)cnt[i]=cnt[i>>1]+(i&1);
    dfs(1,0,0,0);
    printf("%d",ans);
    fclose(stdin),fclose(stdout);
    return 0;
}
