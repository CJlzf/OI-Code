#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <cassert>
#define N 303
#define IL inline
#define REP(a,b,c) for(a=b;a<=c;a++)
using namespace std;
//const int lim=1e7+1;
const int lim = 19,lh=11;
int a[N];
IL int rd(){
    int res=0;char c;while((c=getchar())<'0'||c>'9');
    while(c>='0'&&c<='9')res=res*10+c-'0',c=getchar();return res;
}
int main(int argu,char *argv[]){
    freopen("z.in","w",stdout);
    int n,i,j,T=5,lim;
    if(argu==2){
        sscanf(argv[1],"%d",&n);
        srand(n);
    }else srand(time(NULL));
    printf("%d\n",n=20);
    REP(i,1,n)a[i]=i;lim=rand()%n+1;
    REP(i,1,n){
        T=rand()%lim+1;random_shuffle(a+1,a+1+n);
        printf("%d",T);
        REP(j,1,T)printf(" %d",a[j]);
        putchar('\n');
    }
    REP(i,1,n)printf("%d ",rand()%60-35);
    fclose(stdin),fclose(stdout);
    return 0;
}
