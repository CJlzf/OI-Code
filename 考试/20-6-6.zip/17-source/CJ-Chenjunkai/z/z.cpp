#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <string>
#include <cstring>
#include <algorithm>
#define RG register
#define File(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout)
const int N = 10000;

using namespace std;

int gi(){
	RG char ch=getchar();RG int x=0,q=0;
	while(ch<'0' || ch>'9') { if (ch=='-') q=1; ch=getchar(); }
	while(ch>='0' && ch<='9') x=x*10+ch-'0',ch=getchar();
	return q?(-x):x;
}

int w[N],f[N],p[N],n,t,ans;

inline int check(int s){
	int g=0;
	while(s){
		g+=(s&1);
		s>>=1;
	}
	return g;
}

inline void dfs(int x,int sum,int s,int v){
	if (x>n){
		if (v>=ans) return;
		if (check(sum)==s) ans=v;
		return;
	}
	dfs(x+1,sum|p[x],s+1,v+w[x]);
	dfs(x+1,sum,s,v);
	return;
}

int main(){
	File("z");
	n=gi(); int x;
	for (RG int i=1; i<=n; ++i){
		f[i]=t=gi();
		for (RG int j=1; j<=t; ++j){
			x=gi();
			p[i]|=(1<<(x-1));
		}
	}
	for (RG int i=1; i<=n; ++i) w[i]=gi();
	dfs(1,0,0,0);
	printf("%d\n",ans);
	return 0;
}
