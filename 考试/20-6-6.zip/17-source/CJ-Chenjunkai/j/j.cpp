#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <string>
#include <cstring>
#include <algorithm>
#define RG register
#define File(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout)
const int N = 1000000;

using namespace std;

inline int gi(){
	RG char ch=getchar();RG int x=0,q=0;
	while(ch<'0' || ch>'9') { if (ch=='-') q=1; ch=getchar(); }
	while(ch>='0' && ch<='9') x=x*10+ch-'0',ch=getchar();
	return q?(-x):x;
}

int L[N],R[N],nn[N][3],head[N],id[N],mx[N],cnt,block,dis[N],sum[N],f[N],bl[N],siz[N];

inline void dfs(int x,int fa){
	id[x]=++cnt,siz[cnt]=1;
	for (RG int i=head[x]; i; i=nn[i][0]){
		if (nn[i][1]==fa) continue;
		dis[cnt+1]=dis[id[x]]+nn[i][2];
		dfs(nn[i][1],x);
		siz[id[x]]+=siz[id[nn[i][1]]];
	}
	mx[x]=cnt; return;
}

int main(){
	File("j");
	int n=gi(),m=gi(),len=gi(),p,x,y,k,l,r,u,v,s,mid;
	block=pow(n,0.6);
	for (RG int i=2; i<=n; ++i){
		x=gi();
		nn[++cnt][1]=i,nn[cnt][2]=gi(),nn[cnt][0]=head[x],head[x]=cnt;
	}
	cnt=0,dfs(1,0);
	for (RG int i=1; i<=n; ++i){
		bl[i]=i/block+1,f[i]=dis[i];
		if (L[bl[i]]==0) L[bl[i]]=i;
		if (R[bl[i]]<i)  R[bl[i]]=i;
	}
	x=n/block+1;
	for (RG int i=1; i<=x; ++i) sort(f+L[i],f+R[i]+1);
	for (RG int i=1; i<=m; ++i){
		p=gi(),x=gi(),y=mx[x],x=id[x],k=gi();
		l=bl[x]+1,r=bl[y]-1;
		if (p==1){
			if (siz[x]<k) { printf("-1\n"); continue; }
			if (bl[x]==bl[y]){
				u=0,v=N;
				while(u<v){
					s=0,mid=(u+v)>>1;
					for (RG int j=x; j<=y; ++j) s+=((dis[j]+sum[bl[x]])<=mid?1:0);
					if (s>=k) v=mid;
					else u=mid+1;
				}
				printf("%d\n",u);
				continue;
			}
			u=0,v=N;
			while(u<v){
				s=0,mid=(u+v)>>1;
				for (RG int j=l; j<=r; ++j) s+=(upper_bound(f+L[j],f+R[j]+1,mid-sum[j])-f-L[j]);
				for (RG int j=x; j<=R[bl[x]]; ++j) s+=((dis[j]+sum[bl[x]])<=mid?1:0);
				for (RG int j=L[bl[y]]; j<=y; ++j) s+=((dis[j]+sum[bl[y]])<=mid?1:0);
				if (s>=k) v=mid;
				else u=mid+1;
			}
			printf("%d\n",u);
		}
		else{
			if (bl[x]==bl[y]){
				for (RG int j=x; j<=y; ++j) dis[j]+=k;
				for (RG int j=L[bl[x]]; j<=R[bl[x]]; ++j) f[j]=dis[j];
				sort(f+L[bl[x]],f+R[bl[x]]+1);
				continue;
			}
			for (RG int j=l; j<=r; ++j) sum[j]+=k;
			l=x,r=R[bl[x]];
			for (RG int j=l; j<=r; ++j) dis[j]+=k;
			for (RG int j=L[bl[l]]; j<=r; ++j) f[j]=dis[j];
			sort(f+L[bl[l]],f+r+1);
			l=L[bl[y]],r=y;
			for (RG int j=l; j<=r; ++j) dis[j]+=k;
			for (RG int j=l; j<=R[bl[r]]; ++j) f[j]=dis[j];
			sort(f+l,f+R[bl[r]]+1);
		}
	}
	return 0;
}
