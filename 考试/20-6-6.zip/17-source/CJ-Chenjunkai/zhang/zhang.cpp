#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <string>
#include <cstring>
#include <algorithm>
#define RG register
#define File(a) freopen(a".in","r",stdin),freopen(a".out","w",stdout)

using namespace std;

int gi(){
	RG char ch=getchar();RG int x=0;
	while(ch<'0' || ch>'9') ch=getchar();
	while(ch>='0' && ch<='9') x=x*10+ch-'0',ch=getchar();
	return x;
}

int main(){
	File("zhang");
	cout<<12;
	return 0;
}
