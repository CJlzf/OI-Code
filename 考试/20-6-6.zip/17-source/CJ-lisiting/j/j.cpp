#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<queue>
#include<set>
#include<algorithm>
#define fre(z) freopen(z".in","r",stdin),freopen(z".out","w",stdout)
#define LL long long
#define md double
#define RG register
#define IL inline
using namespace std;
const int inf=2147483647;
const int N=1005;
inline int gi() {
    RG int w=0;
    RG bool q=1;
    RG char c=getchar();
    while ((c<'0'||c>'9') && c!='-') c=getchar();
    if (c=='-') q=0,c=getchar();
    while (c>='0'&&c <= '9') w=w*10+c-'0',c=getchar();
    return q? w:-w;
}
int n,m,len,num=0,tim=0,ord;
int val[N]={0},fa[N]={0},head[N]={0},edge[2*N][2]={0};
int st[N]={0},ed[N]={0};
struct node {int v,id;} f[N]={0};
IL void addedge(RG int u,RG int v)
{
	edge[++num][0]=v;edge[num][1]=head[u];head[u]=num;
	edge[++num][0]=u;edge[num][1]=head[v];head[v]=num;
}
IL void dfs(RG int p,RG int d)
{
	st[p]=++tim,f[tim].id=p,f[tim].v=d+val[p];
	for(RG int i=head[p];i;i=edge[i][1])
		if(edge[i][0]!=fa[p]) dfs(edge[i][0],d+val[p]);
	ed[p]=tim;
}
IL int cmp1(RG node x,RG node y){return x.v<y.v;}
IL int cmp2(RG node x,RG node y){return x.id<y.id;}
IL void work1()
{
	RG int x,k;
	for(RG int i=2;i<=n;++i)
		fa[i]=gi(),addedge(fa[i],i),val[i]=gi();
	dfs(1,0);
	for(;m;--m)
		{
			ord=gi();x=gi(),k=gi();
			if(ord==2)
				for(RG int i=st[x];i<=ed[x];++i)
					f[i].v+=k;
			else
				{
					if(ed[x]-st[x]+1<k){printf("-1\n");continue;}
					sort(f+st[x],f+ed[x]+1,cmp1);
					printf("%d\n",f[st[x]+k-1].v);
					sort(f+st[x],f+ed[x]+1,cmp2);
				}
		}
}
int main()
{
    fre("j");
    n=gi(),m=gi(),len=gi();
	if(n<=1000)work1();
    return 0;
}
