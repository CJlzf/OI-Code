#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<queue>
#include<set>
#include<algorithm>
#define fre(z) freopen(z".in","r",stdin),freopen(z".out","w",stdout)
#define LL long long
#define md double
#define RG register
#define IL inline
#define S 701
#define T 702
#define SS 703
#define TT 704
using namespace std;
const int inf=2147483647;
const int N=705;
inline int gi() {
    RG int w=0;
    RG bool q=1;
    RG char c=getchar();
    while ((c<'0'||c>'9') && c!='-') c=getchar();
    if (c=='-') q=0,c=getchar();
    while (c>='0'&&c <= '9') w=w*10+c-'0',c=getchar();
    return q? w:-w;
}
int n,ans=0,sum,cnt1,cnt2;
int c[N]={0},map[N][N]={0},val[N]={0};
int que[N*N]={0},h,t;
int num;int head[2*N],edge[N*N*4][5]={0};
int p[N]={0},a[N]={0},dis[N]={0};
int inq[N]={0};
IL void work1()
{
	for(RG int s=1;s<=(1 << n)-1;++s)
		{
			sum=0;cnt1=0,cnt2=0;
			for(RG int i=1;i<=n;++i)
				if((s >> (i-1))&1)sum+=val[i],cnt1+=1;
			if(sum>=ans)continue;
			memset(c,0,sizeof(c));
			for(RG int i=1;i<=n;++i)
				{
					if((s >> (i-1))&1)
						for(RG int j=1;j<=n;++j)
							if(map[i][j])c[j]=1;
				}
			for(RG int i=1;i<=n;++i)
				if(c[i])cnt2+=1;
			if(cnt2==cnt1) ans=min(ans,sum);
		}
	printf("%d\n",ans);
}
IL void work2()
{
	for(RG int i=1;i<=n;++i)
		sum+=val[i];
	printf("%d\n",sum);
}
IL void myclear()
{
	num=-1;
	memset(head,-1,sizeof(head));
}
IL void addedge(RG int u,RG int v,RG int cap,RG int s)
{
	edge[++num][0]=v;edge[num][1]=head[u];head[u]=num;edge[num][2]=cap,edge[num][3]=0;edge[num][4]=s;
	edge[++num][0]=u;edge[num][1]=head[v];head[v]=num;edge[num][2]=edge[num][3]=0;edge[num][4]=-s;
}
IL void build_map(RG int k)
{
	addedge(S,SS,n-k,0),addedge(TT,T,k,0);
	for(RG int i=1;i<=n;++i)
		addedge(SS,i,1,val[i]),addedge(i+n,TT,inf,0);
	for(RG int i=1;i<=n;++i)
		for(RG int j=1;j<=n;++j)
			if(map[i][j])addedge(i,j+n,inf,0);
}
IL int EK(RG int k)
{
	RG int flow=0;
    while(true)
		{
		memset(dis,0x3f3f3f3f,sizeof(dis));
		memset(a,0,sizeof(a));
		dis[S]=0,h=t=1,que[h]=S,inq[S]=1,a[S]=0x3f3f3f3f;
	    while(h<=t)
		{

			for(RG int i=head[que[h]];i!=-1;i=edge[i][1])
				{
					if(dis[edge[i][0]]>dis[que[h]]+edge[i][4]&&edge[i][3]<edge[i][2])
						{
							dis[edge[i][0]]=dis[que[h]]+edge[i][4];
							if(!inq[edge[i][0]])que[++t]=edge[i][0],inq[edge[i][0]]=1;
							p[edge[i][0]]=i;
							a[edge[i][0]]=min(edge[i][2]-edge[i][3],a[que[h]]);
						}
				}
			inq[que[h]]=0,h+=1;
		}
	if(!a[T])break;flow+=a[T];
	for(RG int i=p[T];i;i=p[edge[i^1][0]])
		edge[i][3]+=a[T],edge[i^1][3]-=a[T];
	}
	if(flow!=k)return 0;RG int sum=0;
	for(RG int i=head[SS];i!=-1;i=edge[i][1])
		{
			if(edge[i][0]<1||edge[i][0]>n)continue;
			if(edge[i][3]==edge[i][2]) sum+=val[edge[i][0]];
		}
	return sum;
}
IL void work3()
{
	for(RG int k=0;k<=n;++k)
		{
			myclear();
			build_map(k);
			ans=min(ans,EK(k));
		}
	printf("%d\n",ans);
}
int main()
{
    fre("z");
    n=gi();RG int flag=1;
	for(RG int i=1;i<=n;++i)
		for(RG int t=gi();t;--t)
			map[i][gi()]=1;
	for(RG int i=1;i<=n;++i)
		{
			val[i]=gi();
			if(val[i]>0) flag=0;
		}
	if(flag) work2();
	else if(n<=20) work1();
	else work3();
    return 0;
}
