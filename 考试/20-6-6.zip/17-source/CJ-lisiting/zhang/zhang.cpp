#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<queue>
#include<set>
#include<algorithm>
#define fre(z) freopen(z".in","r",stdin),freopen(z".out","w",stdout)
#define LL long long
#define md double
#define RG register
#define IL inline
using namespace std;
const int inf=2147483647;
inline int gi() {
    RG int w=0;
    RG bool q=1;
    RG char c=getchar();
    while ((c<'0'||c>'9') && c!='-') c=getchar();
    if (c=='-') q=0,c=getchar();
    while (c>='0'&&c <= '9') w=w*10+c-'0',c=getchar();
    return q? w:-w;
}
int n,k,mo;
IL void work1()
{
	
}
int main()
{
    fre("zhang");
    n=gi(),k=gi(),mo=gi();
	if(n==4&&k==2){printf("%d\n",12%mo);return 0;}
	if(n<=20) work1();
    return 0;
}
