#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <set>
using namespace std;

const int N=100010,Size=250;
typedef int  arr[N];
struct node{int x,ls,rs;}t[3000000];
struct edge{int s,t,d,n;}e[N];
int n,m,len,mx,ttot,tot;
arr h,dfn,dfnr,dfnn,dep,rt,bit,a,X;
set <int> S;
set <int> ::iterator It,End;

void bit_modify(int x,int k)
{
	for (; x<=n; x+=x&-x)  bit[x]+=k;
}

int bit_ask(int x)
{
	int s=0;
	for (; x; x-=x&-x)  s+=bit[x];
	return s;
}

void modify(int &n,int l,int r,int x)
{
	t[++ttot]=t[n],n=ttot,t[n].x++;
	int mid=(l+r)>>1;
	if (l!=r)  x<=mid?modify(t[n].ls,l,mid,x):modify(t[n].rs,mid+1,r,x);
}

int ask(int n,int l,int r,int L,int R)
{
	if (!n)  return 0;
	int mid=(l+r)>>1;
	if ((L<=l)&&(r<=R))  return t[n].x;
	else  if (mid>=R)  return ask(t[n].ls,l,mid,L,R);
	else  if (L>mid)  return ask(t[n].rs,mid+1,r,L,R);
	return ask(t[n].ls,l,mid,L,R)+ask(t[n].rs,mid+1,r,L,R);
}

void dfs(int x)
{
	dfn[x]=++tot,dfnn[tot]=x;
	for (int i=h[x],y; y=e[i].t,i; i=e[i].n)
		dep[y]=dep[x]+e[i].d,dfs(y);
	dfnr[x]=tot;
}

void build()
{
	S.clear(),len=ttot=0;
	for (int i=1; i<=n; i++)  bit[i]+=bit[i-(i&-i)];
	for (int i=1; i<=n; i++)  dep[i]+=bit[dfn[i]];
	for (int i=1; i<=n; i++)  bit[i]=0;
	for (int i=1; i<=n; i++)  if (dep[i]>len)  len=dep[i];
	mx=len;
	for (int i=1; i<=n; i++)
		rt[i]=rt[i-1],modify(rt[i],0,len,dep[dfnn[i]]);
}

void work()
{
	scanf("%d %d %d",&n,&m,&len);
	for (int i=2,f,x; i<=n; i++)
		scanf("%d %d",&f,&x),e[i]=(edge){f,i,x,h[f]},h[f]=i;
	dfs(1),build();
	for (int i=1,j,ty,x,k,l,r,Mid,s; i<=m; i++)
		{
			scanf("%d %d %d",&ty,&x,&k);
			if (ty==1)
				{
					if (k>dfnr[x]-dfn[x]+1)  {puts("-1");  continue;}
					It=S.lower_bound(dfn[x]),End=S.end(),tot=0;
					if ((It==End)||((*It)!=dfn[x]))  a[++tot]=dfn[x];
					while ((It!=End)&&((*It)<=dfnr[x]))  a[++tot]=*It,It++;
					for (j=1; j<=tot; j++)  X[j]=bit_ask(a[j]);
					l=-1,r=mx;
					while (r-l>1)
						{
							Mid=(l+r)>>1,s=0;
							if (Mid>=X[1])  s-=ask(rt[a[1]-1],0,len,0,Mid-X[1]);
							for (j=2; j<=tot; j++)
								if (X[j-1]<X[j])
									s+=ask(rt[a[j]-1],0,len,Mid-X[j]+1,Mid-X[j-1]);
								else  s-=ask(rt[a[j]-1],0,len,Mid-X[j-1]+1,Mid-X[j]);
							if (Mid>=X[tot])  s+=ask(rt[dfnr[x]],0,len,0,Mid-X[tot]);
							s>=k?r=Mid:l=Mid;
						}
					printf("%d\n",r+e[1].d);
				}else
				{
					e[x].d+=k;
					if (x==1)  continue;
					mx+=k,S.insert(dfn[x]),S.insert(dfnr[x]+1);
					bit_modify(dfn[x],k),bit_modify(dfnr[x]+1,-k);
					if (S.size()>=Size)  build();
				}
		}
}

int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	work();
	return 0;
}
