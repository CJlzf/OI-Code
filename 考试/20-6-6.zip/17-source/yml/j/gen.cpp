#include <bits/stdc++.h>
using namespace std;

int main()
{
	freopen("gen.data","r",stdin);
	int seed;
	scanf("%d",&seed),srand(seed+time(NULL));
	fclose(stdin);

	freopen("j.in","w",stdout);
	int n=1000,m=1000,len=10;
	printf("%d %d %d\n",n,m,len);
	for (int i=1; i<n; i++)  printf("%d %d\n",rand()%i+1,rand()%len+1);
	for (int i=1; i<=m; i++)
		if (rand()&1)  printf("1 %d %d\n",1,rand()%(n/1)+1);
		else  printf("2 %d %d\n",rand()%n+1,rand()%len+1);
	fclose(stdout);

	freopen("gen.data","w",stdout);
	printf("%d",rand());
	fclose(stdout);
	return 0;
}
