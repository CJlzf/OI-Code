#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;

const int N=100010,Size=100;
typedef int  arr[N];
struct edge{int s,t,d,n;}e[N];
int n,m,len,tot;
arr h,dfn,dfnr,dfnn,dep,a;

void dfs(int x,int d)
{
	dfn[x]=++tot,dfnn[tot]=x,dep[tot]=d;
	for (int i=h[x],y; y=e[i].t,i; i=e[i].n)
		dfs(y,d+e[i].d);
	dfnr[x]=tot;
}

void work()
{
	scanf("%d %d %d",&n,&m,&len);
	for (int i=2,f,x; i<=n; i++)
		scanf("%d %d",&f,&x),e[i]=(edge){f,i,x,h[f]},h[f]=i;
	dfs(1,0);
	for (int i=1,j,ty,x,k,tot; i<=m; i++)
		{
			scanf("%d %d %d",&ty,&x,&k);
			if (ty==1)
				{
					if (k>dfnr[x]-dfn[x]+1)  {puts("-1");  continue;}
					for (j=dfn[x],tot=0; j<=dfnr[x]; j++)  a[++tot]=dep[j];
					sort(a+1,a+tot+1);
					printf("%d\n",a[k]);
				}else
				{
					for (j=dfn[x]; j<=dfnr[x]; j++)  dep[j]+=k;
				}
		}
}

int main()
{
	freopen("j.in","r",stdin);
	freopen("bf.out","w",stdout);
	work();
	return 0;
}
