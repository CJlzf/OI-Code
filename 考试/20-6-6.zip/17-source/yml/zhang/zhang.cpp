#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;

int n,k,p,C[105][105],f[105][105];

void work()
{
	scanf("%d %d %d",&n,&k,&p);
	for (int i=0; i<=n; i++)
		{
			C[i][0]=1;
			for (int j=1; j<=i; j++)
				C[i][j]=(C[i-1][j-1]+C[i-1][j])%p;
		}
	f[1][1]=1;
	for (int i=2; i<=n; i++)
		for (int j=1; j<=i; j++)
			for (int k=1; k<i; k++)
				for (int l=0; l<=j&&l<=k; l++)
					f[i][j]=(f[i][j]+1LL*f[i-k][j-l]*f[k][k-l]%p*C[i-2][k-1]%p*k)%p;
	printf("%d",f[n][k]);
}

int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	work();
	return 0;
}
