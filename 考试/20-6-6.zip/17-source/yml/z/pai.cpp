#include <bits/stdc++.h>
using namespace std;

int main()
{
	int t=0;
	while (++t)
		{
			printf("%d : ",t);
			system("./gen");
			system("./z");
			system("./bf");
			if (system("diff z.out bf.out"))
				printf("WA\n"),exit(0);
			printf("AC\n");
		}
	return 0;
}
