#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;

const int N=305,oo=1<<30;
typedef int  arr[N];
struct edge{int s,t,n;}e[N*N];
struct Edge{int s,t,c,n;}E[2*(N*N+N)];
int n,ans;
arr h,p,vis,lm,rm;

namespace Dinic{
	struct edge{int s,t,c,n;}e[2*(N*N+N)];
	arr h,H,dis,Q;
	int tot=1,S,T;

	void addedge(int s,int t,int c)
	{
		e[++tot]=(edge){s,t,c,h[s]},h[s]=tot;
		e[++tot]=(edge){t,s,0,h[t]},h[t]=tot;
	}

	bool BFS(int s,int t)
	{
		int x,y,i,l=1,r=0;
		for (i=1; i<=T; i++)  H[i]=h[i],dis[i]=oo;
		dis[s]=0,Q[++r]=s;
		while (l<=r)
			for (i=h[x=Q[l++]]; y=e[i].t,i; i=e[i].n)
				if ((e[i^1].c)&&(dis[y]==oo))
					{
						dis[y]=dis[x]+1,Q[++r]=y;
						if (y==t)  return 1;
					}
		return 0;
	}

	int DFS(int x,int a)
	{
		if (x==T)  return a;
		int flow=0;
		for (int &i=H[x],y,t; y=e[i].t,i; i=e[i].n)
			if ((e[i].c)&&(dis[y]+1==dis[x])&&(t=DFS(y,min(a,e[i].c))))
				if (e[i].c-=t,e[i^1].c+=t,flow+=t,!(a-=t))
					return flow;
		dis[x]=oo;
		return flow;
	}
}

bool dfs1(int x)
{
	if (vis[x]==vis[0])  return 0;
	vis[x]=vis[0];
	for (int i=h[x],y; y=e[i].t,i; i=e[i].n)
		if ((!rm[y])||(dfs1(rm[y])))
			{lm[x]=y,rm[y]=x;  return 1;}
	return 0;
}

void dfs2(int x)
{
	if (vis[x]==vis[0])  return;
	vis[x]=vis[0];
	for (int i=h[x],y; y=e[i].t,i; i=e[i].n)
		if (y!=lm[x])  dfs2(rm[y]);
}

void work()
{
	scanf("%d",&n),Dinic::S=n+1,Dinic::T=n+2;
	for (int i=1,m,x,tot=0; i<=n; i++)
		{
			scanf("%d",&m);
			for (int j=1; j<=m; j++)
				scanf("%d",&x),e[++tot]=(edge){i,x,h[i]},h[i]=tot;
		}
	for (int i=1; i<=n; i++)
		{
			scanf("%d",&p[i]);
			if (p[i]<0)  Dinic::addedge(Dinic::S,i,-p[i]),ans+=p[i];
			else  Dinic::addedge(i,Dinic::T,p[i]);
		}
	for (int i=1; i<=n; i++)  vis[0]++,dfs1(i);
	for (int i=1; i<=n; i++)
		{
			vis[0]++,dfs2(i);
			for (int j=1; j<=n; j++)
				if ((vis[j]==vis[0])&&(i!=j))
					Dinic::addedge(i,j,oo);
		}
	while (Dinic::BFS(Dinic::T,Dinic::S))  ans+=Dinic::DFS(Dinic::S,oo);
	printf("%d",ans);
}

int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	work();
	return 0;
}
