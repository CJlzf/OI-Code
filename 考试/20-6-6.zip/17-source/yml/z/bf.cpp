#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;

int n,a[305],p[305],cnt[1<<16],ans,res;

int Count(int x){return cnt[x>>16]+cnt[x&65535];}

void work()
{
	scanf("%d",&n);
	for (int i=0,m,x; i<n; i++)
		{
			scanf("%d",&m);
			for (int j=0; j<m; j++)  scanf("%d",&x),a[i]|=1<<(x-1);
		}
	for (int i=0; i<n; i++)  scanf("%d",&p[i]),res+=(p[i]<=0);
	if (res==n)
		{
			for (int i=0; i<n; i++)  ans+=p[i];
			printf("%d",ans);
			return;
		}
	for (int i=1; i<65536; i++)  cnt[i]=cnt[i/2]+(i&1);
	for (int i=(1<<n)-1,j,s; i; i--)
		{
			for (s=0,j=0; j<n; j++)  if (i&(1<<j))  s|=a[j];
			if (Count(i)==Count(s))
				{
					for (s=0,j=0; j<n; j++)  if (i&(1<<j))  s+=p[j];
					if (s<ans)  ans=s;
				}
		}
	printf("%d",ans);
}

int main()
{
	freopen("z.in","r",stdin);
	freopen("bf.out","w",stdout);
	work();
	return 0;
}
