#include <bits/stdc++.h>
using namespace std;

int a[305],e[305][305];

int main()
{
	freopen("gen.data","r",stdin);
	int seed;
	scanf("%d",&seed),srand(seed+time(NULL));
	fclose(stdin);

	freopen("z.in","w",stdout);
	int n=300,m=rand()%(n*n);
	for (int i=1; i<=n; i++)  a[i]=i,e[i][i]=1;
	for (int i=1; i<=m; i++)  e[rand()%n+1][rand()%n+1]=1;
	random_shuffle(a+1,a+n+1);
	printf("%d\n",n);
	for (int i=1,j,tot; i<=n; i++)
		{
			for (j=1,tot=0; j<=n; j++)  tot+=e[i][j];
			printf("%d ",tot);
			for (j=1; j<=n; j++)  if (e[i][j])  printf("%d ",a[j]);
			puts("");
		}
	for (int i=1; i<=n; i++)  printf("%d ",rand()%int(2e3+1)-int(1e3));
	fclose(stdout);

	freopen("gen.data","w",stdout);
	printf("%d",rand());
	fclose(stdout);
	return 0;
}
