#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<ctime>
using namespace std;

inline int getint()
{
	static bool f; static char c; static int x;
	f=0,x=0; do {c=getchar();if(c=='-') f=1;} while(c<'0'||c>'9');
	while(c>='0'&&c<='9') {x=x*10+c-'0';c=getchar();} 
	if(f) return -x; return x;
}

const int maxn=302;
vector<int>A[maxn];
int n,p[maxn],ans,vis[maxn];

int now,tot;
void dfs(int u)
{
	static int i,j;
	if(u>n) {
		for(i=1,j=0;i<=n;++i)
			if(vis[i]) ++j;
		if(j==tot) ans=min(ans,now);
		return;
	}
	++tot; now+=p[u];
	for(i=0,j=A[u].size();i<j;++i)
		++vis[A[u][i]];
	dfs(u+1);
	
	--tot; now-=p[u];
	for(i=0,j=A[u].size();i<j;++i)
		--vis[A[u][i]];
	dfs(u+1);
}

int main()
{
	freopen("z.in","r",stdin),freopen("z.out","w",stdout);
	n=getint(); int i,j,flag=0,S=0;
	for(i=1;i<=n;++i) {
		j=getint();
		while(j--) A[i].push_back(getint());
	}
	for(i=1;i<=n;++i) {
		p[i]=getint(); S+=p[i];
		if(p[i]>0) flag=1;
	}
	if(!flag) printf("%d\n",S);
	else dfs(1),printf("%d\n",ans);
	return 0;
}
