#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<ctime>
using namespace std;

inline int getint()
{
	static bool f; static char c; static int x;
	f=0,x=0; do {c=getchar();if(c=='-') f=1;} while(c<'0'||c>'9');
	while(c>='0'&&c<='9') {x=x*10+c-'0';c=getchar();} 
	if(f) return -x; return x;
}

const int maxn=100002;
int id[maxn];
int in[maxn],out[maxn];
int n,f[maxn],dep[maxn];
struct node{
	int to,v;
	node(int to,int v):to(to),v(v){}
}tmp(0,0);
vector<node>E[maxn];

void dfs(int u)
{
	static int index;
	in[u]=++index; id[index]=u;
	for(int i=0,j=E[u].size();tmp=E[u][i],i<j;++i)
		if(tmp.to!=f[u]) {
			dep[tmp.to]=dep[u]+tmp.v;
			f[tmp.to]=u; dfs(tmp.to);
		}
	out[u]=index;
}
void ask(int x,int k)
{
	static int q[maxn],i,j;
	for(i=in[x],j=0;i<=out[x];++i)
		q[++j]=dep[id[i]];
	if(j<k) printf("-1");
	else {
		nth_element(q+1,q+k+1,q+j+1);
		printf("%d",q[k]);
	} printf("\n");
}
int V;
void updata(int u)
{
	for(int i=0,j=E[u].size();tmp=E[u][i],i<j;++i)
		if(tmp.to!=f[u]) {
			dep[tmp.to]+=V;
			updata(tmp.to);
		}
}

int main()
{
	freopen("j.in","r",stdin),freopen("j.out","w",stdout);
	n=getint();int T=getint(); getint();
	int i,j;
	for(i=2;i<=n;++i) {
		j=getint(),V=getint();
		E[i].push_back(node(j,V));
		E[j].push_back(node(i,V));
	}
	dfs(1);
	while(T--) {
		V=getint(),i=getint(),j=getint();
		switch(V) {
		case 1: ask(i,j); break;
		default: dep[i]+=j; V=j,updata(i);
		}
	}
	return 0;
}
