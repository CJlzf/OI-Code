#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<ctime>
using namespace std;

inline int getint()
{
	static bool f; static char c; static int x;
	f=0,x=0; do {c=getchar();if(c=='-') f=1;} while(c<'0'||c>'9');
	while(c>='0'&&c<='9') {x=x*10+c-'0';c=getchar();} 
	if(f) return -x; return x;
}

typedef long long LL;
const int maxn=50000;
int n,K,mod;
inline int add(int a,int b) {a+=b; return a>=mod?a-mod:a;}
inline int red(int a,int b) {a-=b; return a<0?a+mod:a;}
inline int mul(int a,int b) {return (LL)a*b%mod;}
inline int pow(int d,int k)
{
	static int ans;
	ans=1; while(k) {
		if(k&1) ans=mul(ans,d);
		k>>=1; d=mul(d,d);
	} return ans;
}

int dp[102][102][102];
inline void solve1()
{
	dp[1][1][1]=1;
	int i,j,k,ans=0;
	for(i=2;i<=n;++i)
		for(j=i;j<=n;++j)
			for(k=1;k<=K;++k)
				if(i&1) dp[i][j][k]=mul(add(dp[i][j-1][k-1],dp[i-1][j-1][k-1]),n-j+1);
				else dp[i][j][k]=mul(add(dp[i][j-1][k],dp[i-1][j-1][k]),n-j+1);
	for(i=1;i<=n;++i) ans=add(ans,dp[i][n][K]); printf("%d\n",ans);
}
inline void solve2()
{
}
	
int main()
{
	freopen("zhang.in","r",stdin),freopen("zhang.out","w",stdout);
	n=getint(),K=getint(),mod=getint();
	if(n<=100) solve1(); else solve2();
	return 0;
}
