#include<bits/stdc++.h>
#define N 1000005
#define LL long long
using namespace std;
int n,m,mo; LL fc[N],xf[N],ans;
LL fpm(LL x,LL y){ LL s=1; while(y){ if(y&1) s=(s*x)%mo; y>>=1,x=(x*x)%mo;} return s;}
LL C(int n,int m){ return fc[n]*xf[m]%mo*xf[n-m]%mo;}
int main()
{
	int i;
	freopen("zhang.in","r" , stdin);
	freopen("zhang.out","w",stdout);
	cin>>n>>m>>mo;
	if(m==0||m>=n){ printf("0"); return 0;}
	fc[0]=xf[0]=1;
	for(i=1;i<=n;i++)
		fc[i]=(fc[i-1]*i)%mo;
	xf[n]=fpm(fc[n],mo-2);
	for(i=n-1;i>=0;i--)
		xf[i]=(xf[i+1]*(i+1))%mo;
	ans=C(n-1,m-1),n-=m;
	ans=ans*fpm(n,m-1)%mo*fpm(m,n-1)%mo;
	cout<<ans;
	return 0;
}
