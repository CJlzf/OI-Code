#include<bits/stdc++.h>
using namespace std;
int n=30000,m=30000;
int main()
{
	int i; srand(time(NULL));
	freopen("j.in","w",stdout);
	printf("%d %d 10\n",n,m);
	for(i=2;i<=n;i++)
		printf("%d %d\n",rand()%(i-1)+1,rand()%10+1);
	for(i=1;i<=m;i++){
		int op=rand()%2+1,x=rand()%n+1;
		printf("%d %d ",op,x);
		if(op==1) printf("%d\n",rand()%50+1);
		else printf("%d\n",rand()%10+1);
	  }
	return 0;
}
