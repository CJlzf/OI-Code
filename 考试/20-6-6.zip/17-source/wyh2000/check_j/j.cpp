#include<bits/stdc++.h>
#include<vector>
#define L(__) (__ << 1)
#define R(__) (L(__)|1)
#define N 100005
#define V 20
using namespace std;
int w[N],lw,cnt;
vector<int> G[N],E[N],A[N]; int up,b[N],c[N],tag[N];
int n,m,q,f[N],a[N],lt[N],rt[N],op[N],x[N],k[N],clk;
void dfs(int t,int s)
{
	int i; a[++cnt]=s,lt[t]=cnt;
	for(i=0;i<G[t].size();i++)
	  dfs(G[t][i],s+E[t][i]);
	rt[t]=cnt;
}
void DFS(int t,int p)
{
	int i;
	if(tag[t]==clk) p=t,w[++lw]=t;
	A[p].push_back(a[lt[t]]);
	for(i=0;i<G[t].size();i++)
		DFS(G[t][i],p);
}
void Ask(int t,int k)
{
	int i,s,l=0,r=up+1,mid;
  while(r-l>1){
		mid=(l+r)>>1,s=0;
		for(i=1;i<=lw;i++)
			if(lt[w[i]]>=lt[t]&&lt[w[i]]<=rt[t])
				s+=upper_bound(A[w[i]].begin(),A[w[i]].end(),mid-c[w[i]])-A[w[i]].begin();
		if(s>=k) r=mid; else l=mid;
	  }
	printf("%d\n",r);
}
int main()
{
	int i,j,l,u,v;
	freopen("j.in","r" , stdin);
	freopen("j.out","w",stdout);
	scanf("%d %d %d",&n,&q,&m);
	for(i=2;i<=n;i++){
		scanf("%d %d",&u,&v),f[i]=u;
		G[u].push_back(i);
		E[u].push_back(v);
	  }
	dfs(1,0);
	for(i=0;i<q;i++){
		scanf("%d %d %d",&op[i],&x[i],&k[i]);
		if(op[i]==2)
			b[lt[x[i]]]+=k[i],b[rt[x[i]]+1]-=k[i];
	  }
	for(i=1;i<=n;i++) b[i]+=b[i-1];
	for(i=1;i<=n;i++) up=max(up,a[i]+b[i]);
	for(i=0;i<q;i+=V){
		tag[1]=++clk,lw=0;
		for(j=1;j<=n;j++) c[j]=b[j]=0,E[j].clear();
		for(j=i;j<i+V&&j<q;j++)
			if(op[j]==2) tag[x[j]]=clk;
		DFS(1,1);
		for(j=1;j<=lw;j++)
			sort(A[w[j]].begin(),A[w[j]].end());
		for(j=i;j<i+V&&j<q;j++)
			if(op[j]==2){
			  for(l=1;l<=lw;l++)
					if(lt[w[l]]>=lt[x[j]]&&lt[w[l]]<=rt[x[j]])
						c[w[l]]+=k[j];
				b[lt[x[j]]]+=k[j];
				b[rt[x[j]]+1]-=k[j];
			  }
			else{
				if(rt[x[j]]-lt[x[j]]+1>=k[j]) Ask(x[j],k[j]);
				else printf("-1\n");
			  }
		for(j=1;j<=n;j++) b[j]+=b[j-1],a[j]+=b[j];
	  }
	return 0;
}
