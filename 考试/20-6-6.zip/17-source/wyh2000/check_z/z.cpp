#include<bits/stdc++.h>
#include<vector>
#include<queue>
#define N 305
#define M 200005
#define oo (1<<29)
using namespace std;
vector<int> G[N]; int vis[N],mp[N],clk,a[N];
int n,len=1,head[N],d[N],next[M],num[M],cap[M],ans,S,T;
void link(int x,int y,int z)
{
	num[++len]=y,cap[len]=z,next[len]=head[x],head[x]=len;
	num[++len]=x,cap[len]=0,next[len]=head[y],head[y]=len;
}
bool match(int t)
{
	int i,x,q;
	for(i=0;i<G[t].size();i++){
		if(vis[x=G[t][i]]==clk) continue;
		vis[x]=clk,q=mp[x],mp[x]=t;
		if(!q||match(q)) return 1;
		mp[x]=q;
	  }
	return 0;
}
bool bfs()
{
	int i,x; queue<int> Q;
	for(i=1;i<=T;i++) d[i]=0;
	d[S]=1,Q.push(S);
	while(!Q.empty()){
		x=Q.front(),Q.pop();
		for(i=head[x];i;i=next[i])
			if(cap[i]&&!d[num[i]]){
				d[num[i]]=d[x]+1;
				Q.push(num[i]);
			  }
	  }
	return d[T]>0;
}
int dfs(int t,int mini)
{
	int i,res,ans=0;
	if(t==T||!mini) return mini;
	for(i=head[t];i;i=next[i])
		if(cap[i]&&d[num[i]]==d[t]+1){
			res=dfs(num[i],min(mini,cap[i]));
			ans+=res,mini-=res,cap[i]-=res,cap[i^1]+=res;
			if(!mini) return ans;
		  }
	d[t]=oo; return ans;
}
int main()
{
	int i,j,x,y;
	freopen("z.in","r" , stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d",&x);
		for(j=1;j<=x;j++)
			scanf("%d",&y),G[i].push_back(y);
	  }
	for(i=1;i<=n;i++) scanf("%d",&a[i]),a[i]=-a[i];
	for(i=1;i<=n;i++)
		++clk,match(i);
	S=n+1,T=S+1;
	for(i=1;i<=n;i++)
		for(j=0;j<G[i].size();j++)
			link(i,mp[G[i][j]],oo);
	for(i=1;i<=n;i++)
		if(a[i]>=0) link(S,i,a[i]),ans+=a[i];
		else link(i,T,-a[i]);
	while(bfs()) ans-=dfs(S,oo);
	printf("%d",-ans);
	return 0;
}
