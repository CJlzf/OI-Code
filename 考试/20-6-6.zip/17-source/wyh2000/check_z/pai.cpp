#include<bits/stdc++.h>
using namespace std;
int cnt;
int main()
{
	while(1){
		system("./mk");
		system("./ck");
		system("./z");
		if(system("diff z.out ck.out")){
			printf("Wrong Answer\n");
			return 0;
		  }
		else printf("Accept %d\n",++cnt);
	  }
	return 0;
}
