#include<bits/stdc++.h>
#define N 305
using namespace std;
int n=22,a[N],b[N];
int R(){ return (rand()%1000000)*(rand()&1 ? -1 : 1);}
int main()
{
	int i,j; srand(time(NULL));
	freopen("z.in","w",stdout);
	for(i=1;i<=n;i++) a[i]=i;
	random_shuffle(a+1,a+n+1);
	printf("%d\n",n);
	for(i=1;i<=n;i++){
		for(j=1;j<=n;j++) b[j]=(rand()%6==0);
		b[a[i]]=1;
		int cnt=0;
		for(j=1;j<=n;j++) cnt+=b[j];
		printf("%d ",cnt);
		for(j=1;j<=n;j++)
			if(b[j])
				printf("%d ",j);
		printf("\n");
	  }
	for(i=1;i<=n;i++)
		printf("%d ",R());
	return 0;
}
