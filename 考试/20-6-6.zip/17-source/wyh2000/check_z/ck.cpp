#include<bits/stdc++.h>
#define N 305
#define oo (1<<30)
using namespace std;
int n,ans=oo,S[1<<23],G[1<<23],bt[1<<23];
int main()
{
	int i,j,x,y;
	freopen("z.in","r" , stdin);
	freopen("ck.out","w",stdout);
	cin>>n;
	for(i=0;i<n;i++){
		scanf("%d",&x);
		for(j=1;j<=x;j++){
			scanf("%d",&y),y--;
			G[1<<i]|=(1<<y);
		  }
	  }
	for(i=0;i<n;i++) scanf("%d",&S[1<<i]);
	for(i=1;i<(1<<n);i++){
		bt[i]=bt[i-(i&(-i))]+1;
		S[i]=S[i-(i&(-i))]+S[i&(-i)];
		G[i]=G[i-(i&(-i))]|G[i&(-i)];
	  }
	for(i=0;i<(1<<n);i++)
		if(bt[G[i]]==bt[i])
			ans=min(ans,S[i]);
	cout<<ans;
	return 0;
}
