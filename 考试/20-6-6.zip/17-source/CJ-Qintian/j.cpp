#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
#include<cmath>
using namespace std;
const int N=300050;
int gi() {
	int x=0,flag=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-') {
			flag=-1;
		}
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();
	return x*flag;
}
int n,m,deep[N],dfn[N],ed[N],tt;
int head[N],to[N],nxt[N],c[N],len,cnt,pre,id[N],b[N],tt2;
int L[N],R[N],add[N],pos[N],block;
vector<int>p[N];
inline void lnk(int x,int y,int z) {
	to[++cnt]=y,c[cnt]=z,nxt[cnt]=head[x],head[x]=cnt;
	to[++cnt]=x,c[cnt]=z,nxt[cnt]=head[y],head[y]=cnt;
}
inline void dfs(int x,int fa) {
	dfn[x]=++tt;
	id[tt]=x;
	for(int i=head[x]; i; i=nxt[i]) {
		int y=to[i];
		if(y!=fa) deep[y]=deep[x]+c[i],dfs(y,x);
	}
	ed[x]=tt;
}
inline void update(int l,int r,int k) {
	if(pos[l]==pos[r]) {
		p[pos[l]].clear();
		for(int i=l; i<=r; i++) deep[id[i]]+=k;
		for(int i=L[pos[l]]; i<=R[pos[l]]; i++) p[pos[l]].push_back(deep[id[i]]);
		sort(p[pos[l]].begin(),p[pos[r]].end());
	} else {
		for(int i=pos[l]+1; i<=pos[r]-1; i++) add[i]+=k;
		p[pos[l]].clear();
		for(int i=l; i<=R[pos[l]]; i++) deep[id[i]]+=k;
		for(int i=L[pos[l]]; i<=R[pos[l]]; i++) p[pos[l]].push_back(deep[id[i]]);
		sort(p[pos[l]].begin(),p[pos[l]].end());
		p[pos[r]].clear();
		for(int i=L[pos[r]]; i<=r; i++) deep[id[i]]+=k;
		for(int i=L[pos[r]]; i<=R[pos[r]]; i++) p[pos[r]].push_back(deep[id[i]]);
		sort(p[pos[r]].begin(),p[pos[r]].end());
	}
}
int find(int x,int pl,int y) {
	int l=0,r=p[pl].size()-1,ret=1;
	while(l<=r) {
		int mid=(l+r)>>1;
		if(p[pl][mid]+y>x) ret=mid,r=mid-1;
		else l=mid+1;
	}
	return ret;
}
bool check(int l,int r,int mid,int k) {
	int ret=0;
	if(pos[l]==pos[r]) {
		p[n+1].clear();
		for(int i=l; i<=r; i++) p[n+1].push_back(deep[id[i]]);
		sort(p[n+1].begin(),p[n+1].end());
		ret+=find(mid,n+1,add[pos[l]]);
	} else {
		for(int i=pos[l]+1; i<=pos[r]-1; i++) ret+=find(mid,i,add[i]);
		p[n+1].clear();
		for(int i=L[pos[l]]; i<=R[pos[l]]; i++) p[n+1].push_back(deep[id[i]]);
		sort(p[n+1].begin(),p[n+1].end());
		ret+=find(mid,n+1,add[pos[l]]);
		p[n+2].clear();
		for(int i=L[pos[r]]; i<=R[pos[r]]; i++) p[n+2].push_back(deep[id[i]]);
		sort(p[n+2].begin(),p[n+2].end());
		ret+=find(mid,n+2,add[pos[r]]);
	}
	return ret>=k;
}
inline int query(int l,int r,int k) {
	int l1=0,r1=1000000,ret=0;
	if(r-l+1<k) return -1;
	while(l1<=r1) {
		int mid=(l1+r1)>>1;
		if(check(l,r,mid,k)) ret=mid,r1=mid-1;
		else l1=mid+1;
	}
	return ret;
}
int main() {
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	n=gi(),m=gi(),len=gi();
	for(int i=2; i<=n; i++) {
		int x=gi(),y=gi();
		lnk(i,x,y);
	}
	dfs(1,0);
	if(m<=1000&&n<=1000) {
		for(int i=1; i<=m; i++) {
			int flag=gi();
			if(flag==1) {
				int x=gi(),k=gi(),tot=0;
				for(int j=dfn[x]; j<=ed[x]; j++) {
					b[++tot]=deep[id[j]];
				}
				if(tot<k) puts("-1");
				else {
					sort(b+1,b+1+tot);
					printf("%d\n",b[k]);
				}
			} else if(flag==2) {
				int x=gi(),k=gi();
				for(int j=dfn[x]; j<=ed[x]; j++) {
					deep[id[j]]+=k;
				}
			}
		}
	} else {
		block=sqrt(n);
		for(int i=1; i<=n; i++) pos[i]=(i-1)/block+1;
		tt2=n/block;
		if(n%block) tt2++;
		for(int i=1; i<=tt2; i++) {
			L[i]=(i-1)*block+1,R[i]=i*block;
		}
		R[tt2]=n;
		for(int i=1; i<=tt2; i++) {
			for(int j=L[i]; j<=R[i]; j++) {
				p[i].push_back(deep[id[j]]);
			}
			sort(p[i].begin(),p[i].end());
		}
		for(int i=1; i<=m; i++) {
			int flag=gi();
			if(flag==1) {
				int x=gi(),k=gi(),tot=0;
				printf("%d\n",query(dfn[x],ed[x],k));
			} else if(flag==2) {
				int x=gi(),k=gi();
				update(dfn[x],ed[x],k);
			}
		}
	}
}
