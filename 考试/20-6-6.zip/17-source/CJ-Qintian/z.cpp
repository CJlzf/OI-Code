#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int N=1050;
const int Inf=19260817;
int gi(){
	int x=0,flag=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {if(ch=='-'){flag=-1;}ch=getchar();}
	while(ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();
	return x*flag;
}
int n,v[N],tt[N],Ans=Inf,zhan[N],tot,tong[N];
struct data{
	int me[N];
}a[N];
bool check(){
	int sum=0;
	for(int i=1;i<=n;i++) tong[i]=0;
	for(int i=1;i<=tot;i++){
	   for(int j=1;j<=tt[zhan[i]];j++){
	   	 if(tong[a[zhan[i]].me[j]]==0) tong[a[zhan[i]].me[j]]=1,sum++;
	   }	
	}
	return sum==tot;
}
void Dfs(int x){
	if(x>n){
		if(check()){
			int ret=0;
			for(int i=1;i<=tot;i++) ret+=v[zhan[i]];
			Ans=min(Ans,ret);
		}
		return;
	}
	zhan[++tot]=x;Dfs(x+1);
	tot--;Dfs(x+1);
}
int main(){
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	n=gi();
	for(int i=1;i<=n;i++){
		int t=gi();
		for(int j=1;j<=t;j++) a[i].me[++tt[i]]=gi();
	}
	for(int i=1;i<=n;i++) v[i]=gi();
	Dfs(1);
	printf("%d\n",Ans);
}
