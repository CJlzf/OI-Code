#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
using namespace std;
const int N=310;
int n,ans;
int a[N],p[N];
inline int gi() {
	int x=0,o=1;
	char ch=getchar();
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') o=-1,ch=getchar();
	while(ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();
	return x*o;
}
inline int count(int x) {
	int ret=0;
	while(x) ret+=(x&1),x>>=1;
	return ret;
}
inline void dfs(int t,int sum,int now,int ret) {
	if(t>n) {
		if(sum==count(now)) ans=min(ans,ret);
		return;
	}
	dfs(t+1,sum+1,now|a[t],ret+p[t]);
	dfs(t+1,sum,now,ret);
}
int main() {
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	int t;
	cin>>n;
	for(int i=1;i<=n;i++) {
		t=gi();
		while(t--) a[i]|=(1<<(gi()-1));
	}
	for(int i=1;i<=n;i++) p[i]=gi();
	dfs(1,0,0,0);
	cout<<ans;
	return 0;
}
