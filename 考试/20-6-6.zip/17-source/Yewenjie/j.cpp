#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
using namespace std;
const int N=100010;
int tt,tp,tim;
int head[N],to[N*2],nxt[N*2],s[N*2],dep[N],v[N],fa[N],dfn[N],ed[N];
inline int gi() {
	int x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();
	return x;
}
inline int query(int x,int k) {
	if(ed[x]-dfn[x]+1<k) return -1;
	tp=0;
	for(int i=dfn[x];i<=ed[x];i++) v[++tp]=dep[i];
	sort(v+1,v+1+tp);
	return v[k];
}
inline void dfs(int x,int d) {
	dfn[x]=++tim,dep[tim]=d;
	for(int i=head[x];i;i=nxt[i])
		if(to[i]!=fa[x]) dfs(to[i],d+s[i]);
	ed[x]=tim;
}
int main() {
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	int n,m,len,opt,x,k;
	cin>>n>>m>>len;
	for(int i=2;i<=n;i++) {
		fa[i]=x=gi(),k=gi();
		to[++tt]=i,nxt[tt]=head[x],s[tt]=k,head[x]=tt;
		to[++tt]=x,nxt[tt]=head[i],s[tt]=k,head[i]=tt;
	}
	dfs(1,0);
	for(int i=1;i<=m;i++) {
		opt=gi(),x=gi(),k=gi();
		if(opt==1) printf("%d\n",query(x,k));
		else for(int j=dfn[x];j<=ed[x];j++) dep[j]+=k;
	}
	return 0;
}
