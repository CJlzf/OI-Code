#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
using namespace std;
int n, K, MOD;

int quick_pow(int a, int x) {
	int res = 1;
	while (x) {
		if (x & 1)
			res = 1ll * res * a % MOD;
		a = 1ll * a * a % MOD, x >>= 1;
	}
	return res;
}

int main() {
	freopen("zhang.in", "r", stdin);
	freopen("zhang.out", "w", stdout);
	scanf("%d %d %d", &n, &K, &MOD);
	if (K == n - 1) {
		printf("%d", K);
		return 0;
	}
	if (K == 2 || K == n - 2) {
		int ans = quick_pow(2, n - 4);
		ans = 1ll * ans * (n - 2) % MOD * (n - 1) % MOD;
		if (K == 2)
			printf("%d", ans * 2 % MOD);
		else
			printf("%lld", 1ll * ans * (n - 2) % MOD);
	}
	return 0;
}
