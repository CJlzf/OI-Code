#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
using namespace std;
int n;
int s[30], a[300], b[30], bug[30];
int et, fir[30], to[60], ne[60], dep[30];

void link(int u, int v) {
	to[++et] = v, ne[et] = fir[u], fir[u] = et;
}

int dfs_tree(int o, int fa) {
	int res = dep[o] & 1;
	for (int i = fir[o]; i; i = ne[i])
		if (to[i] != fa)
			dep[to[i]] = dep[o] + 1, res += dfs_tree(to[i], o);
	return res;
}

void check() {
	et = 0;
	for (int i = 1; i <= n; i++)
		a[i] = i, fir[i] = 0;
	for (int i = 1; i <= n - 2; i++)
		a[n + i] = s[i];
	sort(a + 1, a + 2 * n - 1);
	for (int i = 1, p; i <= n - 2; i++) {
		for (int j = 1; j < 2 * n - 2; j++)
			if (a[j] && a[j + 1] != a[j] && (j == 1 || a[j - 1] != a[j])) {
				p = a[j], a[j] = 0;
				break;
			}
		link(p, s[i]), link(s[i], p);
		for (int j = 1; j < 2 * n - 1; j++)
			if (a[j] == s[i]) {
				a[j] = 0;
				break;
			}
	}
	int x = 0, y = 0;
	for (int i = 1; i < 2 * n - 1; i++)
		if (a[i]) {
			if (!x)
				x = a[i];
			else {
				y = a[i];
				break;
			}
		}
	link(x, y), link(y, x);
	dep[1] = 1;
	bug[dfs_tree(1, 0)]++;
}

void dfs(int p) {
	if (p > n - 2) {
		check();
		return;
	}
	for (int i = 1; i <= n; i++) {
		s[p] = i;
		dfs(p + 1);
	}
}

int main() {
	freopen("zhang.in", "r", stdin);
	freopen("zhang.out", "w", stdout);
	printf("1\n1 0\n");
	for (n = 11; n <= 11; n++) {
		for (int i = 1; i <= n; i++)
			bug[i] = 0;
		dfs(1);
		for (int i = 1; i <= n; i++)
			printf("%d ", bug[i]);
		putchar('\n');
	}
	return 0;
}
