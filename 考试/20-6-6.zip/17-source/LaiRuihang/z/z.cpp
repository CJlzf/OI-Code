#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
using namespace std;
const int MAXN = 305;
const int INF = 1e9;
int n;
int s[MAXN], P[MAXN];
int ans;

int chk_1(int S) {
	int res = 0;
	while (S)
		res++, S -= S & (-S);
	return res;
}

void dfs(int p, int S, int tot) {
	if (p > n) {
		if (chk_1(S) == tot) {
			int sum = 0;
			for (int i = 1; i <= n; i++)
				if ((S >> (i - 1)) & 1)
					sum += P[i];
			ans = min(ans, sum);
		}
		return;
	}
	dfs(p + 1, S | s[p], tot + 1);
	dfs(p + 1, S, tot);
}

int main() {
	freopen("z.in", "r", stdin);
	freopen("z.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1, x, t; i <= n; i++) {
		scanf("%d", &t);
		while (t--) {
			scanf("%d", &x);
			s[i] |= 1 << (x - 1);
		}
	}
	for (int i = 1; i <= n; i++)
		scanf("%d", &P[i]);
	dfs(1, 0, 0);
	printf("%d\n", ans);
	return 0;
}
