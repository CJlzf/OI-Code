#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <queue>
using namespace std;
const int MAXN = 200005;
int n, m, L;
int et, fir[MAXN], to[MAXN], ne[MAXN];
int clk, dfn_1[MAXN], dfn_2[MAXN], siz[MAXN];
int bit[MAXN], a[MAXN];

struct like {
	int v, p;
	bool operator < (const like &r) const {
		return v > r.v;
	}
} r;
priority_queue<like> h;

void link(int u, int v) {
	to[++et] = v, ne[et] = fir[u], fir[u] = et;
}

void modify(int x, int v) {
	while (x <= (n << 1))
		bit[x] += v, x += x & (-x);
}

int query(int x) {
	int res = 0;
	while (x)
		res += bit[x], x -= x & (-x);
	return res;
}

void dfs(int o) {
	dfn_1[o] = ++clk, siz[o] = 1;
	modify(clk, a[o]);
	for (int i = fir[o]; i; i = ne[i]) {
		dfs(to[i]);
		siz[o] += siz[to[i]];
	}
	dfn_2[o] = ++clk, modify(clk, -a[o]);
}

int main() {
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);
	scanf("%d %d %d", &n, &m, &L);
	for (int i = 2, x; i <= n; i++) {
		scanf("%d %d", &x, &a[i]);
		link(x, i);
	}
	dfs(1);
	for (int t = 1, tp, x, k; t <= m; t++) {
		scanf("%d %d %d", &tp, &x, &k);
		if (tp == 1) {
			if (siz[x] < k) {
				printf("-1\n");
				continue;
			}
			while (!h.empty())
				h.pop();
			h.push((like){query(x), x});
			while (k--) {
				r = h.top(), h.pop();
				for (int i = fir[r.p]; i; i = ne[i])
					h.push((like){r.v + a[to[i]], to[i]});
			}
			printf("%d\n", r.v);
		} else {
			a[x] += k;
			modify(dfn_1[x], k), modify(dfn_2[x], -k);
		}
	}
	return 0;
}
