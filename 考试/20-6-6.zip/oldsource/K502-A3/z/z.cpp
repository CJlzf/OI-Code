#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <math.h>
using namespace std;
typedef long long ll;
int read()
{
    char c;
    int x=0,flag=1;
    while((c=getchar())&&(c<'0'||c>'9'))
        if(c=='-')
            flag=-1;
    do x=x*10+c-'0';
    while((c=getchar())&&c>='0'&&c<='9');
    return x*flag;
}
const int maxn=310;
int n,bit[maxn],s[maxn],a[maxn],ans;
int count(int x)
{
    int cnt=0;
    for(int i=1;i<=20;i++)
        cnt+=!(!(x&bit[i]));
    return cnt;
}
void update(int cond,int sum,int cnt)
{
    if(count(cond)==cnt)
        ans=min(ans,sum);
}
void dfs(int cur,int cond,int sum,int cnt)
{
    if(cur>n)
        return update(cond,sum,cnt);
    dfs(cur+1,cond,sum,cnt);
    dfs(cur+1,cond|s[cur],sum+a[cur],cnt+1);
}
int main()
{
    freopen("z.in","r",stdin);
    freopen("z.out","w",stdout);
    bit[1]=1;
    for(int i=2;i<=20;i++)
        bit[i]=bit[i-1]<<1;
    n=read();
    for(int i=1;i<=n;i++)
    {
        int t=read();
        for(int j=1;j<=t;j++)
            s[i]|=bit[read()];
    }
    for(int i=1;i<=n;i++)
        a[i]=read();
    if(n>20)
    {
        int sum=0;
        for(int i=1;i<=n;i++)
            sum+=a[i];
        printf("%d\n",sum);
        return 0;
    }
    dfs(1,0,0,0);
    printf("%d\n",ans);
    return 0;
}
