#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <math.h>
using namespace std;
typedef long long ll;
int read()
{
    char c;
    int x=0,flag=1;
    while((c=getchar())&&(c<'0'||c>'9'))
        if(c=='-')
            flag=-1;
    do x=x*10+c-'0';
    while((c=getchar())&&c>='0'&&c<='9');
    return x*flag;
}
const int maxn=101;
int n,lim,a[maxn],mod,c[maxn][maxn],ans,pw[maxn][maxn];
int f[2][maxn][maxn][maxn],cur,mul[maxn][maxn][maxn];
int main()
{
    freopen("zhang.in","r",stdin);
    freopen("zhang.out","w",stdout);
    n=read(),lim=read(),mod=read();
    for(int i=0;i<=n;i++)
    {
        c[i][0]=c[i][i]=1;
        for(int j=1;j<n;j++)
            c[i][j]=(c[i-1][j-1]+c[i-1][j])%mod;
    }
    for(int i=1;i<=n;i++)
    {
        pw[i][0]=1;
        for(int j=1;j<=n;j++)
            pw[i][j]=(ll)pw[i][j-1]*i%mod;
    }
    for(int j=1;j<=n;j++)
        for(int p=1;p<=n;p++)
            for(int r=p;r<=n;r++)
                mul[j][p][r]=(ll)pw[j][p]*c[r][p]%mod;
    cur=1;
    f[1][1][1][1]=1;
    for(int t=1;t<=n;t++)
    {
        memset(f[cur^1],0,sizeof f[cur^1]);
        if(cur==1)
        {
            for(int i=1;i<=n;i++)
            {
                int mn=max(1,lim-(n-i));
                for(int j=1;j<=i;j++)
                    for(int k=mn;k<=lim;k++)
                        if(f[cur][i][j][k])
                            for(int p=1;i+p<=n;p++)
                                // (f[cur^1][i+p][p][k]+=(ll)f[cur][i][j][k]*pw[j][p]%mod*c[n-i][p]%mod)%=mod;
                                (f[cur^1][i+p][p][k]+=(ll)f[cur][i][j][k]*mul[j][p][n-i]%mod)%=mod;
            }
        }
        else
        {
            for(int i=1;i<=n;i++)
            {
                int mn=max(1,lim-(n-i));
                for(int j=1;j<=i;j++)
                    for(int k=mn;k<=lim;k++)
                        if(f[cur][i][j][k])
                            for(int p=1;i+p<=n;p++)
                                // (f[cur^1][i+p][p][k+p]+=(ll)f[cur][i][j][k]*pw[j][p]%mod*c[n-i][p]%mod)%=mod;
                                (f[cur^1][i+p][p][k+p]+=(ll)f[cur][i][j][k]*mul[j][p][n-i]%mod)%=mod;
            }
        }
        for(int j=1;j<=n;j++)
            (ans+=f[cur][n][j][lim])%=mod;
        // printf("%d\n",ans);
        cur^=1;
    }
    printf("%d\n",ans);
    return 0;
}
