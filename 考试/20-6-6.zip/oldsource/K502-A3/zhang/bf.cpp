#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <math.h>
using namespace std;
typedef long long ll;
int read()
{
    char c;
    int x=0,flag=1;
    while((c=getchar())&&(c<'0'||c>'9'))
        if(c=='-')
            flag=-1;
    do x=x*10+c-'0';
    while((c=getchar())&&c>='0'&&c<='9');
    return x*flag;
}
const int maxn=1010;
int n,k,a[maxn],mod,c[maxn][maxn],ans;
int fpm(int a,int x)
{
    int ans=1;
    for(;x>0;x>>=1,a=(ll)a*a%mod)
        if(x&1)
            ans=(ll)ans*a%mod;
    return ans;
}
void update(int cnt)
{
    int sum=0,mul=1,rem=n-1;
    for(int i=1;i<=cnt;i+=2)
        sum+=a[i];
    if(sum!=k)
        return;
    for(int i=2;i<=cnt;i++)
    {
        mul=(ll)mul*c[rem][a[i]]%mod*fpm(a[i-1],a[i])%mod;
        rem-=a[i];
    }
    (ans+=mul)%=mod;
}
void dfs(int cur,int cnt)
{
    if(cur==0)
        return update(cnt);
    for(int i=1;i<=cur;i++)
    {
        a[cnt+1]=i;
        dfs(cur-i,cnt+1);
    }
}
int main()
{
    freopen("zhang.in","r",stdin);
    freopen("bf.out","w",stdout);
    n=read(),k=read(),mod=read();
    for(int i=0;i<=n;i++)
    {
        c[i][0]=c[i][i]=1;
        for(int j=1;j<n;j++)
            c[i][j]=(c[i-1][j-1]+c[i-1][j])%mod;
    }
    a[1]=1;
    dfs(n-1,1);
    printf("%d\n",ans);
    return 0;
}
