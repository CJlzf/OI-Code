#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <math.h>
using namespace std;
typedef long long ll;
int read()
{
    char c;
    int x=0,flag=1;
    while((c=getchar())&&(c<'0'||c>'9'))
        if(c=='-')
            flag=-1;
    do x=x*10+c-'0';
    while((c=getchar())&&c>='0'&&c<='9');
    return x*flag;
}
const int maxn=100100;
int n,m,len,cnt,head[maxn],v[maxn];
int dfnst[maxn],dfnen[maxn],tra[maxn],clo;
int a[maxn],b[maxn];
struct edge
{int next,to,w;}seg[maxn<<1];
void add_seg(int u,int v,int w)
{
    seg[++cnt]=(edge){head[u],v,w};
    head[u]=cnt;
    seg[++cnt]=(edge){head[v],u,w};
    head[v]=cnt;
}
#define nx seg[i].to
void dfs(int cur,int pre)
{
    tra[dfnst[cur]=++clo]=cur;
    for(int i=head[cur];i!=0;i=seg[i].next)
        if(nx!=pre)
        {
            v[nx]=v[cur]+seg[i].w;
            dfs(nx,cur);
        }
    dfnen[cur]=clo;
}
void alter(int x,int k)
{
    for(int i=dfnst[x];i<=dfnen[x];i++)
        a[i]+=k;
}
int query(int x,int k)
{
    if(k>dfnen[x]-dfnst[x]+1)
        return -1;
    for(int i=dfnst[x];i<=dfnen[x];i++)
        b[i]=a[i];
    sort(b+dfnst[x],b+dfnen[x]+1);
    return b[dfnst[x]+k-1];
}
int main()
{
    freopen("j.in","r",stdin);
    freopen("j.out","w",stdout);
    n=read(),m=read(),len=read();
    for(int i=1;i<n;i++)
    {
        int fa=read(),w=read();
        add_seg(fa,i+1,w);
    }
    dfs(1,0);
    for(int i=1;i<=n;i++)
        a[dfnst[i]]=v[i];
    for(int i=1;i<=m;i++)
    {
        int ty=read(),x=read(),k=read();
        if(ty==1)
            printf("%d\n",query(x,k));
        else
            alter(x,k);
    }
    return 0;
}
