#include<cstdio>
#include<cstring>
#include<algorithm>
#include<bitset>
#include<iostream>

const int maxn = 300 + 5;

int n;
std::bitset<maxn> b[maxn];
int t[maxn], p[maxn];

namespace bf1 {
	int ans;
	bool mark[25];

	inline bool check() {
		static bool vis[25];
		int cnt = 0;
		std::bitset<maxn> tmp;
		memset(vis, false, sizeof(vis));
		for(int i = 1; i <= n; i++) {
			if(!mark[i]) continue;
			cnt++; tmp |= b[i];
		}
		if(tmp.count() == (unsigned int)cnt) return true;
		else return false;
	}

	void dfs(int cur, int val) {
		if(cur == n + 1) {
			if(check()) ans = std::min(ans, val);
			return;
		}
		mark[cur] = true;
		dfs(cur + 1, val + p[cur]);
		mark[cur] = false;
		dfs(cur + 1, val);
	}

	void solve() {
		dfs(1, 0);
		printf("%d\n", ans);
	}
}

namespace bf2 {
	int ans;
	inline bool check() {
		for(int i = 1; i <= n; i++)
			if(p[i] > 0) return false;
		return true;
	}

	void solve() {
		ans = 0;
		for(int i = 1; i <= n; i++) ans += p[i];
		printf("%d\n", ans);
	}
}

int main() {
	freopen("z.in", "r", stdin);
	freopen("z.out", "w", stdout);
		scanf("%d", &n);
		for(int i = 1; i <= n; i++) {
			scanf("%d", &t[i]);
			for(int j = 1; j <= t[i]; j++) {
				int id; scanf("%d", &id);
				b[i][id] = 1;
			}
		}
		for(int i = 1; i <= n; i++) scanf("%d", &p[i]);
		if(n <= 20) bf1::solve();
		else if(bf2::check()) bf2::solve();
		else {
		}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
