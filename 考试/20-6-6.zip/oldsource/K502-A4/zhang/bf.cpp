#include<cstdio>
#include<cstring>
#include<algorithm>
#include<map>

typedef long long LL;

const int maxn = 5e5 + 5;

int n, k, P;

inline int pow_mod(int a, int x) {
	int now = 1;
	for(int i = x; i; i >>= 1, a = (LL)a * a % P)
		if(i&1) now = (LL)now * a % P;
	return now;
}

namespace bf2 {
	int C[105][105];
	int ans, cnt[105];

	void dfs(int cur, int sz, int totd) {
		if(sz > k) return;
		if(totd == n) {
			if(sz < k) return;
			int tmp = n - 1, sum = 1;
			for(int i = 2; i <= cur - 1; i++) {
				(sum = (LL)sum * C[tmp][cnt[i]] * pow_mod(cnt[i - 1], cnt[i]) % P) %= P;
				tmp -= cnt[i];
			}
			(ans += sum) %= P;
			return;
		}
		for(int i = 1; i <= n - totd; i++) {
			cnt[cur] = i;
			dfs(cur + 1, sz + (cur & 1 ? i : 0), totd + i);
		}
	}

	void solve() {
		C[0][0] = 1;
		for(int i = 1; i <= n; i++) {
			C[i][0] = C[i][i] = 1;
			for(int j = 1; j < i; j++)
				C[i][j] = (C[i - 1][j - 1] + C[i - 1][j]) % P;
		}
		ans = 0; cnt[1] = 1;
		dfs(2, 1, 1);
		printf("%d ", ans);
	}
}

int main() {
	freopen("zhang.in", "r", stdin);
	freopen("zhang.out", "w", stdout);
		scanf("%d%d%d", &n, &k, &P);
		bf2::solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
