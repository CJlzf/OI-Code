#include<cstdio>
#include<cstring>
#include<algorithm>
#include<map>

typedef long long LL;

const int maxn = 5e5 + 5;

int n, k, P;

inline int pow_mod(int a, int x) {
	int now = 1;
	for(int i = x; i; i >>= 1, a = (LL)a * a % P)
		if(i&1) now = (LL)now * a % P;
	return now;
}

//namespace bf1 {
//	int sz, u[40], v[40];
//	int totedge, start[25], next[85], to[85];
//	int fa[25], dep[25];
//	bool mark[40];
//	int ans;
//	
//	void addedge(int u0, int v0) {
//		to[++totedge] = v0;
//		next[totedge] = start[u0];
//		start[u0] = totedge;
//	}
//
//	void dfs1(int u0, int f) {
//		for(int i = start[u0]; i; i = next[i]) 
//			if(to[i] != f) dep[to[i]] = dep[u0] + 1, dfs1(to[i], u0);
//	}
//
//	inline int find(int p) { return fa[p] == p ? p : fa[p] = find(fa[p]); }
//
//	inline bool check() {
//		int cnt = 0;
//		totedge = 0;
//		memset(start, 0, sizeof(start));
//		for(int i = 1; i <= n; i++) fa[i] = i;
//		for(int i = 1; i <= sz; i++) 
//			if(mark[i]) {
//				int u0 = find(u[i]), v0 = find(v[i]);
//				if(u0 == v0) return 0;
//				fa[u0] = v0;
//				addedge(u[i], v[i]), addedge(v[i], u[i]);
//			}
//		dfs1(dep[1] = 1, 0);
//		for(int i = 1; i <= n; i++) cnt += (dep[i] & 1);
//		return cnt == k;
//	}
//
//	void dfs(int cur, int cnt) {
//		if(cnt > n - 1) return;
//		if(cnt + sz - cur + 1 < n - 1) return;
//		if(cur == sz + 1) {
//			if(check()) ans++;
//			return;
//		}
//		mark[cur] = true;
//		dfs(cur + 1, cnt + 1);
//		mark[cur] = false;
//		dfs(cur + 1, cnt);
//	}
//
//	void solve() {
//		sz = 0;
//		for(int i = 1; i <= n; i++)
//			for(int j = i + 1; j <= n; j++)
//				sz++, u[sz] = i, v[sz] = j;
//		ans = 0;
//		dfs(1, 0);
//		printf("%d\n", ans);
//	}
//}

namespace bf2 {
	int C[25][25];
	int ans, cnt[25];

	void dfs(int cur, int sz, int totd) {
		if(sz > k) return;
		if(totd == n) {
			if(sz < k) return;
			int tmp = n - 1, sum = 1;
			for(int i = 2; i <= cur - 1; i++) {
				(sum = (LL)sum * C[tmp][cnt[i]] * pow_mod(cnt[i - 1], cnt[i]) % P) %= P;
				tmp -= cnt[i];
			}
			(ans += sum) %= P;
			return;
		}
		for(int i = 1; i <= n - totd; i++) {
			cnt[cur] = i;
			dfs(cur + 1, sz + (cur & 1 ? i : 0), totd + i);
		}
	}

	void solve() {
		C[0][0] = 1;
		for(int i = 1; i <= n; i++) {
			C[i][0] = C[i][i] = 1;
			for(int j = 1; j < i; j++)
				C[i][j] = (C[i - 1][j - 1] + C[i - 1][j]) % P;
		}
		ans = 0; cnt[1] = 1;
		dfs(2, 1, 1);
		printf("%d\n", ans);
	}
}

int main() {
	freopen("zhang.in", "r", stdin);
	freopen("zhang.out", "w", stdout);
		scanf("%d%d%d", &n, &k, &P);
		if(n == 4 && k == 2 && P == 998244353) puts("12");
		else if(n <= 20) bf2::solve();
		else {
		}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
