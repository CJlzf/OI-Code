#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>

const int maxn = 1e5 + 5;
const int maxb = 1e3 + 5;

struct Node {
	int v, w;
	Node() { }
	Node(int v, int w) : v(v), w(w) { }
}Edge[maxn];

int n, m, len;
int totedge, start[maxn], next[maxn];
int dfsclock, dep[maxn], dfn[maxn], st[maxn], ed[maxn];
int a[maxn];
//int bsize, totb, bel[maxn], info[maxb][maxb], add[maxb];

void addedge(int u, int v, int w) {
	Edge[++totedge] = Node(v, w);
	next[totedge] = start[u];
	start[u] = totedge;
}

void dfs(int u) {
	dfn[st[u] = ++dfsclock] = u;
	for(int i = start[u]; i; i = next[i]) {
		int v = Edge[i].v;
		dep[v] = dep[u] + Edge[i].w;
		dfs(v);
	}
	ed[u] = dfsclock;
}

void modify(int l, int r, int k) {
}

int main() {
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);
		scanf("%d%d%d", &n, &m, &len);
		for(int i = 2; i <= n; i++) {
			int f, l;
			scanf("%d%d", &f, &l);
			addedge(f, i, l);
		}
		dep[1] = 0; dfs(1);
		//bsize = (int)(std::pow(n, 0.5) + 0.5);
		//totb = (n - 1) / bsize + 1;
		//for(int i = 1; i <= n; i++) bel[i] = (i - 1) / bsize + 1;
		//for(int i = 1; i <= totb; i++) {
		//	int l = (i - 1) * bsize + 1, r = std::min(n, i * bsize);
		//	for(int j = l; j <= r; j++)
		//		info[i][j - l + 1] = dep[dfn[j]];
		//	std::sort(info[i] + 1, info[i] + r - l + 2);
		//}
		///*
		//printf("%d %d\n", bsize, totb);
		//for(int i = 1; i <= totb; i++) {
		//	int l = (i - 1) * bsize + 1, r = std::min(n, i * bsize);
		//	for(int j = l; j <= r; j++) printf("%d ", info[i][j - l + 1]);
		//	putchar('\n');
		//}
		//*/
		for(int i = 1; i <= m; i++) {
			int type, x, k, l, r;
			scanf("%d%d%d", &type, &x, &k);
			l = st[x]; r = ed[x];
			if(type == 1) {
				if(r - l + 1 < k) puts("-1");
				else {
					for(int j = l; j <= r; j++) a[j - l + 1] = dep[dfn[j]];
					std::sort(a + 1, a + r - l + 2);
					printf("%d\n", a[k]);
				}
			}
			if(type == 2) {
				for(int j = l; j <= r; j++) 
					dep[dfn[j]] += k;
			}
		}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
