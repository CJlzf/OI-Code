#include<cstdio>
#include<algorithm>
using namespace std;

#define N 100010
#define K 930
#define mid (l+r>>1)
int n,m,len,i;
int f[N],w[N];
int t[N],nx[N];
int in[N],out[N],tot;
int q[N];

bool xiao(int x,int y)
{
	return q[x]<q[y];
}
int q1[N],t1,q2[N],t2;
struct kuai
{
	int l,r,n,a[K+5],dy[K+5],ad,i;
	void init()
	{ 
	  n=0;
	  for(i=l;i<=r;++i) dy[++n]=i;
	  sort(dy+1,dy+n+1,xiao);
	  for(i=1;i<=n;++i) a[i]=q[dy[i]];	
	}
	void down()
	{
		if(ad)
		{
			for(i=l;i<=r;++i) q[i]+=ad;
			for(i=1;i<=n;++i) a[i]+=ad;
			ad=0;
		}
	}
	void add(int ql,int qr,int k)
	{
		if(ql==l&&qr==r) {ad+=k;return ;}
		for(i=ql;i<=qr;++i) q[i]+=k;
		
		t1=t2=0;
		for(i=1;i<=n;++i) 
		if(dy[i]>=ql&&dy[i]<=qr) q1[++t1]=dy[i];
		else q2[++t2]=dy[i];
		
		int t=0,h1=1,h2=1;
		for(;;)
		if(q[q1[h1]]<q[q2[h2]]) 
		{dy[++t]=q1[h1];
		 if(++h1>t1) 
		 {
		 	for(;h2<=t2;++h2) dy[++t]=q2[h2];
		 	break;
		 }
		}
		else 
		{dy[++t]=q2[h2];
		 if(++h2>t2) 
		 {
		 	for(;h1<=t1;++h1) dy[++t]=q1[h1];
		 	break;
		 }
	    }
		for(i=1;i<=n;++i) a[i]=q[dy[i]];
	}
	int get(int x)
	{
		x-=ad;
		if(a[1]>x) return 0;
		if(a[n]<=x) return n;
		int l=1,r=n;
		while(l+1<r)
		{
		  if(a[mid]>x) r=mid;
		  else l=mid;
		}
		return l;
	}
}k[N/K+5];
int u;
void dfs(int x,int fr,int dep)
{
	in[x]=++tot;q[tot]=dep;
	if(dep>u) u=dep;
	for(int y=t[x];y;y=nx[y]) 
	 dfs(y,x,dep+w[y]);
	out[x]=tot;
}

int kl,kr,l,r,x;
void add()
{
	u+=x;
	if(kl==kr) 
	{
		k[kl].add(l,r,x);
		return ;
    }
	k[kl].add(l,k[kl].r,x);
	while(++kl<kr) k[kl].ad+=x;
	k[kr].add(k[kr].l,r,x);
}

int get(int x)
{
	int ans=0;
	for(i=l;i<=k[kl].r;++i) ans+=(q[i]<=x);
	for(i=k[kr].l;i<=r;++i) ans+=(q[i]<=x);
	for(i=kl;(++i)<kr;++i) ans+=k[i].get(x);
	return ans;
}
int a[N];
int kth()
{
	if(x>r-l+1) return -1;
	if(l==k[kl].l) --kl;
	else k[kl].down();
	if(kl==kr) 
	{
		for(int i=l;i<=r;++i) a[i]=q[i];
		x=x+l-1;
		nth_element(a+l,a+x,a+r+1);
		return a[x];
    }
    if(r==k[kr].r) ++kr;
    else k[kr].down();
    if(get(0)>=x) return 0;
    int l=0,r=u;
    while(l+1<r)
    if(get(mid)>=x) r=mid;
    else l=mid;
    return r;
}

#define ch_top 20000000
char ch[ch_top],*now_r=ch;
void read(int &x)
{
	while(*now_r<'0')++now_r;
	for(x=*now_r-'0';*++now_r>='0';) x=(x<<1)+(x<<3)+*now_r-'0';
}

int main()
{
	freopen("j.in","r",stdin);freopen("j.out","w",stdout);
	int i;
	ch[fread(ch,1,ch_top,stdin)]=0;
	read(n);read(m);read(len);
	for(i=2;i<=n;++i) 
	{
		read(f[i]);read(w[i]);
		nx[i]=t[f[i]];t[f[i]]=i;
    }
    dfs(1,0,0);
    int num=0;
    for(i=1;i<=n;i+=K,++num) 
	{ 
	  k[num].l=i;k[num].r=min(i+K-1,n);
	  k[num].init();
	}
	k[num].l=N;
	while(m--)
	{
		int op,i;
		read(op);read(i);read(x);
		l=in[i];r=out[i];
		kl=(l-1)/K;kr=(r-1)/K;
		if(op==1) printf("%d\n",kth());
		else add();
	}
}
