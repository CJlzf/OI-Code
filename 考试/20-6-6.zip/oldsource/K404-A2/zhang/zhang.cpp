#include<cstdio>

#define ll long long
#define N 25
int n,k,p;
ll num[N];
int f[N];
int t[N],next[N],q[N],tail,now;
int dep[N];
void check()
{
	int i,x,y;
	for(i=1;i<=n;++i) t[i]=0;
	for(i=2;i<=n;++i) {next[i]=t[f[i]];t[f[i]]=i;}
	q[tail=1]=1;now=0;
	for(i=1;i<=tail;++i)
	{
		x=q[i];
		if(dep[x]&1) ++now;
		for(y=t[x];y;y=next[y])
		 dep[q[++tail]=y]=dep[x]+1;
	}
	if(tail<n)
	 return;
	++num[now];
}
void dfs(int x)
{
	if(x>n) {check();return ;}
	int &i=f[x],y;
	for(i=1;i<=n;++i)
	{
		for(y=i;y;y=f[y]) 
		if(y==x) break;
		if(y)continue;
	 dfs(x+1);
	}
}

int main()
{
	freopen("zhang.in","r",stdin);freopen("zhang.out","w",stdout);
	dep[1]=1;
	scanf("%d%d%d",&n,&k,&p);
     	dfs(2);
	printf("%lld",num[k]);
}
