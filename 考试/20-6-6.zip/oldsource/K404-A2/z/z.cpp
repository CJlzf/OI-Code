#include<cstdio>
#include<algorithm>
using namespace std;

#define oo 1000000000
#define N 310
int n,i,j;
int num[N],a[N][N],w[N];
bool b[N],now[N];
int ans;
void check()
{
	int i,j,x,y;
	for(i=1;i<=n;++i)now[i]=0;
	int cnt=0,sum=0;
	for(i=1;i<=n;++i) 
	if(b[i])
	{
		++cnt;sum+=w[i];
	  for(j=1;j<=num[i];++j) now[a[i][j]]=1;
    }
    for(i=1;i<=n;++i)
    if(now[i]) --cnt;
    if(cnt) return ;
    ans=min(ans,sum);
}
void dfs(int x)
{
	if(x>n) {check();return ;}
	b[x]=0;
	dfs(x+1);
	b[x]=1;
	dfs(x+1);
}

int main()
{
	freopen("z.in","r",stdin);freopen("z.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;++i)
	{
		scanf("%d",num+i);
		for(j=1;j<=num[i];++j) scanf("%d",a[i]+j);
	}
	for(i=1;i<=n;++i) 
	{scanf("%d",w+i);
	 if(w[i]>0)ans=oo;
	 else ans-=w[i];
	}
	if(ans>0) {ans=0;dfs(1);}
	printf("%d",ans);
}
