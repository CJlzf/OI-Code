#include <cstdio>
#include <climits>
#include <queue>
#include <algorithm>

const int Nmax = 311;
int N;

const int Vmax = Nmax*2+2;
const int Emax = (Nmax*Nmax+Nmax*2)*2;

struct Edge {
  int p;
  int c;
  Edge*next;
  Edge*brother;
};

Edge*V[Vmax];
int Vcnt;
int S, T;

void init(const int&Size, const int&S, const int&T) {
  ::S = S; ::T = T;
  std::fill_n(V, Size, (Edge*)0);
  Vcnt = Size;
}

void _addEdge(const int&a, const int&b, const int&c) {
  Edge*t = new Edge;
  t->p = b;
  t->c = c;
  t->next = V[a];
  V[a] = t;
}
void addEdge(const int&a, const int&b, const int&c) {
  _addEdge(a, b, c);
  _addEdge(b, a, 0);
  V[a]->brother = V[b];
  V[b]->brother = V[a];
}

int dis[Vmax];
std::queue<int> q;
Edge*cur[Vmax];
bool bfs() {
  std::fill(dis, dis+Vcnt, -1);
  std::copy(V, V+Vcnt, cur);
  dis[S] = 0; q.push(S);
  while(!q.empty()) {
    const int o = q.front(); q.pop();
    for(Edge*v = V[o]; v != 0; v = v->next) {
      if(dis[v->p] != -1 || v->c == 0) continue;
      dis[v->p] = dis[o]+1;
      q.push(v->p);
    }
  }
  getchar();
  return dis[T] != -1;
}

int dfs(const int o, const int maxflow) {
  if(maxflow == 0 || o == T) return maxflow;
  int flow = 0, f;
  for(Edge*&v = cur[o]; v != 0; v = v->next) 
  if(dis[v->p] == dis[o]+1 && (f = dfs(v->p, std::min(maxflow, v->c)))) {
    flow += f;
    v->c -= f;
    v->brother->c += f;
    if(flow == maxflow) break;
  }
  return flow;
}

int dinic() {
  int ans = 0;
  while(bfs()) ans += dfs(S, INT_MAX);
  return ans;
}

int G[Nmax][Nmax];
int A[Nmax];
int B[Nmax];
int P[Nmax];
int main() {
  freopen("z.in", "r", stdin);
  freopen("z.out","w",stdout);
  scanf("%d", &N);
  for(int i = 1; i <= N; ++i) {
    int t; scanf("%d", &t);
    while(t--) {
      int j; scanf("%d", &j);
      G[i][j] = true;
    }
  }

  init(N*2+2, 0, N*2+1);
  for(int i = 1; i <= N; ++i) {
    addEdge(S, i, 1);
    addEdge(i+N, T, 1);
  }
  for(int i = 1; i <= N; ++i) 
    for(int j = 1; j <= N; ++j) 
      if(G[i][j]) addEdge(i, j+N, 1);
  if(dinic() != N) {
    printf("������ƥ��!!!����ѽ������too simple��sometimes naive!\n");
    return 19260817;
  }
  for(int i = 1; i <= N; ++i) 
    for(Edge*v = V[i]; v != 0; v = v->next) 
      if(v->c == 0) A[i] = v->p-N;
  for(int i = 1; i <= N; ++i) B[A[i]] = i;
  
  init(N+2, 0, N+1);
  int ans = 0;
  for(int i = 1; i <= N; ++i) {
    int P; scanf("%d", &P);
    P = -P;
    if(P >= 0) {
      addEdge(S, i, P);
      ans += P;
    } else {
      addEdge(i, T, P);
    }
  }
  for(int i = 1; i <= N; ++i) 
    for(int j = 1; j <= N; ++j) 
      if(G[i][j] && A[i] != j) addEdge(i, B[j], INT_MAX);
  ans -= dinic();

  printf("%d\n", -ans);

  return 0;
}



