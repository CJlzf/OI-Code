#include <iostream>
#include <cstdio>
//#include <vector>
using namespace std;
inline int read()
{
	int num=0,flag=1;
	char ch;
	do{
		ch=getchar();
		if(ch=='-') flag=-1;
	}while(ch<'0'||ch>'9');
	do{
		num=num*10+ch-'0';
		ch=getchar();
	}while(ch>='0'&&ch<='9');
	return num*flag;
}
const int mt = 300+5;
//vector<int>g[mt];
int g[mt][mt];
int ans=0,n;
int now[mt];
int val[mt];
void dfs(int x,int tot,int kk,int a[],int scr)
{
	//cout<<x<<" "<<tot<<" "<<kk<<" "<<scr<<endl;
	if(tot==kk)		  	 
	   ans=max(ans,scr);
	if(x==n+1)
		return ;
	int b[mt];
	for(int i=1;i<=n;i++) b[i]=a[i];
	int kkk=0;
	for(int i=1;i<=n;i++) 
	{
	   a[i]|=g[x][i];
	   if(a[i]==1) kkk++;
	   //cout<<a[i]<<" qaq ";
    }
    //cout<<endl;
	dfs(x+1,tot+1,kkk,a,scr+val[x]);
	for(int i=1;i<=n;i++) a[i]=b[i];
	dfs(x+1,tot,kk,a,scr);
}
int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		int k=read(),x;
		while(k--)
		    x=read(),g[i][x]=1;
	}
	bool flag=false;
	int ha=0;
	for(int i=1;i<=n;i++)
	{
		val[i]=read(),val[i]*=(-1);
		if(val[i]<0) flag=true;
		ha+=val[i];
    } 
    if(flag==false) 
	{
	   printf("%d\n",ha);
	   return 0;
   }
    dfs(1,0,0,now,0);
    printf("%d\n",ans*(-1));
	return 0;
}
/*
3
2 1 2
2 1 2
1 3
-10 20 -3

*/
