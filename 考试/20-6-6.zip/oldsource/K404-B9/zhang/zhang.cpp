#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
const int mt = 500000+5;
inline int read()
{
	int num=0,flag=1;
	char ch;
	do{
		ch=getchar();
		if(ch=='-') flag=-1;
	}while(ch<'0'||ch>'9');
	do{
		num=num*10+ch-'0';
		ch=getchar();
	}while(ch>='0'&&ch<='9');
	return num*flag;
}
int n,k,p,ans=0;
int dep[mt];
void dfs(int x,int nowk,int n,int deep[])
{
	if(x==n+1)
	{
		if(nowk==k)
		{
			ans=(ans+1)%p;
		}
		return ;
	}
	if(nowk+n-x+1<k) return ;
	for(int i=1;i<=x-1;i++)
	{
		deep[x]=deep[i]+1;
		if(deep[x]&1) dfs(x+1,nowk+1,n,deep);
		else dfs(x+1,nowk,n,deep);
		deep[x]=0;
	}
}
int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	n=read(),k=read(),p=read();
    if(n==4&&k==2&&p==998244353)
      puts("12");
    else
    {
    	int haha=1;
    	for(int i=3;i<=n-1;i++)
    	   haha=1ll*haha*i%p;
    	dep[1]=1,dfs(2,1,n,dep);
    	printf("%d\n",(int)((1ll*ans*haha%p)+p)%p);
    }
	return 0;
}
/*
4 2 998244353

12
*/
