#include <iostream>
//#include <vector>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
const int mt =1000+5;
//vector<int>g[mt];
int f[mt];
int g[mt][mt];
int deep[mt];
int n,m,len;
inline int read()
{
	int num=0,flag=1;
	char ch;
	do{
		ch=getchar();
		if(ch=='-') flag=-1;
	}while(ch<'0'||ch>'9');
	do{
		num=num*10+ch-'0';
		ch=getchar();
	}while(ch>='0'&&ch<='9');
	return num*flag;
}
void getdeep(int u)
{
    for(int v=1;v<=n;v++)
    {
    	if(v!=u&&f[v]==u)
    	if(g[u][v])
    	{
    		deep[v]=deep[u]+g[u][v];
    		getdeep(v);
    	}
    }
}
int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	n=read(),m=read(),len=read();
	for(int i=2;i<=n;i++)
	{
		int x=read();
		f[i]=x;
		g[x][i]=read();
		//g[x].push_back(i);
	}
	int now=0;
	while(m--)
	{
		/*cout<<"============="<<endl;
		for(int i=1;i<=n;i++)
		  {
		   for(int j=1;j<=n;j++)
		      cout<<g[i][j]<<" ";
		   cout<<endl;
		  }
		cout<<"------------"<<endl;*/
		int op=read();
		if(op==1)
		{
			int x=read(),k=read();
			if(k>n) puts("-1");
			else
			{
				deep[x]=0,getdeep(x);
				sort(deep+1,deep+n+1);
				int ans=deep[k]+now;
				memset(deep,0,sizeof(deep));
				getdeep(1);
				printf("%d\n",deep[x]+ans);
				memset(deep,0,sizeof(deep));
			}
		}
		else
		{
			int x=read(),k=read();
			//cout<<op<<" >+< "<<x<<" tot "<<k<<endl;
			if(x==1) 
			{
			   now=k;
			   continue;
		    }
			int fa=f[x];
			//cout<<fa<<" "<<x<<" qaq "<<endl;
			g[fa][x]+=k;
		}
	}
	return 0;
}
/*
3 5 3
1 3
2 3
1 1 3
2 3 3
1 1 3
2 1 2
1 1 3

*/
