#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<string>
#include<vector>
#include<queue>
#include<map>
#include<set>
#define LL long long
using namespace std;
const int MAXN = 30010;
int n, m, len;
int f[MAXN], depth[MAXN];
int cur, pos[MAXN][2], t[MAXN];
vector<int> G[MAXN];
void dfs(int x, int d){
	t[cur] = d;
	pos[x][0] = cur++;
	for(int i = 0; i < G[x].size(); i++){
		int y = G[x][i];
		dfs(y, d + depth[y]);
	}
	t[cur] = d;
	pos[x][1] = cur++;
}
int query(int l, int r, int k){
	int L = t[l], R = 10000001;
	while(L < R){
		int mid = (L + R) >> 1, cnt = 0;
		for(int i = l; i <= r; i++){
			if(t[i] < mid) cnt++;
		}
		if(cnt < k) L = mid + 1;
		else R = mid;
	}
	return L - 1;
}
void add(int l, int r, int delta){
	for(int i = l; i <= r; i++){
		t[i] += delta;
	}
}
int main(){
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &len);
	for(int i = 2; i <= n; i++){
		scanf("%d%d", &f[i], &depth[i]);
		G[f[i]].push_back(i);
	}
	cur = 0;
	dfs(1, 0);
	while(m--){
		int opt, x, k;
		scanf("%d%d%d", &opt, &x, &k);
		if(opt == 1){
			if(pos[x][1] - pos[x][0] + 1 < (k << 1)) printf("-1\n");
			else printf("%d\n", query(pos[x][0], pos[x][1], k << 1));
		}
		else{
			add(pos[x][0], pos[x][1], k);
		}
	}
	return 0;
}
