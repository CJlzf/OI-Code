#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<string>
#include<vector>
#include<queue>
#include<map>
#include<set>
#define LL long long
using namespace std;
const int MAXN = 310;
int n;
int sz[MAXN];
int st[MAXN];
int p[MAXN];
int ans;
int main(){
	freopen("z.in", "r", stdin);
	freopen("z.out", "w", stdout);
	scanf("%d", &n);
	if(n <= 20){
		for(int i = 1; i <= n; i++){
			scanf("%d", &sz[i]);
			for(int j = 0; j < sz[i]; j++){
				int x;
				scanf("%d", &x);
				st[i] |= (1 << (x - 1));
			}
		}
		for(int i = 1; i <= n; i++){
			scanf("%d", &p[i]);
		}
		ans = 0;
		for(int i = 0; i < (1 << n); i++){
			int ns = 0, sz1 = 0, tmp = 0;
			for(int j = 1; j <= n; j++)
			if(i & (1 << (j - 1))){
				ns |= st[j];
				sz1++;
			}
			for(int j = 1; j <= n; j++)
			if(ns & (1 << (j - 1))){
				sz1--;
				tmp += p[j];
			}
			if(!sz1 && tmp < ans) ans = tmp;
		}
		printf("%d\n", ans);
	}
	else{
		for(int i = 1; i <= n; i++){
			scanf("%d", &sz[i]);
			for(int j = 0; j < sz[i]; j++){
				int x;
				scanf("%d", &x);
			}
		}
		for(int i = 1; i <= n; i++){
			scanf("%d", &p[i]);
			if(p[i] < 0) ans += p[i];
		}
		printf("%d\n", ans);
	}
	return 0;
}
