#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<string>
#include<vector>
#include<queue>
#include<map>
#include<set>
#define LL long long
using namespace std;
const int MAXN = 21;
LL dp[MAXN][MAXN][MAXN];
int N, K, P;
LL pn[MAXN], C[MAXN][MAXN], S[MAXN][MAXN];
LL ans[MAXN][MAXN], Q[MAXN][MAXN];
int main(){
	freopen("zhang.in", "r", stdin);
	freopen("zhang.out", "w", stdout);
	scanf("%d%d%d", &N, &K, &P);
	dp[1][1][1] = 1;
	ans[1][1] = 1;
	C[0][0] = pn[0] = 1;
	for(int i = 1; i <= N; i++){
		C[i][0] = 1;
		for(int j = 1; j <= i; j++)
			C[i][j] = (C[i - 1][j] + C[i - 1][j - 1]) % P;
		pn[i] = (pn[i - 1] * i) % P;
	}
	
	/*for(int i = 0; i <= N; i++){
		printf("i = %d ", i);
		for(int j = 0; j <= N; j++){
			printf(" %8lld", C[i][j]);
		}
		printf("\n");
	}*/
	
	for(int i = 1; i <= N; i++){
		for(int j = 1; j <= N; j++){
			for(int k = 1; k <= min(i, j); k++){
				S[i][j] = (S[i][j] + (C[i - 1][k - 1] * pn[k]) % P * C[j][k]) % P;
			}
		}
	}
	
	/*for(int i = 1; i <= N; i++){
		printf("i = %d ", i);
		for(int j = 1; j <= N; j++){
			printf(" %8lld", S[i][j]);
		}
		printf("\n");
	}*/
	
	for(int i = 2; i <= N; i++){
		//printf("i = %d =============================\n", i);
		//memset(Q, 0, sizeof(Q));
		for(int j = N; j >= i; j--){
			for(int k = 1; k <= K; k++){
				for(int p = 1; p <= j - i + 1; p++){
					dp[j][k][p] = 0;
					for(int c = 1; c <= j - p - i + 2; c++){
						//Q[j][k] = (Q[j][k] + ((i & 1) ? S[p][c] * dp[j - p][k - p][c] : S[p][c] * dp[j - p][k][c]) % P * C[j - 1][p]) & P;
						if(i & 1) dp[j][k][p] = (dp[j][k][p] + S[p][c] * dp[j - p][k - p][c]) % P;
						else dp[j][k][p] = (dp[j][k][p] + S[p][c] * dp[j - p][k][c]) % P;
					}
					dp[j][k][p] = (dp[j][k][p] * C[j - 1][p]) % P;
					//if(j == 4 && k == 2) printf("dp[%d][4][2][%d] = %lld\n", i, p, dp[4][2][p]);
					ans[j][k] = (ans[j][k] + dp[j][k][p]) % P;
				}
			}
		}
		
		/*for(int j = 1; j <= N; j++){
			for(int k = 1; k <= K; k++){
				printf(" %6lld", Q[j][k]);
			}
			printf("\n");
		}
		printf("\n");*/
		//printf("Ans[4][2] = %lld\n", ans[4][2]);
	}
	/*for(int i = 1; i <= N; i++){
		printf("i = %2d ", i);
		for(int j = 1; j <= K; j++){
			printf(" %6lld", ans[i][j]);
		}
		printf("\n");
	}*/
	printf("%lld\n", ans[N][K]);
	return 0;
}
