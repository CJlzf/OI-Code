#include <cstdio>
#include <cstring>
#define N 105
typedef long long ll;

int pw[N][N];
int fac[N],pinv[N],inv[N];
int mo;
void init(int lim)
{
	fac[0]=fac[1]=inv[0]=inv[1]=pinv[0]=pinv[1]=1;
	for(int i=2;i<=lim;i++)
		fac[i]=(ll)fac[i-1]*i%mo;
	for(int i=2;i<=lim;i++)
		inv[i]=pinv[i]=(ll)pinv[mo%i]*(mo-mo/i)%mo;
	for(int i=2;i<=lim;i++)
		inv[i]=(ll)inv[i-1]*inv[i]%mo;
	for(int i=1;i<=lim;i++)
	{
		pw[i][0]=1;
		for(int j=1;j<=lim;j++)
			pw[i][j]=(ll)pw[i][j-1]*i%mo;
	}
}

int f[N][N][N];
int g[N][N][N];
int getF(int i,int j,int k);
int getG(int i,int j,int k)
{
//	printf("g %d %d %d\n",i,j,k);
	if(i<j || i-j<k) return 0;
	if(~g[i][j][k]) return g[i][j][k];
	int res=0;
	for(int p=1;p<=i;p++)
	{
		int ths=getF(i-k,j,p);
		res=((ll)ths*pw[p][k]+res)%mo;
	}
	res=(ll)res*inv[k]%mo;
	return g[i][j][k]=res;
}
int getF(int i,int j,int k)
{
//	printf("f %d %d %d\n",i,j,k);
	if(i<j || j<k) return 0;
	if(~f[i][j][k]) return f[i][j][k];
	int res=0;
	for(int p=1;p<=i;p++)
	{
		int ths=getG(i-k,j-k,p);
		res=((ll)ths*pw[p][k]+res)%mo;
	}
	res=(ll)res*inv[k]%mo;
	return f[i][j][k]=res;
}
int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	int n,K;
	scanf("%d%d%d",&n,&K,&mo);
	if(!K){puts("0");return 0;}
	init(100);
	memset(f,-1,sizeof(f));
	memset(g,-1,sizeof(g));
	for(int i=0;i<=n;i++)
		for(int j=0;j<=n;j++)
			f[1][i][j]=g[1][i][j]=0;
	f[1][1][1]=fac[n];
	ll ans=0;
	for(int i=1;i<=K;i++)
		ans+=getF(n,K,i);
	for(int i=1;i<=n-K;i++)
		ans+=getG(n,K,i);
	ans=ans%mo*pinv[n]%mo;
	int totans=ans%mo;
	printf("%d\n",totans);
}
