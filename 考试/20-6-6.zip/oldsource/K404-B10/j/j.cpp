#include <cstdio>
#include <algorithm>
inline int RD()
{
	int res;char cr;
	while( (cr=getchar())<'0' || cr>'9'); res=cr-'0';
	while( (cr=getchar())>='0' && cr<='9') res=res*10+cr-'0';
	return res;
}
#define N 1050

int h[N];
int fson[N],bro[N],fa[N];
int dfn[N],pos[N],fin[N],timetip;
int val[N];
int que[N];
void dfs(int p)
{
	dfn[pos[p]=++timetip]=p;
	for(int i=fson[p];i;i=bro[i])
		dfs(i);
	fin[p]=timetip;
}
int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	int n,Q,len;n=RD();Q=RD();len=RD();
	for(int i=2;i<=n;i++)
	{
		fa[i]=RD();
		bro[i]=fson[fa[i]];
		fson[fa[i]]=i;
		h[i]=h[fa[i]]+RD();
	}
	dfs(1);
	for(int i=1;i<=n;i++)
		val[i]=h[dfn[i]];
	while(Q--)
	{
		if(RD()==1)
		{
			int x,k;x=RD();k=RD();
			int cnt=0;
			for(int i=dfn[x];i<=fin[x];i++)
				que[++cnt]=val[i];
			std::sort(que+1,que+1+cnt);
			printf("%d\n",cnt>=k? que[k]: -1);
		}
		else
		{
			int x,k;x=RD();k=RD();
			for(int i=dfn[x];i<=fin[x];i++)
				val[i]+=k;
		}
	}
}
