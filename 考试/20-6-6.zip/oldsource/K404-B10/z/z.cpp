#include <cstdio>
inline int RD()
{
	int res,sign=1;char cr;
	while( (cr=getchar())<'0' || cr>'9')
		cr=='-'? (sign=-1):0;
	res=cr-'0';
	while( (cr=getchar())>='0' && cr<='9')
		res=res*10+cr-'0';
	return res*sign;
}

#define lowbit(x) ((x)&(-x))
#define Min(a,b) (a<b?a:b)
int has[1<<20];
int need[21],co[21];
int lim,ans;
void dfs(int flo,int got,int cond,int cost)
{
	if(flo==lim)
	{
		if(has[cond]==got)
			ans=Min(ans,cost);
		return;
	}
	dfs(flo+1,got,cond,cost);
	dfs(flo+1,got+1,cond|need[flo],cost+co[flo]);
}
void solve1(int n)
{
	for(int i=0;i<n;i++)
		for(int tot=RD();tot--;)
			need[i]|=1<<(RD()-1);
	for(int i=0;i<n;i++)
		co[i]=RD();
	
	for(int i=1;i<(1<<n);i++)
		has[i]=has[i-lowbit(i)]+1;
	lim=n;
	dfs(0,0,0,0);
	printf("%d\n",ans);
}
int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	int n=RD();
	if(n<=20)
		solve1(n);
	else
	{
		for(int i=0;i<n;i++)
			for(int tot=RD();tot--;)
				RD();
		int tans=0;
		for(int i=0;i<n;i++)
			tans+=RD();
		printf("%d\n",tans);
	}
}
