#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath> 
	using namespace std;
const int N=310;
int n,ans;
bool xy=1;
int yc[N],d[N];
int P[4000020];
inline int lowbit(int x) {return x&(-x);}
int sum;
int c(int x){
	int r=0;
	while (x) x-=lowbit(x),++r;
	return r;
}
void calc(int b){
	int p=0,eff=0,t=b;
	while (b) {
		int cur=P[lowbit(b)];
		p|=yc[cur]; eff+=d[cur]; 
		b-=lowbit(b);
	}
	if (c(p)==c(t)) 
		ans=min(ans,eff);
}
int main() {
//	freopen("z.in","r",stdin);
//	freopen("z.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++) {
		int t;
		scanf("%d",&t);
		for (int j=1;j<=t;j++) {
			int u; cin>>u;
			yc[i]|=(1<<u);
		}
	}
	for (int i=1;i<=n;i++) {
		cin>>d[i];
		xy&=(d[i]<0);
		sum+=d[i];
	}
	if (xy) {
		cout<<sum<<endl;
		return 0;
	}
	if (n<=20) {
		for (int i=1;i<=n;i++) P[(1<<(i-1))]=i;
		ans=~0u>>2;
		for (int i=1;i<(1<<n);i++) calc(i);
		cout<<ans<<endl;
	}
	else 
		cout<<min(sum,0)<<endl;
	return 0;
}
/*
3
2 1 2
2 1 2
1 3
-10 20 -3
*/
