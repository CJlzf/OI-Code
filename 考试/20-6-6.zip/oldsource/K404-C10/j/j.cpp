#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#define pb push_back
	using namespace std;
const int N=30010;
int n,m,len;
int ihead[N],to[2*N],inext[2*N],c[N],f[N],cnt;
int dep[N],sz[N];
vector<int> v;
void addedge(int u,int v) {
	inext[++cnt]=ihead[u]; ihead[u]=cnt; to[cnt]=v; 
	inext[++cnt]=ihead[v]; ihead[v]=cnt; to[cnt]=u; 
}
void dfs(int u){
	sz[u]=1;
	for (int i=ihead[u];i;i=inext[i]) {
		int v=to[i];
		if (f[u]!=v) {
			dep[v]=dep[u]+c[v];
			dfs(v);
			sz[u]+=sz[v];
		}
	}
}
void find(int u){
	v.pb(dep[u]);
	for (int i=ihead[u];i;i=inext[i]) {
		int v=to[i];
		if (f[u]!=v) 
			find(v);
	}
}
int main() {
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	cin>>n>>m>>len;
	for (int i=2;i<=n;i++) {
		cin>>f[i]>>c[i];
		addedge(i,f[i]);
	}
	dep[1]=0;
	dfs(1);
	for (int i=1;i<=m;i++) {
		int opt=0,x,k;
		cin>>opt>>x>>k;
		if (opt==1) {
			v.clear();
			find(x);
			if (v.size()<k) cout<<-1<<endl;
			else {
				sort(v.begin(),v.end());
				cout<<v[k-1]<<endl;
			}
		}
		else {
			if (x!=1)
				c[x]+=k;
			else dep[1]+=k;
			dfs(1);
		}
	}
	return 0;
}
/*
3 5 3
1 3
2 3
1 1 3
2 3 3
1 1 3
2 1 2
1 1 3
*/

