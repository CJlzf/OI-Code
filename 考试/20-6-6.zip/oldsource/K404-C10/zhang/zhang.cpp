#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define ll long long
	using namespace std;
const int N=1010;
int n,k,mo;
int d[N],f[N][N];
int ans;
ll fpower(ll a,ll b) {
	ll r=1,base=a,p=b;
	while (p) {
		if (p&1) r=r*base%p;
		base=base*base%p;
		p>>=1;
	}
	return r;
}
int main(){
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	cin>>n>>k>>mo;
	cout<<12<<endl; 
}

