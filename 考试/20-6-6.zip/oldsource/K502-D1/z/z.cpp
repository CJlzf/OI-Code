#include<bits/stdc++.h>

#define sp putchar(' ')
#define ln putchar('\n')
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

typedef long long ll;
typedef std::pair<int, int> pii;

template<typename T>inline bool chkmin(T &a, T b){return b < a ? a = b, true : false;}
template<typename T>inline bool chkmax(T &a, T b){return b > a ? a = b, true : false;}

template<class T> inline T read(T &x)
{
    int sign = 1;
    char c = getchar();
    for(; !isdigit(c); c = getchar())
        if(c == '-')
            sign = -1;
    for(x = 0; isdigit(c); c = getchar())
        x = x * 10 + c - '0';
    return x *= sign;
}
template<class T> inline void write(T x)
{
    if(x == 0) {putchar('0'); return;}
    if(x < 0) {putchar('-'); x = -x;}
    static char s[20];
    int top = 0;
    for(; x; x /= 10)
        s[++ top] = x % 10 + '0';
    while(top)
        putchar(s[top --]);
}

// bool dfs(int u)
// {
//     for(int e = head[u]; e; e = edge[e].next) {
//         int v = edge[e].v;
//         if(vis[v] != timer) {
//             vis[v] = timer;
//             if(!match[v] || dfs(match[v])) {
//                 match[v] = u, match[u] = v;
//                 return true;
//             }
//         }
//     }
//     return false;
// }

const int maxN = 300 + 10;

int a[maxN][maxN], cnt[maxN];
int p[maxN];
bool b[maxN], c[maxN];
int n, ans;

void Update()
{
    int tot1 = 0, tot2 = 0;
    for(int i = 1; i <= n; ++i) {
        b[i] = true;
        for(int j = 1; j <= cnt[i]; ++j)
            b[i] &= c[a[i][j]];
        tot1 += b[i], tot2 += c[i];
    }
    if(tot1 != tot2) return;
    int ret = 0;
    for(int i = 1; i <= n; ++i)
        if(b[i]) ret += p[i];
    chkmin(ans, ret);
}

void dfs(int cur)
{
    if(cur == n + 1) {
        Update();
        return;
    }
    c[cur] = 0;
    dfs(cur + 1);
    c[cur] = 1;
    dfs(cur + 1);
}

int main()
{
    if(fopen("z.in", "r")) {
        freopen("z.in", "r", stdin);
        freopen("z.out", "w", stdout);
    }

    read(n);
    for(int i = 1; i <= n; ++i) {
        read(cnt[i]);
        for(int j = 1; j <= cnt[i]; ++j)
            read(a[i][j]);
    }
    for(int i = 1; i <= n; ++i) read(p[i]);

    ans = 0;
    if(n <= 20)
        dfs(1);
    else {
        std::sort(p + 1, p + n + 1);
        int ret = 0;
        for(int i = 1; i <= n; ++i) chkmin(ans, ret += p[i]);
    }

    write(ans), ln;
    return 0;
}
