#include<bits/stdc++.h>

#define sp putchar(' ')
#define ln putchar('\n')
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

typedef long long ll;
typedef std::pair<int, int> pii;

template<typename T>inline bool chkmin(T &a, T b){return b < a ? a = b, true : false;}
template<typename T>inline bool chkmax(T &a, T b){return b > a ? a = b, true : false;}

template<class T> inline T read(T &x)
{
    int sign = 1;
    char c = getchar();
    for(; !isdigit(c); c = getchar())
        if(c == '-')
            sign = -1;
    for(x = 0; isdigit(c); c = getchar())
        x = x * 10 + c - '0';
    return x *= sign;
}
template<class T> inline void write(T x)
{
    if(x == 0) {putchar('0'); return;}
    if(x < 0) {putchar('-'); x = -x;}
    static char s[20];
    int top = 0;
    for(; x; x /= 10)
        s[++ top] = x % 10 + '0';
    while(top)
        putchar(s[top --]);
}

const int maxN = 1e5 + 100;

struct Edge {
    int v, next;
}edge[maxN << 1];

int n, m, len;
int size[maxN], dep[maxN], w[maxN], a[maxN];
int seq[maxN], dfn[maxN], low[maxN];
int sz = 0;

int head[maxN];

inline void addedge(int u, int v)
{
    static int totedge = 0;
    edge[++ totedge] = (Edge){v, head[u]}, head[u] = totedge;
}

void dfs(int u)
{
    dfn[u] = ++ sz, seq[sz] = u;
    size[u] = 1;
    for(int e = head[u]; e; e = edge[e].next) {
        int v = edge[e].v;
        dep[v] = dep[u] + w[v];
        dfs(v);
        size[u] += size[v];
    }
    low[u] = sz;
}

int main()
{
    if(fopen("j.in", "r")) {
        freopen("j.in", "r", stdin);
        freopen("j.out", "w", stdout);
    }

    read(n), read(m), read(len);
    for(int i = 2; i <= n; ++i) {
        int fa;
        read(fa), read(w[i]);
        addedge(fa, i);
    }

    dfs(1);
    for(int i = 1; i <= n; ++i) a[i] = dep[seq[i]];

    while(m --) {
        int type, u, x;
        read(type), read(u), read(x);
        if(type == 1) {
            if(size[u] < x) {puts("-1"); continue;}
            static int tmp[maxN];
            std::copy(a + dfn[u], a + low[u] + 1, tmp + 1);
            int l = low[u] - dfn[u] + 1;
            std::nth_element(tmp + 1, tmp + x, tmp + l + 1);
            write(tmp[x]), ln;
        } else {
            for(int i = dfn[u]; i <= low[u]; ++i)
                a[i] += x;
        }
    }

    return 0;
}
