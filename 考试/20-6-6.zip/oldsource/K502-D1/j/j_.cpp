#include<bits/stdc++.h>

#define sp putchar(' ')
#define ln putchar('\n')
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

typedef long long ll;
typedef std::pair<int, int> pii;

template<typename T>inline bool chkmin(T &a, T b){return b < a ? a = b, true : false;}
template<typename T>inline bool chkmax(T &a, T b){return b > a ? a = b, true : false;}

template<class T> inline T read(T &x)
{
    int sign = 1;
    char c = getchar();
    for(; !isdigit(c); c = getchar())
        if(c == '-')
            sign = -1;
    for(x = 0; isdigit(c); c = getchar())
        x = x * 10 + c - '0';
    return x *= sign;
}
template<class T> inline void write(T x)
{
    if(x == 0) {putchar('0'); return;}
    if(x < 0) {putchar('-'); x = -x;}
    static char s[20];
    int top = 0;
    for(; x; x /= 10)
        s[++ top] = x % 10 + '0';
    while(top)
        putchar(s[top --]);
}

const int maxN = 1e5 + 100;

struct Edge {
    int v, next;
}edge[maxN << 1];

int n, m, len;
int size[maxN], dep[maxN], w[maxN], a[maxN];
int seq[maxN], dfn[maxN], low[maxN];
int sz = 0;

int head[maxN];

inline void addedge(int u, int v)
{
    static int totedge = 0;
    edge[++ totedge] = (Edge){v, head[u]}, head[u] = totedge;
}

void dfs(int u)
{
    dfn[u] = ++ sz, seq[sz] = u;
    size[u] = 1;
    for(int e = head[u]; e; e = edge[e].next) {
        int v = edge[e].v;
        dep[v] = dep[u] + w[v];
        dfs(v);
        size[u] += size[v];
    }
    low[u] = sz;
}

struct node {
    int size, val, lx, rx, ans, max, min;
    node *fa, *ch[2];
}pond[maxN], *cur = pond, *null = pond, *root;

#define lc ch[0]
#define rc ch[1]

inline node* newnode(int val)
{
    ++ cur;
    cur->size = 1, cur->ans = +inf;
    cur->val = cur->lx = cur->rx = cur->max = cur->min = val;
    cur->fa = cur->lc = cur->rc = null;
    return cur;
}

void update(node *u)
{
    u->size = u->lc->size + u->rc->size + 1;
    u->lx = u->rx = u->max = u->min = u->val;
    u->ans = std::min(u->lc->ans, u->rc->ans);
    chkmin(u->min, u->lc->min);
    chkmin(u->min, u->rc->min);
    chkmax(u->max, u->lc->max);
    chkmax(u->max, u->rc->max);
    if(u->lc != null) u->lx = u->lc->lx, chkmin(u->ans, abs(u->val - u->lc->rx));
    if(u->rc != null) u->rx = u->rc->rx, chkmin(u->ans, abs(u->val - u->rc->lx));
}

#define LOC(u) (u->fa->rc == (u))

void rotate(node *u)
{
    node *v = u->fa;
    int d = LOC(u);

    v->ch[d] = u->ch[!d];
    if(v->ch[d] != null) v->ch[d]->fa = v;
    if(v->fa != null) v->fa->ch[LOC(v)] = u;
    u->fa = v->fa;
    u->ch[!d] = v;
    v->fa = u;
    if(v == root) root = u;

    update(v);
}

void splay(node *u, node *f = null)
{
    while(u->fa != f) {
        node *v = u->fa;
        if(v->fa != f)
            rotate(LOC(u) ^ LOC(v) ? u : v);
        rotate(u);
    }
    update(u);
}

node* select(int k)
{
    node *u = root;
    while(true)
        if(k <= u->lc->size)
            u = u->lc;
        else if(k == u->lc->size + 1)
            return u;
        else
            k -= u->lc->size + 1, u = u->rc;
}

#define extract(l, r) splay(select(l - 1)), splay(select(r + 1), root);

void Delete(int l, int r)
{
    extract(l, r);
    root->rc->lc = null;
    update(root->rc);
    update(root);
}

void Insert(int k, int val)
{
    node *v = newnode(val), *u = root;
    while(true) {
        if(k <= u->lc->size)
            if(u->lc == null)
            {u->lc = v, v->fa = u; break;}
            else u = u->lc;
        else
            if(u->rc == null)
            {u->rc = v, v->fa = u; break;}
            else k -= u->lc->size + 1, u = u->rc;
    }
    // while(u != null)
    //     update(u), u = u->fa;
    splay(v);
}

void Querymax(int l, int r)
{
    extract(l, r);
    write(root->rc->lc->max - root->rc->lc->min), ln;
}

void Querymin(int l, int r)
{
    extract(l, r);
    write(root->rc->lc->ans), ln;
}

void DEBUG(node *u)
{
    if(u == null) return;
    DEBUG(u->lc);
    write(u->val), sp;
    DEBUG(u->rc);
}

int main()
{
    if(fopen("j.in", "r")) {
        freopen("j.in", "r", stdin);
        freopen("j.out", "w", stdout);
    }

    read(n), read(m), read(len);
    for(int i = 2; i <= n; ++i) {
        int fa;
        read(fa), read(w[i]);
        addedge(fa, i);
    }

    dfs(1);
    for(int i = 1; i <= n; ++i) a[i] = dep[seq[i]];

    null->size = 0;
    null->fa = null->lc = null->rc = null;

    return 0;
}
