#include <cstdio>
#include <iostream>
#include <cstring>
#define ll long long
using namespace std;
int n,k;
ll mod,f[21][21]={{0},
	{0,1},
	{0,1,2},
	{0,1,12,3},
	{0,1,48,72,4},
	{0,1,160,810,320,5},
	{0,1,480,6480,6840,1200,6},
	{0,1,1344,42525,143360,70875,4032,7},
};
int main(){
	freopen ("zhang.in","r",stdin);
	freopen ("zhang.out","w",stdout);
	scanf ("%d%d%lld",&n,&k,&mod);
	if (k==1){
		printf ("1\n");
		return 0;
	}
	printf ("%lld\n",f[n][k]%mod);
	return 0;
}

