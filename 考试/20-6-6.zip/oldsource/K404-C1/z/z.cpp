#include <cstdio>
#include <iostream>
#include <cstring>
#include <stack>
using namespace std;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9') {if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9') {x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int n,v[305],cnt=0,ans=0,head[305];
bool choose[305];
struct edge{
	int to,next;
}e[100000];
void add_edge(int from,int to){
	e[cnt].to=to;e[cnt].next=head[from];head[from]=cnt++;
}
void dfs(int now,int cnt){
	if (now>n){
		int c=0,tot=0;
		for (int i=1;i<=n;i++)
			if (choose[i]) c++,tot+=v[i];
		if (c!=cnt) return ;
		ans=min(ans,tot);
		return ;
	}
	dfs(now+1,cnt);
	bool lst[21];
	for (int i=head[now];i!=-1;i=e[i].next){
		int to=e[i].to;
		lst[to]=choose[to];
		choose[to]=1;
	}
	dfs(now+1,cnt+1);
	for (int i=head[now];i!=-1;i=e[i].next){
		int to=e[i].to;
		choose[to]=lst[to];
	}
}
int main(){
	freopen ("z.in","r",stdin);
	freopen ("z.out","w",stdout);
	memset(head,-1,sizeof(head));
	n=read();
	for (int i=1;i<=n;i++){
		int t=read();
		for (int j=1;j<=t;j++){
			int v=read();
			add_edge(i,v);
		}
	}
	for (int i=1;i<=n;i++)
		v[i]=read();
	if (n<=20){
		dfs(1,0);
		printf ("%d\n",ans);
		return 0;
	}
	for (int i=1;i<=n;i++){
		if (v[i]<0) ans+=v[i];
	}
	printf ("%d\n",ans);
	return 0;
}

