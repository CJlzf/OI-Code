#include <cstdio>
#include <iostream>
#include <cstring>
#include <vector>
#include <algorithm>
#define block 310
using namespace std;
const int maxn=100005;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9') {if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9') {x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int n,m,head[maxn],cnt=0,a[maxn],ll[maxn],rr[maxn],dfn=0,sz,ad[400],L[400],R[400];
vector<int>vec[400],A;
struct edge{
	int to,next,c;
}e[maxn<<1];
void add_edge(int from,int to,int c){
	e[cnt].to=to;e[cnt].next=head[from];e[cnt].c=c;head[from]=cnt++;
	e[cnt].to=from;e[cnt].next=head[to];e[cnt].c=c;head[to]=cnt++;
}
void get_tree(int x,int fa,int dep){
	ll[x]=++dfn;a[dfn]=dep;
	for (int i=head[x];i!=-1;i=e[i].next){
		int y=e[i].to;if (y==fa) continue;
		get_tree(y,x,dep+e[i].c);
	}
	rr[x]=dfn;
}
void add(int l,int r,int val){
	int idl=l/block,idr=r/block;
	if (idl==idr){
		for (int i=l;i<=r;i++) a[i]+=val;
		vec[idl].clear();
		for (int i=L[idl];i<=R[idl];i++)
			vec[idl].push_back(a[i]);
		sort(vec[idl].begin(),vec[idl].end());
		return ;
	}
	if (l>L[idl]){
		vec[idl].clear();
		for (int i=l;i<=R[idl];i++) a[i]+=val;
		for (int i=L[idl];i<=R[idl];i++)
			vec[idl].push_back(a[i]);
		sort(vec[idl].begin(),vec[idl].end());
		idl++;
	}
	if (r<R[idr]){
		vec[idr].clear();
		for (int i=r;i>=L[idr];i--) a[i]+=val;
		for (int i=L[idr];i<=R[idr];i++)
			vec[idr].push_back(a[i]);
		sort(vec[idr].begin(),vec[idr].end());
		idr--;
	}
	for (int i=idl;i<=idr;i++) ad[i]+=val;
}
int count1(int l,int r,int val){
	int idl=l/block,idr=r/block;
	A.clear();int res=0;
	if (idl==idr){
		for (int i=l;i<=r;i++) A.push_back(a[i]);
		sort(A.begin(),A.end());
		return upper_bound(A.begin(),A.end(),val-ad[idl])-A.begin();
	}
	if (l>L[idl]){
		for (int i=l;i<=R[idl];i++) A.push_back(a[i]+ad[idl]);
		idl++;
	}
	if (r<R[idr]){
		for (int i=r;i>=L[idr];i--) A.push_back(a[i]+ad[idr]);
		idr--;
	}
	sort(A.begin(),A.end());
	res+=upper_bound(A.begin(),A.end(),val)-A.begin();
	for (int i=idl;i<=idr;i++)
		res+=upper_bound(vec[i].begin(),vec[i].end(),val-ad[i])-vec[i].begin();
	return res;
}
int solve(int l,int r,int k){
	int lll=0,rrr=1000100,res=0;
	while (lll<=rrr){
		int mid=(lll+rrr)>>1;
		if (count1(l,r,mid)>=k) res=mid,rrr=mid-1;
		else lll=mid+1;
	}
	return res;
}
int main(){
	freopen ("j.in","r",stdin);
	freopen ("j.out","w",stdout);
	memset(head,-1,sizeof(head));
	n=read(),m=read(),read();sz=n/block;
	for (int i=2;i<=n;i++){
		int v=read(),c=read();
		add_edge(v,i,c);
	}
	get_tree(1,0,0);
	L[0]=1;for (int i=1;i<=sz;i++) L[i]=i*block;
	R[sz]=n;for (int i=0;i<sz;i++) R[i]=L[i+1]-1;
	for (int i=1;i<=n;i++)
		vec[i/block].push_back(a[i]);
	for (int i=0;i<=sz;i++) sort(vec[i].begin(),vec[i].end());
	int op,x,k;
	for (int i=1;i<=m;i++){
		op=read(),x=read(),k=read();
		if (op==1){
			if (rr[x]-ll[x]+1<k){
				printf ("-1\n");
				continue;
			}
			printf ("%d\n",solve(ll[x],rr[x],k));
		}
		else add(ll[x],rr[x],k);
	}
	return 0;
}

