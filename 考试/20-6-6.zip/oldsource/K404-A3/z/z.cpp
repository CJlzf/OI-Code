#include <cstdio>
#include <vector>
#include <fstream>
using namespace std;
const int MAXN=2000,MAXM=400000,INF=1e9;
struct Edge
{
	int v,c,p;
};
int n;
Edge e[MAXM];
int las[MAXN],slot=-1,par[MAXN];
int vis[MAXN],dis[MAXN],top,fi,la,cur[MAXN];
int p[MAXN];
int perf=0,ans;
vector<int> req[MAXN];
void addedge(int a,int b,int c)
{
	slot++;
	e[slot].v=b;
	e[slot].p=las[a];
	e[slot].c=c;
	las[a]=slot;
}
int dinic(int s,int t)
{
	int flow=0;
	while(true)
	{
		for(int i=0;i<=t;i++)
		{
			dis[i]=0;
		}
		dis[vis[fi=la=1]=s]=1;
		while(fi<=la)
		{
			for(int i=las[vis[fi]];i!=-1;i=e[i].p)
			{
				if(e[i].c && (!dis[e[i].v]))
				{
					dis[vis[++la]=e[i].v]=dis[vis[fi]]+1;
					if(vis[la]==t)
					{
						fi=la;
						break;
					}
				}
			}
			fi++;
		}
		if(!dis[t])
		{
			return flow;	
		}
		for(int i=0;i<=t;i++)
		{
			cur[i]=las[i];
		}
		vis[top=1]=s;
		while(top)
		{
			if(vis[top]==t)
			{
				int upd=INF,loc;
				for(int i=1;i<top;i++)
				{
					if(e[cur[vis[i]]].c<upd)
					{
						loc=i;
						upd=e[cur[vis[i]]].c;
					}
				}
				flow+=upd;
				for(int i=1;i<top;i++)
				{
					e[cur[vis[i]]].c-=upd;
					e[cur[vis[i]]^1].c+=upd;
				}
				top=loc;
			}
			else
			{
				for(int i=cur[vis[top]];i!=-1;cur[vis[top]]=i=e[i].p)
				{
					if(e[i].c && (dis[e[i].v]==dis[vis[top]]+1) && cur[e[i].v]!=-1)
					{
						break;
					}
				}
				if(cur[vis[top]]!=-1)
				{
					vis[top+1]=e[cur[vis[top]]].v;
					top++;
				}
				else
				{
					top--;
				}
			}
		}
	}
}
void init()
{
	scanf("%d",&n);
	for(int i=0;i<=n*2+1;i++)
	{
		las[i]=-1;
	}
	for(int i=1;i<=n;i++)
	{
		req[i].clear();
	}
	for(int i=1;i<=n;i++)
	{
		int t,a;
		scanf("%d",&t);
		for(int j=1;j<=t;j++)
		{
			scanf("%d",&a);
			addedge(i,n+a,1);
			addedge(n+a,i,0);
			req[i].push_back(a);
		}
	}
	for(int i=1;i<=n;i++)
	{
		addedge(0,i,1);
		addedge(i,0,0);
		addedge(n+i,n*2+1,1);
		addedge(n*2+1,n+i,0);
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&p[i]);
	}
	dinic(0,n*2+1);
}
void solve()
{
	for(int i=1;i<=n;i++)
	{
		for(int j=las[i];j!=-1;j=e[j].p)	
		{
			if(e[j].v>n && (!e[j].c))
			{
				par[e[j].v-n]=i;
			}
		}
	}
	slot=-1;
	for(int i=0;i<=n+1;i++)
	{
		las[i]=-1;
	}
	for(int i=1;i<=n;i++)
	{
		for(vector<int>::iterator j=req[i].begin();j<req[i].end();j++)
		{
			if(par[*j]!=i)
			{
				addedge(i,par[*j],INF);
				addedge(par[*j],i,0);
			}
		}
	}
	for(int i=1;i<=n;i++)
	{
		if(p[i]<=0)
		{
			addedge(0,i,-p[i]);
			addedge(i,0,0);
			perf-=p[i];
		}
		else
		{
			addedge(i,n+1,p[i]);
			addedge(n+1,i,0);
		}
	}
	ans=perf-dinic(0,n+1);
	printf("%d\n",-ans);
}
int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	init();
	solve();
	return 0;
}
