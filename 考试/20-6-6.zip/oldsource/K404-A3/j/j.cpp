#include <cstdio>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;
const int MAXN=2000;
int n,m,len;
vector<int> ch[MAXN];
int v[MAXN];
int dep[MAXN];
int top,tmp[MAXN];
void find(int loc)
{
	tmp[++top]=dep[loc];
	for(vector<int>::iterator i=ch[loc].begin();i<ch[loc].end();i++)
	{
		find(*i);
	}
}
void dfs(int loc)
{
	for(vector<int>::iterator i=ch[loc].begin();i<ch[loc].end();i++)
	{
		dep[*i]=dep[loc]+v[*i];
		dfs(*i);
	}
}
int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	scanf("%d%d%d",&n,&m,&len);
	for(int i=2;i<=n;i++)
	{
		int a,b;
		scanf("%d%d",&a,&b);
		ch[a].push_back(i);
		v[i]=b;	
	}
	v[1]=0;
	dep[1]=v[1];
	dfs(1);
	for(int i=1;i<=m;i++)
	{
		int opt,x,k;
		scanf("%d%d%d",&opt,&x,&k);
		if(opt==1)
		{
			top=0;
			find(x);
			sort(tmp+1,tmp+top+1);
			if(k<=top)	
			{
				printf("%d\n",tmp[k]);
			}
			else
			{
				printf("%d\n",-1);
			}
		}
		else
		{
			v[x]+=k;
			dep[1]=v[1];
			dfs(1);
		}
	}
}
