#include <cstdio>
#include <fstream>
using namespace std;
int main()
{
	freopen("zhang.out","w",stdout);
	printf("12\n");
}
