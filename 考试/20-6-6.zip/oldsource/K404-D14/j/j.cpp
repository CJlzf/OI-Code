#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cmath>
#define maxn 100021
using namespace std;
void init(){
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
}
void read(int& x){
	x=0;char c=getchar();
	for(;c>'9'||c<'0';c=getchar());
	for(;c>='0'&&c<='9';c=getchar())x=x*10+c-'0';
}
int block,n,m,bl[maxn],c[350][maxn],lz[maxn],head[maxn];
int tot=1,len,dfn[maxn],cnt,in[maxn],out[maxn],cur[maxn],h[maxn];
int a[maxn],lc[321],rc[321];
int nu;
struct edge{int v,next,w;}e[maxn*2];
void adde(int a,int b,int c){
	e[tot].w=c;
	e[tot].v=b,e[tot].next=head[a];head[a]=tot++;
}
void dfs(int u,int fa){
	cur[in[u]=++cnt]=h[u];
	for(int v,i=head[u];i;i=e[i].next){
		if((v=e[i].v)==fa)continue;
		h[v]=h[u]+e[i].w;
		dfs(v,u);
	}out[u]=cnt;
}
void build(){
	for(int i=1;i<=n;i++)a[i]=cur[i];
	for(int i=1;i<=nu;i++)lc[i]=(i-1)*block+1,rc[i]=i*block;
}
int er(int l,int r,int z){
	int bg=l;
	while(l<r){
		int mid=l+r>>1;
		if(a[mid]<=z)r=mid;
		else l=mid+1;
	}
	if(a[l]>z)l--;
	return l-bg+1;
}
int cont(int l,int r,int x){
	int ans=0;
	if(bl[l]==bl[r]){
		for(int i=l;i<=r;i++){
			ans+=(cur[i]+lz[bl[l]] <= x);
		}
	}else{
		for(int i=bl[l]+1;i<=bl[r]-1;i++){
			ans+=er(lc[i],rc[i],x-lz[i]);
		}
		for(int i=l;i<=rc[bl[l]];i++){
			ans+=(cur[i]+lz[bl[l]] <= x);
		}
		for(int i=lc[bl[r]];i<=r;i++){
			ans+=(cur[i]+lz[bl[r]] <= x);
		}
	}
	return ans;
}
int query(int x,int y,int k){
	if(y-x+1 < k)return -1;
	int l=0,r=300000;
	while(l<r){
		int mid=l+r>>1;
		int c=cont(x,y,mid);
		if(c>=k)r=mid;
		else l=mid+1;
	}
	
	return l;
}
void opp(int x){
	for(int i=lc[x];i<=rc[x];i++){
		a[i]=cur[i];
	}sort(a+lc[x],a+rc[x]+1);
}
void update(int a,int b,int x){
	if(bl[a]==bl[b]){
		for(int i=a;i<=b;i++)cur[i]+=x;
		opp(bl[a]);
	}else{
		for(int i=bl[a]+1;i<=bl[b]-1;i++)lz[i]+=x;
		for(int i=a;i<=rc[bl[a]];i++){
			cur[i]+=x;
			opp(bl[a]);
		}
		for(int i=lc[bl[b]];i<=b;i++){
			cur[i]+=x;
			opp(bl[b]);
		}
	}
}
int main(){
	init();
	scanf("%d%d%d",&n,&m,&len);
	block=sqrt(n),nu=n/block+(n%block!=0);
	for(int i=1;i<=n;i++)bl[i]=(i-1)/block+1;
	for(int a,b,i=2;i<=n;i++){
		read(a);read(b);
		adde(i,a,b),adde(a,i,b);
	}dfs(1,0);
	build();
	int pos,a,b;
	while(m--){
		read(pos);read(a);read(b);
		if(pos==1)printf("%d\n",query(in[a],out[a],b));
		else update(in[a],out[a],b);
	}
	return 0;
}
