#include<cstdio>
#include<cstring>
#include<iostream>
#define maxn 102100
#define LL long long 
using namespace std;
void init(){
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
}
LL n,k,p,f[maxn];
LL mull(LL x,LL y){
	LL ans=1;
	for(;y;y>>=1){
		if(y&1)ans=ans*x%p;
		x=x*x%p;
	}return ans;
}

int main(){
	init();
	scanf("%lld%lld%lld",&n,&k,&p);
	if(k<1){puts("0");return 0;}
	if(k==1){puts("1");return 0;}
	if(n==4&&k==2){puts("12");return 0;}
	LL ans=mull(n,n-2);
	printf("%lld",ans);
	return 0;
}
