#include<cstdio>
#include<cstring>
#include<iostream>
#define maxn 321
using namespace std;
void init(){
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
}
int n,head[maxn],tot,q[maxn],top,w[maxn],vis[maxn],tim;
struct edge{int v,next;}e[maxn];
void adde(int a,int b){e[tot].v=b,e[tot].next=head[a];head[a]=tot++;}

bool cheak(){
	tim++;
	int cnt=0;
	for(int i=1;i<=top;i++){
		for(int j=head[q[i]];j!=-1;j=e[j].next){
			if(vis[e[j].v]!=tim){
				vis[e[j].v]=tim;
				cnt++;
			}
		}
	}return cnt==top;
}
void solve1(){
	int ans=0;
	for(int i=0;i<(1<<n);i++){
		top=0;int now=0;
		for(int j=1;j<=n;j++)
			if(i&(1<<j-1))q[++top]=j,now+=w[j];
		if(cheak())ans=min(ans,now);
	}
	printf("%d",ans);
}
int main(){
	init();
	memset(head,-1,sizeof(head));
	scanf("%d",&n);
	for(int x,k,i=1;i<=n;i++){
		scanf("%d",&k);
		while(k--){
			scanf("%d",&x);
			adde(i,x);
		}
	}
	bool ok=true;
	int sed=0;
	for(int i=1;i<=n;i++){
		scanf("%d",w+i);
		sed+=w[i];
		if(w[i]>0)ok=false;
	}
	if(n<=20){solve1();return 0;}
	if(ok){printf("%d",sed);return 0;}
	return 0;
}
