#include"cstdio"
#include"cstring"
#include"algorithm"
using namespace std;
int n,k,p,ou,ji;
int ans=0;
const int maxn=500001;
int c[maxn];
int jie(int x)
{if(c[x]) return c[x];
c[x]=1;
for(int i=2;i<=x;i++)
c[x]=(c[x]*i)%p;
return c[x];
}
void dfs(int x,int m,int j)
{if(x==0) {for(int j=0;j<=min(j,ji);j++) 
{if(j==0) ans+=1;else ans=(ans+(jie(j)/(jie(j-ji)*jie(ji))))%p;}
ans=ans%p;return;}
for(int i=x;i>=1;i--)
 {if(i<=m)
  dfs(x-i,i,j+1);
 } 
}
main()
{//freopen("zhang.in","r",stdin);
//freopen("zhang.out","w",stdout);
scanf("%d%d%d",&n,&k,&p);
ji=n-2*(k-1)-1;
dfs(k-1,k-1,0);
ans=(ans*jie(n-1))%p;
printf("%d",ans); 
}

