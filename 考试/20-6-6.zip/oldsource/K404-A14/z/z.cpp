#include"cstdio"
#include"cstring"
#include"algorithm"
#include"vector"
#include"queue"
using namespace std;
struct machine
{int p;
vector<int> m;
};
const int maxn=300+10;
machine a[maxn];
int n;
struct daxiao
{int data;
bool flag;
};
daxiao min_daxiao(daxiao a,daxiao b)
 {if(!a.flag) return b;
 else if(!b.flag) return a;
 return a.data<=b.data?a:b;
 }
int f[maxn];
bool visit[maxn];
daxiao dfs(int x,int y,int size,int ans)
{//printf("%d %d %d %d\n",x,y,size,ans);
if(x==n+1) {daxiao op;
if(y==size) op.flag=true;else op.flag=false;op.data=ans;return op;}
//queue<int> q;
daxiao t1=dfs(x+1,y,size,ans);
for(int i=0;i<a[x].m.size();i++)
 if(!visit[a[x].m[i]]) {
 size++;visit[a[x].m[i]]=true;}
 //else q.push(a[x].m[i]); 
daxiao t2=dfs(x+1,y+1,size,ans+a[x].p);
return min_daxiao(t1,t2); 
}
main()
{freopen("z.in","r",stdin);
freopen("z.out","w",stdout);
int x,y,sum=0;
bool flag=true;
scanf("%d",&n);
for(int i=1;i<=n;i++)
 {scanf("%d",&x);
 while(x--) {scanf("%d",&y);a[i].m.push_back(y);f[y]++;}
 }
for(int i=1;i<=n;i++) 
 {scanf("%d",&a[i].p);
 if(a[i].p>0) flag=false;
 }
if(flag) 
 {for(int i=1;i<=n;i++)
 sum+=a[i].p;
 printf("%d",sum);
 return 0;
 }
daxiao ans=dfs(1,0,0,0);
printf("%d",ans.data);  
}
