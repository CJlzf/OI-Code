/*{{{*/
// think twice code once
// Start:[]
// End  :[]
#include <bits/stdc++.h>
using namespace std;

#define rep(i, x, y) for(int i = (x), _ = (y); i <= _; ++ i)
#define per(i, x, y) for(int i = (x), _ = (y); i >= _; -- i)
#define dprintf(...) fprintf(stderr, __VA_ARGS__)
#define disp(x) cout << #x << " = " << x << "; "
#define x first
#define y second
#define mp make_pair
#ifdef __linux__
#define getchar getchar_unlocked
#define LLFORMAT "%lld"
#else
#define LLFORMAT "%I64d"
#endif

typedef long long LL;

template <class T> bool chkmin(T& a, T b) { return a > b ? a = b, true : false; }
template <class T> bool chkmax(T& a, T b) { return a < b ? a = b, true : false; }

template <class T> void read(T& a) {
	char c = getchar(); T f = 1; a = 0;
	for(; !isdigit(c); c = getchar()) if(c == '-') f = -1;
	for(; isdigit(c); c = getchar()) a = a * 10 + c - '0';
	a *= f;
}
/*}}}*/

const int maxN = 105;

int dp[2][maxN][maxN][maxN];
int C[maxN][maxN];
int N, K, mo;

void upd(int& a, int b)
{
	a += b;
	if(a >= mo) a -= mo;
}

int main()
{
	freopen("zhang.in", "r", stdin);
	freopen("zhang.out", "w", stdout);

	read(N); read(K); read(mo);

	rep(i, 0, 100)
	{
		C[i][0] = 1;
		rep(j, 1, i)
			C[i][j] = (C[i - 1][j] + C[i - 1][j - 1]) % mo;
	}

	int cur = 1, last = 0, ans = 0;
	dp[1][1][1][1] = 1;
	rep(i, 2, N)
	{
		swap(cur, last);
		memset(dp[cur], 0, sizeof(dp[cur]));

		rep(j, 1, N) rep(k, 1, N) 
		{
			if(i & 1)
			{
				rep(t, 1, N) rep(lastk, 1, N) if(j >= k && t >= k)
				{
					upd(dp[cur][j][k][t], (LL) dp[last][j - k][lastk][t - k] * k % mo * lastk % mo * C[N - j + k][k] % mo);
				}
			}
			else
			{
				rep(t, 1, N) rep(lastk, 1, N) if(j >= k)
				{
					upd(dp[cur][j][k][t], (LL) dp[last][j - k][lastk][t] * k % mo * lastk % mo * C[N - j + k][k] % mo);
				}
			}
		}
		rep(k, 1, N)
			upd(ans, dp[cur][N][k][K]);
	}

	ans *= 2;
	ans /= 3;
	cout << ans << endl;

	return 0;
}
