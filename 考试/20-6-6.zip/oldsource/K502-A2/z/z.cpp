/*{{{*/
// think twice code once
// Start:[]
// End  :[]
#include <bits/stdc++.h>
using namespace std;

#define rep(i, x, y) for(int i = (x), _ = (y); i <= _; ++ i)
#define per(i, x, y) for(int i = (x), _ = (y); i >= _; -- i)
#define dprintf(...) fprintf(stderr, __VA_ARGS__)
#define disp(x) cout << #x << " = " << x << "; "
#define x first
#define y second
#define mp make_pair
#ifdef __linux__
#define getchar getchar_unlocked
#define LLFORMAT "%lld"
#else
#define LLFORMAT "%I64d"
#endif

typedef long long LL;

template <class T> bool chkmin(T& a, T b) { return a > b ? a = b, true : false; }
template <class T> bool chkmax(T& a, T b) { return a < b ? a = b, true : false; }

template <class T> void read(T& a) {
	char c = getchar(); T f = 1; a = 0;
	for(; !isdigit(c); c = getchar()) if(c == '-') f = -1;
	for(; isdigit(c); c = getchar()) a = a * 10 + c - '0';
	a *= f;
}
/*}}}*/

const int maxN = 305;

int cond[maxN];
int N;
int ans;
int val;
int lala, cnt;
int P[maxN];

void dfs(int cur)
{
	int ori = lala;
	if(cur == N + 1)
	{
		if(__builtin_popcount(lala) == cnt)
			chkmin(ans, val);
		return;
	}

	dfs(cur + 1);
	val += P[cur];
	++ cnt;
	lala |= cond[cur];
	dfs(cur + 1);
	val -= P[cur];
	lala = ori;
	-- cnt;
}

int main()
{
	freopen("z.in", "r", stdin);
	freopen("z.out", "w", stdout);

	read(N);
	rep(i, 1, N)
	{
		int k;
		read(k);
		rep(j, 1, k)
		{
			int a;
			read(a);
			cond[i] |= (1 << (a - 1));
		}
	}
	rep(i, 1, N) read(P[i]);
	if(N > 20)
	{
		int ans = 0;
		rep(i, 1, N) ans += P[i];
		chkmin(ans, 0);
		cout << ans << endl;
	}

	dfs(1);
	cout << ans << endl;

	return 0;
}
