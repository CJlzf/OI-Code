from random import *

out = ""

n = randint(5, 10)
m = randint(5, 10)
l = randint(5, 10)

out += "%d %d %d\n"%(n, m, l)

for i in range(2, n + 1) :
    fa = randint(1, i - 1)
    w = randint(1, l)
    out += "%d %d\n"%(fa, w)

for i in range(1, m + 1):
    ty = randint(1, 2)
    u = randint(1, n)
    out += "%d "%(ty)
    if ty == 1:
        out += "%d %d\n"%(u, randint(1, n))
    else:
        out += "%d %d\n"%(u, randint(1, l))

print >> open("j.in", "w"), out

