/*{{{*/
// think twice code once
// Start:[]
// End  :[]
#include <bits/stdc++.h>
using namespace std;

#define rep(i, x, y) for(int i = (x), _ = (y); i <= _; ++ i)
#define per(i, x, y) for(int i = (x), _ = (y); i >= _; -- i)
#define dprintf(...) fprintf(stderr, __VA_ARGS__)
#define disp(x) cout << #x << " = " << x << "; "
#define x first
#define y second
#define mp make_pair
#ifdef __linux__
#define getchar getchar_unlocked
#define LLFORMAT "%lld"
#else
#define LLFORMAT "%I64d"
#endif

typedef long long LL;

template <class T> bool chkmin(T& a, T b) { return a > b ? a = b, true : false; }
template <class T> bool chkmax(T& a, T b) { return a < b ? a = b, true : false; }

template <class T> void read(T& a) {
	char c = getchar(); T f = 1; a = 0;
	for(; !isdigit(c); c = getchar()) if(c == '-') f = -1;
	for(; isdigit(c); c = getchar()) a = a * 10 + c - '0';
	a *= f;
}
/*}}}*/

const int maxN = 1e5 + 5;

struct Edge
{
	int v, w, next;
}G[maxN << 1];

int N, n, M, len;
int st[maxN], e;
int seq[maxN];
int deep[maxN];
int sz[maxN];

void addedge(int u, int v, int w)
{
	G[++e] = (Edge) {v, w, st[u]};
	st[u] = e;
}

void dfs(int u)
{
	sz[u] = 1;
	for(int e = st[u]; e; e = G[e].next)
	{
		int v = G[e].v;
		deep[v] = deep[u] + G[e].w;
		dfs(v);
		sz[u] += sz[v];
	}
}

void modify(int u, int k)
{
//	dprintf("u = %d\n", u);
	deep[u] += k;
	for(int e = st[u]; e; e = G[e].next)
		modify(G[e].v, k);
}

void getans(int u)
{
	seq[++n] = deep[u];
	for(int e = st[u]; e; e = G[e].next)
		getans(G[e].v);
}

int main()
{
	freopen("j.in", "r", stdin);
	freopen("j1.out", "w", stdout);

	read(N); read(M); read(len);
	rep(i, 2, N)
	{
		int fa, w;
		read(fa), read(w);
		addedge(fa, i, w);
	}

	dfs(1);

//	rep(i, 1, N) disp(i), disp(deep[i]), puts("");

	rep(tt, 1, M)
	{
		int ty, k, u;
		read(ty);
//		dprintf("while tt = %d ty = %d--------\n", tt, ty);
		if(ty == 1)
		{
			read(u), read(k);
			n = 0;
			if(sz[u] < k) 
			{
				puts("-1");
				continue;
			}
			getans(u); 
			sort(seq + 1, seq + n + 1);
			printf("%d\n", seq[k]);
		}
		else
		{
			read(u), read(k);
			modify(u, k);
		}
	}

//	rep(i, 1, N)
//		disp(i), disp(deep[i]), puts("");

	return 0;
}
