/*{{{*/
// think twice code once
// Start:[]
// End  :[]
#include <bits/stdc++.h>
using namespace std;

#define rep(i, x, y) for(int i = (x), _ = (y); i <= _; ++ i)
#define per(i, x, y) for(int i = (x), _ = (y); i >= _; -- i)
#define dprintf(...) fprintf(stderr, __VA_ARGS__)
#define disp(x) cout << #x << " = " << x << "; "
#define x first
#define y second
#define mp make_pair
#ifdef __linux__
#define getchar getchar_unlocked
#define LLFORMAT "%lld"
#else
#define LLFORMAT "%I64d"
#endif

typedef long long LL;

template <class T> bool chkmin(T& a, T b) { return a > b ? a = b, true : false; }
template <class T> bool chkmax(T& a, T b) { return a < b ? a = b, true : false; }

template <class T> void read(T& a) {
	char c = getchar(); T f = 1; a = 0;
	for(; !isdigit(c); c = getchar()) if(c == '-') f = -1;
	for(; isdigit(c); c = getchar()) a = a * 10 + c - '0';
	a *= f;
}
/*}}}*/

const int maxN = 5e5 + 5;

struct Edge
{
	int v, w, next;
}G[maxN << 1];

int N, len, M;
int st[maxN], e;
int A[maxN], seq[maxN];
int dfn[maxN], ed[maxN], dfs_clock;

void addedge(int u, int v, int w)
{
	G[++e] = (Edge) {v, w, st[u]};
	st[u] = e;
}

void dfs(int u)
{
	seq[dfn[u] = ++ dfs_clock] = A[u];
	for(int e = st[u]; e; e = G[e].next)
	{
		int v = G[e].v;
		A[v] = A[u] + G[e].w;
		dfs(v);
	}

	ed[u] = dfs_clock;
}

namespace BK
{
	const int BL_SIZE = 2000;

	struct Blocks
	{
		int l, r, sz;
		int lz;
		int a[BL_SIZE + 5]; // ori
		int b[BL_SIZE + 5]; // after sort

		void rebuild()
		{
			rep(i, 1, sz) 
			{
				a[i] += lz;
				b[i] = a[i];
			}
			lz = 0;
			sort(b + 1, b + sz + 1);
		}

		inline int getsum(int v) { return upper_bound(b + 1, b + sz + 1, v - lz) - b - 1; }
	}B[maxN / (BL_SIZE + 5) + 5];

	int L[maxN];
	int SZ;
	int n;

	void build(int* seq)
	{
		SZ = min(BL_SIZE, int(sqrt(N * log(N))));

		for(int i = 1; i <= N; i += SZ)
		{
			++n;
			B[n].l = i;
			B[n].r = min(N, i + SZ - 1);
			B[n].sz = B[n].r - B[n].l + 1;
			L[n] = i;
			rep(j, B[n].l, B[n].r) B[n].a[j - B[n].l + 1] = seq[j];
			B[n].rebuild();
		}
	}

	void add(int l, int r, int v)
	{
		int lb = upper_bound(L + 1, L + n + 1, l) - L - 1;
		int rb = upper_bound(L + 1, L + n + 1, r) - L - 1;

		rep(i, l - (lb - 1) * SZ, min(B[lb].sz, r - (lb - 1) * SZ)) 
			B[lb].a[i] += v;
		B[lb].rebuild();

		if(lb != rb)
		{
			rep(i, 1, r - (rb - 1) * SZ) B[rb].a[i] += v;
			B[rb].rebuild();
		}

		rep(i, lb + 1, rb - 1) B[i].lz += v;
	}

	int getsum(int l, int r, int v)
	{
		int lb = upper_bound(L + 1, L + n + 1, l) - L - 1;
		int rb = upper_bound(L + 1, L + n + 1, r) - L - 1;
		int ret = 0;

		rep(i, l - (lb - 1) * SZ, min(B[lb].sz, r - (lb - 1) * SZ)) 
			ret += ((B[lb].a[i] + B[lb].lz) <= v);
		if(lb != rb)
			rep(i, 1, r - (rb - 1) * SZ) ret += ((B[rb].a[i] + B[rb].lz) <= v);

		rep(i, lb + 1, rb - 1) ret += B[i].getsum(v);
		return ret;
	}

//	int getmax(int l, int r)
//	{
//		int lb = upper_bound(L + 1, L + n + 1, l) - L - 1;
//		int rb = upper_bound(L + 1, L + n + 1, r) - L - 1;
//		int ret = 0;
//		rep(i, l - (lb - 1) * SZ, min(B[lb].sz, r - (lb - 1) * SZ)) 
//			ret += ((B[lb].a[i] + B[lb].lz) <= v);
//			chkmax(ret, (B[lb].a[i] + B[lb].lz));
//		if(lb != rb)
//			rep(i, 1, r - (rb - 1) * SZ) chkmax(ret, (B[rb].a[i] + B[rb].lz));
//
//		rep(i, lb + 1, rb - 1) chkmax(ret, B[i].b[B[i].sz] + B[i].lz);
//		return ret;
//	}
//
	int getans(int L, int R, int k)
	{
		int l = -1, r = 2 * N * len;
		while(l + 1 < r)
		{
			int mid = (l + r) >> 1;
			if(getsum(L, R, mid) < k)
				l = mid;
			else
				r = mid;
		}
		
		return r;
	}

	void print()
	{
		rep(i, 1, n)
		{
			rep(j, 1, B[i].sz)
				printf("%d ", B[i].a[j] + B[i].lz);
			puts("");
		}
	}
}

int main()
{
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);
#ifdef Leeson
	double st = clock();
#endif

	read(N); read(M); read(len);
	rep(i, 2, N)
	{
		int fa, w;
		read(fa), read(w);
		addedge(fa, i, w);
	}

	dfs(1);

	BK::build(seq);

	rep(tt, 1, M)
	{
//	BK::print();
		int ty, u, k;
		read(ty);
		if(ty == 1)
		{
			read(u), read(k);
			if(ed[u] - dfn[u] + 1 < k) 
			{
				puts("-1");
				continue;
			}
			printf("%d\n", BK::getans(dfn[u], ed[u], k));
		}
		else
		{
			read(u), read(k);
			BK::add(dfn[u], ed[u], k);
		}
//	BK::print();
	}

#ifdef Leeson
	cerr << (clock() - st) / CLOCKS_PER_SEC << endl;
#endif

	return 0;
}
