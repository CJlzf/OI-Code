#include<cstdio>
int main() {
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	int n,k,p;
	scanf("%d%d%d",&n,&k,&p);
	if(n==4&&k==2&&p==998244353)return puts("12"),0;
	if(k==1)return puts("1"),0;
	return puts("0"),0;
}
