#include<cstdio>
#include<cstring>
#include<cctype>
#include<algorithm>
#include<vector>
using namespace std;
inline int read() {
	char ch;int x=0;bool f=0;while(ch=getchar(),ch<'!');if(ch=='-')f=1,ch=getchar();
	while(x=x*10+ch-'0',ch=getchar(),isdigit(ch));return f?-x:x;
}
const int N=1005;
int n,m,len;
int f[N],size[N],dist[N];
int val[N],tp;
vector<int> G[N];
void dfs(int u){
	size[u]=1;
	for(int i=0,v;i<G[u].size();i++) {
		if((v=G[u][i])==f[u])continue;
		dist[v]+=dist[u]; dfs(v); size[u]+=size[v];
	}
}
void find(int u) {
	val[++tp]=dist[u];
	for(int i=0,v;i<G[u].size();i++) 
		if((v=G[u][i])!=f[u])find(v);
}
void add(int u,int k) {
	dist[u]+=k;
	for(int i=0,v;i<G[u].size();i++)
		if((v=G[u][i])!=f[u])add(v,k);
}
int main() {
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	n=read(),m=read(),len=read();
	for(int i=2;i<=n;i++) 
		scanf("%d%d",f+i,dist+i),G[f[i]].push_back(i),G[i].push_back(f[i]);
	dfs(1);
	for(int i=1,op,x,k;i<=m;i++) {
		op=read(),x=read(),k=read();
		if(op==1) {
			if(size[x]<k)puts("1");
			else {
				tp=0; find(x);
				sort(val+1,val+tp+1);
				printf("%d\n",val[k]);
			}
		} else {
			add(x,k);
		}
	}
	return 0;
}
