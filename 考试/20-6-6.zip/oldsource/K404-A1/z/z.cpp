#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int N=305;
int n,a[N][N],p[N];
namespace One
{
	int bitcnt[1<<21],s[1<<21],b[N];
	int main() {
		for(int i=1;i<(1<<n);i++)bitcnt[i]=bitcnt[i>>1]+(i&1);
		for(int i=1;i<=n;i++)s[1<<i-1]=p[i];
		for(int i=1;i<(1<<n);i++)s[i]=s[i^(i&-i)]+s[i&-i];
		for(int i=1;i<=n;i++)
			for(int j=1;j<=a[i][0];j++)
			b[i]|=(1<<a[i][j]-1);
		int ans=0;
		for(int i=0;i<(1<<n);i++) {
			int k=0;
			for(int j=0;j<n;j++)
				if(i>>j&1)k|=b[j+1];
			if(bitcnt[k]==bitcnt[i])ans=min(ans,s[i]);
		}
		printf("%d\n",ans);
		return 0;
	}
}
namespace Two
{
	int main() {
		int ans=0;
		for(int i=1;i<=n;i++)ans+=p[i];
		printf("%d\n",ans);
		return 0;
	}
}
int main() {
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) {
		scanf("%d",a[i]);
		for(int j=1;j<=a[i][0];j++)
			scanf("%d",a[i]+j);
	}
	for(int i=1;i<=n;i++)scanf("%d",p+i);
	if(n<=20)return One::main();
	return Two::main();
}
