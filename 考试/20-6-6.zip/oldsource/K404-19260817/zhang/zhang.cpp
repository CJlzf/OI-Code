#include <cstdio>

int main() {
  freopen("zhang.in", "r", stdin);
  freopen("zhang.out", "w", stdout);
  puts("12");
  return 0;
}

