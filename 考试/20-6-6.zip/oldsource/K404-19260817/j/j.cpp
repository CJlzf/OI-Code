#include <cstdio>
#include <algorithm>
#include <vector>

const int Nmax = 1001;
struct Edge {
  int p;
  Edge*next;
} *V[Nmax];
void addEdge(const int&a, const int&b) {
  Edge*t = new Edge;
  t->p = b;
  t->next = V[a];
  V[a] = t;
}

int v[Nmax];
int fa[Nmax];

void add(const int&o, const int&a) {
  ::v[o] += a;
  for(Edge*v = V[o]; v != 0; v = v->next) add(v->p, a);
}

std::vector<int> H;
void Q(const int&o) {
  H.push_back(::v[o]);
  for(Edge*v = V[o]; v != 0; v = v->next) Q(v->p);
}

int query(const int&o, const int&k) {
  H.clear();
  Q(o);
  if(H.size()>(unsigned int)k) return -1;
  else {
    std::nth_element(H.begin(), H.begin()+k-1, H.end());
    return H[k-1];
  }
}

int N, M, L;
int U[Nmax];
int main() {
  freopen("j.in", "r", stdin);
  freopen("j.out","w",stdout);
  scanf("%d%d%d", &N, &M, &L);
  for(int i = 2; i <= N; ++i) {
    int p; scanf("%d%d", &p, &U[i]);
    addEdge(p, i);
  }
  for(int i = 2; i <= N; ++i) add(i, U[i]);
  while(M--) {
    int opt, x, k;
    scanf("%d%d%d", &opt, &x, &k);
    if(opt == 1) printf("%d\n", query(x, k));
    else add(x, k);
  }
  return 0;
}

