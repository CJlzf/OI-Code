#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
const int  MAX2N = 300;
int m[MAX2N + 5][MAX2N + 5], p[MAX2N + 5], fz, lz, ff, lf, sumd[MAX2N + 5], n; 
long long besta = 0;
int t[MAX2N + 5];
bool d[MAX2N+5], dt[MAX2N + 5]; 
int INP()
{
	scanf("%d\n",&n);
	int ty = 0;
	for(int i = 1; i<=n; i++)
	{
		scanf("%d ", &t[i]);
		for(int j = 1; j <= t[i]; j ++)
			scanf("%d ", &m[i][j]);
		scanf("\n");
	}
	for(int j = 1; j<= n; j++)
	{
		scanf("%d ",&p[j]);
		if (p[j] > 0) ty += 1;
		else
			ty -= 1;		
	}
	scanf("\n");
	return ty;
}
void pre()
{
	for(int i = 1; i<=n; i++)
		if(p[i] > 0)
		{
			fz = i;
			break;	
		}
	for(int i = 1; i<=n; i++)
		if(p[i] < 0)
		{
			ff = i;
			break;	
		}
	for(int i = n; i>=1; i--)
		if(p[i] > 0)
		{
			lz = i;
			break;	
		}
	for(int i = n; i>=1; i--)
		if(p[i] < 0)
		{
			ff = i;
			break;	
		}
	for(int i = n; i>=1; i--)
		sumd[i] = sumd[i+1] + (p[i] < 0) * p[i];
}
void check()
{
	int u = 0,v = 0;
	long long w = 0;
	for(int i = 1; i <= n; i++)
	{
		if (d[i])
		{ 
			u ++;
			for(int j = 1; j <= t[i]; j++)
				if (!dt[m[i][j]]) 
				{
					v++;
					w += (long long)p[m[i][j]];
				}
		}
	}
	if(u == v) 
			besta = min(besta, w);
}
void search1(int x)
{
	int ans = 0;
	if(x > n) 
	{
		check();
		return;
	}
	d[x] = true;
	search1(x+1);
	d[x] = false;
	search1(x+1);
}
int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	int s = INP();
	if(s == -n)
	{
		int sum1 = 0;
		for(int i = 1; i<=n; i++)
			sum1 += p[i];
		printf("%d\n",sum1);
	}
	if(s == n)
		printf("0\n");
	if(s > -n && s < n)
	{
		//pre1();
		search1(1);
		printf("%d\n",besta);
	}
	return 0;
}
