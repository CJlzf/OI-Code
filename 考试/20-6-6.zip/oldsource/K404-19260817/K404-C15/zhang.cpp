#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	printf("%12\n");
	return 0;
}
