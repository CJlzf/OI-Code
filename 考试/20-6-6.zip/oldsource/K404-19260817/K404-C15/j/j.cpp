#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn = 1000;
int n,m,len,mt[maxn+10][maxn+10], fa[maxn+10], a[maxn+10], que[maxn+10], size1[maxn+10], j;
int dfs(int x)
{
	size1[x] = 0;
	if(x > n) return 0;
	for(int i = 1; i<=n; i++)
		if(mt[x][i] && fa[x] != i)
			size1[x] += dfs(i);
	size1[x]++;
	return size1[x];
}
int dfs2(int x,int lenp)
{
	if(x > n) return 0;
	que[++j] =lenp;
	for(int i = 1; i<=n; i++)
		if(mt[x][i] && fa[x] != i)
			dfs2(i, lenp + mt[x][i]);
	return 0;
}
int cmp(int a,int b)
{
	return a>b;
}
int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	scanf("%d %d %d\n", &n, &m, &len);
	int u, v;
	for(int i = 1 ; i <= n-1; i++)
	{
		scanf("%d %d\n", &u, &v);
		mt[i][u] = mt[u][i] = v;
		fa[i] = u;
	}
	int op, x, k;
	dfs(1);
	for(int i = 1; i <= m; i ++)
	{
		scanf("%d %d %d\n", &op, &x, &k);
		if(size1[x] >= k)
		{
		if(op == 1)
		{
			j = 0;
			dfs2(x,0);
		}
		sort(que+1, que + size1[x]+1,cmp);
		printf("%d\n", &que[k]);
		}
		else
			printf("-1\n");
	}
	return 0;
}
