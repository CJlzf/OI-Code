#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
//#include<ctime>
using namespace std;

void read(int &x)
{
	char c=getchar(); x=0;
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9') x=x*10+c-'0',c=getchar();
}

const int maxn=2e5+10;

int n,m,lim,fa[maxn],w[maxn];
int tote,TO[maxn],NEXT[maxn],FIR[maxn];
int sz[maxn],val[maxn],L[maxn],R[maxn];
int times,dfn[maxn];

void addedge(int u,int v)
{
	TO[++tote]=v;
	NEXT[tote]=FIR[u];
	FIR[u]=tote;
}

void dfs(int u,int dis)
{
	sz[u]=1;
	dfn[++times]=u;
	val[times]=dis;
	L[u]=times;
	for (int p=FIR[u];p;p=NEXT[p])
		dfs(TO[p],dis+w[TO[p]]),sz[u]+=sz[TO[p]];
	R[u]=times;
}

const int SIZE=300;
int a[(100010/SIZE)+5][SIZE+5];
int lz[(100010/SIZE)+5],b[(SIZE+5)<<1],len,Lk,Rk;

void build()
{
	for (int i=0,x=0;i<n;i+=SIZE,x++)
	for (int j=i;j<i+SIZE&&j<n;j++) a[x][j-i]=val[j];
	int num=(n-1)/SIZE,tmp=SIZE*(num+1);
	for (int i=n;i<tmp;i++) val[num*SIZE+i]=a[num][i]=1e8;
	for (int i=0;i<=num;i++) sort(a[i],a[i]+SIZE);
	memset(lz,0,sizeof(lz));
}

void rebuild(int num)
{
	int i,s=SIZE*num,t=s+SIZE;
	for (i=s;i<t;i++)
		a[num][i-s]=val[i]+=lz[num];
	sort(a[num],a[num]+SIZE);
	lz[num]=0;
}

void modify(int l,int r,int k)
{
	int i,num=l/SIZE,tmp;

	tmp=min(r+1,SIZE*(num+1));
	for (i=l;i<tmp;i++) val[i]+=k;
	rebuild(num);

	tmp=r/SIZE;
	for (i=num+1;i<tmp;i++) lz[i]+=k;

	if (l/SIZE==r/SIZE) return;
	num=tmp;
	for (i=num*SIZE;i<=r;i++) val[i]+=k;
	rebuild(num);
}

void prework(int l,int r)
{
	int i,num=l/SIZE,tmp;
	len=0;

	tmp=min(r+1,SIZE*(num+1));
	for (i=l;i<tmp;i++)
		b[len++]=val[i]+lz[num];

	tmp=r/SIZE;
	Lk=num+1;
	Rk=tmp-1;

	if (l/SIZE==r/SIZE) return;
	num=tmp;
	for (i=num*SIZE;i<=r;i++)
		b[len++]=val[i]+lz[num];
}

int count(int k)
{
	int i,cnt=0,l,r,mid;
	for (i=Lk;i<=Rk;i++)
	{
		l=0; r=SIZE-1;
		while (l<=r)
		{
			mid=(l+r)>>1;
			if (a[i][mid]+lz[i]<=k) l=mid+1;
			else r=mid-1;
		}
		cnt+=r+1;
	}
	l=0; r=len-1;
	while (l<=r)
	{
		mid=(l+r)>>1;
		if (b[mid]<=k) l=mid+1;
		else r=mid-1;
	}
	cnt+=r+1;
	return cnt;
}

int main()
{
//	long long ST=clock();
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	int i,op,x,k;
	read(n); read(m); read(lim);
	for (i=2;i<=n;i++)
	{
		read(fa[i]);
		read(w[i]);
		addedge(fa[i],i);
	}
	dfs(1,0);
	n++;
	build();
	while (m--)
	{
		read(op); read(x); read(k);
		if (op==1)
		{
			if (k>sz[x]) puts("-1");
			else
			{
				prework(L[x],R[x]);
				sort(b,b+len);
				int l=0,r=1e7+100,mid;
				while (l<=r)
				{
					mid=(l+r)>>1;
					if (count(mid)<k) l=mid+1;
					else r=mid-1;
				}
				printf("%d\n",l);
			}
		}
		if (op==2) modify(L[x],R[x],k);
	}
//	printf("using time = %lld\n",clock()-ST);
}

