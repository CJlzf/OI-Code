#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;

const int maxn=310;
const int maxm=200010;

int n,SS,TT,left[maxn];
int tote,FIR[maxn],_FIR[maxn];
int NEXT[maxm],TO[maxm],CAP[maxm];
int edgecnt;
bool vis[maxn];

struct edge{
	int u,v;
	edge() {}
	edge(int u,int v):u(u),v(v) {}
}e[maxm];

void addedge(int u,int v)
{
	TO[++tote]=v;
	NEXT[tote]=FIR[u];
	FIR[u]=tote;
}

void addedge(int u,int v,int cap)
{
	TO[++tote]=v;
	NEXT[tote]=FIR[u];
	CAP[tote]=cap;
	FIR[u]=tote;

	TO[++tote]=u;
	NEXT[tote]=FIR[v];
	CAP[tote]=0;
	if (v!=TT) FIR[v]=tote;
}

bool match(int u)
{
	for (int p=FIR[u];p;p=NEXT[p])
	{
		int v=TO[p];
		if (!vis[v])
		{
			vis[v]=1;
			if (!left[v]||match(left[v]))
			{
				left[v]=u;
				return 1;
			}
		}
	}
	return 0;
}

int q[maxn],dis[maxn];
bool build()
{
	int H=0,T=1;
	q[1]=SS;
	memset(dis,0,sizeof(dis));
	dis[SS]=1;
	while (H-T)
	{
		int u=q[++H];
		for (int p=FIR[u];p;p=NEXT[p]) if (CAP[p])
		{
			int v=TO[p];
			if (!dis[v])
			{
				dis[v]=dis[u]+1;
				q[++T]=v;
			}
		}
	}
	return dis[TT];
}

int dfs(int u,int lim)
{
	if (u==TT||!lim) return lim;
	int use=0,res=lim;
	for (int &p=_FIR[u];p;p=NEXT[p])
	{
		int v=TO[p];
		if (dis[v]==dis[u]+1)
		{
			int flow=dfs(v,min(res,CAP[p]));
			CAP[p]-=flow;
			CAP[p^1]+=flow;
			res-=flow;
			use+=flow;
			if (!res) break;
		}
	}
	return use;
}

int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	int i,k,x;
	scanf("%d",&n);
	for (i=1;i<=n;i++)
	{
		scanf("%d",&k);
		while (k--)
			scanf("%d",&x),addedge(i,x);
	}
	for (i=1;i<=n;i++)
	{
		memset(vis,0,sizeof(vis));
		match(i);
	}

	for (int u=1;u<=n;u++)
		for (int p=FIR[u];p;p=NEXT[p])
			e[++edgecnt]=edge(u,left[TO[p]]);
	SS=n+1;
	TT=n+2;
	tote=1;
	memset(FIR,0,sizeof(FIR));
	for (i=1;i<=edgecnt;i++)
		addedge(e[i].u,e[i].v,1e9);

	int Ans=0;
	for (i=1;i<=n;i++)
	{
		scanf("%d",&x);
		x=-x;
		if (x>=0) addedge(SS,i,x),Ans+=x;
		else addedge(i,TT,-x);
	}

	while (build())
	{
		memcpy(_FIR,FIR,sizeof(FIR));
		Ans-=dfs(SS,1e9);
	}
	printf("%d\n",-Ans);
}

