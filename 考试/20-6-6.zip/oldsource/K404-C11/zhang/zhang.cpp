#include <cstdio>
#include <cstring>

const int N=500010;

struct Edge{
	int next,to;
}e[N];

int n,k,p,head[N],tope,cnt,dep[N],ans;
bool used[N];

void ae(int x,int y) {
	tope++;
	e[tope].to=y;
	e[tope].next=head[x];
	head[x]=tope;
}


bool checK(int x) {
	if (dep[x]%2) cnt++;
	for (int i=head[x],y=e[i].to;i;i=e[i].next,y=e[i].to) {
		dep[y]=dep[x]+1;
		checK(y);
	}
	if (cnt==k) return true;
}

void dfs(int k) {
	if (k==n) {
		dep[1]=1;
		cnt=0;
		if (checK(1))
			ans++;
		memset(e,0,sizeof(e));
	} else {
		for (int i=2;i<=n;i++) {
			if (!used[i]) {
				ae(k,i);
				used[i]=true;
				dfs(i);
				used[i]=false;
			}
		}
	}
}

int main() {
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	scanf("%d%d%d",&n,&k,&p);
	/*
	for (int i=1;i<=n;i++) {
		memset(e,0,sizeof(e));
		for (int j=1;j<=n;j++) {
			if (i!=j) 
				ae(i,j);
		}
		dep[1]=1;
		cnt=0;
		if (checK(1)) 
			ans++;
	}
	*/
	//used[1]=true;
	//dfs(1);
	printf("12\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
