#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

int n,N,ans=0;
int med[500][500];
int eff[500];
int eat[500];
bool used[500];
int preeff[500];

void pf() {
	for (int i=1;i<=N;i++) {
		printf("%d ",eat[i]);
	}
	printf("\n");
}

int getnew() {
	int temp=0;
	bool tused[500];
	memset(tused,0,sizeof(tused));
	for (int i=1;i<=N;i++) {
		for (int j=1;j<=med[eat[i]][0];j++) {
			if (!tused[med[eat[i]][j]]) {
				temp++;
				tused[med[eat[i]][j]]=true;
			}
		}
	}
	if (temp==N) {
		int ttemp=0;
		for (int i=1;i<=N;i++) {
			ttemp+=eff[eat[i]];
		}
		if (ttemp<0) return ttemp;
		else return 0;
	}
	return 0;
}

void dfs(int k) {
	if (k==N+1) {
		//pf();
		ans=min(ans,getnew());
	} else {
		for (int i=1;i<=n;i++) {
			if (!used[i]&&i>eat[k-1]) {
				used[i]=true;
				eat[k]=i;
				dfs(k+1);
				used[i]=false;
			}
		}
	}
}


int main() {
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++) {
		scanf("%d",&med[i][0]);
		for (int j=1;j<=med[i][0];j++) {
			scanf("%d",&med[i][j]);
		}
	}
	for (int i=1;i<=n;i++) 
		scanf("%d",&eff[i]);
	for (int i=1;i<=n;i++) {
		N=i;
		dfs(1);
	}
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
