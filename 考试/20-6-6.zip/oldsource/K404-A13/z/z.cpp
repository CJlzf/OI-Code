#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

 #define rep(i, a, b) for (int i = a; i <= b; i++)

 const int N = 20 + 5, INF = 0x7f7f7f7f;

 int has[N], wei[N];
 int t, n, x;

 void solve_30_per() {
 	int U = (1 << n) - 1, ans = INF;
 	rep(i, 1, U) {
 		int tmp = i, j = 1, cnt1 = 0, cnt2 = 0, S = 0, cur = 0;
 		while (tmp) {
 			if (tmp & 1) S |= has[j], cnt1++, cur += wei[j];
 			tmp >>= 1; j++;
 		}
 		if (cur > ans) continue;
 		while (S) {
 			if (S & 1) cnt2++;
 			S >>= 1;
 		}
 		if (cnt1 == cnt2) ans = min(ans, cur);
 	}
 	printf("%d\n", ans);
 }

int main()
{
	freopen("z.in", "r", stdin);
	freopen("z.out", "w", stdout);
	
	scanf("%d", &n);
	rep(i, 1, n) {
		scanf("%d", &t);
		rep(j, 1, t) scanf("%d", &x), has[i] |= (1 << (x - 1));
	}
	bool flag = false;
	rep(i, 1, n) scanf("%d", &wei[i]), flag |= (wei[i] > 0);
	if (!flag) {
		int ans = 0;
		rep(i, 1, n) ans += wei[i];
		printf("%d\n", ans);
		return 0;
	}
	else solve_30_per();
	return 0;
}

