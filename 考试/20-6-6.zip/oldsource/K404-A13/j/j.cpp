#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
using namespace std;

 #define rep(i, a, b) for (int i = a; i <= b; i++)
 #define fill(a, x) memset(a, x, sizeof(a))
 
 const int N = 50000 + 5, max_Len = 50000 * 10 + 5, RT = 226;
 
 struct Block { int l, r; } blk[RT];
 int n, q, w, x, k, mode, es, bsz, num, maxl, dfs_clock, len;
 int pre[N], bel[N], dep[N], fwk[RT][max_Len];
 int prev[N], post[N], mark[N], tmp[N];
 
 struct Edge { int to, pre, w; } e[N * 2];
 void ine(int a, int b, int w) {
 	es++;
 	e[es].to = b; e[es].pre = pre[a]; e[es].w = w;
 	pre[a] = es;
 }
 void ine2(int a, int b, int w) { ine(a, b, w); ine(b, a, w); }
 #define reg(i, x) for (int i = pre[x]; i; i = e[i].pre)
 
 inline void fwk_update(int id, int val, int d) {
 	int *cur = fwk[id];
 	if (!val) { cur[val] += d; return; }
 	while (val <= maxl) {
 		cur[val] += d;
 		val += (val & (-val));
 	}
 }
 
 inline int fwk_query(int id, int val) {
 	if (val < 0) return 0;
 	int ret = 0, *cur = fwk[id];
 	while (val) {
 		ret += cur[val];
 		val -= (val & (-val));
 	}
 	return ret + cur[0];
 }
 
 inline void force_update(int id, int x, int y) {
 	rep(i, x, y) {
 		int ori = dep[i], now = dep[i] = ori + k;
 		fwk_update(id, ori, -1);
 		fwk_update(id, now, +1);
 	}
 }
 
 inline int force_query(int id, int x, int y, int val) {
 	int ret = 0, mkid = mark[id];
 	rep(i, x, y) if (dep[i] + mkid <= val) ret++;
 	return ret;
 }

 inline int get_ord(int x, int val) {
 	val--;
	int ret = 0, l = prev[x], r = post[x], bl = bel[l], br = bel[r];
 	int lbl = blk[bl].l, lbr = blk[bl].r, rbl = blk[br].l, rbr = blk[br].r;
 	if (bl == br) {
 		if (bl == lbl && br == rbr) return fwk_query(bl, val - mark[bl]);
 		else return force_query(bl, l, r, val);
	}
	
	rep(i, bl + 1, br - 1) ret += fwk_query(i, val - mark[i]);
	ret += (bl == lbl ? fwk_query(bl, val - mark[bl]) : force_query(bl, l, lbr, val));
	ret += (br == rbr ? fwk_query(br, val - mark[br]) : force_query(br, rbl, r, val));
	return ret;
 }

 inline void op_update(int x, int k) {
 	int l = prev[x], r = post[x], bl = bel[l], br = bel[r];
 	int lbl = blk[bl].l, lbr = blk[bl].r, rbl = blk[br].l, rbr = blk[br].r;
 	if (bl == br) {
 		if (bl == lbl && br == rbr) mark[bl] += k;
 		else force_update(bl, l, r);
 		return;
	}
	rep(i, bl + 1, br - 1) mark[i] += k;
	if (bl == lbl) mark[bl] += k; else force_update(bl, l, lbr);
	if (br == rbr) mark[br] += k; else force_update(br, rbl, r);
 }
 
 inline void op_query(int x, int k) {
 	if (post[x] - prev[x] + 1 < k) { puts("-1"); return; }
 	int mid, l = -1, r = maxl + 1;
 	while (l + 1 < r) {
 		mid = (l + r) >> 1;
 		if (mid == 0) { l = mid; break; }
 		if (get_ord(x, mid) < k - 1) l = mid; else r = mid;
 	}
 	printf("%d\n", l);
 }
 
 void dfs(int x, int deep, int dad) {
 	prev[x] = ++dfs_clock;
 	dep[dfs_clock] = deep;
 	reg(i, x) {
 		int y = e[i].to;
 		if (y == dad) continue;
 		dfs(y, deep + e[i].w, x);
 	}
 	post[x] = dfs_clock;
 }
 
 void init_graph() {
 	dfs_clock = es = 0;
 	fill(pre, 0);
 }
 
 void init_blocks() {
 	bsz = ceil(pow(n, 0.5));
 	num = n / bsz + 1;
 	rep(i, 1, n) bel[i] = i / bsz + 1;
 	blk[1].l = 1;
 	rep(i, 2, n) if (bel[i] != bel[i - 1]) {
 		blk[bel[i - 1]].r = i - 1;
 		blk[bel[i]].l = i;
 	}
 	blk[num].r = n;
 	fill(fwk, 0);
 	fill(mark, 0);
 	rep(i, 1, num) {
 		int l = blk[i].l, r = blk[i].r;
 		rep(j, l, r) fwk_update(i, dep[j], +1);
 	}
 }
 
 void solve_10_per() {
	while (q--) {
		scanf("%d%d%d", &mode, &x, &k);
		int l = prev[x], r = post[x];
		if (mode == 1) {
			if (r - l + 1 < k) { puts("-1"); continue; }
			int cnt = 0;
			rep(i, l, r) tmp[++cnt] = dep[i];
			sort(tmp + 1, tmp + cnt + 1);
			printf("%d\n", tmp[k]);
		}
		else rep(i, l, r) dep[i] += k;
	}
 }

int main()
{
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);

	scanf("%d%d%d", &n, &q, &len);
	init_graph();
	rep(i, 2, n) scanf("%d%d", &x, &w), ine2(x, i, w);
	dfs(1, 0, 0);

	if (n <= 1000 && q <= 1000) { solve_10_per(); return 0; }

	maxl = 0;
	rep(i, 1, n) maxl = max(maxl, dep[i]);
	init_blocks();
	while (q--) {
		scanf("%d%d%d", &mode, &x, &k);
		if (mode == 1) op_query(x, k);
		else maxl += k, op_update(x, k);
	}
	return 0;
}

