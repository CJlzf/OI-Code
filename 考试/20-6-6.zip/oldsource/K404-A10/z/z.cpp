#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<queue>
using namespace std;
typedef long long ll;


int n;
int s[305],b[305*305],nn,val[305];
int mp[305][305],num[305];

void work1()
{
	int x;
	for (int i=1;i<=n;i++)
	{
		scanf("%d",&num[i]);
		for (int j=1;j<=num[i];j++) scanf("%d",&mp[i][j]),b[nn++]=mp[i][j];
	}
	for (int i=1;i<=n;i++) scanf("%d",&val[i]);
	sort(b,b+nn);
	nn=unique(b,b+nn)-b;
	
	for (int i=1;i<=n;i++)
		for (int j=1;j<=num[i];j++) s[i]|=(1<<(lower_bound(b,b+nn,mp[i][j])-b));
	
	int ans=0,S=1<<n,tmp,num,kk;
	
	for (int p=1;p<S;p++)
	{
		tmp=0;num=0;kk=0;
		for (int i=1;i<=n;i++) 
		if (p&(1<<i-1))
		{
			num++;tmp+=val[i];
			kk=kk|s[i];
		}
		for (int i=0;i<30;i++) if (kk&(1<<i)) num--;
		if (num!=0) continue;
		ans=min(ans,tmp);
	} 
	printf("%d",ans);
}

void work2()
{
	for (int i=1;i<=n;i++) 
	{
		scanf("%d",&num[i]);
		for (int j=1;j<=num[i];j++) scanf("%d",&mp[i][j]);
	}
	int ans=0,x;
	for (int i=1;i<=n;i++) scanf("%d",&x),ans+=x;
	printf("%d",ans);
}
int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	if (n<=20) {work1();return 0;}
	else {work2();return 0;}
	return 0;
}
