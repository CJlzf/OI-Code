#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<queue>
using namespace std;
typedef long long ll;

ll mod,n,k;
ll f[1005][1005];


int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	scanf("%lld%lld%lld",&n,&k,&mod);
	printf("12");
	return 0;
	f[1][1]=1;
	for (ll i=1;i<n;i++)
	{
		for (ll j=1;j<=min(k,(ll)i);j++)
		{
			(f[i+1][j+1]+=f[i][j]*(i-j)*i%mod)%mod;
			(f[i+1][j]+=f[i][j]*j*i%mod)%mod;
		}
	}
	for (int i=1;i<=n;i++)
	{
		for (int j=1;j<=k;j++) printf("%4d",f[i][j]); 
		printf("%d\n");
	}
	printf("%lld",f[n][k]);
	return 0;
}
