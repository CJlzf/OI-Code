#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<queue>
using namespace std;
const int N=100005;

inline int read()
{
	int ans;char ch;
	while ((ch=getchar())<'0'||ch>'9') ;ans=ch-'0';
	while ((ch=getchar())>='0'&&ch<='9') ans=ans*10+ch-'0';
	return ans;	
}

int n,m,len;
int head[N],to[N],pre[N],tot,dis[N];
void addedge(int u,int v,int d)
{
	to[++tot]=v;pre[tot]=head[u];dis[tot]=d;head[u]=tot;
}

int dep[N],tt,L[N],R[N];
void dfs(int u,int depth)
{
	L[u]=++tt;
	dep[tt]=depth;
	for (int i=head[u];i;i=pre[i]) dfs(to[i],depth+dis[i]);
	R[u]=tt;
}


int pos[N],block,num;
struct aa
{
	int a[451];
	int l,r,size,add;
	void build()
	{
		size=0;
		for (int j=l;j<=r;j++) a[++size]=dep[j]=dep[j]+add;
		sort(a+1,a+size+1);
		add=0;
	}
	int query(int mid)
	{
		if (size==0) return 0;
		return lower_bound(a+1,a+size+1,mid)-a-1;
	}
}kui[451];
int pan(int l,int r,int mid)
{
	int ans=0;
	if (pos[l]==pos[r]) 
	{
		mid-=kui[pos[l]].add;
		for (int i=l;i<=r;i++) ans+=(dep[i]<mid);
		return ans;
	}
	for (int i=pos[l]+1;i<=pos[r]-1;i++) ans+=kui[i].query(mid-kui[i].add);
	for (int i=l;i<=kui[pos[l]].r;i++) ans+=(dep[i]<mid-kui[pos[l]].add);
	for (int i=kui[pos[r]].l;i<=r;i++) ans+=(dep[i]<mid-kui[pos[r]].add);
	return ans;
}
int query(int l,int r,int k)
{
	if (r-l+1<k) return -1;
	int tl=0,tr=2*1e6,mid,ans=0;
	while (tl<=tr)
	{
		mid=(tl+tr)>>1;
		if (pan(l,r,mid)<=k-1) ans=mid,tl=mid+1;else tr=mid-1;
	}
	return ans;
}

void updata(int l,int r,int k)
{
	for (int i=pos[l]+1;i<=pos[r]-1;i++) kui[i].add+=k;
	if (pos[l]==pos[r]) 
	{
		for (int i=l;i<=r;i++) dep[i]+=k;
		kui[pos[l]].build();
		return ;
	}
	for (int i=l;i<=kui[pos[l]].r;i++) dep[i]+=k;kui[pos[l]].build();
	for (int i=kui[pos[r]].l;i<=r;i++) dep[i]+=k;kui[pos[r]].build();
}
int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	n=read(),m=read(),len=read();
	int x,d;
	for (int i=2;i<=n;i++) 
	{
		x=read();d=read();
		addedge(x,i,d);
	}
	dfs(1,0);
	block=sqrt(n);num=(n-1)/block+1;
	for (int i=1;i<=n;i++) pos[i]=(i-1)/block+1;
	for (int i=1;i<=num;i++)
	{
		kui[i].l=(i-1)*block+1;
		kui[i].r=min(i*block,n);
		kui[i].build();
	}
	int op,k;
	for (int i=1;i<=m;i++)
	{
		op=read();x=read(),k=read();
		if (op==1) printf("%d\n",query(L[x],R[x],k));
		else updata(L[x],R[x],k);
	}
	
	return 0;
}
