#include<cstdio>
#include<queue>
#include<vector>
#include<algorithm>
using namespace std;
const int MAXN=510;
const int inf=1e9;
struct edge{int to,flo,next;};
struct MAX_FLOW{
	int S,T,cnt;
	edge e[MAXN*MAXN*2];
	int tot;
	void init(int s,int t,int c){
		S=s;T=t;cnt=c;tot=1;
	}
	int new_(int to,int flo,int next){
		e[++tot]=(edge){to,flo,next};
		return tot;
	}
	int gg[MAXN*2];
	void add(int u,int v,int f){
		gg[u]=new_(v,f,gg[u]);
		gg[v]=new_(u,0,gg[v]);
	}	
	queue<int>q;
	int bfn[MAXN*2];
	int bfs(){
		while(!q.empty())q.pop();
		for(int i=0;i<=cnt;++i)bfn[i]=0;
		bfn[S]=1;q.push(S);
		while(!q.empty()){
			int p=q.front();q.pop();
			for(int i=gg[p];i;i=e[i].next){
				if(e[i].flo>0&&!bfn[e[i].to]){
					bfn[e[i].to]=bfn[p]+1;
					q.push(e[i].to);
				}
			}
		}
		return bfn[T]>0;
	}
	int cur[MAXN*2];
	int dfs(int p,int mx){
		if(p==T)return mx;
		if(mx<=0)return 0;
		int lef=mx;
		for(int &i=cur[p];i;i=e[i].next){
			if(bfn[e[i].to]==bfn[p]+1&&e[i].flo>0){
				int aa=dfs(e[i].to,min(lef,e[i].flo));
				e[i].flo-=aa;
				e[i^1].flo+=aa;
				lef-=aa;
				if(lef==0)break;
			}	
		}
		return mx-lef;
	}
	int solve(){
		int ans=0;
		while(bfs()){
			int fl=0;
			for(int i=0;i<=cnt;++i)cur[i]=gg[i];
			while(fl=dfs(S,inf)){
				ans+=fl;
			}
		}
		return ans;
	}
}T1,T2;
int n;
int len[MAXN];
vector<int>mat[MAXN];
int val[MAXN];
int com[MAXN];
int templ;
int ans;
int main(){
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%d",&len[i]);
		for(int j=0;j<len[i];++j){
			int x;scanf("%d",&x);
			mat[i].push_back(x);
		}
	}
	for(int i=1;i<=n;++i)scanf("%d",&val[i]);
	T1.init(0,2*n+1,2*n+1);
	for(int i=1;i<=n;++i){
		T1.add(T1.S,i,1);
		T1.add(n+i,T1.T,1);
		for(int j=0;j<len[i];++j)
			T1.add(i,n+mat[i][j],1);
	}
	templ=T1.solve();
	for(int i=1;i<=n;++i){
		for(int j=T1.gg[i];j;j=T1.e[j].next){
			if(!(j&1)&&T1.e[j].flo==0){
				com[i]=T1.e[j].to-n;
				break;
			}
		}
	}
	T2.init(0,2*n+1,2*n+1);
	for(int i=1;i<=n;++i){
		if(val[i]<0){
			ans+=val[i];
			T2.add(T2.S,i,-val[i]);
			for(int j=0;j<len[i];++j)
				T2.add(i,n+mat[i][j],-val[i]);
		}else{
			T2.add(i,T2.T,val[i]);
			T2.add(n+com[i],i,val[i]);
		}
	}
	printf("%d\n",min(0,ans+T2.solve()));
	fclose(stdin);
	fclose(stdout);
}
