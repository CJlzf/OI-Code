#include <stdio.h>
#include <string.h>
#include <iostream>
#include <algorithm>
#include <stdlib.h>
#include <math.h>
#include <vector>
using namespace std;

const int maxn=1e5;
const int maxGn=1000;

void Read(int &x)
{
	x=0;
	char ch=getchar();
	while ( ch<'0' || ch>'9' ) ch=getchar();
	while ( '0'<=ch && ch<='9' ) x=x*10+ch-'0',ch=getchar();
}

int n,m,len;

int a[maxn+10];
int G,Gn;
int belong[maxn+10];
int g[maxn+10];
int beg[maxGn+10],siz[maxGn+10],fix[maxGn+10];

vector <int> nex[maxn+10],w[maxn+10];
int L[maxn+10],R[maxn+10];
int xn,xl[maxn+10];
void DFS(int ,int );

void In_();

int Count_Single(int qL,int qR,int Gi,int v);
int Count_Whole(int Gi,int v);
int Count(int qL,int qR,int v);
int Query_(int qL,int qR,int k);

void Update_Single(int uL,int uR,int Gi,int add);
void Update_(int uL,int uR,int add);

int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	In_();
	int opt,x,k;
	for (int i=0;i<m;++i)
	{
		Read(opt); Read(x); Read(k);
		if ( opt==1 ) printf( "%d\n",Query_(L[x],R[x],k) );
				 else Update_(L[x],R[x],k);
	}
	return 0;
}

void DFS(int u,int d)
{
	++xn;
	a[xn]=d; xl[xn]=u;
	L[u]=xn; 
	for (int i=0,siz=nex[u].size(),v;i<siz;++i)
	{
		v=nex[u][i];
		DFS(v,d+w[u][i]);
	}
	R[u]=xn;
}

void In_()
{
	Read(n); Read(m); Read(len);
	int x,y;
	for (int i=2;i<=n;++i)
	{
		Read(x); Read(y);
		nex[x].push_back(i);
		w[x].push_back(y);
	}
	xn=-1;
	DFS(1,0);
/*for (int i=0;i<n;++i)
printf("%d ",xl[i]);
printf("\n");
for (int i=0;i<n;++i)
printf("%d ",a[i]);
printf("\n");
for (int i=1;i<=n;++i)
printf("%d %d\n",L[i],R[i]);*/
	G=sqrt(n*log2(sqrt(n))); Gn=n/G+(n%G>0);
	for (int i=0;i<Gn;++i)
	{
		beg[i]=i*G; siz[i]=min(G,n-beg[i]); 
		fix[i]=0;
		for (int j=beg[i];j<beg[i]+siz[i];++j)
			belong[j]=i,g[j]=a[j];
		sort(g+beg[i],g+beg[i]+siz[i]);
	}
}

int Count_Single(int qL,int qR,int Gi,int v)
{
	if ( qR-qL+1==siz[Gi] ) return Count_Whole(Gi,v);
	int ret=0;
	for (int i=qL;i<=qR;++i)
		if ( a[i]+fix[Gi]<v ) ++ret;
	return ret; 
}

int Count_Whole(int Gi,int v)
{
	return lower_bound(g+beg[Gi],g+beg[Gi]+siz[Gi],v-fix[Gi])-g-beg[Gi];
}

int Count_(int qL,int qR,int v)
{
	int LG=belong[qL],RG=belong[qR];
	if ( LG==RG ) return Count_Single(qL,qR,LG,v);
	int ret=0;
	for (int i=LG+1;i<RG;++i) ret+=Count_Whole(i,v);
	ret+=Count_Single(qL,beg[LG]+siz[LG]-1,LG,v);
	ret+=Count_Single(beg[RG],qR,RG,v);
	return ret;
}

int Query_(int qL,int qR,int k)
{
	if ( k>qR-qL+1 ) return -1;
	int lo=0,hi=len*(n+m)+5,mid;
	while ( lo+1<hi )
	{
		mid=(lo+hi)>>1;
		if ( Count_(qL,qR,mid)<k ) lo=mid;
					   	      else hi=mid;
	}
	return lo;
}

void Update_Single(int uL,int uR,int Gi,int add)
{
	if ( uR-uL+1==siz[Gi] ) 
	{
		fix[Gi]+=add;
		return;
	}
	for (int i=beg[Gi];i<beg[Gi]+siz[Gi];++i) a[i]+=fix[Gi];
	fix[Gi]=0;
	for (int i=uL;i<=uR;++i) a[i]+=add;
	for (int i=beg[Gi];i<beg[Gi]+siz[Gi];++i) g[i]=a[i];
	sort(g+beg[Gi],g+beg[Gi]+siz[Gi]);
}

void Update_(int uL,int uR,int add)
{
	int LG=belong[uL],RG=belong[uR];
	if ( LG==RG ) 
	{
		Update_Single(uL,uR,LG,add);
		return;
	}
	for (int i=LG+1;i<RG;++i) fix[i]+=add;
	Update_Single(uL,beg[LG]+siz[LG]-1,LG,add);
	Update_Single(beg[RG],uR,RG,add);
}
