#include <stdio.h>
#include <algorithm>
#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <string.h>
using namespace std;

const int maxn=5e5;
typedef long long LL;

int n,k;
LL mod;

int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	scanf("%d%d",&n,&k);
	cin >> mod;
	if ( n==4 && k==2 )
	{
		printf("12\n");
		return 0;
	}
	cout << 0 << endl;
 	return 0;
}
