#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <math.h>
#include <iostream>
#include <stdlib.h>
#include <ctime>
#include <vector>
using namespace std;

const int maxn=300;

int n;
int p[maxn+10];
vector <int> v[maxn+10];
int xl[maxn+10];
int ans=0;
int flag[maxn+10];
int SufMax[maxn+10];

void In_()
{
	scanf("%d",&n);
	int t,x;
	for (int i=1;i<=n;++i)
	{
		scanf("%d",&t);
		for (int j=0;j<t;++j)
		{
			scanf("%d",&x);
			v[i].push_back(x);
		}
	}
	for (int i=1;i<=n;++i)
		scanf("%d",&p[i]);
	for (int i=0;i<n;++i)
		xl[i]=i+1;
	srand(time(0));
	for (int i=0;i<n;++i) swap(xl[rand()%n],xl[rand()%n]);
	for (int i=n-1;i>=0;--i)
	{
		SufMax[i]=SufMax[i+1];
		if ( p[xl[i]]<0 ) SufMax[i]+=p[xl[i]];
	}
}

void DFS(int k,int sp,int cntL,int cntR)
{
	if ( sp+SufMax[k]>=ans ) return;
	if ( k>=n ) 
	{
		if ( cntL==cntR ) ans=min(ans,sp);	
		return;
	}
	int t,siz;
	for (int i=0,siz=v[xl[k]].size();i<siz;++i)
	{
		t=v[xl[k]][i];
		if ( flag[t]==0 ) ++cntR;
		++flag[t];
	}
	DFS(k+1,sp+p[xl[k]],cntL+1,cntR);
	for (int i=0,siz=v[xl[k]].size();i<siz;++i)
	{
		t=v[xl[k]][i];
		--flag[t];
		if ( flag[t]==0 ) --cntR;
	}
	DFS(k+1,sp,cntL,cntR);
}

int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	In_();
	DFS(0,0,0,0);
	printf("%d\n",ans);
	return 0;
}
