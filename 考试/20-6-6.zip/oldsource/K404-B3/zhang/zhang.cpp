#include <cstdio>

int main() {
	freopen("zhang.out", "w", stdout);
	puts("12");
}
