#include <cstdio>
#include <cassert>
#include <cmath>
#include <algorithm>
#include <stack>
#include <vector>

const int MAXN = 100000;
const int MAXN_SQRT = 317; // 100000 ** 0.5 = 316.22776601683796
const int BUCKET_SIZE = 10000000;

struct Node {
	std::vector<Node *> ch;
	int dep, upW, dfn, dfnEnd;
	bool vis;
} N[MAXN + 1];

inline void addEdge(int fa, int ch) {
	N[fa].ch.push_back(&N[ch]);
}

struct Block {
	int l, r, sorted[MAXN_SQRT + 1], tagAdd, size;
} B[MAXN_SQRT + 1];

int n, blockCnt, depSeq[MAXN + 1], whichBlock[MAXN + 1], maxDep;

inline void dfs() {
	std::stack<Node *> s;
	s.push(&N[1]);

	static int ts = 0;
	while (!s.empty()) {
		Node *v = s.top();

		if (!v->vis) {
			v->vis = true;
			depSeq[v->dfn = ++ts] = v->dep;
			maxDep = std::max(maxDep, v->dep);

			for (Node **p = &v->ch.front(), *u; p && p <= &v->ch.back() ? (u = *p) : NULL; p++) {
				u->dep = v->dep + u->upW;
				s.push(u);
			}
		} else {
			v->dfnEnd = ts;
			s.pop();
		}
	}
}

inline void prepare() {
	dfs();

	int blockSize = ceil(sqrt(n));
	blockCnt = n / blockSize + (n % blockSize != 0);
	for (int i = 1, j = 1; i <= blockCnt; i++) {
		int l = j, r = std::min(j + blockSize - 1, n);

		B[i].l = l;
		B[i].r = r;
		B[i].size = r - l + 1;
		std::fill(whichBlock + l, whichBlock + r + 1, i);

		std::copy(depSeq + l, depSeq + r + 1, B[i].sorted + 1);
		std::sort(B[i].sorted + 1, B[i].sorted + B[i].size + 1);

		j = r + 1;
	}
}

inline void rebuild(int i) {
	for (int k = B[i].l, j = 1; k <= B[i].r; k++, j++) B[i].sorted[j] = (depSeq[k] += B[i].tagAdd);
	B[i].tagAdd = 0;
	std::sort(B[i].sorted + 1, B[i].sorted + B[i].size + 1);
}

inline void update(int l, int r, int delta) {
	if (delta > 0) maxDep += delta;

#ifdef FORCE
	for (int i = l; i <= r; i++) depSeq[i] += delta;
	return;
#endif

	int bl = whichBlock[l], br = whichBlock[r];

	if (bl == br) {
		for (int i = l; i <= r; i++) depSeq[i] += delta;
		rebuild(bl);
		return;
	}

	if (l != B[bl].l) {
		for (int i = l; i <= B[bl].r; i++) depSeq[i] += delta;
		rebuild(bl);
		bl++;
	}

	if (r != B[br].r) {
		for (int i = B[br].l; i <= r; i++) depSeq[i] += delta;
		rebuild(br);
		br--;
	}

	for (int i = bl; i <= br; i++) B[i].tagAdd += delta;
}

inline int rank(int l, int r, int x) {
	int bl = whichBlock[l], br = whichBlock[r];
	int res = 0;

#ifdef FORCE
	for (int i = l; i <= r; i++) res += (depSeq[i] < x);
	printf("rank(%d, %d, %d) = %d\n", l, r, x, res + 1);
	return res + 1;
#endif

	if (bl == br) {
		for (int i = l; i <= r; i++) res += (depSeq[i] < x - B[bl].tagAdd);
		return res + 1;
	}

	if (l != B[bl].l) {
		for (int i = l; i <= B[bl].r; i++) res += (depSeq[i] < x - B[bl].tagAdd);
		bl++;
	}
	
	if (r != B[br].r) {
		for (int i = B[br].l; i <= r; i++) res += (depSeq[i] < x - B[br].tagAdd);
		br--;
	}

	for (int i = bl; i <= br; i++) res += std::lower_bound(B[i].sorted + 1, B[i].sorted + B[i].size + 1, x - B[i].tagAdd) - (B[i].sorted + 1);

	// printf("rank(%d, %d, %d) = %d\n", l, r, x, res + 1);
	return res + 1;
}

inline int query(int l, int r, int k) {
	int vl = 0, vr = maxDep;
	// for (int i = vr; i >= vl; i--) if (rank(l, r, i) <= k) return i;
	while (vl + 1 < vr) {
		int vm = vl + (vr - vl) / 2;
		if (rank(l, r, vm) <= k) vl = vm;
		else vr = vm;
	}
	if (rank(l, r, vr) == k) return vr;
	else return vl;
}

int main() {
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);

	int m, len;
	scanf("%d %d %d", &n, &m, &len);

	for (int i = 2; i <= n; i++) {
		int fa;
		scanf("%d %d", &fa, &N[i].upW);
		addEdge(fa, i);
	}

	prepare();

	while (m--) {
		int opt, x, k;
		scanf("%d %d %d", &opt, &x, &k);
		
		int l = N[x].dfn, r = N[x].dfnEnd;
		if (opt == 1) {
			// printf("query(%d, %d, %d)\n", l, r, k);
			if (r - l + 1 < k) puts("-1");
			else printf("%d\n", query(l, r, k));
		} else {
			update(l, r, k);
		}
	}

	return 0;
}
