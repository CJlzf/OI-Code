#include <cstdio>

int main() {
	freopen("z.in", "r", stdin);
	freopen("z.out", "w", stdout);

	int n;
	scanf("%d", &n);

	int a[n];
	for (int i = 0; i < n; i++) {
		int k;
		scanf("%d", &k);

		a[i] = 0;
		while (k--) {
			int x;
			scanf("%d", &x);
			a[i] |= (1 << --x);
		}
	}

	int p[n], sum = 0;
	bool allLessThanZero = true;
	for (int i = 0; i < n; i++) scanf("%d", &p[i]), allLessThanZero &= (p[i] < 0), sum += p[i];

	if (allLessThanZero) {
		printf("%d\n", sum);
	} else {
		int ans = 0;
		for (int s = 0; s < (1 << n); s++) {
			int s2 = 0, tmp = 0;
			for (int i = 0; i < n; i++) if (s & (1 << i)) s2 |= a[i], tmp += p[i];
			if (__builtin_popcount(s) == __builtin_popcount(s2) && ans > tmp) ans = tmp;
		}

		printf("%d\n", ans);
	}
}
