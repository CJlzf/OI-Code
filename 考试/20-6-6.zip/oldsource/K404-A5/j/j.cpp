#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <iostream>

using namespace std;

const int maxn = 30010;
int n, m, len;
struct Edge
{
	int v, w, next;
	Edge (int v = 0, int w = 0, int next = 0):
		v(v), w(w), next(next) {}
}e[maxn*2];
int head[maxn], label;
int depth[maxn], siz[maxn];
int line[maxn], cnt;

void ins(int u, int v, int w)
{
	e[++label] = Edge(v, w, head[u]);
	head[u] = label;
}

void dfs1(int u)
{
	siz[u] = 1;
	for (int i = head[u]; i != -1; i = e[i].next)
	{
		int v = e[i].v, w = e[i].w;
		depth[v] = depth[u]+w;
		dfs1(v);
		siz[u] += siz[v];
	}
}

void dfs2(int u)
{
	line[++cnt] = depth[u];
	for (int i = head[u]; i != -1; i = e[i].next)
		dfs2(e[i].v);
}

void get_ans(int x, int k)
{
	if (siz[x] < k)
	{
		puts("-1");
		return ;
	}
	cnt = 0;
	dfs2(x);
	sort(line+1, line+cnt+1);
	printf("%d\n", line[k]);
}

void dfs3(int u, int k)
{
	depth[u] += k;
	for (int i = head[u]; i != -1; i = e[i].next)
		dfs3(e[i].v, k);
}

int main()
{
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);
	scanf("%d %d %d", &n, &m, &len);
	for (int i = 1; i <= n; ++i)
		head[i] = -1;
	label = -1;
	for (int i = 2; i <= n; ++i)
	{
		int fa_, d;
		scanf("%d %d", &fa_, &d);
		ins(fa_, i, d);
	}
	depth[1] = 0;
	dfs1(1);
	while (m --)
	{
		int oper, x, k;
		scanf("%d %d %d", &oper, &x, &k);
		if (oper == 1)
			get_ans(x, k);
		else
			dfs3(x, k);
	}
	return 0;
}
