#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <iostream>

using namespace std;

typedef long long LL;
const int maxn = 104;
int p;
LL f[maxn][maxn][maxn][2];

LL dfs(int n, int k, int lim, int cur)
{
//	printf("%d %d %d %d\n", n, k, lim, cur);
	if (f[n][k][lim][cur] != -1)
		return f[n][k][lim][cur];
	if (n == 0 && k == 0)
		return f[n][k][lim][cur] = 1;
	if (n == 1)
	{
		if (k == 1 && cur == 1)
			return f[n][k][lim][cur] = 1;
		if (k == 0 && cur == 0)
			return f[n][k][lim][cur] = 1;
		return f[n][k][lim][cur] = 0;
	}/*
	if (k == 0 && lim == 1 && cur == 1)
		return f[n][k][lim][cur] = 1;
	if (k == 0 && lim == 1 && cur == 0)
		return f[n][k][lim][cur] = 0;
	if (k > 0 && lim == 1 && cur == 1)
		return f[n][k][lim][cur] = 0;
	if (k > 0 && lim == 1 && cur == 0 && n-1 == k)
		return f[n][k][lim][cur] = 1;
	if (k > 0 && lim == 1 && cur == 0 && n-1 != k)
		return f[n][k][lim][cur] = 0;*/
	LL ret = 0;
	for (int i = 1; i <= min(n-1, lim); ++i)
	{
		int t = cur ? k-1 : k;
		for (int j = 0; j <= t; ++j)
		{
//			printf("fa    : %d %d %d %d\n", n, k, lim, cur);
//			printf("part1 : %d %d %d %d\n", i, j, i-1, !cur);
//			printf("part2 : %d %d %d %d\n\n", n-i, k-j, i, cur);
			(ret += dfs(i, j, i-1, !cur)*dfs(n-i, k-j, i, cur)%p) %= p;
//			printf("fa's ans  : %d %d %d %d : %d\n\n", n, k, lim, cur, ret);
		}
	}
	return f[n][k][lim][cur] = ret;
}

int main()
{
	freopen("zhang.in", "r", stdin);
	freopen("zhang.out", "w", stdout);
	int n, k;
	scanf("%d %d %d", &n, &k, &p);
	memset(f, -1, sizeof(f));
	LL ans = dfs(n, k, n-1, 1);
	for (int i = 1; i <= n-1; ++i)
		(ans *= i) %= p;
	printf("%lld\n", ans);
	return 0;
}
