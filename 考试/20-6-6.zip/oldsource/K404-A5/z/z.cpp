#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <iostream>
#include <bitset>

using namespace std;

const int maxn = 305;
int n, ans = 0;
struct Node
{
	int p, cnt, b[maxn];
	bool operator < (const Node &AI) const
	{
		return p < AI.p;
	}
}a[maxn];
int choose[maxn];

void dfs(int now, int sum, int cnt_1, int cnt_2)
{
//	cout <<now <<" " <<sum <<" " <<cnt_1 <<" " <<cnt_2 <<endl;
	if (ans <= sum && a[now].p >= 0)
		return ;
	if (cnt_1 == cnt_2)
		ans = min(ans, sum);
	if (now == n+1)
		return ;
	int t_cnt_2 = cnt_2;
	for (int i = 1; i <= a[now].cnt; ++i)
	{
		if (choose[a[now].b[i]] == 0)
			t_cnt_2 ++;
		choose[a[now].b[i]] ++;
	}
	dfs(now+1, sum+a[now].p, cnt_1+1, t_cnt_2);
	for (int i = 1; i <= a[now].cnt; ++i)
		choose[a[now].b[i]] --;
	dfs(now+1, sum, cnt_1, cnt_2);
}

int main()
{
	freopen("z.in", "r", stdin);
	freopen("z.out", "w", stdout);
	scanf("%d", &n);
//	cout <<n <<endl;
	for (int i = 1; i <= n; ++i)
	{
		scanf("%d", &a[i].cnt);
		for (int j = 1; j <= a[i].cnt; ++j)
			scanf("%d", &a[i].b[j]);	
	}
	for (int i = 1; i <= n; ++i)
		scanf("%d", &a[i].p);
	sort(a+1, a+n+1);
	dfs(1, 0, 0, 0);
	printf("%d\n", ans);
	return 0;
}
