#include<cmath>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,k,p;
bool vis[30];
int cnt[30];
int son[30][30];
int ans=0,kk=0;
void dfs(int now,int total,int step);
void dfs2(int u,int step){
	if(step%2!=0) kk++;
	for(int i=1;i<=cnt[u];i++){
		dfs2(son[u][i],step+1);
	}  
}
void dfs1(int num,int u,int now,int all,int total,int step){
//	printf("total=%d kk=%d\n",total,kk);
	if(now==all){
		if(total==0){
			if(kk==k) ans++;
			ans%=p;
			return;
		}
		for(int i=1;i<=cnt[u];i++){
			dfs(son[u][i],total,step+1);
		}
		return;
	}
	if(num>n) return;
	if(!vis[num]){
		vis[num]=true;
		son[u][++cnt[u]]=num;
		dfs1(num+1,u,now+1,all,total,step);
		cnt[u]--;vis[num]=false;
	}
	dfs1(num+1,u,now,all,total,step);
}
void dfs(int u,int total,int step){
//	printf("%d",kk);
//	system("pause");
	if(total==0 || kk>k || kk+total<k) return;
	for(int i=1;i<=total;i++){
		if(step%2==0)
		kk+=i;
		dfs1(2,u,0,i,total-i,step);
		if(step%2==0)
		kk-=i;
	}
}
int main(){
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	scanf("%d%d%d",&n,&k,&p);
	kk=1;
	dfs(1,n-1,1);
	printf("%d",ans);
}
/*
0
1 0
1 2 0
1 12 3 0
1 48 60 4 0
1 160 570 260 5 0
1 480 4140 4920 990 6 0
1 1344 25935 63560 35805 3402 7 0
1 3584 146664 671440 767480 234528 10808 8 0
1 9216 766836 6246576 12608190 8031744 1416996 32328 9 0
1 23040
*/
