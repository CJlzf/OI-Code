#include<cmath>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,k=0;
int p[100000];
struct node{
	int to,next;
}e[1000000];
int vis[1000000];
int t=0;
bool visi=true;
struct node1{
	int u,w;
}point[400];
int head[100000];
int ans=0;
void add(int u,int v){
	e[++k].to=v;
	e[k].next=head[u];
	head[u]=k;
}
bool cmp(node1 a,node1 b){
	return a.w<b.w;
}
void dfs(int now,int ans1,int l,int r){
	if(t>80000000) return;
	t++;
	if(ans1>=ans && point[now].w>=0) return;
	if(now>n){
	    if(l==r) ans=ans1;
	    return;
	}
	for(int i=head[point[now].u];i;i=e[i].next){
		if(!vis[e[i].to]) r++;
		vis[e[i].to]++;
	}
	dfs(now+1,ans1+point[now].w,l+1,r);
	for(int i=head[point[now].u];i;i=e[i].next){
		vis[e[i].to]--;
		if(!vis[e[i].to]) r--;
	}
	dfs(now+1,ans1,l,r);
}
int main(){
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	for(int x,y,i=1;i<=n;i++){
		scanf("%d",&x);
		while(x--){
			scanf("%d",&y);
			add(i,y);
		}
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&p[i]);
		point[i].u=i;
		point[i].w=p[i];
		ans+=p[i];
		if(p[i]>0) visi=false;
	}
    if(!visi){
		sort(point+1,point+n+1,cmp);
		dfs(1,0,0,0);
	}
	printf("%d",min(ans,0));
	return 0;
}

