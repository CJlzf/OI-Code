#include<cmath>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
struct node{
	int l,r,ls,rs,sum;
}tree[8000000];
int root[100000];
int n,m,len,k=0;
struct node1{
	int to,next;
}e[200000];
int head[200000];
int dfn[200000];
int sz=0,indx=0;
int size[200000];
int deep[200000];
int ll[200000];
int rr[200000];
int cnl,cnr=0;
int lowbit(int x){
	return x&(-x);
}
int c[200000];
int maxn;
void add(int u,int v){
	e[++k].to=v;
	e[k].next=head[u];
	head[u]=k;
}
void dfs(int u,int fa){
	dfn[u]=++indx;size[u]=1;
	for(int i=head[u];i;i=e[i].next){
		if(e[i].to==fa) continue;
		deep[indx+1]=deep[indx]+len;
		dfs(e[i].to,fa); 
		size[u]+=size[e[i].to]; 
	}
}
void insert(int pre,int &now,int l,int r,int pos){
	now=++sz;
	tree[now].ls=tree[pre].ls;
	tree[now].rs=tree[pre].rs;
	tree[now].sum=tree[pre].sum+1;
	if(l==r) return;
	int mid=(l+r)>>1;
	if(mid>=pos) insert(tree[pre].ls,tree[now].ls,l,mid,pos);
	else insert(tree[pre].rs,tree[now].rs,mid+1,r,pos);
}
int query(int l,int r,int kk){
	if(l==r) return l;
	int suml=sumr=0;
	for(int i=1;i<=cnr;i++){
		sumr+=tree[tree[rr[i]].ls].sum;
	}
	for(int i=1;i<=cnl;i++){
		suml+=tree[tree[ll[i]].ls].sum;
	}
	if(sumr-suml>=k){
		
	}
	else{
		
	}
}
int main(){
	scanf("%d%d%d",&n,&m,&len);
	maxn=m*len;
	for(int u,v,i=1;i<n;i++){
		scanf("%d%d",&u,&v);
		add(u,v);add(v,u);
	}
	dfs(1,0);
	for(int i=1;i<=n;i++){
		for(int j=i;j<=n;j+=lowbit(j))
		insert(root[j],root[j],1,maxn,deep[i]);
	}
	for(int opt,x,kk,i=1;i<=m;i++){
		scanf("%d%d%d",&opt,&x,&kk);
		if(opt==1){
			int l=dfn[x],r=dfn[x]+size[x]-1;
			cnl=cnr=0;
			for(int j=r;j>=1;j-=lowbit(j)) rr[++cnr]=root[j];
			for(int j=l;j>=1;j-=lowbit(j)) ll[++cnl]=root[j];
			printf("%d",query(1,maxn,kk));
		}
		else{
			
		}
	}
}
