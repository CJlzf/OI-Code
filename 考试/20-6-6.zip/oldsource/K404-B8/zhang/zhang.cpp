#include<algorithm>
#include<cstdio>
using std::min;
typedef long long ll;
int p;
ll wop(ll t,ll n){
	ll s=1;
	for(;n;n>>=1){
		if(n&1)s=s*t%p;
		if(n>1)t=t*t%p;
	}
	return s;
}
const int N=1005;
ll f[N*N];
int g[N][N];
ll c(int n,int m){
	if(n>1000){
		f[0]=1;
		for(int i=1;i<=n;++i)
			f[i]=f[i-1]*i%p;
		return f[n]*wop(f[m],p-2)%p*wop(f[n-m],p-2)%p;
	}else{
		for(int i=0;i<=n;++i){
			g[i][0]=1;
			for(int j=1;j<=i;++j)
				g[i][j]=(g[i-1][j]+g[i-1][j-1])%p;
		}
		return g[n][m];
	}
}
ll cal(int n,int m){
	m=min(m,n-m-1);
	return wop(m+1,n-m-1)*wop(n-m,m)%p;
}
int main(){
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	int n,m;
	scanf("%d%d%d",&n,&m,&p);
	if(--n==--m)
		printf("%d\n",!n%p);
	else
		printf("%lld\n",c(n,m)*cal(n,m)%p);
}
