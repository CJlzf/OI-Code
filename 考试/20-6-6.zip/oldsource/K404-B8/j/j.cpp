#include<bits/stdc++.h>
using namespace std;
typedef unsigned short u16;
const int N=1e5+5;
struct edge{
	int v,w;edge*s;
}e[N];
edge*l=e,*h[N];
void ins(int u,int v,int w){
	edge s={v,w,h[u]};
	*(h[u]=l++)=s;
}
int dfn,n1,n2,n4;
typedef int arr[N];
arr d,f1,f2,b;
void dfs(int u){
	f1[u]=++dfn;
	for(edge*i=h[u];i;i=i->s)
		d[dfn+1]=d[f1[u]]+i->w,dfs(i->v);
	f2[u]=dfn;
}
struct blo{
	u16 s[16000];
	int l,r,a,b,d;
	u16 ask(int j){
		j-=d;
		if(j>=b)return r-l+1;
		if(j<a)return 0;
		return s[j-a];
	}
	void down(){
		for(int i=l;i<=r;++i)
			::d[i]+=d;
		d=0;
	}
	void pre(){
		a=1e9,b=0;
		for(int i=l;i<=r;++i){
			a=min(a,::d[i]);
			b=max(b,::d[i]);
		}
		for(int i=0;i<b-a;++i)
			s[i]=0;
		for(int i=l;i<=r;++i)
			++s[::d[i]-a];
		for(int i=1;i<b-a;++i)
			s[i]+=s[i-1];
	}
}c[1200];
void pre(){
	for(int i=1;i<=n2;++i)
		c[i].down();
	n4=0;
	for(int i=1;i<=n1;++i)
		n4=max(n4,d[i]);
	n2=1;
	int s1=1e9,s2=0,s3=0;
	for(int i=1;i<=n1;++i){
		s1=min(s1,d[i]);
		s2=max(s2,d[i]);
		if(++s3>400||s2-s1>4000)
			++n2,s3=1,s1=s2=d[i];
		c[b[i]=n2].r=i;
	}
	for(int i=n1;i;--i)
		c[b[i]].l=i;
	for(int i=1;i<=n2;++i)
		c[i].pre();
}
void inc(int s1,int u,int v){
	n4+=s1;
	if(b[u]==b[v]){
		for(int i=u;i<=v;++i)
			d[i]+=s1;
		c[b[u]].pre();
		return;
	}
	for(int i=c[b[u]].r;i>=u;--i)
		d[i]+=s1;
	for(int i=c[b[v]].l;i<=v;++i)
		d[i]+=s1;
	c[b[u]].pre();
	c[b[v]].pre();
	for(int i=b[u]+1;i<b[v];++i)
		c[i].d+=s1;
}
int ask(int s1,int u,int v){
	int s6=0;
	if(b[u]==b[v]){
		for(int i=u;i<=v;++i)
			s6+=s1-c[b[u]].d>=d[i];
		return s6;
	}
	for(int i=c[b[u]].r;i>=u;--i)
		s6+=s1-c[b[u]].d>=d[i];
	for(int i=c[b[v]].l;i<=v;++i)
		s6+=s1-c[b[v]].d>=d[i];
	for(int i=b[u]+1;i<b[v];++i)
		s6+=c[i].ask(s1);
	return s6;
}
int main(){
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	int m,o,v,w;
	scanf("%d%d%*d",&n1,&m);
	for(int i=2;i<=n1;++i)
		scanf("%d%d",&v,&w),ins(v,i,w);
	dfs(1);
	pre();
	int l=0;
	while(m--){
		scanf("%d%d%d",&o,&v,&w);
		if(o==1)
			if(w>f2[v]-f1[v]+1)
				puts("-1");
			else{
				int s=0,t=n4;
				while(s!=t){
					int j=s+t>>1;
					ask(j,f1[v],f2[v])<w?s=j+1:t=j;
				}
				printf("%d\n",s);
			}
		else{
			inc(w,f1[v],f2[v]);
			if(++l%1200==0)
				pre();
		}
	}
}
