#include<iostream>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<cstdio>
using namespace std;
typedef long long ll;
int n,p[1005],ans=0;
int a[1005][1005],vis[25],ha[25],cnt=0,cnt2=0;
int judge(int x){
	cnt=cnt2=0;
	memset(vis,0,sizeof(vis));
	int mn=0;
	for(int i=1;i<=n;i++){
		if((x>>(i-1))&1)ha[++cnt]=i;
	}
	for(int i=1;i<=cnt;i++){
		for(int j=1;j<=a[ha[i]][0];j++){
			if(!vis[a[ha[i]][j]]){
				vis[a[ha[i]][j]]=1;
				cnt2++;
			}
		}
	}
	if(cnt!=cnt2){
		return 2333333;
	}
	for(int i=1;i<=cnt;i++){
		mn+=p[ha[i]];
	}
	//printf("233 %d %d\n",x,cnt);
	return mn;
}
int main(){
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i][0]);
		for(int j=1;j<=a[i][0];j++){+
			scanf("%d",&a[i][j]);
		}
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&p[i]);
		p[0]+=p[i];
	}
	if(n>25){
		if(p[0]<0){
			printf("%d\n",p[0]);
			return 0;
		}
		printf("0\n");
		return 0;
	}
	int nn=1<<n;
	for(int i=1;i<nn;i++){
		ans=min(ans,judge(i));
	}
	printf("%d\n",ans);
	return 0;
}
