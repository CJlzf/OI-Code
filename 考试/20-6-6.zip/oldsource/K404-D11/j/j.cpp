#include<iostream>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<cstdio>
using namespace std;
struct wn{
	int to,v,nxt;
}w[500005];
int h[100005],cnt;
int f[100005],depp[100005],dep[100005],b[100005],pos[100005],ha[100005],id[100005],end[100005],sz[100005],siz;
int n,m,len,k,mm,anss;
inline int re(){
	int x=0,ff=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')ff=-ff;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*ff;
}
inline void addedge(int x,int y,int z){
	cnt++;
	w[cnt].to=y;
	w[cnt].v=z;
	w[cnt].nxt=h[x];
	h[x]=cnt;
}
void dfs(int x,int fa,int zz){
	f[x]=fa;
	depp[x]=depp[fa]+zz;
	sz[x]=1;
	id[x]=++siz;
	end[x]=x;
	for(int i=h[x];i;i=w[i].nxt){
		dfs(w[i].to,x,w[i].v);
		sz[x]+=sz[w[i].to];
		end[x]=end[w[i].to];
	}
	//printf("%d %d %d %d\n",id[x],id[fa],dep[fa],dep[x]);
}
void build(int x){
	int l=(x-1)*k+1,r=min(n,x*k);
	for(int i=l;i<=r;i++){
		b[i]=dep[i];
	}
	sort(b+l,b+r+1);
}
void change(int l,int r,int x){
	for(int i=pos[l]+1;i<pos[r];i++){
		ha[i]+=x;
	}
	if(pos[l]==pos[r]){
		for(int i=l;i<=r;i++)dep[i]+=x;
		build(pos[l]);
		return;	
	}
	for(int i=l;i<=pos[l]*k;i++)dep[i]+=x;
	build(pos[l]);
	for(int i=(pos[r]-1)*k+1;i<=r;i++)dep[i]+=x;
	build(pos[r]);
}
int baosou(int x,int v){
	int l=(x-1)*k+1,r=min(n,x*k);
	int rl=l,mid;
	while(l<=r){
		mid=(l+r)>>1;
		if(b[mid]>=v)r=mid-1;
		else {
			l=mid+1;
		}
	}
	return l-rl;
}
int pd(int l,int r,int mid){
	int xu1s=0,cnttt=0;
	for(int i=pos[l]+1;i<pos[r];i++){
		xu1s+=baosou(i,mid-ha[i]);
	}
	if(pos[l]==pos[r]){
		for(int i=l;i<=r;i++){
			if(dep[i]+ha[pos[l]]<mid)xu1s++,cnttt++;
		}
		return xu1s;
	}
	for(int i=l;i<=pos[l]*k;i++){
		if(dep[i]+ha[pos[l]]<mid)xu1s++,cnttt++;
	}
	for(int i=(pos[r]-1)*k+1;i<=r;i++){
		if(dep[i]+ha[pos[r]]<mid)xu1s++,cnttt++;
	}
	//printf("%d %d %d\n",mid,xu1s,cnttt);
	return xu1s;
}
int query(int l,int r,int x){
	if(r-l+1<x)return -1;
	int L=0,R=1e9+7;
	while(L<=R){
		int mid=(L+R)>>1;
		if(pd(l,r,mid)>=x)R=mid-1;
		else L=mid+1;
	}
	return R;
}
int main(){
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	n=re();m=re();len=re();
	for(int i=2;i<=n;i++){
		int xx,yy;
		xx=re();yy=re();
		addedge(xx,i,yy);
	}
	dfs(1,0,0);
	k=sqrt(n);
	for(int i=1;i<=n;i++){
		pos[i]=(i-1)/k+1;
		dep[id[i]]=depp[i];
	}
	mm=pos[n];
	for(int i=1;i<=mm;i++){
		build(i);
	}
	int opt,xx,yy;
	for(int i=1;i<=m;i++){
		opt=re();xx=re();yy=re();
		//printf("%d %d\n",id[xx],id[end[xx]]);
		if(opt==1){
			printf("%d\n",query(id[xx],id[end[xx]],yy));
		}else{
			change(id[xx],id[end[xx]],yy);
		}
	}
	return 0;
}
