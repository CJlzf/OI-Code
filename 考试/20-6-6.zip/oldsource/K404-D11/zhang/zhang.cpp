#include<iostream>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<cstdio>
using namespace std;
typedef long long ll;
int n,m,K;
ll frog;
ll f[2][105][105][105];
ll fac[1005],A[1005][1005],SA[1005][1005],C[1005][1005],SC[1005][1005];
inline ll qpow(ll a,ll x){
	ll res=1;
	for(;x;x>>=1,a=a*a%frog){
		if(x&1)res=res*a%frog;
	}
	return res;
}
inline ll rev(ll a){
	return qpow(a,frog-2);
}
inline void pre(){
	fac[0]=1;
	for(int i=1;i<=1000;i++)fac[i]=fac[i-1]*i%frog;
	A[0][0]=SA[0][0]=1;
	for(ll i=1;i<=1000;i++){
		A[i][0]=1;SA[i][0]=0;
		for(ll j=1;j<=i;j++){
			A[i][j]=A[i][j-1]*(i-j+1)%frog;
			SA[i][j]=SA[i][j-1]+A[i][j];
			if(SA[i][j]>=frog)SA[i][j]-=frog;
		}
		SA[i][0]=1;
	}
	C[0][0]=SC[0][0]=1;
	for(int i=1;i<=1000;i++){
		C[i][0]=1;
		for(int j=1;j<=i;j++){
			C[i][j]=C[i-1][j-1]+C[i-1][j];
			if(C[i][j]>=frog)C[i][j]-=frog;

		}
	}
}
inline void sol1(){
	int p=0,q=1;
	f[q][0][0][0]=1;
	ll ans=0;
	for(int i=1;i<=n;i++){
		
		if(i&1){
			for(int j=i;j<=n;j++){
				
				for(int k=1;k<=j-i+1;k++){
				//	cout<<k<<endl;
					for(int l=0;l<=j;l++){
						
						f[p][j][k][l]=f[q][j-k][0][l]*C[n-j+k][k]%frog;
						f[p][j][k][l]=f[p][j][k][l]*SA[k][min(n-j,k)]%frog;
						f[p][j][0][l]+=f[p][j][k][l];
						if(f[p][j][0][l]>=frog)f[p][j][0][l]-=frog;
						//cout<<i<<' '<<j<<' '<<k<<' '<<l<<' '<<SA[k][min(n-j,k)]<<endl;
					}
				}
			}
		}else{
			for(int j=i;j<=n;j++){
				for(int k=1;k<=j-i+1;k++){
					for(int l=k;l<=j;l++){
						//cout<<i<<' '<<j<<' '<<k<<' '<<l<<' '<<endl;
						f[p][j][k][l]=f[q][j-k][0][l-k]*C[n-j+k][k]%frog;
						f[p][j][k][l]=f[p][j][k][l]*SA[k][min(n-j,k)]%frog;
						f[p][j][0][l]+=f[p][j][k][l];
						if(f[p][j][0][l]>=frog)f[p][j][0][l]-=frog;
						//cout<<i<<' '<<j<<' '<<k<<' '<<l<<' '<<f[p][j][k][l]<<endl;
					}
				}
			}
		}
		ans+=f[p][n][0][K];
		if(ans>=frog)ans-=frog;
		swap(p,q);
	}
	cout<<ans<<endl;
	
}

int main(){
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	
	cin>>n>>K>>frog;
	n--;
	K--;
	pre();
	sol1();
	return 0;
}
