#include <bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for (int i = (a), i##_end_ = (b); i <= i##_end_; ++i)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define x first
#define y second
#define pb push_back
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }

typedef long long LL;

inline int read()
{
	register int c = getchar(), sum(0), fg(1);
	while (c < '0' || c > '9') { if (c == '-') fg = -1; c = getchar(); }
	while (c >= '0' && c <= '9') sum = sum * 10 + c - '0', c = getchar();
	return sum * fg;
}

const int oo = 0x3f3f3f3f;

const int maxn = 100;

int N, M;

vector <int> c[maxn + 5];

int e[maxn + 5], vis[maxn + 5], used[maxn + 5];

int ans = oo;

inline int check()
{
	int sum = 0, Ans = 0, num = 0;
	memset(used, 0, sizeof used);
	REP(i, 1, N)
		if (vis[i])
		{
			++num;
			REP(j, 0, SZ(c[i]) - 1)
				sum += !used[c[i][j]], used[c[i][j]] = 1;
		}
	if (sum != num) return oo;
	REP(i, 1, N)
		if (vis[i])
			Ans += e[i];
	return Ans;
}

inline void dfs(const int &x)
{
	if (x > N)
	{
		chkmin(ans, check());
		return;
	}
	vis[x] = 1;
	dfs(x + 1);
	vis[x] = 0;
	dfs(x + 1);
}

int main()
{
	freopen("z.in", "r", stdin);
	freopen("z.out", "w", stdout);
	N = read();
	REP(i, 1, N)
	{
		int num = read();
		while (num--)
		{
			int x = read();
			c[i].pb(x);
		}
	}
	REP(i, 1, N) e[i] = read();
	dfs(1);
	printf("%d\n", ans);
	return 0;
}

