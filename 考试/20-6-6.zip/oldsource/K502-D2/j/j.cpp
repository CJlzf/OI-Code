#include <bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for (int i = (a), i##_end_ = (b); i <= i##_end_; ++i)
#define debug(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define x first
#define y second
#define pb push_back
#define SZ(x) (int((x).size()))
#define ALL(x) (x).begin(), (x).end()

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }

typedef long long LL;

inline int read()
{
	register int c = getchar(), sum(0), fg(1);
	while (c < '0' || c > '9') { if (c == '-') fg = -1; c = getchar(); }
	while (c >= '0' && c <= '9') sum = sum * 10 + c - '0', c = getchar();
	return sum * fg;
}

const int oo = 0x3f3f3f3f;

const int maxn = 1000;

int N, M, len;

struct edge
{
	int id, nxt, w;

	edge() { }
	edge(int _id, int _nxt, int _w): id(_id), nxt(_nxt), w(_w) { }
};

edge e[(maxn << 1) + 5];

int st[maxn + 5], cnt;

inline void add(const int &x, const int &y, const int &w, const int &type = 1)
{
	e[cnt] = edge(y, st[x], w), st[x] = cnt++;
	if (type) add(y, x, w, 0);
};

int size[maxn + 5], pre[maxn + 5], val[maxn + 5];

inline void dfs(const int &x)
{
	size[x] = 1;
	for (int i = st[x]; ~i; i = e[i].nxt)
	{
		int y = e[i].id;
		if (y != pre[x])
		{
			val[y] = val[x] + e[i].w;
			dfs(y), size[x] += size[y];
		}
	}
}

vector <int> tmp;

inline void vis(const int &x)
{
	tmp.pb(val[x]);
	for (int i = st[x]; ~i; i = e[i].nxt)
	{
		int y = e[i].id;
		if (y != pre[x]) vis(y);
	}
}

inline int query(int x, int k)
{
	tmp.clear();
	vis(x);
	sort(ALL(tmp));
	return tmp[k - 1];
}

inline void dfs(const int &x, const int &add)
{
	val[x] += add;
	for (int i = st[x]; ~i; i = e[i].nxt)
	{
		int y = e[i].id;
		if (y != pre[x]) dfs(y, add);
	}
}

int main()
{
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);
	memset(st, -1, sizeof st), cnt = 0;
	N = read(), M = read(), len = read();
	REP(i, 2, N)
	{
		int x = pre[i] = read(), w = read();
		add(i, x, w);
	}
	dfs(1);
	while (M--)
	{
		int type = read(), x = read(), k = read();
		if (type == 1) printf("%d\n", query(x, k));
		else dfs(x, k);
	}
	return 0;
}

