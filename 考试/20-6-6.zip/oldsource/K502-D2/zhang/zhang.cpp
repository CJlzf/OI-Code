#include <bits/stdc++.h>

using namespace std;

#define REP(i, a, b) for (int i = (a), i##_end_ = (b); i <= i##_end_; ++i)
#define debug(...) fprintf(stderr, __VA_ARGS__)

template<typename T> inline bool chkmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }
template<typename T> inline bool chkmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }

typedef long long LL;

inline int read()
{
	register int c = getchar(), sum(0), fg(1);
	while (c < '0' || c > '9') { if (c == '-') fg = -1; c = getchar(); }
	while (c >= '0' && c <= '9') sum = sum * 10 + c - '0', c = getchar();
	return sum * fg;
}

const int oo = 0x3f3f3f3f;

int N, M;

int f[maxn + 5][maxn + 5];

int main()
{
	freopen("zhang.in", "r", stdin);
	freopen("zhang.out", "w", stdout);
	puts("12");
	return 0;
}

