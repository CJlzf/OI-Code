#include<bits/stdc++.h>
int n,m,len;
int to[100010],nxt[100010],fst[100010],tot;
void add(int u,int v){to[++tot]=v,nxt[tot]=fst[u],fst[u]=tot;}
int sz[100010],dis[100010];
void pre(int u)
{
    sz[u]=1;
    for(int e=fst[u],v;e;e=nxt[e])
        dis[v=to[e]]+=dis[u],pre(v),sz[u]+=sz[v];
}
int d[100010],c;
void dfs1(int u)
{
    d[++c]=dis[u];
    for(int e=fst[u];e;e=nxt[e])
        dfs1(to[e]);
}
void dfs2(int u,int d)
{
    dis[u]+=d;
    for(int e=fst[u];e;e=nxt[e])
        dfs2(to[e],d);
}
int main()
{
    freopen("j.in","r",stdin);
    freopen("j.out","w",stdout);
    scanf("%d%d%d",&n,&m,&len),add(0,1);
    for(int v=2,u,w;v<=n;++v)
        scanf("%d%d",&u,&w),add(u,v),dis[v]=w;
    pre(1);
    for(int i=1,t,x,k;i<=m;++i)
    {
        scanf("%d%d%d",&t,&x,&k);
        if(t==1)
            if(sz[x]<k)puts("-1");
            else
            {
                c=0,dfs1(x);
                std::nth_element(d+1,d+k,d+c+1);
                printf("%d\n",d[k]);
            }
        else dfs2(x,k);
    }
    return 0;
}
