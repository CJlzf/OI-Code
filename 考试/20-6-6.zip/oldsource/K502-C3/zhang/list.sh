n=0
while ((++n<=9));do
    k=0
    while ((++k<=n));do
        echo $n $k 998244353 > zhang.in
        ./zhang
        echo -n `cat zhang.out`\	
    done
    echo
done
