#include<bits/stdc++.h>
typedef long long ll;
int c[110][110],d[110][110],n,m,p;
int f[110][110][110],g[110][110][110],ans;
void up(int &a,int b){(a+=b)>=p&&(a-=p);}
int main()
{
    freopen("zhang.in","r",stdin);
    freopen("zhang.out","w",stdout);
    scanf("%d%d%d",&m,&n,&p);
    for(int i=0;i<=m;++i)
    {
        c[i][0]=d[i][0]=1;
        for(int j=1;j<=i;++j)
            up(c[i][j]=c[i-1][j-1],c[i-1][j]);
        for(int j=1;j<=m;++j)
            d[i][j]=(ll)d[i][j-1]*i%p;
    }
    m-=n,f[1][0][1]=1;
    for(int i=1;i<=n;++i)
    {
        for(int j=1;j<i;++j)
            for(int k=1;k<=m;++k)
                for(int l=1;l<=k;++l)
                    up(f[i][k][i-j],(ll)g[j][k][l]*c[n-j][i-j]%p*d[l][i-j]%p);
        for(int j=1;j<=m;++j)
            for(int k=1;k<=j;++k)
                for(int l=1;l<=i;++l)
                    up(g[i][j][k],(ll)f[i][j-k][l]*c[m-j+k][k]%p*d[l][k]%p);
    }
    for(int i=1;i<=n;++i)up(ans,f[n][m][i]);
    for(int i=1;i<=m;++i)up(ans,g[n][m][i]);
    printf("%lld\n",(ll)ans*c[n+m-1][n-1]%p);
    return 0;
}
