#include<bits/stdc++.h>
int a[310],p[310],n,ans,k;
void dfs(int i,int s,int t,int y)
{
    if(i>n)
    {
        if(__builtin_popcount(s)==t)
            ans=std::min(ans,y);
        return;
    }
    dfs(i+1,s,t,y),dfs(i+1,s|a[i],t+1,y+p[i]);
}
int main()
{
    freopen("z.in","r",stdin);
    freopen("z.out","w",stdout);
    scanf("%d",&n);
    for(int i=1,c;i<=n;++i)
    {
        scanf("%d",&c);
        for(int j=1,x;j<=c;++j)
            scanf("%d",&x),a[i]|=1<<(x-1);
    }
    for(int i=1;i<=n;++i)scanf("%d",&p[i]),k+=p[i];
    if(n>20)return printf("%d\n",k),0;
    dfs(1,0,0,0),printf("%d\n",ans);
    return 0;
}
