#include<cstdio>
#include<algorithm>
#include<utility>
#include<cstdlib>
#include<ctime>
using std::max;using std::min;using std::abs;
template<typename T>inline void repl(T&a,T b){if(a>b)a=b;}
template<typename T>inline void repr(T&a,T b){if(a<b)a=b;}
#define fo0(i,n) for(int i=0,i##end=n;i<n;i++)
#define fo1(i,n) for(int i=1,i##end=n;i<=n;i++)

#define PN "z"
struct io{io(){freopen(PN ".in","w",stdout);}~io(){fclose(stdin);fclose(stdout);}}yjq_naive;

#define R (rand()<<16|rand())

int s[301],v[301];

int main()
{
	srand(time(0));
	int n=300;
	fo1(i,n)s[i]=i;
	std::random_shuffle(s+1,s+n+1);
	printf("%d\n",n);
	fo1(i,n)
	{
		fo1(j,n)v[j]=j;
		v[s[i]]=1;
		v[1]=s[i];
		std::random_shuffle(v+2,v+n+1);
		int t=R%5+1;
		printf("%d",t);
		fo1(j,t)printf(" %d",v[j]);putchar(10);
	}
	fo1(i,n)printf("%d ",R%2000000-1000000);putchar(10);
}
