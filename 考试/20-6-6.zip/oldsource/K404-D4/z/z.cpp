#include<cstdio>
#include<algorithm>
#include<utility>
#include<cstring>
using std::max;using std::min;using std::abs;
template<typename T>inline void repl(T&a,T b){if(a>b)a=b;}
template<typename T>inline void repr(T&a,T b){if(a<b)a=b;}
#define fo0(i,n) for(int i=0,i##end=n;i<n;i++)
#define fo1(i,n) for(int i=1,i##end=n;i<=n;i++)

#define PN "z"
struct io{io(){freopen(PN ".in","r",stdin);freopen(PN ".out","w",stdout);}~io(){fclose(stdin);fclose(stdout);}}yjq_naive;

const int N=303,M=200010,inf=1e9;

struct edge
{
	int to,w;edge*ne,*re;
}_e[M],*e=_e,*p[N*2],*ep[N*2];

inline void add(int a,int b,int w)
{
	*e=(edge){b,w,p[a],e+1};p[a]=e++;
	*e=(edge){a,0,p[b],e-1};p[b]=e++;
}

int q[N*2],dep[N*2],fl[N*2];
bool vis[N*2];

bool dfs(int s,int t)
{
	if(s==t)return 1;
	for(edge*&i=ep[s];i;i=i->ne)
	{
		if(i->w&&dep[i->to]==dep[s]+1)
		{
			fl[i->to]=min(fl[s],i->w);
			if(dfs(i->to,t))
			{
				i->w-=fl[t];
				i->re->w+=fl[t];
				return 1;
			}
		}
	}
	dep[s]=-1;
	return 0;
}

inline int dinic(int s,int t)
{
	int flow=0;
	while(1)
	{
		memset(vis,0,sizeof vis);
		memset(dep,0xff,sizeof dep);
		memcpy(ep,p,sizeof p);
		int qe=1;
		q[0]=s;
		dep[s]=0;
		vis[s]=1;
		for(int i=0;i<qe;i++)
		{
			for(edge*j=p[q[i]];j;j=j->ne)
				if(j->w&&!vis[j->to])
				{
					dep[j->to]=dep[q[i]]+1;
					q[qe++]=j->to;
					vis[j->to]=1;
				}
		}
		if(dep[t]==-1)break;
		fl[s]=inf;
		while(dfs(s,t))flow+=fl[t];//,printf("%d %d\n",fl[t],flow);
	}
	return flow;
}

edge*fe[N][N];
int n,cnt[N],s[N][N],val[N*N],ir[N],low[N],dfn[N],tm,bc,bl[N],st[N],sm,dc[N],sz[N];
bool c[N][N];

void tj(int x)
{
	low[x]=dfn[x]=++tm;
	st[sm++]=x;
	vis[x]=1;
	fo1(y,n)if(c[x][y])
	{
		if(!dfn[y])
		{
			tj(y);
			repl(low[x],low[y]);
		}
		else if(!bl[y])
		{
			repl(low[x],dfn[y]);
		}
	}
	if(low[x]==dfn[x])
	{
		for(dc[++bc]=x;;)
		{
			bl[st[--sm]]=bc;
			if(st[sm]==x)break;
		}
	}
}

int main()
{
	scanf("%d",&n);
	int vm=0;
	fo1(i,n)
	{
		scanf("%d",cnt+i);
		fo0(j,cnt[i])scanf("%d",s[i]+j),val[vm++]=s[i][j];
	}
	std::sort(val,val+vm);
	std::unique(val,val+vm);
	fo1(i,n)fo0(j,cnt[i])s[i][j]=std::lower_bound(val,val+n,s[i][j])-val+1;
	int S=n*2+1,T=S+1;
	fo1(i,n)fo0(j,cnt[i])fe[i][s[i][j]]=e,add(i,s[i][j]+n,1);
	fo1(i,n)add(S,i,1);
	fo1(i,n)add(i+n,T,1);
	dinic(S,T);
	fo1(i,n)fo0(j,cnt[i])
		if(!fe[i][s[i][j]]->w)val[i]=s[i][j];
	fo1(i,n)ir[val[i]]=i;
	fo1(i,n)fo0(j,cnt[i])c[i][ir[s[i][j]]]=1;
	//fo1(i,n){fo1(j,n)printf("%d ",c[i][j]);putchar(10);}
	memset(vis,0,sizeof vis);
	fo1(i,n)if(!vis[i])tj(i);
	//fo1(i,n)printf("%d ",bl[i]);puts("");
	fo1(i,n)
	{
		int x;
		scanf("%d",&x);
		sz[bl[i]]+=x;
	}
	memset(p,0,sizeof p);
	e=_e;
	fo1(i,bc)sz[i]=-sz[i];
	int ans=0;
	fo1(i,bc)
	{
		if(sz[i]>=0)add(S,i,sz[i]),ans-=sz[i];
		if(sz[i]<=0)add(i,T,-sz[i]);
	}
	fo1(i,bc)fo1(j,bc)
		if(c[dc[i]][dc[j]])
			add(i,j,inf);
	ans+=dinic(S,T);
	printf("%d\n",ans);
}
