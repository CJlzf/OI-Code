#include<cstdio>
#include<algorithm>
#include<utility>
#include<cstring>
using std::max;using std::min;using std::abs;
template<typename T>inline void repl(T&a,T b){if(a>b)a=b;}
template<typename T>inline void repr(T&a,T b){if(a<b)a=b;}
#define fo0(i,n) for(int i=0,i##end=n;i<n;i++)
#define fo1(i,n) for(int i=1,i##end=n;i<=n;i++)

#define PN "zhang"
//struct io{io(){freopen(PN ".in","r",stdin);freopen(PN ".out","w",stdout);}~io(){fclose(stdin);fclose(stdout);}}yjq_naive;

int n,m,e[6000][2],c[400][400],a[400],fa[400];

inline int find(int x){return x==fa[x]?x:fa[x]=find(fa[x]);}

int dfs(int x,int fa,int dep)
{
	int ans=dep;
	fo0(i,n)if(c[x][i]&&i!=fa)
	{
		ans+=dfs(i,x,dep^1);
	}
	return ans;
}

inline void solve(int _n)
{
	n=_n,m=0;
	memset(a,0,sizeof a);
	fo0(i,n)fo0(j,i)e[m][0]=i,e[m][1]=j,m++;
	fo0(i,1<<m)
	{
		if(__builtin_popcount(i)!=n-1)continue;
		memset(c,0,sizeof c);
		fo0(j,m)if(i&(1<<j))c[e[j][0]][e[j][1]]=1,c[e[j][1]][e[j][0]]=1;
		fo0(j,n)fa[j]=j;
		fo0(j,n)fo0(k,n)if(c[j][k]&&find(j)!=find(k))fa[fa[j]]=fa[k];
		bool flag=1;
		fo0(j,n)fo0(k,n)if(find(j)!=find(k))flag=0;
		if(flag)
		{
			a[dfs(0,-1,1)]++;
		}
	}
	fo0(i,n+1)printf("%d ",a[i]);puts("");
}

int main()
{
	fo1(i,8)solve(i);
}
