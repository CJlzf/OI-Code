#include<cstdio>
#include<algorithm>
#include<utility>
using std::max;using std::min;using std::abs;
template<typename T>inline void repl(T&a,T b){if(a>b)a=b;}
template<typename T>inline void repr(T&a,T b){if(a<b)a=b;}
#define fo0(i,n) for(int i=0,i##end=n;i<n;i++)
#define fo1(i,n) for(int i=1,i##end=n;i<=n;i++)

#define PN "zhang"
struct io{io(){freopen(PN ".in","r",stdin);freopen(PN ".out","w",stdout);}~io(){fclose(stdin);fclose(stdout);}}yjq_naive;

typedef long long ll;

inline int pow(int a,int b,int p)
{
	int r=1;
	for(;b;b>>=1,a=(ll)a*a%p)
		if(b&1)r=(ll)r*a%p;
	return r;
}

int main()
{
	int n,k,p,a=1,b=1;
	scanf("%d%d%d",&n,&k,&p);
	for(int i=1;i<k;i++)
		a=(ll)a*(n-i)%p,b=(ll)b*i%p;
	a=(ll)a*pow(b,p-2,p)%p;
	a=(ll)a*pow(n-k,k-1,p)%p;
	a=(ll)a*pow(k,n-k-1,p)%p;
	printf("%d",a);
}
