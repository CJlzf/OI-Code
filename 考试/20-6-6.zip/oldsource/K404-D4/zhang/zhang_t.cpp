#include<cstdio>
#include<algorithm>
#include<utility>
using std::max;using std::min;using std::abs;
template<typename T>inline void repl(T&a,T b){if(a>b)a=b;}
template<typename T>inline void repr(T&a,T b){if(a<b)a=b;}
#define fo0(i,n) for(int i=0,i##end=n;i<n;i++)
#define fo1(i,n) for(int i=1,i##end=n;i<=n;i++)

#define PN "zhang"
//struct io{io(){freopen(PN ".in","r",stdin);freopen(PN ".out","w",stdout);}~io(){fclose(stdin);fclose(stdout);}}yjq_naive;

int f[11][11];

inline int P(int a,int b)
{
	int r=1;
	fo0(i,b)r*=a-i;
	return r;
}

inline int F(int a)
{
	int r=1;
	fo1(i,a)r*=a;
	return r;
}

int main()
{
	f[1][1]=1;
	for(int i=2;i<=10;i++)
		fo1(j,i)f[i][j]=f[i-1][j]*j+f[i-1][j-1]*(i-j);
	fo1(i,10)
	{
		fo1(j,i)printf("%d ",f[i][j]*P(i-1,j-1)*P(i-j,i-j));
		putchar(10);
	}
}
