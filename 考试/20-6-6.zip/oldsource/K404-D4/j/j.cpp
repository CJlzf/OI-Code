#include<cstdio>
#include<algorithm>
#include<utility>
#include<cmath>
#include<vector>
using std::max;using std::min;using std::abs;
template<typename T>inline void repl(T&a,T b){if(a>b)a=b;}
template<typename T>inline void repr(T&a,T b){if(a<b)a=b;}
#define fo0(i,n) for(int i=0,i##end=n;i<n;i++)
#define fo1(i,n) for(int i=1,i##end=n;i<=n;i++)

#define PN "j"
struct io{io(){freopen(PN ".in","r",stdin);freopen(PN ".out","w",stdout);}~io(){fclose(stdin);fclose(stdout);}}yjq_naive;

const int N=100001;

struct edge
{
	int to,w;edge*ne;
}_e[N],*e=_e,*p[N];

inline void add(int a,int b,int w)
{
	*e=(edge){b,w,p[a]};p[a]=e++;
}

int n,m,idm,id[N],idr[N],len[N],gg[N];

void dfs(int x)
{
	id[x]=++idm;
	for(edge*i=p[x];i;i=i->ne)
		len[i->to]=len[x]+i->w,dfs(i->to);
	idr[x]=idm;
}

struct Q
{
	int op,l,r,k;
}qr[N];

struct data
{
	int os,ok,pl;
	std::vector<int>f,mo,qr;
}t[270000];

void pre(int x,int l,int r,int ql,int qr,int op,int v)
{
	if(l==ql&&r==qr){if(op==1)t[x].qr.push_back(v);else t[x].mo.push_back(v);return;}
	int f=(l+r)>>1;
	if(ql<=f)pre(x<<1,l,f,ql,min(qr,f),op,v);
	if(qr>f)pre(x<<1|1,f+1,r,max(ql,f+1),qr,op,v);
}

void build(int x,int l,int r)
{
	t[x].os=0;
	t[x].ok=1;
	t[x].pl=0;
	//for(int i=l;i<=r;i++)
	//	t[x].f.insert(len[i]);
	if(l^r)
	{
		int t=(l+r)>>1;
		build(x<<1,l,t);
		build(x<<1|1,t+1,r);
	}
	std::sort(gg+l,gg+r+1);
	for(int i=l;i<=r;i++)
		t[x].f.push_back(gg[i]);
}

inline void mo_pd(int x)
{
	if(t[x].ok)
	{
		t[x<<1].os+=t[x].pl;
		t[x<<1].pl+=t[x].pl;
		t[x<<1|1].os+=t[x].pl;
		t[x<<1|1].pl+=t[x].pl;
		t[x].f.clear();
		t[x].ok=0;
		t[x].pl=0;
	}
}

int pu_t[N];

inline void pu(int x,int now,int len)
{
	if(!t[x<<1].ok||!t[x<<1|1].ok)return;
	int g=std::upper_bound(t[x].mo.begin(),t[x].mo.end(),now)-t[x].mo.begin();
	if(g==t[x].mo.size())g=m+1;else g=t[x].mo[g];
	int ltr=std::upper_bound(t[x].qr.begin(),t[x].qr.end(),g)-std::upper_bound(t[x].qr.begin(),t[x].qr.end(),now);
	if(ltr*20>=len)
	{
		//t[x].f.clear();
		int cnt=0,ao=t[x<<1].os,bo=t[x<<1|1].os;
		std::vector<int>&A=t[x<<1].f,&B=t[x<<1|1].f;
		std::vector<int>::iterator a=A.begin(),b=B.begin();
		while(a!=A.end()&&b!=B.end())
		{
			if(*a+ao<*b+bo)pu_t[cnt++]=ao+*a++;
			else pu_t[cnt++]=bo+*b++;
		}
		for(;a!=A.end();pu_t[cnt++]=ao+*a++);
		for(;b!=B.end();pu_t[cnt++]=bo+*b++);
		fo0(i,cnt)t[x].f.push_back(pu_t[i]);
		t[x].os=0;
		t[x].ok=1;
		t[x].pl=0;
	}
}

void modify(int x,int l,int r,int ql,int qr,int v,int p)
{
	if(l==ql&&r==qr&&t[x].ok)
	{
		t[x].os+=v;
		t[x].pl+=v;
		return;
	}
	int f=(l+r)>>1;mo_pd(x);
	if(ql<=f)modify(x<<1,l,f,ql,min(qr,f),v,p);
	if(qr>f)modify(x<<1|1,f+1,r,max(ql,f+1),qr,v,p);
	pu(x,p,r-l+1);
}

inline void qr_pd(int x)
{
	if(t[x].ok)
	{
		t[x<<1].os+=t[x].pl;
		t[x<<1].pl+=t[x].pl;
		t[x<<1|1].os+=t[x].pl;
		t[x<<1|1].pl+=t[x].pl;
		t[x].pl=0;
	}
}

int query(int x,int l,int r,int ql,int qr,int v)
{
	if(l==ql&&r==qr&&t[x].ok)
	{
		//printf("query:%d %d %d %d %d %d\n",x,l,r,v,t[x].os,t[x].f.size());
		return std::upper_bound(t[x].f.begin(),t[x].f.end(),v-t[x].os)-t[x].f.begin();
	}
	int f=(l+r)>>1,ans=0;qr_pd(x);
	if(ql<=f)ans+=query(x<<1,l,f,ql,min(qr,f),v);
	if(qr>f)ans+=query(x<<1|1,f+1,r,max(ql,f+1),qr,v);
	return ans;
}

int main()
{
	scanf("%d%d%*d",&n,&m);
	fo0(i,n-1)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,i+2,y);
	}
	dfs(1);
	fo0(i,m)
	{
		int o,x,k;
		scanf("%d%d%d",&o,&x,&k);
		qr[i].op=o;
		qr[i].l=id[x];
		qr[i].r=idr[x];
		qr[i].k=k;
		pre(1,1,n,qr[i].l,qr[i].r,o,i);
	}
	fo1(i,n)gg[id[i]]=len[i];
	build(1,1,n);
	fo0(i,m)
	{
		if(qr[i].op==2)
		{
			modify(1,1,n,qr[i].l,qr[i].r,qr[i].k,i);
		}
		else
		{
			if(qr[i].r-qr[i].l+1<qr[i].k)
			{
				puts("-1");
				continue;
			}
			int l=-1,r=2000005;
			while(l+1<r)
			{
				if(query(1,1,n,qr[i].l,qr[i].r,(l+r)/2)>=qr[i].k)
					r=(l+r)/2;
				else
					l=(l+r)/2;
				//printf("%d %d %d\n",qr[i].l,qr[i].r,query(1,1,n,qr[i].l,qr[i].r,(l+r)>>1));
			}
			printf("%d\n",r);
		}
	}
}
