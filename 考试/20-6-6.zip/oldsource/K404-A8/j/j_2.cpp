#include<bits/stdc++.h>
using namespace std;
#define maxn 100020
#define maxm 1000020

struct node{
	int next,to,w;
}e[maxn * 2];
int head[maxn],cnt;
int sum[120][maxm],add[120];
int sz,l[maxn],r[maxn],dth[maxn],++dfstime,fa[maxn],a[maxn];
int n,m,len;

inline void adde(int x,int y,int w){
	e[++cnt].to = y;
	e[cnt].next = head[x];
	e[cnt].w = w;
	head[x] = cnt;
}
void dfs(int x){
	l[x] = ++dfstime , a[dfstime] = x;
	for (int i = head[x] ; i ; i = e[i].next){
		if ( e[i].to == fa[x] ) continue;
		dth[e[i].to] = dth[x] + e[i].w;
	}
	r[x] = dfstime;
}
void init(){
	sz = min(100,(int)n / sqrt(n)) , sz = n / sz;
	for (int i = 0 , c = 0 ; i < n ; i += sz , c++){
		sum[c][dth[a[i]]]++;
		for (register int j = 1 ; j <= (m + n) * len ; j++){
			sum[c][j] += sum[c][j - 1];
		}
	}
}
inline void modify(int l,int r,int k){
	int l2,r2;
	if ( !(l % sz) ) l2 = l;
	else l2 = (l / sz + 1) * sz;
	if ( (r % sz) == sz - 1 ) r2 = r;
	else r2 = (r / sz) * sz;
	for (register int i = l2 ; i <= r2 ; i += sz){
		add[i / sz] += k;
	}
	for (register int i = l ; i < l2 ; i++){
			
	}
}
int main(){
	scanf("%d %d %d",&n,&m,&len);
	for (int i = 2 ; i <= n ; i++){
		int w;
		scanf("%d %d",&fa[i],&w);
		adde(fa[i],i,w);
	}
	dfs(1);
	init();
	while ( m-- ){
		int opt,x,k;
		scanf("%d %d %d",&opt,&x,&k);
		if ( opt == 1 ){
			modify(l[x],r[x],k);
		}
		else{
			printf("%d\n",query(l[x],r[x],k));
		}
	}
	return 0;
}

