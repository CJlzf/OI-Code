#include<bits/stdc++.h>
using namespace std;
#define maxn 1020

struct node{
	int next,to,w;
}e[maxn * 2];
int head[maxn],cnt;
int n,m,len,fa[maxn],dth[maxn],a[maxn],tot;

inline void adde(int x,int y,int w){
	e[++cnt].to = y;
	e[cnt].next = head[x];
	e[cnt].w = w;
	head[x] = cnt;
}
void dfs(int x){
	for (int i = head[x] ; i ; i = e[i].next){
		dth[e[i].to] = dth[x] + e[i].w;
		dfs(e[i].to);
	}
}
void dfs(int x,int k){
	dth[x] += k;
	for (int i = head[x] ; i ; i = e[i].next){
		dfs(e[i].to,k);
	}
}
void dfs2(int x){
	a[++tot] = dth[x];
	for (int i = head[x] ; i ; i = e[i].next) dfs2(e[i].to);
}
int main(){
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	scanf("%d %d %d",&n,&m,&len);
	for (int i = 2 ; i <= n ; i++){
	   	int w;
		scanf("%d %d",&fa[i],&w);
		adde(fa[i],i,w);
	}
	dfs(1);
	while ( m-- ){
		int opt,x,k;
		scanf("%d %d %d",&opt,&x,&k);
		if ( opt == 2 ){
			dfs(x,k);
		}
		else{
			tot = 0;
			dfs2(x);
			sort(a + 1,a + tot + 1);
			if ( k <= tot ) printf("%d\n",a[k]);
			else printf("-1\n");
		}
	}
	return 0;
}
