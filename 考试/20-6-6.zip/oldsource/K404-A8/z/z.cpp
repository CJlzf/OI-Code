#include<bits/stdc++.h>
using namespace std;
#define maxn 120

int e[maxn],p[maxn];
int n,m,ans,cnt[1 << 21];

int main(){
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	for (int i = 1 ; i <= n ; i++){
		int t,x;
		scanf("%d",&t);
		for (int j = 1 ; j <= t ; j++){
			scanf("%d",&x);
			e[i] += 1 << (x - 1);
		}
	}
	for (int i = 1 ; i <= n ; i++) scanf("%d",&p[i]);
	for (int i = 0 ; i < 1 << n ; i++){
		for (int j = 0 ; j < n ; j++){
			if ( i & (1 << j) ) cnt[i]++;
		}
	}
	for (int i = 1 ; i < 1 << n ; i++){
		int cur = 0,d = 0;
		for (int j = 0 ; j < n ; j++){
			if ( i & (1 << j) ) cur |= e[j + 1] , d += p[j + 1];
		}
		if ( cnt[cur] == cnt[i] ) ans = min(ans,d);
	}
	cout<<ans<<endl;
	return 0;
}

