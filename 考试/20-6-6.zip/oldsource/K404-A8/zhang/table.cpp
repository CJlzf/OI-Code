#include<bits/stdc++.h>
using namespace std;
#define maxn 120

struct node{
	int next,to;
}e[maxn * 2];
int head[maxn],cnt;
int n,k,p,ans,fa[maxn],vis[maxn];
int tot1,tot2,dfstime;

void clear(){
	for (int i = 1 ; i <= cnt ; i++) e[i].next = e[i].to = 0;
	for (int i = 1 ; i <= n ; i++) head[i] = 0;
	cnt = 0 , tot1 = tot2 = 0 , ++dfstime;
}
inline void adde(int x,int y){
	e[++cnt].to = y;
	e[cnt].next = head[x];
	head[x] = cnt;
}
void dfs(int x,int d){
	tot2++;
	if ( d & 1 ) tot1++;
	for (int i = head[x] ; i ; i = e[i].next){
		if ( vis[e[i].to] == dfstime ) continue;
		vis[e[i].to] = dfstime;
		dfs(e[i].to,d + 1);
	}
}
void dfs(int x){
	if ( x == n + 1 ){
		clear();
		for (int i = 2 ; i <= n ; i++) adde(fa[i],i) , adde(i,fa[i]);
		vis[1] = dfstime , dfs(1,1);
		if ( tot1 == k && tot2 == n ) ans++;
		return;
	}
	for (int i = 1 ; i <= n ; i++){
		if ( i == x ) continue;
		fa[x] = i;
		dfs(x + 1);
		fa[x] = 0;
	}
}
int main(){
	freopen("table.out","w",stdout);
	for (n = 1 ; n <= 9 ; n++){
		for (k = 1 ; k <= n ; k++){
			ans = 0;
			dfs(2);
			cout<<ans<<" ";
		}
		cout<<endl;
	}
	return 0;
}
