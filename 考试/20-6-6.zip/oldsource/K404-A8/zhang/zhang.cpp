#include<bits/stdc++.h>
using namespace std;
#define maxn 500020

typedef long long ll;
int n,k,p;
ll fac[maxn],inv[maxn];

inline ll power(ll x,int y){
	ll res = 1;
	while ( y ){
		if ( y & 1 ) res = res * x % p;
		x = x * x % p;
		y >>= 1;
	}
	return res;
}
inline ll getinv(int n){ return power(fac[n],p - 2); }
inline ll C(int n,int m){
	if ( n == m || !m ) return 1;
	return fac[n] * getinv(m) % p * getinv(n - m) % p;
}
int main(){
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	scanf("%d %d %d",&n,&k,&p);
	if ( k == 1 ) return cout<<1<<endl , 0;
	if ( n < k + 1 ) return cout<<0<<endl , 0;
	fac[0] = 1;
	for (int i = 1 ; i <= n ; i++) fac[i] = fac[i - 1] * i % p;
	cout<<(ll)C(n - 1,k - 1) * power(k,n - k - 1) % p * power(n - k,k - 1) % p<<endl;
	return 0;
}
