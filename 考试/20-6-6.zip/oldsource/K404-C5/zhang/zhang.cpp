#include <bits/stdc++.h>
#define debug(x) std::cerr << #x << " : " << (x) << std::endl

typedef long long LL;

LL n = 0, k = 0, P = 0;

LL NTT(LL a, LL b) {
	LL ans = 1;
	for (; b; b >>= 1) {
		if (b & 1) ans = ans * a % P;
		a = a * a % P;
	}
	return ans;
}

LL C(LL n, LL k) {
	LL ans = 1;
	for (int i = 0; i < k; i++) ans = ans * (n - i) % P, ans = ans * NTT(i + 1, P - 2) % P;
	return ans;
}

LL f(LL n, LL k) {
	return (C(n - 1, k) * NTT(n - k, k - 2) % P) * NTT(k, n - k) % P;
}

int main() {
	freopen("zhang.in", "r", stdin);
	freopen("zhang.out", "w", stdout);
	scanf("%lld%lld%lld", &n, &k, &P);
	printf("%lld\n", f(n, k));
    return 0;
}
