#include <bits/stdc++.h>
#define debug(x) std::cerr << #x << " : " << (x) << std::endl

typedef std::pair<int, int> E;

const int MAXN = 1031;

std::vector<E> g[MAXN];

int n = 0, q = 0;
int d[MAXN];

void dfs(int u) {
	for (int i = 0; i < g[u].size(); i++) {
		int v = g[u][i].first;
		d[v] = d[u] + g[u][i].second;
		dfs(v);
	}
}

int w[MAXN], cnt = 0;

void add(int u, int x) {
	d[u] += x;
	w[cnt++] = d[u];
	for (int i = 0; i < g[u].size(); i++) {
		int v = g[u][i].first;
		add(v, x);
	}
}

int query(int u, int k) {
	add(u, 0);
	return k > cnt ? -1 : (std::nth_element(w, w + cnt, w + k - 1), w[k - 1]);
}

int main() {
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);
	scanf("%d%d%*d", &n, &q);
	for (int i = 2, u = 0, v = 0; i <= n; i++) scanf("%d%d", &u, &v), g[u].push_back({i, v});
	dfs(1);
	for (int op = 0, x = 0, k = 0; q--; cnt = 0) {
		scanf("%d%d%d", &op, &x, &k);
		if (op == 1) printf("%d\n", query(x, k));
		else add(x, k);
	}
    return 0;
}
