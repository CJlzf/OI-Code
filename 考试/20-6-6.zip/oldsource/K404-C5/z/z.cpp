#include <bits/stdc++.h>
#define debug(x) std::cerr << #x << " : " << (x) << std::endl

const int MAXN = 331;

int n = 0;

int s[MAXN], p[MAXN];

int main() {
	freopen("z.in", "r", stdin);
	freopen("z.out", "w", stdout);
	scanf("%d", &n);
	if (n >= 21) {
		for (int i = 0, t = 0, x = 0; i < n; i++) for (scanf("%d", &t); t--; ) scanf("%*d");
		int ans = 0;
		for (int i = 0; i < n; i++) scanf("%d", p + i), ans += p[i];
		printf("%d\n", ans);
		return 0;
	}
	for (int i = 0, t = 0, x = 0; i < n; i++) for (scanf("%d", &t); t--; scanf("%d", &x), s[i] |= 1 << x);
	for (int i = 0; i < n; i++) scanf("%d", p + i);
	int ans = 0;
	for (int i = 0; i < (1 << n); i++) {
		int sum = 0, z = 0;
		for (int j = 0; j < n; j++) if (i & (1 << j)) sum += p[j], z |= s[j];
		if (__builtin_popcount(i) == __builtin_popcount(z)) ans = std::min(ans, sum);
	}
	printf("%d\n", ans);
    return 0;
}
