#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
using namespace std;
const int N=100005;
int n,m,len,head[N],cnt,fa[N],sz[N],dis[N];
vector<int>vec;
struct Edge{int v,w,next;}e[N];
void adde(int u,int v,int w){
	e[++cnt]=(Edge){v,w,head[u]};
	head[u]=cnt;
}
void dfs(int u){
	vec.push_back(dis[u]);
	for(int i=head[u];i;i=e[i].next)dfs(e[i].v);
}
void dfs0(int u){
	sz[u]=1;
	for(int i=head[u];i;i=e[i].next){
		dfs0(e[i].v);
		sz[u]+=sz[e[i].v];
	}
}
void dfs1(int u){
	for(int i=head[u];i;i=e[i].next){
		dis[e[i].v]=dis[u]+e[i].w;
		dfs1(e[i].v);
	}
}
int main(){
	freopen("j.in","r",stdin);freopen("j.out","w",stdout);
	scanf("%d%d%d",&n,&m,&len);
	for(int w,i=2;i<=n;i++){
		scanf("%d%d",&fa[i],&w);
		adde(fa[i],i,w);
	}
	adde(0,1,0);
	dfs1(1);dfs0(1);
	for(int op,x,k,i=1;i<=m;i++){
		scanf("%d%d%d",&op,&x,&k);
		if(op==1){
			if(sz[x]<k){
				puts("-1");
				continue;
			}
			vec.clear();
			dfs(x);
			sort(vec.begin(),vec.end());
			printf("%d\n",vec[k-1]);
		}else{
			for(int i=head[fa[x]];i;i=e[i].next)if(e[i].v==x){
				e[i].w+=k;
				break;
			}
			dfs1(fa[x]);
		}
	}
	return 0;
}
