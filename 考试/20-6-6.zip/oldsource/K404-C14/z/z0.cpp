#include<cstdio>
int main(){
	int n,t,x;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		for(scanf("%d",&t);t;t--)scanf("%d",&x);
	}
	t=0;for(int i=1;i<=n;i++){scanf("%d",&x);t+=x;}
	printf("%d\n",t);
}
