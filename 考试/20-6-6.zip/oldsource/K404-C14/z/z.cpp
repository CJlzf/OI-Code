#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
using namespace std;
const int N=305;
vector<int>vec[N];
int n,p[N],ans;
bool vis[N];
bool check(int S){
	int c=0,c1=0;
	for(int i=1;i<=n;i++)vis[i]=0;
	for(int i=1;i<=n;i++)if((S>>(i-1))&1){
		c++;
		for(int j=0;j<(int)vec[i].size();j++)if(!vis[vec[i][j]]){
			vis[vec[i][j]]=1;
			c1++;
		}
	}
	return c==c1;
}
int main(){
	freopen("z.in","r",stdin);freopen("z.out","w",stdout);
	scanf("%d",&n);
	for(int t,x,i=1;i<=n;i++){
		for(scanf("%d",&t);t;t--){
			scanf("%d",&x);
			vec[i].push_back(x);
		}
	}
	bool ok=1;
	for(int i=1;i<=n;i++){
		scanf("%d",&p[i]);
		if(p[i]>0)ok=0;
	}
	if(ok){
		for(int i=1;i<=n;i++)ans+=p[i];
		printf("%d\n",ans);
		return 0;
	}
	for(int i=0;i<(1<<n);i++)
	if(check(i)){
		int tmp=0;
		for(int j=1;j<=n;j++)if((i>>(j-1))&1)tmp+=p[j];
		ans=min(tmp,ans);
	}
	printf("%d\n",ans);
	return 0;
}
