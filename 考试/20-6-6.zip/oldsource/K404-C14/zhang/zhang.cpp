#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
typedef long long LL;
const int N=1005,N1=500005;
int n,k,p;
LL dp[N][N],fac[N];
int main(){
	freopen("zhang.in","r",stdin);freopen("zhang.out","w",stdout);
	scanf("%d%d%d",&n,&k,&p);
	fac[0]=1;for(int i=1;i<=n;i++)fac[i]=fac[i-1]*i%p;
	dp[1][1]=1;
	for(int i=1;i<n;i++){
		for(int j=1;j<=min(i,k-1);j++){
			dp[i+1][j]=dp[i+1][j]+dp[i][j]*j%p;
			dp[i+1][j+1]=dp[i+1][j+1]+dp[i][j]*(i-j)%p;
		}
	}
	printf("%lld\n",dp[n][k]*fac[n-1]%p);
	return 0;
}
