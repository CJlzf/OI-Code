#include<bits/stdc++.h>
#define x first
#define y second
#define sp putchar(' ')
#define ln putchar('\n')
#define SZ(s) ((int)(s).size())
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

typedef std::pair<int,int> Pii;
typedef long long i64;
typedef long double f64;

template<class K> inline bool umax(K& a,K b) {
  return a < b ? a = b, true: false;
}

template<class K> inline bool umin(K& a,K b) {
  return a > b ? a = b, true: false;
}

template<class K> inline void read(K& x) {
  char c = getchar(); K f = +1;
  for(x = 0;!isdigit(c); c = getchar())
    if(c == '-') f = -1;
  for(;isdigit(c); c = getchar())
    x = x * 10 + c - '0';
  x = x * f;
}

template<class K> inline void write(K x) {
  static int fout[20], top;
  if(x < 0) putchar('-'), x = -x;
  do fout[top++] = x % 10, x /= 10; while(x);
  while(top) putchar(fout[--top] + '0');
}

const int maxN = 300 + 5, BIT = 300;

typedef std::bitset<BIT> set;

bool flag;
int N;
set s[maxN];
int P[maxN];
int sum;

void input() {
  read(N);
  for(int i = 0;i < N; ++i) {
    int t, c; read(t); while(t--) {
      read(c); s[i].set(c);
    }
  }
  flag = true;
  for(int i = 0;i < N; ++i) {
    read(P[i]), sum += P[i];
    flag &= P[i] <= 0;
  }
}

void exec() {
  if(N <= 20) {
    int ans = 0;
    for(int S = 0;S < 1 << N; ++S) {
      set ss; int tmp = 0, cnt = 0;
      for(int i = 0;i < N; ++i) {
	if(S >> i & 1) {
	  tmp += P[i];
	  ss |= s[i];
	  ++cnt;
	}
      }
      if(cnt == (int) ss.count())
	umin(ans, tmp);
    }
    write(ans), ln;
  }else if(flag)
    write(sum), ln;
  else {
    srand(time(0));
    int ans = sum;
    while(true) {
      set ss;
      int tmp = 0;
      int cnt = 0;
      for(int i = 0;i < N; ++i) {
	if(rand() & 1) {
	  tmp += P[i];
	  ss |= s[i];
	  ++cnt;
	}
      }
      if(cnt == (int) ss.count())
	umin(ans, tmp);
      if(clock() > 0.99*CLOCKS_PER_SEC)
	break;
    }
    write(ans), ln;
  }
}

int main() {
  if(fopen("z.in","r")) {
    freopen("z.in","r",stdin);
    freopen("z.out","w",stdout);
  }

  input();
  exec();
  
  return 0;
}
