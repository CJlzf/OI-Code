#include<bits/stdc++.h>
#define x first
#define y second
#define sp putchar(' ')
#define ln putchar('\n')
#define SZ(s) ((int)(s).size())
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

typedef std::pair<int,int> Pii;
typedef long long i64;
typedef long double f64;

template<class K> inline bool umax(K& a,K b) {
  return a < b ? a = b, true: false;
}

template<class K> inline bool umin(K& a,K b) {
  return a > b ? a = b, true: false;
}

template<class K> inline void read(K& x) {
  char c = getchar(); K f = +1;
  for(x = 0;!isdigit(c); c = getchar())
    if(c == '-') f = -1;
  for(;isdigit(c); c = getchar())
    x = x * 10 + c - '0';
  x = x * f;
}

template<class K> inline void write(K x) {
  static int fout[20], top;
  if(x < 0) putchar('-'), x = -x;
  do fout[top++] = x % 10, x /= 10; while(x);
  while(top) putchar(fout[--top] + '0');
}

const int maxN = 2e5 + 5;

struct edge{
  int next, v;

  edge () {}
  edge (int x,int y)
    :next(x), v(y) {}
};

int tote;
int head[maxN];
edge E[maxN];
void addedge(int u,int v) {
  E[++tote] = edge(head[u], v); head[u] = tote;
}

int SIZE;
int n, m, len;
int dfc;
int ed[maxN];
int nfd[maxN];
int dfn[maxN];
int a[maxN];
int b[maxN];
int c[maxN];
int d[maxN];
int add[maxN];

inline void Add(int x,int l,int r,int v) {
  register int L = (x - 1) * SIZE + 1;
  register int R = x * SIZE;
  if(l <= L && R <= r) add[x] += v;
  else {
    for(register int i = L;i <= R; ++i) {
      a[i] += add[x];
      if(l <= i && i <= r)
	a[i] += v;
      b[i] = a[i];
    }
    add[x] = 0;
    std::sort(b + L,b + R + 1);
  }
}

inline int Query(int x,int l,int r,int v) {
  int L = (x - 1) * SIZE + 1;
  int R = x * SIZE;
  if(l <= L && R <= r) 
    return std::upper_bound(b + L,b + R + 1,v - add[x]) - b - L;
  else {
    int ret = 0;
    int lb = std::max(l, L);
    int rb = std::min(r, R);
    for(register int i = lb;i <= rb; ++i)
      ret += v >= a[i] + add[x];
    return ret;
  }
}

void dfs(int u) {
  dfn[u] = ++dfc; nfd[dfc] = u;
  for(int e = head[u], v; e; e = E[e].next)
    d[v = E[e].v] += d[u], dfs(v);
  ed[u] = dfc;
}

void input() {
  read(n), read(m), read(len);
  SIZE = std::max(1, n / 50);
  
  for(int i = 2;i <= n; ++i) {
    int u; read(u), read(d[i]);
    addedge(u, i);
  }
}

void exec() {
  for(int i = 1;i <= n; i += SIZE)
    for(int j = 1;j <= SIZE; ++j)
      a[j] = 2e6;
    
  dfs(1);

  for(int i = 1;i <= n; ++i) {
    b[i] = a[i] = d[nfd[i]];
  }

  for(int i = 1, id = 1;i <= n; i += SIZE, ++id) {
    int st = (id - 1) * SIZE;
    for(int j = 1;j <= SIZE; ++j)
      c[st+j] = id;
    std::sort(b+st+1, b+st+SIZE+1);
  }
  
  while(m--) {
    int op, x, k;
    read(op), read(x), read(k);
    int l = dfn[x], r = ed[x];
    if(op == 1) {
      if(ed[x]-dfn[x]+1 < k) puts("-1");
      else {
	register int lb = 0, rb = 2e6, ans = 0;
	while(lb <= rb) {
	  register int mid = (lb + rb) >> 1;
	  register int ret = 0;
	  for(register int i = c[l];i <= c[r]; ++i)
	    ret += Query(i, l, r, mid);
	  if(ret >= k) rb = mid - 1, ans = mid;
	  else lb = mid + 1;
	}
	write(ans), ln;
      }
    }else {
      for(register int i = c[l];i <= c[r]; ++i)
	Add(i, l, r, k);
    }
  }
}

int main() {
  if(fopen("j.in","r")) {
    freopen("j.in","r",stdin);
    freopen("j.out","w",stdout);
  }

  input();
  exec();
  
  return 0;
}
