#include<bits/stdc++.h>
#define x first
#define y second
#define sp putchar(' ')
#define ln putchar('\n')
#define SZ(s) ((int)(s).size())
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

typedef std::pair<int,int> Pii;
typedef long long i64;
typedef long double f64;

template<class K> inline bool umax(K& a,K b) {
  return a < b ? a = b, true: false;
}

template<class K> inline bool umin(K& a,K b) {
  return a > b ? a = b, true: false;
}

template<class K> inline void read(K& x) {
  char c = getchar(); K f = +1;
  for(x = 0;!isdigit(c); c = getchar())
    if(c == '-') f = -1;
  for(;isdigit(c); c = getchar())
    x = x * 10 + c - '0';
  x = x * f;
}

template<class K> inline void write(K x) {
  static int fout[20], top;
  if(x < 0) putchar('-'), x = -x;
  do fout[top++] = x % 10, x /= 10; while(x);
  while(top) putchar(fout[--top] + '0');
}

const int maxN = 1e5 + 5, SIZE = 416, high = 2e5;

struct edge{
  int next, v;

  edge () {}
  edge (int x,int y)
    :next(x), v(y) {}
};

int tote;
int head[maxN];
edge E[maxN];
void addedge(int u,int v) {
  E[++tote] = edge(head[u], v); head[u] = tote;
}

int n, m, len;
int dfc;
int ed[maxN];
int nfd[maxN];
int dfn[maxN];
int a[maxN];
int d[maxN];

void dfs(int u) {
  dfn[u] = ++dfc; nfd[dfc] = u;
  for(int e = head[u], v; e; e = E[e].next)
    d[v = E[e].v] += d[u], dfs(v);
  ed[u] = dfc;
}

void input() {
  read(n), read(m), read(len);
  for(int i = 2;i <= n; ++i) {
    int u; read(u), read(d[i]);
    addedge(u, i);
  }
}

void exec() {
  dfs(1);

  for(int i = 1;i <= n; ++i)
    a[i] = d[nfd[i]];
  while(m--) {
    int op, x, k;
    read(op), read(x), read(k);
    if(op == 1) {
      static int b[maxN]; int top = 0;
      for(register int i = dfn[x];i <= ed[x]; ++i)
	b[++top] = a[i];
      if(top < k) puts("-1");
      else {
	std::nth_element(b + 1,b + k,b + top + 1);
	write(b[k]), ln;
      }
    }else
      for(register int i = dfn[x];i <= ed[x]; ++i)
	a[i] += k;
  }
}

int main() {
  if(fopen("j.in","r")) {
    freopen("j.in","r",stdin);
    freopen("j.out","w",stdout);
  }

  input();
  exec();
  
  return 0;
}
