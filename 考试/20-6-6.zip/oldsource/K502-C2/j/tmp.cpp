#include <cstdio>
#include <algorithm>
#define FOR(i, x, y) for(int i = x,_ = y;i <= _; ++i)
#define update1(x) xs = sign + x * SIZE;sort(xs,xs + SIZE);
#define update2(x) xa = arr + x * SIZE;xs = sign + x * SIZE;for(int i = 0; i < SIZE; ++i) xs[i] = xa[i] += Add[x];Add[x] = 0;
using namespace std;
const int maxn = 100900, SIZE = 450;
const int high = 100010;
int arr[maxn], sign[maxn], tmp[maxn], end, Add[maxn];
template<class K>inline void read(K &x){
	char c = getchar(); int f = 1; x = 0;
	while(c < '0' || c > '9'){if(c == '-') f = -1; c = getchar();}
	while(c >= '0' && c <= '9'){x = x * 10 + c - '0'; c = getchar();}
	x = x * f;
}
int ok(int LL, int RR, int k, int v) {
    FOR(i,LL,RR) {
        int *xs = sign + i * SIZE;
        k -= upper_bound(xs,xs + SIZE,v - Add[i]) - xs;
        if(k <= 0) return 1;
    }
    k -= upper_bound(tmp,tmp + end,v) - tmp;
    return k <= 0;
}
int main() {
//    freopen("kth.in", "r", stdin);
//    freopen("kth.out", "w", stdout);
    int N, M, st = 0;
    read(N);
    FOR(i,0,N-1) {
        read(arr[i]); sign[i] = arr[i];
        if(i % SIZE == SIZE - 1) sort(sign + st,sign + i + 1),st = i + 1;
    }
    read(M);
    while(M--) {
        int t, L, R, x;
        read(t);read(L);read(R);read(x);
        --L; --R;
        int LL = L / SIZE, RR = R / SIZE,*xs, *xa;
        if(t == 1)         
            if(LL == RR) {
				update2(LL);
                FOR(i,L,R) sign[i] = arr[i] += x;						
                update1(LL);
            } else {
            	FOR(i,LL + 1,RR - 1)Add[i] += x;				
                update2(LL);update2(RR);
                FOR(i,L,(LL + 1)*SIZE-1) sign[i] = arr[i] += x;
                FOR(i,RR * SIZE,R) sign[i] = arr[i] += x;				
                update1(LL);update1(RR);
            }
        else {
            end = 0;
            if(LL == RR) {
                FOR(i,L,R) tmp[end++] = arr[i] + Add[LL];
                sort(tmp, tmp + end);
                printf("%d\n", tmp[x - 1]);
            } else {
            	FOR(i,L,(LL + 1)*SIZE-1) tmp[end++] = arr[i] + Add[LL];
            	FOR(i,RR * SIZE,R) tmp[end++] = arr[i] + Add[RR];
                sort(tmp,tmp+end);
                int L = 0, R = high + high, ans = 0x3f3f3f3f;
                while(L <= R) {
                    int mid = (L + R) >> 1;
                    if(ok(LL + 1, RR - 1, x, mid - high))  R = (ans = mid) - 1;
                    else L = mid + 1;                   
                }
                printf("%d\n", ans - high);
            }
        }
    }
    return 0;
}
