#include<bits/stdc++.h>
#define x first
#define y second
#define sp putchar(' ')
#define ln putchar('\n')
#define SZ(s) ((int)(s).size())
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

typedef std::pair<int,int> Pii;
typedef long long i64;
typedef long double f64;

template<class K> inline bool umax(K& a,K b) {
  return a < b ? a = b, true: false;
}

template<class K> inline bool umin(K& a,K b) {
  return a > b ? a = b, true: false;
}

template<class K> inline void read(K& x) {
  char c = getchar(); K f = +1;
  for(x = 0;!isdigit(c); c = getchar())
    if(c == '-') f = -1;
  for(;isdigit(c); c = getchar())
    x = x * 10 + c - '0';
  x = x * f;
}

template<class K> inline void write(K x) {
  static int fout[20], top;
  if(x < 0) putchar('-'), x = -x;
  do fout[top++] = x % 10, x /= 10; while(x);
  while(top) putchar(fout[--top] + '0');
}

int N, K, P;
int s[1005], top;
int f[1005][1005];

void dfs(int max,int sum,int n) {
  if(sum == 0) {
    static int ret[2][1005];
    memset(ret, 0, sizeof ret);
    ret[0][0] = 1; int c = 0;
    for(int i = 1;i <= top; ++i) {
      memset(ret[c^1], 0, sizeof ret[c]);
      for(int j = 0;j < n; ++j) 
	for(int k = 0;k < n; ++k) 
	  (ret[c^1][j + k] += (i64) ret[c][j] * f[s[i]][k] % P) %= P;
      c ^= 1;
    }
    
    for(int i = n - 1; i; --i)
      (f[n][n-i] += ret[c][i]) %= P;
  }else {
    for(int i = max;i <= sum; ++i) {
      s[++top] = i;
      dfs(i, sum - i, n);
      top--;
    }
  }
}

int main() {
  if(fopen("zhang.in","r")) {
    freopen("zhang.in","r",stdin);
    freopen("zhang.out","w",stdout);
  }

  read(N), read(K), read(P);

  if(K == 1) puts("1"), exit(0);
  
  f[1][1] = 1;

  int ans = 1;
  for(int i = 1;i < N; ++i)
    ans = (i64) ans * i % P;


  // else if(K == 1) write(
  for(int i = 2;i <= N; ++i)
    dfs(1, i - 1, i);
    
  write((i64) f[N][K] * ans % P), ln;
#ifdef DEBUG
  for(int i = 1;i <= N; ++i) {
    for(int j = 1;j <= i; ++j) {
      fprintf(stderr, "%7d%c", f[i][j], " \n"[j==i]);
    }
  }
#endif
  
  return 0;
}
