#include<cstdio>

typedef long long ll;
#define add(a,b) (a+=b)>=mod&&(a-=mod)
int dp[101][101],f[101][101][101],c[101][101],inv[101],mod;
int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);

	int i,j,k,l,x,n,m;scanf("%d%d%d",&n,&m,&mod);
	for(i=0;i<=n;i++)
	{
		c[i][0]=c[i][i]=1;
		for(j=1;j<i;j++)
			c[i][j]=(c[i-1][j-1]+c[i-1][j])%mod;
	}
	inv[0]=inv[1]=1;
	for(i=2;i<=n;i++)
		inv[i]=mod-(ll)mod/i*inv[mod%i]%mod;

	dp[1][1]=f[1][1][0]=1;
	for(i=2;i<=n;i++)
		for(j=1;j<i;j++)
			for(x=1;x<=i;add(dp[i][j],f[i][j][x]),x++)
				for(k=1;k<=i;k++)
					for(l=1;l<=k;l++)
						add(f[i][j][x],(ll)f[i-k][j-k+l][x-1]*dp[k][l]%mod*c[i][k]%mod*inv[x]%mod);

	printf("%lld\n",(ll)dp[n][m]*inv[n]%mod);
}
