// srt: 2017年03月13日 10時54分28秒
// 宁可枝头抱香死，何曾吹落北风中。
//     -- 郑思肖《画菊》
// end: 2017年03月13日 11時14分19秒

#include<cstdio>

int dp[1048577],f[1048577];
int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);

	int i,s,k,t,n,ans=0;scanf("%d",&n);
	if(n>20)
	{
		for(i=0;i<n;i++)
			for(scanf("%d",&k);k--;
				scanf("%*d"));
		for(i=0;i<n;i++)
			scanf("%d",&k),ans+=k;
		printf("%d\n",ans);
		return 0;
	}

	for(i=0;i<n;i++)
	{
		int&c=dp[1<<i];
		scanf("%d",&k);
		while(k--)
			scanf("%d",&s),c|=1<<(s-1);
	}
	for(i=0;i<n;i++)scanf("%d",f+(1<<i));

	s=1<<n;
	for(i=1;i<s;i++)
	{
		t=__builtin_popcount(i);
		if(t!=1)
		{
			k=i&-i;
			dp[i]=dp[i^k]|dp[k];
			f[i]=f[i^k]+f[k];
		}
		if(t==__builtin_popcount(dp[i])&&f[i]<ans)
			ans=f[i];
	}

	printf("%d\n",ans);
}
