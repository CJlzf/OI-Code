// srt: 2017年03月13日 11時29分11秒
// 半天凉月色，一笛酒人心。
//     -- 袁枚《夜过借园见主人坐月下吹笛》
// end: 2017年03月13日 11時43分42秒

#include<cstdio>
#include<algorithm>
#define getchar getchar_unlocked
#define putchar putchar_unlocked
inline void read(int&r)
{
	register char c;r=0;
	do c=getchar();while(c<'0'||c>'9');
	do r=r*10+c-'0',c=getchar();while(c>='0'&&c<='9');
}
inline void writeln(int w)
{
	static char s[20];
	static int top=0;
	do s[top++]=w%10+'0';while(w/=10);
	while(top)putchar(s[--top]);
	putchar(10);
}

int first[100001],fa[100001],up[100001],nx[100001],a[100001],l;

void dfs(int u,int f,int d)
{
	a[l++]=d;
	for(int v=first[u];v;v=nx[v])
		if(v!=f)
			dfs(v,u,d+up[v]);
}

int find(int u,int k)
{
	l=0,dfs(u,fa[u],0);
	return l<k?-1:(std::nth_element(a,a+k-1,a+l),a[k-1]);
}

int dep(int u)
{
	int d=0;
	while(u)d+=up[u],u=fa[u];
	return d;
}

int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);

	int i,n,m,k;
	read(n),read(m),read(i);
	for(i=2;i<=n;i++)
		read(fa[i]),read(up[i]),nx[i]=first[fa[i]],first[fa[i]]=i;

	while(m--)
		if(read(i),i==2)read(i),read(k),up[i]+=k;
		else read(i),read(k),writeln(find(i,k)+dep(i));
}
