#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

const int maxn=310;
const int maxd=maxn*2;
const int maxe=maxn*maxn*10;
const int INF=1<<30;

struct edge{
	int to,next,cap;
}e[maxe];
int head[maxd],cur[maxd],s,t,num,e_num=1,d[maxd],q[maxd];
bool vis[maxd];

void add_edge(int u,int v,int c){
	e[++e_num]=(edge){v,head[u],c};
	head[u]=e_num;
	e[++e_num]=(edge){u,head[v],0};
	head[v]=e_num;
}

bool bfs(){
	for(int i=0; i<=num; ++i) vis[i]=0,d[i]=INF;
	int hh,tt;
	hh=tt=d[s]=0;
	vis[s]=1;
	q[tt++]=s;
	while(hh<tt){
		int x=q[hh++];
		for(int i=head[x]; i; i=e[i].next)
			if(e[i].cap&&!vis[e[i].to]){
				vis[e[i].to]=1;
				d[e[i].to]=d[x]+1;
				q[tt++]=e[i].to;
			}
	}
	return vis[t];
}

int dfs(int now,int a){
	if(now==t||a==0) return a;
	int f,cnt=0;
	for(int &i=cur[now]; i; i=e[i].next)
		if(d[e[i].to]==d[now]+1&&(f=dfs(e[i].to,min(e[i].cap,a)))>0){
			cnt+=f;
			a-=f;
			e[i].cap-=f;
			e[i^1].cap+=f;
			if(!a) break;
		}
	return cnt;
}

int dinic(){
	int ans=0;
	while(bfs()){
		for(int i=0; i<=num; ++i) cur[i]=head[i];
		ans+=dfs(s,INF);
	}
	return ans;
}

int n,val[maxn];

int get_ans(int st){
	int hh,tt;
	hh=tt=0;
	for(int i=0; i<=num; ++i) vis[i]=0;
	vis[st]=1;
	q[tt++]=st;
	int ans=0;
	while(hh<tt){
		int x=q[hh++];
		if(x>=1&&x<=n) ans+=val[x];
		for(int i=head[x]; i; i=e[i].next)
			if(e[i].cap&&!vis[e[i].to]){
				vis[e[i].to]=1;
				q[tt++]=e[i].to;
			}
	}
	return ans;
}

int main(){
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	s=n*2+1;
	t=num=s+1;
	for(int i=1; i<=n; ++i){
		int tot;
		scanf("%d",&tot);
		int x;
		while(tot--){
			scanf("%d",&x);
			add_edge(i,x+n,1);
		}
	}
	for(int i=1; i<=n; ++i){
		scanf("%d",val+i);
		add_edge(s,i,1);
		add_edge(i+n,t,1);
	}
	dinic();
	int ans=0;
	for(int i=1; i<=n; ++i) ans=min(ans,get_ans(i));
	printf("%d\n",ans);
	return 0;
}
