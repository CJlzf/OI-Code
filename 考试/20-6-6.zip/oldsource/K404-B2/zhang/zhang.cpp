#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
using namespace std;

typedef long long LL;

const int maxn=500010;

LL mod,num[maxn];
int n,k;

LL pp(LL a,LL b){
	if(!b) return 1;
	LL cnt=pp(a,b/2);
	cnt=cnt*cnt%mod;
	if(b&1) cnt=cnt*a%mod;
	return cnt;
}

int main(){
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	cin>>n>>k>>mod;
	num[0]=1;
	for(int i=1; i<=n; ++i) num[i]=num[i-1]*i%mod;
	LL ans=pp(n-k,k-2)*pp(k,n-k)%mod*num[n-1]%mod*pp(num[k],mod-2)%mod*pp(num[n-1-k],mod-2)%mod;
	ans=(ans%mod+mod)%mod;
	cout<<ans<<endl;
	return 0;
}
