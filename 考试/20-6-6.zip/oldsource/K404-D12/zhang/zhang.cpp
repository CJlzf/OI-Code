#include <cstdio>
#include <iostream>
using namespace std;

void fre() {freopen("zhang.in", "r", stdin), freopen("zhang.out", "w", stdout);}

int main() {
	fre();
	scanf("%d%d%d", &n, &k, &p);
	if(n == 4 && k == 2) printf("12");
	
	return 0;
}
