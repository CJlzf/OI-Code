#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
#define adde(u, v, w) (e[ecnt] = (edge){v, w, head[u]}, head[u] = &e[ecnt++])
void fre() {freopen("j.in", "r", stdin), freopen("j.out", "w", stdout);}

const int maxn = 1e5 + 10;
int r[maxn], pos[maxn], dep[maxn], sz[maxn];
int a[maxn], tmp[maxn], cnt, ecnt;
struct edge {int v, w; edge *next;} e[maxn], *head[maxn];

void dfs(int u) {
	r[pos[u] = ++cnt] = u, sz[u] = 1;
	for(edge *k = head[u]; k; k = k->next) dep[k->v] = dep[u] + k->w, dfs(k->v), sz[u] += sz[k->v];
}

int main() {
	fre();
	int n, m, l, u, x, k, op;
	scanf("%d%d%d", &n, &m, &l);
	for(int i = 1; i < n; i++) scanf("%d%d", &u, &x), adde(u, i+1,x);
	dep[1] = 0;
	dfs(1);
	for(int i = 1; i <= n; i++) a[i] = dep[r[i]];
	for(int i = 0; i < m; i++) {
		scanf("%d%d%d", &op, &x, &k);
		if(op == 1) {
			if(sz[x] < k) {puts("-1"); continue;}
			for(int j = pos[x]; j < pos[x]+sz[x]; j++) tmp[j] = a[j];
			sort(tmp+pos[x], tmp+pos[x]+sz[x]);
			printf("%d\n", tmp[pos[x]+k-1]);
		}
		else {
			for(int j = pos[x]; j < pos[x]+sz[x]; j++) a[j] += k;
		}
	}
	return 0;
}
