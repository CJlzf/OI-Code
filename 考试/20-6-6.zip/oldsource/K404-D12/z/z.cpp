#include <cstdio>
#include <bitset>
#include <iostream>
using namespace std;

void fre() {freopen("z.in", "r", stdin), freopen("z.out", "w", stdout);}
const int maxn = 310;
bitset<maxn>m[maxn], tmp;
int a[maxn];

int main() {
	fre();
	int n, t, x, res;
	scanf("%d", &n);
	for(int i = 0; i < n; i++) {
		scanf("%d", &t);
		for(int j = 1; j <= t; j++) scanf("%d", &x), m[i][x] = 1;
	}
	int ok = 1;
	for(int i = 0; i < n; i++) {
		scanf("%d", a + i), res += a[i];if(a[i] > 0) ok = 0;
	}
	if(ok) return printf("%d\n", res), 0;
	int M = (1<<n) - 1;
	int ans = 0;
	for(int s = M; s; s--) {
		tmp.reset(), x = res = 0;
		for(int i = 0; i < n; i++) 
			if((1<<i) & s)x++, tmp |= m[i], res += a[i];
		if(tmp.count() == x) ans = min(ans, res);
		//printf("%d\n", tmp.count());
	}
	printf("%d", ans);
	return 0;
}
