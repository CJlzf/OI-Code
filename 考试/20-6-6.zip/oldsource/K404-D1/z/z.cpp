#include <cstdio>
#include <cstring>
#include <algorithm>

const int N=21;;
int p_cnt[1<<N];


int state[N],p[N],n,ans=0;
void dfs(int x,int sum,int s,int cnt) {
	if (x>n) {
		if (p_cnt[s]==cnt)
			ans = std::min(ans, sum);
		return;
	}
	dfs(x+1,sum+p[x],s|state[x],cnt+1);
	dfs(x+1,sum,s,cnt);
}

int main() {
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	for (int i=1;i<(1<<N);++i) p_cnt[i] = p_cnt[i>>1] + (i&1);
	scanf("%d",&n);
	for (int i=1;i<=n;++i) {
		int t; scanf("%d",&t);
		for (int j=1;j<=t;++j) {
			int c; scanf("%d",&c);
			state[i] |= 1<<(c-1);
		}
	}
	for (int i=1;i<=n;++i) scanf("%d",&p[i]);
	if (n<=20) {
		dfs(1,0,0,0);
	} else {
		for (int i=1;i<=n;++i) ans += p[i];
	}
	printf("%d\n",ans);
	return 0;
}
