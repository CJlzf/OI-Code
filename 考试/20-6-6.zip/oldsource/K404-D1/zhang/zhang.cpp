#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
typedef long long ll;
const int N=500010;

int n,k,MOD;
ll fact[N],r_fact[N];
ll pw(ll x,ll y,ll mod) { ll ans=1; for (;y;y>>=1) {if (y&1) ans=ans*x%mod;x=x*x%mod;} return ans; }
ll rev(ll x) { return pw(x, MOD-2, MOD); }
ll C(ll n, ll m) { return fact[n]*rev(fact[m]*fact[n-m]%MOD)%MOD; }

int main() {
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	scanf("%d%d%d",&n,&k,&MOD);
	r_fact[0] = fact[0] = 1; for (int i=1;i<=n;++i) fact[i] = fact[i-1] * i % MOD;
	if (k==n-1) { printf("%d\n",C(n-1,k-1)); return 0; }
	ll a = n-k, b = k; if (a>b) swap(a,b); ll cnt1=b,cnt2=a; --cnt2;
	ll ans = ((pw(a,cnt1,MOD)*pw(b,cnt2,MOD)%MOD)-((pw(a,cnt1-1,MOD)*pw(b,cnt2-1,MOD)%MOD)*(cnt1*cnt2%MOD)%MOD)+MOD)%MOD;
	printf("%d\n",ans*C(n-1,k-1)%MOD);
}
