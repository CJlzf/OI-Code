#include <cstdio>
#include <algorithm>
using namespace std;

const int N=110010;
const int K=300;

struct E{
	int to,next,c;
}e[N*2];
int head[N],tote;
void adde(int u,int v,int c) { e[++tote]=(E){v,head[u],c}; head[u] = tote; }

int l[N],r[N],rnt,v[N];
void dfs(int rt,int fat,int depth) {
	l[rt] = ++rnt; v[rnt] = depth;
	for (int p=head[rt];p;p=e[p].next) if (e[p].to != fat) {
		dfs(e[p].to,rt,depth+e[p].c);
	}
	r[rt] = rnt;
}

int belong[N];
struct Chunk{
	int l,r,a[K+10],mark,size;
	inline void build(int _l,int _r) {
		l = _l; r = _r; size = mark = 0;
		for (int i=l;i<=r;++i) a[++size] = v[i];
		sort(a+1,a+1+size);
	}
	inline void pushdown() {
		for (int i=l;i<=r;++i) v[i] += mark;
		for (int i=1;i<=size;++i) a[i] += mark;
		mark = 0;
	}
	inline void rebuild() {
		pushdown();
		size = 0; for (int i=l;i<=r;++i) a[++size] = v[i]; sort(a+1, a+1+size);
	}
	inline int query(int x) {
		x -= mark;
		if (a[1]>x) return 0;
		int l = 1, r = size;
		while (l!=r) {
			int mid=(l+r) >> 1;
			if (a[mid+1]<=x) l = mid+1;
			else r = mid;
		}
		return l;
	}
	inline int tag_dt(int x) {
		mark += x;
	}
	inline int clear() {
		size = mark = 0;
	}
}c[N/K],t1,t2;

int main() {
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	int n,m,len; scanf("%d%d%d",&n,&m,&len);
	for (int i=2;i<=n;++i) {
		int f,c; scanf("%d%d",&f,&c);
		adde(i,f,c); adde(f,i,c);
	}
	dfs(1,0,0); int totc=0;
	for (int i=1;i<=n;i+=K) {
		c[++totc].build(i,min(i+K-1,n));
		for (int j=i;j<i+K && j<=n;++j) belong[j] = totc;
	}
	int pcnt=0;
	for (int i=1;i<=m;++i) {
		int fl,x,y; scanf("%d%d%d",&fl,&x,&y);
		if (fl==1) {
			if (r[x]-l[x]+1 < y) { puts("-1"); continue; }
			if (belong[l[x]] == belong[r[x]]) {
				t1.clear(); t1.build(l[x],r[x]); printf("%d\n",t1.a[y]);
			} else {
				int fi = l[x], fj =r[x]; t1.clear(); t2.clear();
				while (belong[fi]==belong[l[x]]) ++fi; t1.build(l[x], fi-1);
				while (belong[fj]==belong[r[x]]) --fj; t2.build(fj+1,r[x]);
				int l = 0, r = 2000000;
				while (l!=r) {
					int mid=(l+r) >> 1, cnt = 0;
					for (int k=belong[fi];k<=belong[fj];++k) cnt += c[k].query(mid);
					cnt += t1.query(mid); cnt += t2.query(mid);
					if (cnt>=y) r=mid; else l=mid+1;
				}
				printf("%d\n",l);
			}
		}
		if (fl==2) {
			if (belong[l[x]] == belong[r[x]]) {
				for (int j=l[x];j<=r[x];++j) v[j] += y;
				c[belong[l[x]]].rebuild();
			} else {
				int fi=l[x],fj=r[x];
				while (belong[fi]==belong[l[x]]) v[fi++] += y; c[belong[l[x]]].rebuild();
				while (belong[fj]==belong[r[x]]) v[fj--] += y; c[belong[r[x]]].rebuild();
				for (int k=belong[fi];k<=belong[fj];++k) c[k].tag_dt(y);
			}
		}
	}
}
