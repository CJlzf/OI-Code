#include<cstdio>
#include<cstring>
#include<iostream>
#include<cstdlib>
#include<cmath>
#include<algorithm>

using namespace std;

struct data{
	int v,to,next;
}e[60005];
int n,m,len,cnt = 1,sz,fl = 0;
int last[30005],q[30005],ans[30005],fa[30005],lentofa[30005];

int read(){
	int x = 0, f = 1; char ch = getchar();
	while (ch < '0' || ch > '9'){
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9'){
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * f;
}

void add(int u, int v, int w){ 
	e[++cnt].to = v; e[cnt].next = last[u]; last[u] = cnt; e[cnt].v = w;
}

void dfs(int x,int now){
	ans[++sz] = now;
	for (int i = last[x]; i; i = e[i].next){
		dfs(e[i].to, now + e[i].v);
	}
}

int finddep(int x){
	if (x == 1) return 0;
	else return (lentofa[x] + finddep(fa[x]));
}


int main(){
	
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	
	n = read(), m = read(), len = read();
	for (int i =2; i <= n; i++){
		int v =read(), w = read();
		add(v,i,w);
		fa[i] = v; lentofa[i] = w;
	}
/*
for (int i= 1; i <= n; i++){
	for (int j = last[i]; j; j = e[j].next){
		printf("%d ", e[j].to);
	}
	printf("\n");
}*/	
	for (int i = 1; i <= m; i++){
		int op = read(), x = read(), k = read();
		if (op == 1){
			memset(ans,0,sizeof(ans));
			sz = 0;
			dfs(x,0);
			sort(ans+1, ans+1+sz);
			if (sz < k) puts("-1"); else
			printf("%d\n", ans[k] + fl + finddep(x));
		}
		if (op == 2){
			if (x == 1) fl += k;
			lentofa[x] += k;
			for (int i = last[fa[x]]; i ; i = e[i].next)
				if (e[i].to == x){
					e[i].v += k;
					break;
				}
		}
	}
	
	return 0;
}

