#include<cstdio>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>

using namespace std;

int n, ans , cnt , cnt2;
int lisan[405], lisan2[405];
struct data{
	int siz,num,yao;
	int ki[25];
}a[25];

int read(){
	int x = 0, f = 1; char ch = getchar();
	while (ch < '0' || ch > '9'){
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9'){
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * f;
}

int find(int x){
	for (int i= 1;i <= cnt2; i++)
	if (lisan2[i] == x) return i;
} 

int count(int x){
	int tmp = 0;
	while (x){
		if (x & 1) tmp++;
		x >>= 1;
	}
	return tmp;
}

int main(){
	
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	
	n = read();
	if (n <=20){
		for (int i = 1; i <= n; i++){
			int t = read(); a[i].siz = t;
			for (int j = 1; j <= t; j++){
				a[i].ki[j] = read();
				lisan[++cnt] = a[i].ki[j];	
			}
		}
		for (int i = 1; i <= n; i++){
			a[i].num = read();
		}
		
		sort(lisan+1, lisan + 1 + cnt);
		for (int i = 1; i <= cnt; i++){
			if (lisan[i] != lisan[i-1]) lisan2[++cnt2] = lisan[i]; 
		}
		
	
		
		for (int i = 1; i <= n ;i++){
			a[i].yao = 0;
			for (int j = 1; j <= a[i].siz; j++){
				int p = find(a[i].ki[j]);
				a[i].yao |= (1 << (p-1));
			}
		}
		
		int maxi = (1 << n) - 1;
		
		for (int i = 0; i <= maxi; i++){
			int x = i,now = 0, tmp = 0, cnt = 0,j = 0;
			while (x){
				j++;
				if (x & 1){
					cnt++; now += a[j].num;
					tmp |= a[j].yao;
				}
				x >>= 1;
			}

			if (count(tmp) == cnt) ans = min(ans, now);
		}
		
		printf("%d", ans);
		
	}else{
		for (int i = 1; i <= n; i++){
			int t = read();
			for (int j = 1; j <= t; j++) int q = read();
		}
		for (int i = 1; i <= n; i++) {
			int x = read();
			ans += x;
		}
		if (ans > 0) ans = 0;
		printf("%d\n", ans);
	}
	return 0;
}
