#include<cstdio>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#define ll long long 

using namespace std;

int n,k,p;
int num[25];
ll ans = 0;

int read(){
	int x = 0, f = 1; char ch = getchar();
	while (ch < '0' || ch > '9') { 
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9'){
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * f;
}

void dfs(int step, int cnt, ll nu){
     
	if (step > n && cnt == k){
		ans = (ans + nu) % p;
	/*	for (int i = 1; i <= n; i++){
			printf("%d ", num[i]);
		}
		printf("\n");*/
		return;
	}
	if (step > n) return;
	for (int i = 2; i <= n; i++){
		if (num[i-1] == 0) break;
		num[i]++;
		int cnnt;
		ll nuum;
		int q;
		if (n - step > 1) q = n - step; else q = 1;
		if (i % 2 != 0) cnnt = cnt + 1; else cnnt = cnt;
		nuum = (nu * num[i-1]) % p;
		dfs(step+1, cnnt, nuum);
		num[i]--;
	}
}


int main(){
	
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	
	n = read(), k = read(), p = read();
	
	if (k == 1) {puts("1"); return 0;}

	num[1] = 1;
	dfs(2,1,1LL);
	
	printf("%lld", ans * (n-1) % p);
	return 0;
}
