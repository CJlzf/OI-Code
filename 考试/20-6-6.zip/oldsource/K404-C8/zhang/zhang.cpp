#include<iostream>
#include<cstdio>
#include<cctype>
#include<vector>
#define ll long long
using namespace std;

#define M 500005
int n,k,P;
int inv[M];

inline int moc(ll x)
{
	return x>=P?x%P:x;
}

int mi(int m,int x)
{
	int ret=1,temp=m;
	while(x)
	{
		if(x&1)ret=moc((ll)ret*temp);
		temp=moc((ll)temp*temp);
		x>>=1;
	}
	return ret;
}

void get_inv()
{
	inv[1]=1;
	for(int x=2;x<=n;x++)
		inv[x]=(-(ll)(P/x)*inv[P%x]%P+P)%P;
}

int C(int x,int y)
{
	if(y>x/2)y=x-y;
	int ret=1;
	for(int i=1;i<=x;i++)ret=moc((ll)ret*i);
	for(int i=1;i<=y;i++)
	ret=moc((ll)ret*inv[i]);
	for(int i=1;i<=x-y;i++)
	ret=moc((ll)ret*inv[i]);
	return ret;
}

int main()
{
	
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	cin>>n>>k>>P;
	get_inv();
	if(k>=n)return puts("0"),n=0;
	cout<<(ll)mi(n-k,n-k-2)*mi(k,n-k-1)%P*(n-1)%P*C(n-2,k-1)%P;
	return 0;
}
