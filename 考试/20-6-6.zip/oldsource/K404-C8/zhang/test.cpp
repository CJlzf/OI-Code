#include<iostream>
#include<cstdio>
#include<cctype>
#include<vector>
#define ll long long
using namespace std;

inline int read()
{
	register int ret=0,c=getchar();
	while(!isdigit(c))c=getchar();
	while(isdigit(c))ret=ret*10+c-'0',c=getchar();
	return ret;
}

#define M 25

int ans,n,k,p;
int is[M],fa[M],C[M][M];
int siz[M];


inline int mod(int x)
{
	return x>=p?x-p:x;	
}

inline int moc(ll x)
{
	return x>=p?x%p:x;
}

void get_C()
{
	C[0][0]=1;
	for(int i=1;i<=20;i++)
		for(int j=0;j<=i;j++)
			C[i][j]=j==0?1:mod(C[i-1][j-1]+C[i-1][j]);
}

int mi(int m,int x)
{
	int ret=1,temp=m;
	while(x)
	{
		if(x&1)ret=moc((ll)ret*temp);
		temp=moc((ll)temp*temp);
		x>>=1;
	}
	return ret;
}

void check()
{
	int num=n-1,ret=1,tot=1;
	for(int i=2;i<=n&&num>0;num-=siz[i],i++)
	{
		if(i&1)tot+=siz[i];
		if(siz[i]==0)return ;
		ret=moc((ll)ret*mi(siz[i-1],siz[i]));
	}
	if(tot==k)ans=mod(ans+ret);
}

void dfs(int x)
{
	if(x==n+1)return check();
	for(int i=2;i<=n;i++)
	{
		siz[i]++;
		dfs(x+1);
		siz[i]--;
	}
}

int main()
{
	//freopen("in.txt","r",stdin);
	freopen("table.txt","w",stdout);
	siz[1]=1;
	//n=read(),k=read();
	p=1e9+7.1;
	get_C();
	for(n=2;n<=10;n++,putchar('\n'))
		for(k=1;k<n;k++)
		{
			ans=0;
			dfs(2);	
			printf("%d ",ans/k/C[n-2][k-1]/(n-1));
		}
	return 0;
}
