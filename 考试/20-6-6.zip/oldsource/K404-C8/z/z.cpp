#include<iostream>
#include<cstdio>
#include<cctype>
#include<vector>
#define ll long long
using namespace std;

inline int read()
{
	register int ret=0,b=1,c=getchar();
	while(!isdigit(c))b=c=='-'?-1:1,c=getchar();
	while(isdigit(c))ret=ret*10+c-'0',c=getchar();
	return ret*b;
}

#define M 25

int a[M],b[M],v[M],tot,n,ans;
vector<int>V[M];

void check()
{
	int num=0,ret=0;
	for(int i=1;i<=n;i++)num+=b[i],ret+=a[i]?v[i]:0;
	if(num!=tot)return ;
	ans=min(ans,ret);
}

void dfs(int x)
{
	if(x==n+1)return check();
	dfs(x+1);
	tot++;
	a[x]=1;
	for(int i=0;i<V[x].size();i++)
		b[V[x][i]]=1;
	dfs(x+1);
	a[x]=0;
	tot--;
}

int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		int m=read();
		for(int j=1;j<=m;j++)V[i].push_back(read());
	}
	for(int i=1;i<=n;i++)v[i]=read();
	dfs(1);
	printf("%d",ans);
	return 0;
}
