#include<bits/stdc++.h>
#define ll long long
using namespace std;

inline int read()
{
	register int ret=0,c=getchar();
	while(!isdigit(c))c=getchar();
	while(isdigit(c))ret=ret*10+c-'0',c=getchar();
	return ret;
}

#define M 1005

int n,m,len;
int l[M],r[M],cnt;
int first[M],to[M<<1],next[M<<1],d[M],t;
int fa[M],siz[M],a[M],temp[M];

void addedge(int s,int v,int val)
{
	next[++t]=first[s];
	first[s]=t;
	to[t]=v;
	d[t]=val;
}

void dfs(int x)
{
	l[x]=++cnt;
	siz[x]=1;
	for(int i=first[x];i;i=next[i])
	{
		int v=to[i];
		if(v==fa[x])continue;
		a[v]=a[x]+d[i];
		dfs(v);
		siz[x]+=siz[v];
	}
	r[x]=cnt;
}

int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	n=read();m=read();len=read();
	if(n>1001)return 0;
	for(int i=2;i<=n;i++)
	{
		int a=read(),b=read();
		fa[i]=a;
		addedge(a,i,b);
	}
	dfs(1);
	for(int i=1;i<=m;i++)
	{
		int A=read(),x=read(),y=read();
		if(A==1)
		{
			if(y>siz[x])
			{
				puts("-1");
				continue;
			}
			for(int j=l[x],k=1;j<=r[x];j++,k++)
				temp[k]=a[j];
			sort(temp+1,temp+r[x]-l[x]+2);
			printf("%d\n",temp[y]);
		}
		else
			for(int j=l[x];j<=r[x];j++)a[j]+=y;
	}
	return 0;
}
