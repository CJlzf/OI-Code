#include <bits/stdc++.h>
using namespace std;

const int MAXN = 100010;

int n, m, zqqak_, dfn[MAXN], size[MAXN], tim, val[MAXN], head[MAXN], e_cnt, fa[MAXN], a[MAXN], t[MAXN], tp;

struct edge { int to, nxt, val; }e[MAXN << 1];

inline void addedge(int x, int y, int w) { e[ ++e_cnt ] = ( edge ){ y, head[ x ], w }; head[ x ] = e_cnt; }

inline void dfs(int x)
{
	size[ x ] = 1;
	dfn[ x ] = ++tim;
	for( int i = head[ x ] ; i ; i = e[ i ].nxt )
		dfs( e[ i ].to ), size[ x ] += size[ e[ i ].to ];
}

int main()
{
	freopen( "j.in" , "r", stdin  );
	freopen( "j.out", "w", stdout );
	scanf( "%d%d%d", &n, &m, &zqqak_ );
	for( int i = 2 ; i <= n ; i++ )
	{
		scanf( "%d%d", &fa[ i ], &val[ i ] );
		addedge( fa[ i ], i, val[ i ] );
		val[ i ] += val[ fa[ i ] ];
	}
	dfs( 1 );
	for( int i = 1 ; i <= n ; i++ ) a[ dfn[ i ] ] = val[ i ];
	while( m-- )
	{
		int opt, x, k;
		scanf( "%d%d%d", &opt, &x, &k );
		if( opt == 1 )
		{
			if( size[ x ] < k ) puts( "-1" );
			else
			{
				tp = 0;
				for( int i = dfn[ x ] ; i <= dfn[ x ] + size[ x ] - 1 ; i++ ) t[ ++tp ] = a[ i ];
				sort( t + 1, t + tp + 1 );
				printf( "%d\n", t[ k ] );
			}
		}
		else
			for( int i = dfn[ x ] ; i <= dfn[ x ] + size[ x ] - 1 ; i++ ) a[ i ] += k;
	}
	return 0;
}
