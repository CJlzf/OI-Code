#include <bits/stdc++.h>
using namespace std;

const int MAXN = 500050;

int n, m, mod, fac[MAXN], inv[MAXN];

inline int qpow(int x, int y)
{
	int s = 1;
	for( ; y ; y >>= 1, x = 1ll * x * x % mod ) if( y & 1 ) s = 1ll * s * x % mod;
	return s;
}

inline int C(int x, int y) { return 1ll * fac[ x ] * inv[ y ] % mod * inv[ x - y ] % mod; }

int main()
{
	freopen( "zhang.in" , "r", stdin  );
	freopen( "zhang.out", "w", stdout );
	scanf( "%d%d%d", &n, &m, &mod );
	fac[ 0 ] = inv[ 0 ] = 1;
	for( int i = 1 ; i <= n ; i++ ) fac[ i ] = 1ll * fac[ i - 1 ] * i % mod;
	inv[ n ] = qpow( fac[ n ], mod - 2 );
	for( int i = n - 1 ; i ; i-- ) inv[ i ] = 1ll * ( i + 1 ) * inv[ i + 1 ] % mod;
	printf( "%d\n", 1ll * C( n - 1, m - 1 ) * qpow( m, n - m - 1 ) % mod * qpow( n - m, m - 1 ) % mod );
	return 0;
}
