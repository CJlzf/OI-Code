#include <bits/stdc++.h>
#define xx first
#define yy second
using namespace std;

typedef pair < int, int > pa;

const int MAXN = 305;
const int MAXM = 200020;
const int INF = 1e9 + 7;

int n, a[MAXN][MAXN], v[MAXN];
int lk[MAXN], ans;
bool vis[MAXN], mp[MAXN][MAXN];

namespace Flow
{
	struct edge { int to, nxt, flow; } e[MAXM];

	int e_cnt = 1, S, T, head[MAXN], q[MAXN], ql, qr, dis[MAXN], cur[MAXN];
	
	inline void Add(int x, int y, int w) { e[ ++e_cnt ] = ( edge ){ y, head[ x ], w }; head[ x ] = e_cnt; }
	inline void Addedge(int x, int y, int w) { Add( x, y, w ); Add( y, x, 0 ); }

	inline bool Bfs()
	{
		ql = 0; qr = 1; memset( dis, 0, sizeof dis );
		dis[ q[ ql ] = S ] = 1;
		while( ql ^ qr )
		{
			int x = q[ ql++ ];
			for( int i = head[ x ] ; i ; i = e[ i ].nxt )
				if( e[ i ].flow && !dis[ e[ i ].to ] ) dis[ q[ qr++ ] = e[ i ].to ] = dis[ x ] + 1;
		}
		return dis[ T ];
	}

	inline int Dfs(int x, int f)
	{
		if( x == T ) return f;
		int ret = 0;
		for( int &i = cur[ x ] ; i ; i = e[ i ].nxt )
			if( e[ i ].flow && dis[ e[ i ].to ] == dis[ x ] + 1 )
			{
				int d = Dfs( e[ i ].to, min( f - ret, e[ i ].flow ) );
				e[ i ].flow -= d; e[ i ^ 1 ].flow += d; ret += d;
				if( ret == f ) return ret;
			}
		if( !ret ) dis[ x ] = -1;
		return ret;
	}

	inline int Dinic()
	{
		int ret = 0;
		while( Bfs() ) memcpy( cur, head, sizeof cur ), ret += Dfs( S, INF );
		return ret;
	}
}

inline bool Dfs(int x)
{
	for( int i = 1 ; i <= n ; i++ )
		if( mp[ x ][ i ] && !vis[ i ] )
		{
			vis[ i ] = 1;
			if( !lk[ i ] || Dfs( lk[ i ] ) )
			{
				lk[ i ] = x;
				return true;
			}
		}
	return false;
}

struct edge { int to, nxt; }e[MAXN * MAXN];

int head[MAXN], e_cnt, dfn[MAXN], tim, scc[MAXN], st[MAXN], top, num, low[MAXN], p[MAXN];

inline void Addedge(int x, int y) { e[ ++e_cnt ] = ( edge ){ y, head[ x ] }; head[ x ] = e_cnt; }

inline void Tarjan(int x)
{
	low[ x ] = dfn[ x ] = ++tim;
	st[ ++top ] = x; int tmp = 0;
	for( int i = head[ x ] ; i ; i = e[ i ].nxt )
		if( !dfn[ e[ i ].to ] ) Tarjan( e[ i ].to ), low[ x ] = min( low[ x ], low[ e[ i ].to ] );
		else if( !scc[ e[ i ].to ] ) low[ x ] = min( low[ x ], dfn[ e[ i ].to ] );
	if( low[ x ] == dfn[ x ] )
	{
		num++;
		while( tmp ^ x )
		{
			scc[ tmp = st[ top-- ] ] = num;
			p[ num ] -= v[ tmp ];
		}
	}
}

map < pa, bool > F;

inline void Build()
{
	for( int i = 1 ; i <= n ; i++ )
		for( int j = 1 ; j <= a[ i ][ 0 ] ; j++ )
			if( scc[ i ] ^ scc[ lk[ a[ i ][ j ] ] ] )
				if( F.find( make_pair( scc[ i ], scc[ lk[ a[ i ][ j ] ] ] ) ) == F.end() )
					Flow::Addedge( scc[ i ], scc[ lk[ a[ i ][ j ] ] ], INF ), F[ make_pair( scc[ i ], scc[ lk[ a[ i ][ j ] ] ] ) ] = 1;
	for( int i = 1 ; i <= num ; i++ )
		if( p[ i ] > 0 ) Flow::Addedge( Flow::S, i, p[ i ] ), ans += p[ i ];
		else Flow::Addedge( i, Flow::T, -p[ i ] );
}

int main()
{
	freopen( "z.in" , "r", stdin  );
	freopen( "z.out", "w", stdout );
	scanf( "%d", &n );
	for( int i = 1 ; i <= n ; i++ )
	{
		scanf( "%d", &a[ i ][ 0 ] );
		for( int j = 1 ; j <= a[ i ][ 0 ] ; j++ ) scanf( "%d", &a[ i ][ j ] ), mp[ i ][ a[ i ][ j ] ] = 1;
	}
	for( int i = 1 ; i <= n ; i++ ) scanf( "%d", &v[ i ] );
	for( int i = 1 ; i <= n ; i++ )
	{
		memset( vis, 0, sizeof vis );
		Dfs( i );
	}
	for( int i = 1 ; i <= n ; i++ )
		for( int j = 1 ; j <= a[ i ][ 0 ] ; j++ )
			if( lk[ a[ i ][ j ] ] ^ i ) Addedge( i, lk[ a[ i ][ j ] ] );
	for( int i = 1 ; i <= n ; i++ ) if( !dfn[ i ] ) Tarjan( i );
	Flow::T = num + 1;
	Build();
	ans -= Flow::Dinic();
	cout << -ans << endl;
	return 0;
}
