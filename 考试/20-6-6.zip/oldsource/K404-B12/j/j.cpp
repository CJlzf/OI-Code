#include <cstdio>
#include <cstring>
#include <algorithm>
const int MaxN = 1e5 + 7;
struct edge {
	int to, w;
	edge *nxt;
}edge_mset[MaxN], *g[MaxN], *cedge = edge_mset;
inline void add_edge(int u, int v, int w) {
	*cedge = (edge) {v, w, g[u]};
	g[u] = cedge++;
}
int dep[MaxN], in[MaxN], ou[MaxN], dfn, d[MaxN];

void dfs(int u) {
	d[in[u] = ++dfn] = dep[u];
	for (edge *it = g[u]; it; it = it->nxt) {
		dep[it->to] = dep[u] + it->w;
		dfs(it->to);
	}
	ou[u] = dfn;
}


int main() {
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);
	int n, m, u, w;
	scanf("%d%d%*d", &n, &m);
	for (int i = 2; i <= n; ++i) {
		scanf("%d%d", &u, &w);
		add_edge(u, i, w);
	}

	dfs(1);	

	for (int opt, x, k; m; --m) {
		scanf("%d%d%d", &opt, &x, &k);
		static int a[MaxN], *end;
		if (opt & 1) {
			if (ou[x] - in[x] + 1 < k) {
				puts("-1");
				continue;
			}
			end = a;
			for (int i = in[x]; i <= ou[x]; ++i)
				*end++= d[i];
			std::sort(a, end);
			printf("%d\n", a[k - 1]);
		} else for (int i = in[x]; i <= ou[x]; ++i)
			d[i] += k;
	}

	return 0;
}
