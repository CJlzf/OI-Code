#include <cstdio>
#include <cstring>
#include <algorithm>
const int MaxN = 1e5 + 7;
struct edge {
	int to, w;
	edge *nxt;
}edge_mset[MaxN << 1], *g[MaxN], *cedge = edge_mset;
inline void add_edge(int u, int v, int w) {
	*cedge = (edge) {v, w, g[u]};
	g[u] = cedge++;
}
int dep[MaxN], in[MaxN], ou[MaxN], dfn, tr[MaxN];
inline void add(int x, const int &v) {
	for (; x <= dfn; x += x & -x) tr[x] += v;
}
inline int sum(int x) {
	static int r;
	for (r = 0; x; x ^= x & -x) r += tr[x];
	return r; 
}
void dfs(int u) {
	in[u] = ++dfn;
	for (edge *it = g[u]; it; it = it->nxt)
		if (!in[it->to]) {
			dep[it->to] = dep[u] + it->w;
			dfs(it->to);
		}
	ou[u] = dfn;
}
int ans[MaxN];
struct ask {
	int l, r, tim, _l, _r, id;
} q[MaxN];
struct chg {
	int l, r, delta;
} p[MaxN];
bool operator < (const ask &a, const ask &b) {
	return (a._l ^ b._l) ? a._l <  b._l : ((a._r ^ b._r) ? a._r < b._r : a.tim < b.tim);
}
int main() {
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);
	int n, m, u, v, w, _p, _q, blo;
	scanf("%d%d%*d", &n, &m);
	for (int i = 1; i < n; ++i) {
		scanf("%d%d%d", &u, &v, &w);
		add_edge(u, v, w);
		add_edge(v, u, w);
	}
	dfs(1);	
	return 0;
}
