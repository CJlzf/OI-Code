#include <cstdio>
#include <cstring>
#include <algorithm>
const int MaxN = 1e5 + 7, blosize = 400;
struct edge {
	int to, w;
	edge *nxt;
}edge_mset[MaxN], *g[MaxN], *cedge = edge_mset;
inline void add_edge(int u, int v, int w) {
	*cedge = (edge) {v, w, g[u]};
	g[u] = cedge++;
}
int dep[MaxN], in[MaxN], ou[MaxN], dfn, bel[MaxN], blo;
int arr_pool[MaxN], *poolend = arr_pool, a[MaxN];

struct block {
	int *begin, *end, delta;
	void init() {
		begin = end = poolend;
		poolend += blo;
		delta = 0;
	}
	void append(const int &x) {
		*end++ = x;
	}
	void rebuild() {
		std::sort(begin, end);
	}
	void find(const int &x) const {
		return std::upper_bound(begin, end, x) - begin;
	}
}B[blosize];

void dfs(int u) {
	a[in[u] = ++dfn] = dep[u];
	B[bel[dfn]].append(dep[u]);
	for (edge *it = g[u]; it; it = it->nxt) {
		dep[it->to] = dep[u] + it->w;
		dfs(it->to);
	}
	ou[u] = dfn;
}
int ans[MaxN];
struct opt {
	int opt, x, k, id;
	void read(const int &idx) {
		id = idx;
		scanf("%d%d%d", &opt, &x, &k);
	}
}q[MaxN];

void solve(int l, int r, int L, int R) {
	if (l == r) {
		for (int i = L; i <= R; ++i)
			if (q[i].opt & 1) ans[q[i].id] = l;
		return;
	}
	int mid = (l + r) >> 1;

}

int main() {
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);
	int n, m, u, w;
	scanf("%d%d%*d", &n, &m);
	for (int i = 2; i < n; ++i) {
		scanf("%d%d", &u, &w);
		add_edge(u, i, w);
	}
	for (blo = 1; blo * blo <= n; ++blo);
	for (int i = 1; i <= n; ++i) bel[i] = i / blo;
	for (int i = 0; i <= bel[n]; ++i) B[i].init();

	dfs(1);	
	
	for (int i = 0; i <= bel[n]; ++i) B[i].rebuild();
	for (int i = 0; i < m; ++i) q[i].read(i);
	memset(ans, -1, sizeof ans);
	solve(1, 2e6, 0, m - 1);
	for (int i = 0; i < m; ++i) if (~ans[i]) printf("%d\n", ans[i]);
	return 0;
}
