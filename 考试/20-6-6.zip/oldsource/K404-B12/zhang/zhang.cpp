#include <cstdio>
#include <cstring>
#include <algorithm>

const int MaxN = 103;
#define rep(i, l, r) for (register int i = l; i < r; ++i)

inline int pw(int a, int b, const int &p) {
	int r = 1;
	for (; b; (b >>= 1) ? a = (long long)a * a % p : 0)
		if (b & 1) r = (long long)r * a % p;
	return r;
}


int a[MaxN][MaxN], C[MaxN][MaxN];
inline int guass(const int &n, const int &p) {
	int ans = 1;
	rep(i, 1, n) {
		int id = i;
		while (id < n && !a[id][i]) ++id;
		if (id >= n) return 0;
		if (id ^ i) {
			rep(j, 1, n) std::swap(a[i][j], a[id][j]);
			ans = -ans;
		}
		rep(j, i + 1, n)
			while (a[j][i]) {
				int t = a[i][i] / a[j][i];
				rep(k, 1, n) {
					a[i][k] = (a[i][k] - t * a[j][k]) % p;
					if (a[i][k] < 0) a[i][k] += p;
				}
				rep(k, 1, n) std::swap(a[j][k], a[i][k]);
			}
	}
	rep(i, 1, n) ans = (long long)ans * a[i][i] % p;
	if (ans < 0) ans += p;
	return ans;
}

int main() {
	freopen("zhang.in", "r", stdin);
	freopen("zhang.out", "w", stdout);
	int n, k, p;
	scanf("%d%d%d", &n, &k, &p);
	rep(i, 1, n) rep(j, 1, n) 
		if (i ^ j) 
			a[i][j] = (i ^ j) & 1;
		else 
			a[i][j] = (i & 1) ? (n - k) : k;
	C[0][0] = 1;
	for (int i = 1; i < n; ++i)
		for (int j = C[i][0] = 1; j <= i; ++j) {
			for (C[i][j] = C[i - 1][j] + C[i - 1][j - 1]; C[i][j] >= p; C[i][j] -= p);
			//printf("%d %d %d\n", i, j, C[i][j]);
		}
	printf("%d\n", (int)((long long)guass(n, p) * C[n - 1][k - 1] % p));
	return 0;
}
