#include <cstdio>
#include <vector>

const int MaxN = 303;

typedef std::vector<int> vii;

vii a[MaxN];
int P[MaxN], vis[MaxN], count[1<<20|3];

int main() {
	freopen("z.in", "r", stdin);
	freopen("z.out", "w", stdout);
	int n;
	scanf("%d", &n);
	for (int i = 0, t, x; i < n; ++i) {
		scanf("%d", &t);
		while (t--) {
			scanf("%d", &x);
			a[i].push_back(x);
		}
	}
	for (int i = 0; i < n; ++i) scanf("%d", P + i);
	if (n > 20) {
		int sum = 0;
		for (int i = 0; i < n; ++i)
			if (P[i] < 0) sum += P[i];
		printf("%d\n", sum);
		return 0;
	}
	int all = 1 << n, _vis = 0, cnt, ans = 0, sum;
	for (int i = 1; i < all; ++i) {
		++_vis;
		cnt = sum = 0;
		count[i] = count[i & (i - 1)] + 1;
		for (int j = 0; j < n; ++j)
			if (i >> j & 1) {
				for (vii::iterator it = a[j].begin(); it != a[j].end(); ++it)
				if (vis[*it] ^ _vis) {
					++cnt;
					vis[*it] = _vis;
				}
				sum += P[j];
			}
		if (cnt == count[i] && sum < ans) ans = sum;
	}
	printf("%d\n", ans);
	return 0;
}

