#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
struct line
{	int v,w,next;
}e[100005];
int len,n,m,t,b[100005],cnt,q,x,y,dfn[100005],size[100005],w[100005],z[100005],dis[100005];
void add(int x,int y,int z)
{	e[++t].v=y;
	e[t].w=z;
	e[t].next=b[x];
	b[x]=t;
}
void dfs(int u)
{	size[u]=1;
	dfn[u]=++cnt;
	for(int o=b[u];o;o=e[o].next)
	{	dis[e[o].v]=dis[u]+e[o].w;
		dfs(e[o].v);
		size[u]+=size[e[o].v];
	}
}
void tp()
{	while(m--)
	{	scanf("%d%d%d",&q,&x,&y);
		if(q==1)
		{	int t=0;
			if(y>size[x])
			{	printf("-1\n");
				continue;
			}
			for(int i=dfn[x];i<dfn[x]+size[x];i++)z[++t]=w[i];
			sort(z+1,z+t+1);
			printf("%d\n",z[y]);
		}else
		{	for(int i=dfn[x];i<dfn[x]+size[x];i++)w[i]+=y;
		}
	}
}
int main()
{	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	memset(b,0,sizeof b);
	t=0;
	scanf("%d%d%d",&n,&m,&len);
	add(0,1,0);
	for(int i=2;i<=n;i++)
	{	scanf("%d%d",&x,&y);
		add(x,i,y);
	}
	cnt=0;
	dis[0]=0;
	dfs(0);
	for(int i=0;i<=n;i++)w[dfn[i]]=dis[i];
//	if(n<=1000&&m<=1000)
	{	tp();
		return 0;
	}
	return 0;
}
