#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int a[305],p[305],x,med[305],n,k,ac;
void translate(int x)
{	for(int i=1;i<=n;i++)
	{	a[i]=x&1;
		x>>=1;
	}
}
void calc()
{	int cnt=0,cnt2=0,d=0,w=0;
	for(int i=1;i<=n;i++)if(a[i])
	{	++cnt;
		d|=med[i];
		w+=p[i];
	}
	while(d)
	{	cnt2+=d&1;
		d>>=1;
	}
	if(cnt==cnt2)ac=min(ac,w);
}
int main()
{	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	memset(med,0,sizeof med);
	for(int i=1;i<=n;i++)
	{	scanf("%d",&k);
		while(k--)
		{	scanf("%d",&x);
			med[i]+=1<<(x-1);
		}
	}
	bool sym=true;
	for(int i=1;i<=n;i++)scanf("%d",&p[i]);
	for(int i=1;i<=n;i++)if(p[i]>0)sym=false;
	if(sym)
	{	ac=0;
		for(int i=1;i<=n;i++)ac+=p[i];
		printf("%d\n",ac);
		return 0;
	}
	ac=0;
	int tar=(1<<n)-1;
	for(int i=0;i<=tar;i++)
	{	translate(i);
		calc();
	}
	printf("%d\n",ac);
	return 0;
}
