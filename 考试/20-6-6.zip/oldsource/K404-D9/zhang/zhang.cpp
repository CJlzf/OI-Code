#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,k,pen[500005],inv[500005],pinv[500005];
long long ac,zhhx;
long long qpow(long long y,long long b)
{	long long ac=1;
	while(b>0)
	{	if(b%2==1)ac=ac*y%zhhx;
		y=y*y%zhhx;
		b=b/2;
	}
	return ac;
}
int main()
{	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	scanf("%d%d%lld",&n,&k,&zhhx);
	pen[0]=pinv[0]=pen[1]=inv[1]=pinv[1]=1;
	for(int i=2;i<=n;i++)
	{	inv[i]=zhhx-(long long)(zhhx/(long long)i)*inv[zhhx%(long long)i]%zhhx;
		pen[i]=(long long)pen[i-1]*i%zhhx;
		pinv[i]=(long long)pinv[i-1]*inv[i]%zhhx;
	}
	ac=qpow(k,n-k-1);
	ac=ac*qpow(n-k,k-1)%zhhx;
	ac=ac*(long long)pen[n-1]%zhhx;
	ac=ac*(long long)pinv[k-1]%zhhx;
	ac=ac*(long long)pinv[n-k]%zhhx;
	printf("%lld\n",ac);
	return 0;
}
