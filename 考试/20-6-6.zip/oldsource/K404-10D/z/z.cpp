#include <cstdio>
#include <bitset>
#include <algorithm>

using namespace std;

int rd() {
	char ch;
	int s = 0, f = 1;
	do ch = getchar(); while ((ch < '0' || ch > '9') && ch != '-');
	if (ch == '-') ch = getchar(), f = -1;
	do s = s * 10 + ch - '0', ch = getchar(); while (ch >= '0' && ch <= '9');
	return s * f;
}

const int maxn = 310;

bitset<maxn> a[maxn];
int n, p[maxn], ans, s[maxn];

bool chosen[maxn];

void dfs(int k, int sum) {
	if (k > n) {
		bitset<maxn> s;
		int cnt = 0;
		for (int i = 1; i <= n; ++i)
			if (chosen[i]) s |= a[i], ++cnt;
		if (cnt == s.count()) ans = min(ans, sum);
		return;
	}
	dfs(k + 1, sum);
	chosen[k] = 1;
	dfs(k + 1, sum + p[k]);
	chosen[k] = 0;
}

int main() {
	freopen("z.in", "r", stdin);
	freopen("z.out", "w", stdout);
	n = rd();
	bool flag = 1;
	for (int i = 1; i <= n; ++i) {
		int t = rd();
		for (int j = 0; j < t; ++j)
			a[i].set(rd() - 1);
	}
	for (int i = 1; i <= n; ++i)
		flag &= (p[i] = rd()) <= 0;
	for (int i = n - 1; i; --i)
		s[i] += s[i + 1];
	if (flag) {
		int sum = 0;
		for (int i = 1; i <= n; ++i)
			sum += p[i];
		printf("%d\n", sum);
	} else {
		dfs(1, 0);
		printf("%d\n", ans);
	}
	return 0;
}
