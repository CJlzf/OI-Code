#include <cstdio>
#include <algorithm>

using namespace std;

int rd() {
	char ch;
	int s = 0, f = 1;
	do ch = getchar(); while ((ch < '0' || ch > '9') && ch != '-');
	if (ch == '-') ch = getchar(), f = -1;
	do s = s * 10 + ch - '0', ch = getchar(); while (ch >= '0' && ch <= '9');
	return s * f;
}

const int maxn = 100010, K = 400, inf = 1e9;

struct edge {
	int to, nxt, w;
}e[maxn * 2];

int hd[maxn], tot;

void add(int u, int v, int w) {
	e[++tot] = (edge) {v, hd[u], w}; hd[u] = tot;
	e[++tot] = (edge) {u, hd[v], w}; hd[v] = tot;
}

int st[maxn], ed[maxn], tme, dep[maxn];

void dfs(int u, int f, int d) {
	st[u] = ++tme;
	dep[tme] = d;
	for (int t = hd[u]; t; t = e[t].nxt) {
		int v = e[t].to;
		if (v == f) continue;
		dfs(v, u, d + e[t].w);
	}
	ed[u] = tme;
}

int cnt[K], tag[K];
int kuai[K + 10][K + 10];

int find(int t, int x) {
	int l = 0, r = cnt[t] + 1;
	while (l < r) {
		int mid = l + r + 1 >> 1;
		if (kuai[t][mid] > x) r = mid - 1;
		else l = mid;
	}
	return l;
}

int main() {
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);
	int n = rd(), m = rd(), len = rd();
	for (int i = 2; i <= n; ++i) {
		int fa = rd(), w = rd();
		add(fa, i, w);
	}
	dfs(1, 0, 0);
	for (int i = 1, j = 1; i <= n; ++i) {
		kuai[j][++cnt[j]] = dep[i];
		if (i % K == 0) {
			sort(kuai[j] + 1, kuai[j] + cnt[j] + 1);
			kuai[j][cnt[j] + 1] = inf;
			++j;
		}
	}
	for (int i = 1; i <= m; ++i) {
		int opt = rd(), x = rd(), k = rd();
		int l = st[x], r = ed[x];
		int L = (l + K - 1) / K, R = (r + K - 1) / K;
		int bot = L * K + 1, top = (R - 1) * K;
		if (opt == 1) {
			int p = inf, q = 0;
			for (int j = L + 1; j < R; ++j)
				p = min(p, kuai[j][1]),
				q = max(q, kuai[j][cnt[j]]);
			if (L < R) {
				for (int j = l; j < bot; ++j)
					p = min(p, dep[j] + tag[L]),
					q = max(q, dep[j] + tag[L]);
				for (int j = top + 1; j <= r; ++j)
					p = min(p, dep[j] + tag[R]),
					q = max(q, dep[j] + tag[R]);
			} else {
				for (int j = l; j <= r; ++j)
					p = min(p, dep[j] + tag[L]),
					q = max(q, dep[j] + tag[L]);
			}
			while (p < q) {
				int mid = p + q >> 1;
				int sum = 0;
				for (int j = L + 1; j < R; ++j)
					sum += find(j, mid);
				if (L < R) {
					for (int j = l; j < bot; ++j)
						sum += (dep[j] + tag[L]) <= mid;
					for (int j = top + 1; j <= r; ++j)
						sum += (dep[j] + tag[R]) <= mid;
				} else {
					for (int j = l; j <= r; ++j)
						sum += (dep[j] + tag[L]) <= mid;
				}
				if (sum < k) p = mid + 1; else q = mid;
			}
			printf("%d\n", q);
		} else {
			for (int j = L + 1; j < R; ++j)
				tag[j] += k;
			int p = bot - K, q = min(top + K, n);
			if (L < R) {
				for (int j = p; j < bot; ++j) {
					dep[j] += tag[L] + k;
					kuai[L][j - p + 1] = dep[j];
				}
				sort(kuai[L] + 1, kuai[L] + cnt[L] + 1);
				for (int j = top + 1; j <= q; ++j) {
					dep[j] += tag[R] + k;
					kuai[R][j - top] = dep[j];
				}
				sort(kuai[R] + 1,  kuai[R] + cnt[R] + 1);
			} else {
				for (int j = p; j <= q; ++j) {
					dep[j] += tag[L] + k;
					kuai[L][j - p + 1] = dep[j];
				}
			}
			tag[L] = tag[R] = 0;
		}
	}
	return 0;
}
