#include <cstdio>
#include <algorithm>

using namespace std;

int rd() {
	char ch;
	int s = 0, f = 1;
	do ch = getchar(); while ((ch < '0' || ch > '9') && ch != '-');
	if (ch == '-') ch = getchar(), f = -1;
	do s = s * 10 + ch - '0', ch = getchar(); while (ch >= '0' && ch <= '9');
	return s * f;
}

typedef long long LL;

int N, K, P;

int ksm(LL a, int k) {
	LL x = 1;
	for (; k; k >>= 1, a = a * a % P)
		if (k & 1) x = x * a % P;
	return x;
}

const int maxn = 500010;

int fac[maxn], inv[maxn];

void prefac(int n) {
	fac[0] = 1;
	for (int i = 1; i <= n; ++i)
		fac[i] = 1ll * fac[i - 1] * i % P;
	inv[n] = ksm(fac[n], P - 2);
	for (int i = n - 1; i >= 0; --i)
		inv[i] = 1ll * inv[i + 1] * (i + 1) % P;
}

int a[maxn];
int ans;

void dfs(int k, int left, int sumo) {
	if (left < K - sumo) return;
	if (!left) {
		int sum = 1;
		for (int i = 1; i < k; ++i)
			sum = 1ll * sum * inv[a[i]] % P;
		for (int i = 1; i < k - 1; ++i)
			sum = 1ll * sum * ksm(a[i], a[i + 1]) % P;
		ans += sum;
		if (ans >= P) ans -= P;
		return;
	}
	if (k & 1) {
		for (int i = 1; i <= left; ++i) {
			a[k] = i;
			dfs(k + 1, left - i, sumo);
		}
	} else {
		for (int i = 1; i <= min(K - sumo, left); ++i) {
			a[k] = i;
			dfs(k + 1, left - i, sumo + i);
		}
	}
}

int main() {
	freopen("zhang.in", "r", stdin);
	freopen("zhang.out", "w", stdout);
	N = rd(), K = rd(), P = rd();
	prefac(N);
	dfs(1, N - 1, 1);
	ans = 1ll * ans * fac[N - 1] % P;
	printf("%d\n", ans);
	return 0;
}
