#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n;
long long ans=0;
struct node
{
	int num,t[301];
	long long val;
}q[301];
int vis[301];
int sta[301],top;

void dfs(int x,int num,int f,long long y)
{
	if(x==n+1 && num==f){
		ans=min(ans,y);
		return;
	}
	if(x==n+1)return;
	for(int i=x;i<=n;i++)
	{
		dfs(i+1,num,f,y);
		int t=0;
		for(int j=1;j<=q[i].num;j++)
			if(vis[q[i].t[j]]==0)t++,vis[q[i].t[j]]=1;
			else vis[q[i].t[j]]++;
		//if(q[i].val>0 && num+1!=f+t && ans<y+q[i].val)continue;
		dfs(i+1,num+1,f+t,y+q[i].val);
		for(int j=1;j<=q[i].num;j++)vis[q[i].t[j]]--;
	}
}
bool cmp(node a,node b){
	return a.val<b.val;
}
int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&q[i].num);
		for(int j=1;j<=q[i].num;j++){
			scanf("%d",&q[i].t[j]);
		}
	}
	for(int i=1;i<=n;i++)scanf("%lld",&q[i].val);
	long long f=0,t=0;
	for(int i=1;i<=n;i++)f+=q[i].val,t+=q[i].val<0;
	if(t==n){
		printf("%lld",f);
		exit(0);
	}
	t=0;
	for(int i=1;i<=n;i++)t+=q[i].val>0;
	if(t==n){
		printf("0");
		exit(0);
	}
	sort(q+1,q+1+n,cmp);
	dfs(1,0,0,0);
	printf("%d",ans);
}
/*
3
2 1 2
2 1 2
1 3 
-2 1 -3
*/
