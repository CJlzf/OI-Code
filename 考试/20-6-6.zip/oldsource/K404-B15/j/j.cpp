#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,k=1,f[30010],len,m;
struct node
{
	int to,next,w;
}edge[2000000];
int head[3001];
int q[30001],top;
int dist[30001],d[3001],size[3001];

struct neas
{
	int l,r;
}a[30001];
void add(int u,int v,int w)
{
	edge[++k].to=v;
	edge[k].w=w;
	edge[k].next=head[u];
	head[u]=k;
}

bool cmp(int a,int b)
{
	return a<b;
}
void DFS(int x)
{
	size[x]=1;
	for(int i=head[x];i;i=edge[i].next)
	{
		int to=edge[i].to;
		dist[to]=dist[x]+edge[i].w;
		DFS(to);
		size[x]+=size[to];
	}
}
void dfs(int x)
{
	d[++top]=x;
	for(int i=head[x];i;i=edge[i].next)
	{
		dfs(edge[i].to);
	}d[++top]=-x;
}
void solve(int x,int h)
{
	if(size[x]<h){
		printf("-1");return ;
	}
	top=0;
	for(int i=a[x].l;i<=a[x].r;i++)
		if(d[i]>0)q[++top]=dist[d[i]];
	sort(q+1,q+1+top,cmp);
	printf("%d\n",q[h]);
}
int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	scanf("%d%d%d",&n,&m,&len);
	for(int i=2;i<=n;i++)
	{
		int fa,w;
		scanf("%d%d",&fa,&w);
		f[i]=fa;
		add(fa,i,w);
	}
	dfs(1);
	DFS(1);
	//for(int i=1;i<=n;i++)printf("%d ",size[i]);
//	printf("\n");
	for(int i=1;i<=2*n;i++)
		if(d[i]>0)a[d[i]].l=i;
		else a[-d[i]].r=i;
	for(int i=1;i<=m;i++){
		int opt,x,w;
		scanf("%d%d%d",&opt,&x,&w);
		if(opt==1){
			solve(x,w);
		}
		else
		{
			for(int j=a[x].l;j<=a[x].r;j++)
				if(d[j]>0)dist[d[j]]+=w;
		}
	}	
}
/*
3 5 3
1 3
2 3
1 1 3
2 3 3
1 1 3
2 1 2
1 1 3
*/
