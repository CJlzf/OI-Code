#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;


int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	printf("12");
}

/*
1
1   2
1   12   3
1   48   60    4             4*12 4*20
1   160  570   260   5       5*32 5*114 5*52 
1   480  4140  4920  990   6 6*80 6*690 6*820 6*165
1   1344 25935 63560 35805 3402  7
      1
	  6     1
	  24    20      1    
	  80    190	    65	
	  240   1380	1230	 	
	  672   8645    15890	
	  
	  4   1
	  12  15   1
	  32  114  52   1
	  80  690  820  165  1  
	  192 3705 9080 5115 486
	  
*/	   
