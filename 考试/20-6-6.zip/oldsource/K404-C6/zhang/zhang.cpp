#include<cstdio>
#define maxn 500100
#define lld long long
lld mod;
using namespace std;
lld fac[maxn];
inline lld qpow(lld a,lld b){
	lld as = 1;
	while(b){
		if(b & 1) as = as * a % mod;
		a = a * a %mod;
		b >>= 1;
	}
	return as;
}
inline lld inv(lld x){
	return qpow(x,mod-2);
}
inline lld cal_c(lld a,lld b){
	return fac[a] * inv(fac[b]) %mod * inv(fac[a - b]) % mod; 
}
inline lld cal_f(lld n,lld k){
	return cal_c(n - 1,k) * qpow(n - k,k - 2) % mod * qpow(k, n - k) % mod;
}
lld n,k;
inline void ini(){
	fac[0] = 1;
	for(int i = 1;i <= n;++i){
		fac[i] = fac[i-1] * i % mod;
	}
}
int main(){
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	scanf("%lld%lld%lld",&n,&k,&mod);
	ini();
	printf("%lld\n",cal_f(n,k));
	return 0;
}
