#include<cstdio>
#include<bitset>
#define maxn 25
using namespace std;
#define lld long long
bitset<maxn> hs[maxn];
bitset<maxn> now;
lld tot;
lld va[maxn];
lld as = 0;
int n,t,a1;
int main(){
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	for(int i = 1;i<=n;++i){
		scanf("%d",&t);
		for(int j = 1;j<=t;++j){
			scanf("%d",&a1);
			hs[i][a1] = 1;
		}
	}
	for(int i = 1;i<=n;++i){
		scanf("%lld",&va[i]);
	}
	for(int s = 0;s < (1 << n);++s){
		now.reset();
		int ct = 0;
		tot = 0;
		for(int i = 1;i<=n;++i){
			if((s >> ( i - 1 )) & 1) tot += va[i],++ct,now |= hs[i];
		}
		if(now.count() == ct){
			as = min(as,tot);
		}
	}
	printf("%lld\n",as);
	return 0;
}
