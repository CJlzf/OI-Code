#include <cstdio>
#include <vector>
#include <cstdlib>
#include <iostream>
#include <algorithm>

using namespace std;

int n,m,len;

int fa[30050];
int w[30050];
int dis[30050];
int st[30050],top;
vector<int> cnt[30050];

void Update(int x,int s=0) {
	dis[x] = s;
	st[top++] = s;
	for(vector<int>::iterator it = cnt[x].begin();it != cnt[x].end();it++) {
		Update(*it,s+w[*it]);
	}
}

int main(void) {
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	int x,y,z;
	cin>>n>>m>>len;
	if(n <= 30000) {
		for(int i=2;i<=n;i++) {
			cin>>x>>y;
			fa[i] = x;
			w[i] = y;
			cnt[x].push_back(i);
		}
		Update(1,0);
		for(int i=0;i<m;i++) {
			cin>>x>>y>>z;
			if(x == 2) {
				w[y]+=z;
				Update(y,dis[fa[y]]+w[y]);
			}
			else {
				top=0;
				Update(y,dis[y]);
				nth_element(st,st+z-1,st+top);
				cout<<*(st+z-1)<<endl;
			}
		}
	}
	else {
		puts("Naive");
		return 19260817;
	}
	return 0;
}
