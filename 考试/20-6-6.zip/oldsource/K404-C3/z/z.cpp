#include <vector>
#include <bitset>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>

using std::cin;
using std::cout;
using std::endl;
using std::vector;
using std::min;
using std::max;
using std::bitset;

namespace Data {
	int n;
	vector<int> cn[310];
	int ws[310];
}

using Data::ws;
using Data::n;
using Data::cn;

namespace Graph {
	struct Edge {
		int to,next;
    } table[180050];

    int head[310],etot;

    int dfn[310],low[310],dft;
    int scc[310],scctot;
    int stack[310],top;
    bool ins[310];

    void Tarjan(int x,int fa) {
		dfn[x] = low[x] = ++dft;
		stack[top++] = x;
		ins[x] = true;
		for(int h = head[x];h;h=table[h].next) {
			//if(table[h].to == fa) continue;
			if(!dfn[table[h].to]) {
				Tarjan(table[h].to,x);
				low[x] = min(low[x],low[table[h].to]);
			}
			if(ins[table[h].to]) {
				low[x] = min(low[x],dfn[table[h].to]);
			}
		}
		if(low[x] == dfn[x]) {
			scctot++;
			do {
				top--;
				scc[stack[top]] = scctot;
				ins[stack[top]] = false;
			} while(stack[top] != x);
		}
    }

    void AddE(int u,int v) {
		//cout<<u<<' '<<v<<endl;
		table[++etot].to = v;
		table[etot].next = head[u];
		head[u] = etot;
    }
}
using Graph::scctot;
namespace K_M {
	const int M=310;
	const int inf=0x3f3f3f3f;

	int nx,ny;
	int link[M],lx[M],ly[M],slack[M];		
	int visx[M],visy[M],w[M][M];

	int DFS(int x)
	{
		visx[x] = 1;
		for (int y = 1;y <= ny;y ++)
		{
			if (visy[y])
			continue;
			int t = lx[x] + ly[y] - w[x][y];
			if (t == 0)			 
			{
				visy[y] = 1;
				if (link[y] == -1||DFS(link[y]))
				{
					link[y] = x;
					return 1;
				}
			}
			else if (slack[y] > t)	
				slack[y] = t;
		}
		return 0;
	}
	int KM()
	{
		int i,j;
		memset (link,-1,sizeof(link));
		memset (ly,0,sizeof(ly));
		for (i = 1;i <= nx;i ++)						
		for (j = 1,lx[i] = -inf;j <= ny;j ++)
			if (w[i][j] > lx[i])
				lx[i] = w[i][j];

		for (int x = 1;x <= nx;x ++)
		{
			for (i = 1;i <= ny;i ++)
			slack[i] = inf;
			while (1)
			{
				memset (visx,0,sizeof(visx));
				memset (visy,0,sizeof(visy));
				if (DFS(x))		 
					break;	
			
			
				int d = inf;
				for (i = 1;i <= ny;i ++)
				if (!visy[i]&&d > slack[i])
					d = slack[i];
				for (i = 1;i <= nx;i ++)
				if (visx[i])
					lx[i] -= d;
				for (i = 1;i <= ny;i ++)	
				if (visy[i])
					ly[i] += d;
				else
					slack[i] -= d;
			}
		}
		int res = 0;
		for (i = 1;i <= ny;i ++)
			if (link[i] > -1)
				res += w[link[i]][i];
		return res;
	}
	void init ()
	{
		memset(w,-1,sizeof w);
	}
}

namespace newGraph {
	bool mk[310][310];
	int w1[310],totw[310];
	bitset<310> totchose[310];
	int chosew[310];
	bitset<310> chose[310];
	bool used[310];
	struct Edge {
		int to,next;
	} table[180050];
	int head[310],etot;
	void AddE(int u,int v) {
		if(mk[u][v]) return;
		table[++etot].to = v;
		table[etot].next = head[u];
		head[u] = etot;
	}
	void DFS(int x) {
		used[x] = true;
		totw[x] = w1[x];
		totchose[x][x] = 1;
		for(int h = head[x];h;h=table[h].next) {
			if(!used[table[h].to]) {
				DFS(table[h].to);
			}
			chose[x] |= chose[table[h].to];
			totchose[x] |= totchose[table[h].to];
			totw[x] += totw[table[h].to];
		}
		for(int i=1;i<=scctot;i++) {
			if(chose[x][i]) {
				chosew[x] += w1[i];
			}
		}
		if(totw[x] < chosew[x]) {
			chose[x] = totchose[x];
			chosew[x] = totw[x];
		}
	}
	void BuildGraph() {
		using Graph::scc;
		for(int i=1;i<=n;i++) {
		w1[scc[i]]+=ws[i];
			for(vector<int>::iterator it = cn[i].begin();it != cn[i].end();it++) {
				if(K_M::link[i] == i) continue;
					newGraph::AddE(scc[i],scc[K_M::link[*it]]);
			}
		}
	}
}

namespace PROG {
	void init() {
		cin>>n;
		K_M::nx = K_M::ny = n;
		for(int i=1;i<=n;i++) {
			int x,y;
			cin>>x;
			for(int j=1;j<=x;j++) {
				cin>>y;
				cn[i].push_back(y);
			}
		}
		for(int i=1;i<=n;i++) 
			cin>>ws[i];
		for(int i=1;i<=n;i++) {
			for(vector<int>::iterator it = cn[i].begin();it != cn[i].end();it++)
				K_M::w[i][*it] = ws[i]+1000050;
		}
		K_M::KM();
		for(int i=1;i<=n;i++) {
			for(vector<int>::iterator it = cn[i].begin();it != cn[i].end();it++) {
				if(K_M::link[i] == *it) continue;
				Graph::AddE(i,K_M::link[*it]);
			}
		}
		for(int i=1;i<=n;i++) {
			if(!Graph::dfn[i]) 
				Graph::Tarjan(i,0);
		}
		newGraph::BuildGraph();
		int ans = 0;
		bitset<310> sol;
		for(int i=1;i<=scctot;i++) {
			if(!newGraph::used[i]) {
				newGraph::DFS(i);
			}
			sol |= newGraph::chose[i];
		}
		for(int i=1;i<=scctot;i++) {
			if(sol[i]) {
				ans += newGraph::w1[i];
			}
		}
		//cout<<sol[0]<<' '<<sol[1]<<' '<<sol[2]<<' '<<sol[3]<<endl;
		cout<<ans<<endl;
	}
}

int main(void) {
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	K_M::init();	
	PROG::init();
	return 0;
}
