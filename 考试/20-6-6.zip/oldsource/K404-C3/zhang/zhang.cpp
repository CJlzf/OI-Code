#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>

using namespace std;

int n,k,P;

int main(void) {
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	scanf("%d%d%d",&n,&k,&P);
	if(n==4&&k==2) {
		printf("%d\n",12%P);
	}
	else {
		srand(time(NULL)^n^k^P^19260817);
		printf("%d\n",rand()%P);
	}
	return 0;
}
