#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;

typedef long long ll;

int n,K,P;
ll f[105][105][105];

ll Search(ll m,ll x,ll d) {
	if(~f[m][x][d]) {
		return f[m][x][d];
	}
	for(int a = m-1;a>=0;a-=d) {
		if(f[a][x][d-1] == -1) {
			Search(a,x,d-1);
		}
	}
} 

int main(void) {
	cin>>n>>K>>P;
	memset(f,0xff,sizeof f);
	return 0;
}
