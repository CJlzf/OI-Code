#include <iostream>
#include <cstdio>
#include <cmath>
#include <queue>
#include <stack>
#include <cstring>
#include <algorithm>
using namespace std;
typedef long long LL;
const int INF = 1e9;
const int N = 1e5 + 10;

struct Edge
{
	int f, t, d;
}es[N * 2];
struct node
{
	node *ch[2], *f;
	int v, sz, cnt, add;
	
	void maintain()
	{
		sz = ch[0] -> sz + ch[1] -> sz + cnt;
	}
	
	int cmp(int x)
	{
		return x == v ? -1 : x < v ? 0 : 1;
	}
	
	int dir()
	{
		return f -> ch[1] == this;
	}
	
	void setc(node *x, int d)
	{
		(ch[d] = x) -> f = this;
	}
	
	void pushdown();
}T[N], *null, *root;
int first[N * 2], nxt[N * 2], tot = 1;
int fa[N], in[N], out[N], deep[N], P[N], dfn;
int n, m, len, Tcnt, tmp[N];

void node:: pushdown()
{
	if(add)
	{
		if(ch[0] != null)
		{
			ch[0] -> v += add;
			ch[0] -> add += add;
		}
		if(ch[1] != null)
		{
			ch[1] -> v +=add;
			ch[1] -> add += add;
		}
		add = 0;
	}
}	

node *newnode(node *p, int x)
{
	node *k = T + (++Tcnt);
	k -> f = p;
	k -> ch[0] = k -> ch[1] = null;
	k -> sz = k -> cnt = 1;
	k -> v = x;
	k -> add = 0;
	return k;
}

void build(node *&p, int l, int r, node *f)
{
	if(l > r)
		return ;
	int mid = (l + r) >> 1;
	p = newnode(f, deep[mid]);
	build(p -> ch[0], l, mid - 1, p);
	build(p -> ch[1], mid + 1, r, p);
	p -> maintain();
}

void init()
{
	null = newnode(null, -INF);
	null -> sz = null -> cnt = 0;
	root = newnode(null, -INF);
	root -> ch[1] = newnode(root, INF);
	build(root -> ch[1] -> ch[0], 1, n, root -> ch[1]);
 	root -> ch[1] -> maintain();
	root -> maintain();
}

void rotate(node *p)
{
	p -> f -> pushdown();
	p -> pushdown();
	node *fa = p -> f;
	int d = p -> dir();
	fa -> f -> setc(p, fa -> dir());
	fa -> setc(p -> ch[d ^ 1], d);
	p -> setc(fa, d ^ 1);
	fa -> maintain();
	p -> maintain();
	if(root == fa)
		root = p;
}

void splay(node *p, node *rt = null)
{
	while(p -> f != rt)
	{
		p -> pushdown();
		if(p -> f -> f == rt)
			rotate(p);
		else
		{
			if(p -> dir() == p -> f -> dir())
				rotate(p -> f), rotate(p);
			else
				rotate(p), rotate(p);
		}
	}
	p -> maintain();
}

node *find(node *p, int k)
{
	while(p != null)
	{
		p -> pushdown();
		int l = p -> ch[0] -> sz + 1;
		int r = p -> ch[0] -> sz + p -> cnt;
		if(l <= k && k <= r)
			return p;
		if(r < k)
			k -= r, p = p -> ch[1];
		else
			p = p -> ch[0];	
	}
}

void change(int l, int r, int v)
{
	l++, r++;
	node *pre = find(root, l - 1);
	node *suf = find(root, r + 1);
	splay(pre);
	splay(suf, root);
	root -> ch[1] -> ch[0] -> v += v;
	root -> ch[1] -> ch[0] -> add += v;
}

int ask(int l, int r, int k)
{
	l++, r++;
	node *pre = find(root, l - 1);
	node *suf = find(root, r + 1);
	splay(pre);
	splay(suf, root);
	if(root -> ch[1] -> ch[0] -> sz < k)
		return -1;
	node *res = find(root -> ch[1] -> ch[0], k);
	return res -> v;
}

void dfs(int u, int d)
{
	deep[u] = d;
	in[u] = ++dfn;
	P[dfn] = u;
	for(int i = first[u]; i; i = nxt[i])
	{
		int v = es[i].t;
		if(v == fa[u])
			continue;
		fa[v] = u;
		dfs(v, d + es[i].d);
	}
	out[u] = dfn;
}

void read(int &x)
{
	x = 0;
	char c = getchar(); int f = 1;
	while(c < '0' || '9' < c) {if(c == '-') f = -1; c = getchar();}
	while('0' <= c && c <= '9') {x = x * 10 + (c - '0'); c = getchar();}
	x *= f;
}

void edge_insert(int f, int t, int d)
{
	es[++tot] = (Edge){f, t, d}; nxt[tot] = first[f]; first[f] = tot;
	es[++tot] = (Edge){t, f, d}; nxt[tot] = first[t]; first[t] = tot;
}

int main()
{
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);
	read(n), read(m), read(len);
	int f, v;
	for(int i = 2; i <= n; i++)
	{
		read(f), read(v);
		edge_insert(i, f, v);
	}
	dfs(1, 0);
	int op, x, k;
	if(m <= 1000)
	{
		while(m--)
		{
			read(op), read(x), read(k);
			if(op == 1)
			{
				if(out[x] - in[x] + 1 < k)
					cout<<-1<<'\n';
				else
				{
					int a = 0;
					for(int i = in[x]; i <= out[x]; i++)
						tmp[++a] = deep[i];
					sort(tmp + 1, tmp + 1 + a);
					printf("%d\n", tmp[k]);
				}
			}
			if(op == 2)
				for(int i = in[x]; i <= out[x]; i++)	
					deep[i] += k;
		}
	}
	else
	{
		init();
		while(m--)
		{
			read(op), read(x), read(k);
			if(op == 1)
				printf("%d\n", ask(in[x], out[x], k));
			if(op == 2)
				change(in[x], out[x], k);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
