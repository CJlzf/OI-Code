#include <iostream>
#include <cstdio>
#include <cmath>
#include <queue>
#include <stack>
#include <cstring>
#include <algorithm>
using namespace std;
typedef long long LL;
const int INF = 1e9;
const int N = 310;

int a[N][N], P[N], cnt[N], Get[N], n, ans = 0;
bool vis[N], use[N];

void dfs(int x)
{
	if(x > n)
	{
		for(int i = 1; i <= n; i++)
			use[i] = 0;
		int k = 0;
		for(int i = 1; i <= n; i++)
			if(vis[i])
				Get[++k] = i;
		for(int i = 1; i <= k; i++)
			for(int j = 1; j <= cnt[Get[i]]; j++)
				use[a[Get[i]][j]] = 1;
		int tot = 0;
		for(int i = 1; i <= n; i++)
			if(use[i])
				tot++;
		if(tot != k)
			return ;
		int tmp = 0;
		for(int i = 1; i <= k; i++)
			tmp += P[Get[i]];
		ans = min(ans, tmp);
		return ;
	}
	dfs(x + 1);
	vis[x] = 1;
	dfs(x + 1);
	vis[x] = 0;
}

int main()
{
	freopen("z.in", "r", stdin);
	freopen("z.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; i++)
	{
		scanf("%d", &cnt[i]);
		for(int j = 1; j <= cnt[i]; j++)
			scanf("%d", &a[i][j]);
	}
	bool flag = 0;
	for(int i = 1; i <= n; i++)
	{
		scanf("%d", &P[i]);
		if(P[i] >= 0)
			flag = 0;
	}
	if(n <= 20)
		dfs(1);
	else if(flag)
	{
		ans = 0;
		for(int i = 1; i <= n; i++)
			ans += P[i];
	}
	printf("%d", ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
