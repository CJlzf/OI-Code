#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
struct Map
{
    int r,next;
} line[100010];
struct node
{
    int val,siz,st,ed;
} point[100010];
int tot,cnt,n,m,len;
int head[100010],now[100010],val[100010];
inline int read()
{
    int x=0;
    char ch=getchar();
    while(ch<'0'||ch>'9')
        ch=getchar();
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x;
}
void add(int x,int y)
{
    tot++;
    line[tot].r=y;
    line[tot].next=head[x];
    head[x]=tot;
}
void dfs(int pos,int cost)
{
    point[pos].siz=1;
    cnt++;
    point[pos].st=cnt;
    val[cnt]=cost;
    for(int i=head[pos]; i; i=line[i].next)
    {
        int rx=line[i].r;
        dfs(rx,cost+point[rx].val);
        point[pos].siz+=point[rx].siz;
    }
    point[pos].ed=cnt;
}
void solve(int pos,int want)
{
    int st=point[pos].st,len=point[pos].ed-point[pos].st+1;
    memcpy(&now[1],&val[st],4*len);
    sort(&now[1],&now[len+1]);
    printf("%d\n",now[want]);
}
void change(int pos,int add)
{
    for(int i=point[pos].st; i<=point[pos].ed; i++)
        val[i]+=add;
}
int main()
{
    freopen("j.in","r",stdin);
    freopen("j.out","w",stdout);
    n=read(),m=read(),len=read();
    for(int i=2; i<=n; i++)
    {
        add(read(),i);
        point[i].val=read();
    }
    dfs(1,point[1].val);
    for(int i=1; i<=m; i++)
    {
        int id=read(),pos=read(),want=read();
        if(id==1)
        {
            if(want>point[pos].siz)
            {
                puts("-1");
                continue;
            }
            solve(pos,want);
        }
        else change(pos,want);
    }
    return 0;
}
