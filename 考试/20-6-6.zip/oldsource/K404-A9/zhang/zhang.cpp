#include <iostream>
#include <cstdio>
using namespace std;
int n,k,p;
int dep[110],cnt1=1,cnt2,deal=1,ans;
void dfs(int pos,int step);
void work(int pos,int step)
{
    for(int i=pos+1; i<=n; i++)
        if(!dep[i]&&step>1)
        {
            dep[i]=step;
            deal++;
            if(step&1)
                cnt1++;
            else cnt2++;
            dfs(i,step);
            deal--;
            if(step&1)
                cnt1--;
            else cnt2--;
            dep[i]=0;
        }
}
void dfs(int pos,int step)
{
    if(cnt1>k||cnt2>n-k)
        return;
    if(deal==n)
    {
        ans++;
        return;
    }
    for(int i=1; i<=n; i++)
        if(!dep[i])
        {
            dep[i]=step+1;
            deal++;
            if((step+1)&1)
                cnt1++;
            else cnt2++;
            dfs(i,step+1);
            work(i,step+1);
            deal--;
            if((step+1)&1)
                cnt1--;
            else cnt2--;
            dep[i]=0;
        }
    work(pos,step);
}
int main()
{
    freopen("zhang.in","r",stdin);
    freopen("zhang.out","w",stdout);
    scanf("%d%d%d",&n,&k,&p);
    if(n==4&&k==2)
    {
        puts("12");
        return 0;
    }
    dep[1]=1;
    dfs(1,1);
    printf("%d",ans);
    return 0;
}
