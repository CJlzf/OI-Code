#include <iostream>
#include <cstdio>
#include <bitset>
#define inf 1000000000
using namespace std;
int n,ans;
int val[310];
bool use[310];
bitset<21>need[21];
inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9')
    {
        if(ch=='-')
            f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9')
    {
        x=x*10+ch-'0';
        ch=getchar();
    }
    return x*f;
}
int check()
{
    int cnt=0,change=0;
    bitset<21>data;
    data.reset();
    for(int i=1; i<=n; i++)
        if(use[i])
        {
            data|=need[i];
            cnt++;
            change+=val[i];
        }
    if((int)data.count()!=cnt)
        return inf;
    else return change;
}
void dfs(int pos)
{
    if(pos==n+1)
        ans=min(ans,check());
    else
    {
        use[pos]=true;
        dfs(pos+1);
        use[pos]=false;
        dfs(pos+1);
    }
}
int main()
{
    freopen("z.in","r",stdin);
    freopen("z.out","w",stdout);
    n=read();
    for(int i=1; i<=n; i++)
    {
        int len=read();
        for(int j=1; j<=len; j++)
            need[i][read()]=true;
    }
    bool easy=true;
    for(int i=1; i<=n; i++)
    {
        val[i]=read();
        if(val[i]>0)
            easy=false;
    }
    if(easy)
    {
        int sum=0;
        for(int i=1; i<=n; i++)
            sum+=val[i];
        printf("%d",sum);
        return 0;
    }
    ans=inf;
    dfs(1);
    printf("%d",ans);
    return 0;
}
