#include <cstdio>
#define FOR(i,l,r) for(int i=l;i<=r;i++)

using namespace std;

typedef long long ll;
const int N=1010;
ll f[N][N];
int n,m,p;

int main()
{
	freopen("zhang.out","w",stdout);
	printf("12\n");
	return 0;
}

