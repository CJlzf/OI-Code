#include <cstdio>
#define FOR(i,l,r) for(int i=l;i<=r;i++)

using namespace std;

const int N=200;
int p[N],v[N];
int ans,n,x,y,tmp;
bool fl;

void check(int x,int y)
{
	if(x>=ans)return; int tot=0;
	while(y){tot+=y&1; y>>=1;}
	if(tot==tmp)ans=x;
}

void dfs(int x,int y,int f)
{
	if(x>n){check(y,f); return;}
	tmp++; dfs(x+1,y+p[x],f|v[x]); tmp--;
	dfs(x+1,y,f);
}

int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	FOR(i,1,n)
	{
		scanf("%d",&y);
		FOR(j,1,y)
		{
			scanf("%d",&x);
			v[i]|=1<<(x-1);
		}
	}
	fl=1; FOR(i,1,n){scanf("%d",p+i); if(p[i]>=0)fl=0;}
	if(fl)
	{
		FOR(i,1,n)ans+=p[i];
		printf("%d\n",ans);
		return 0;
	}
	dfs(1,0,0);
	printf("%d\n",ans);
	return 0;
}
