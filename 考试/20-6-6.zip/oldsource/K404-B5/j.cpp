#include <cstdio>
#include <cmath>
#include <algorithm>
#define FOR(i,l,r) for(int i=l;i<=r;++i)

using namespace std;

const int blo_num=110,N=400010;
struct edge{int to,next,v;}e[N];
int num,blo,n,m,opt,x,y,k,fir,cnt,maxn,ans,tmp,tt,len,pt,now;
int ll[blo_num],rr[blo_num],tag[blo_num];
int L[N],R[N],head[N],a[N],pos[N];
int h[blo_num][1000011];

int read()
{
	int x=0; char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9'){x=x*10+c-'0'; c=getchar();}
	return x;
}

void ins(int x,int y,int z)
{
	e[++cnt].to=y; e[cnt].next=head[x]; e[cnt].v=z; head[x]=cnt;
}

void dfs(int x,int dep)
{
	L[x]=++pt; a[pt]=dep;
	for(int i=head[x];i;i=e[i].next)
		dfs(e[i].to,dep+e[i].v);
	R[x]=pt;
}

void change(int p,int x,int f)
{
	for(;x<=maxn;x+=x&-x)h[p][x]+=f;
}

void update(int l,int r,int x)
{
	now++;
	FOR(i,pos[l]+1,pos[r]-1)tag[i]+=x;
	if(pos[l]==pos[r])
	{
		FOR(i,l,r)
		{
			change(pos[l],a[i],-1);
			a[i]+=x;
			change(pos[l],a[i],1);
		}
	}
	else
	{
		FOR(i,l,rr[pos[l]])
		{
			change(pos[l],a[i],-1);
			a[i]+=x;
			change(pos[l],a[i],1);
		}
		FOR(i,ll[pos[r]],r)
		{
			change(pos[r],a[i],-1);
			a[i]+=x;
			change(pos[r],a[i],1);
		}
	}
}

int find(int x,int y)
{
	if(y<=0)return 0; int ans=0; 
	for(;y;y-=y&-y)ans+=h[x][y];
	return ans;
}

int check(int l,int r,int tmp)
{
	int ans=0;
	FOR(i,pos[l]+1,pos[r]-1)ans+=find(i,tmp-tag[i]);
	if(pos[l]==pos[r])FOR(i,l,r)if(a[i]+tag[pos[l]]<=tmp)ans++;else;
	else
	{
		FOR(i,l,rr[pos[l]])if(a[i]+tag[pos[l]]<=tmp)ans++;
		FOR(i,ll[pos[r]],r)if(a[i]+tag[pos[r]]<=tmp)ans++;
	}
	return ans;
}

void query(int l,int r,int k)
{
	ans=0;
	if(r-l+1<k){printf("-1\n"); return;}
	int ll=1,rr=(now+n+1)*len,mid;
	while(ll<=rr)
	{
		mid=(ll+rr)>>1;
		if(check(l,r,mid)<k)ll=mid+1,ans=mid;else rr=mid-1;
	}
	printf("%d\n",ans);
}

int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	n=read(); m=read(); len=read(); 
	maxn=(n+m+1)*len; 
	for(fir=1;fir*2<=maxn;fir*=2);
	FOR(i,2,n)
	{
		x=read(); y=read();
		ins(x,i,y);
	}
	dfs(1,1);
	num=100; blo=n/num; if(blo*num!=n)blo++;
	num=n/blo; if(blo*num!=n)num++;
	FOR(i,1,num)
	{
		ll[i]=(i-1)*blo+1;
		rr[i]=min(n,i*blo);
	}
	FOR(i,1,n)pos[i]=(i-1)/blo+1;
	FOR(i,1,n)change(pos[i],a[i],1);
	FOR(i,1,m)
	{
		opt=read(); x=read(); k=read();
		if(opt==1)query(L[x],R[x],k);
		else update(L[x],R[x],k);
	}
	return 0;
}
