#include<bits/stdc++.h>
using namespace std;
const int N=305;
int n,t,v,g[N][N],p[N],f[N];
int main(){
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%d",&t);
		while(t--)
			scanf("%d",&v),g[i][v]=1;
	}
	for(int i=1;i<=n;++i)
		scanf("%d",p+i);
	if(*max_element(p+1,p+n+1)<=0)
		return!printf("%d\n",accumulate(p+1,p+n+1,0));
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			f[i]|=g[i][j]<<j-1;
	int s1=0;
	for(int i=0;i<1<<n;++i){
		int s2=0;
		for(int j=0;j<n;++j)
			if(i>>j&1)s2|=f[j+1];
		if(__builtin_popcount(i)==__builtin_popcount(s2)){
			int s3=0;
			for(int j=0;j<n;++j)
				if(i>>j&1)s3+=p[j+1];
			s1=min(s1,s3);
		}
	}
	printf("%d\n",s1);
}
