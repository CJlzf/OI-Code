#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<cmath>
#define maxn 100100
using namespace std;
struct edge{
	int r,nxt,w;
}e[maxn];
struct treap{
	treap *ch[2];
	int key,ran,size,cnt;
	void reset(int key){this->key=(key),ran=rand(),size=1,ch[0]=ch[1]=0;cnt=1;}
	void update(){size=cnt+(ch[0]?ch[0]->size:0)+(ch[1]?ch[1]->size:0);}
}*st[500],mem[maxn<<1],*pool[maxn<<1],**pm=pool;
int head[maxn],esz,a[maxn],mx,b[maxn],addv[500],c[maxn],dfn[maxn],tim,size[maxn],tp,n,m,l;
void addedge(int u,int v,int w){
	e[++esz].r=v;e[esz].nxt=head[u];head[u]=esz;e[esz].w=w;
}
void dfs(int u,int d=0){
	a[tim]=d,dfn[u]=tim++;
	size[u]=1,mx=max(mx,d);
	for(int t=head[u];t;t=e[t].nxt)
		dfs(e[t].r,d+e[t].w),size[u]+=size[e[t].r];
}
void rotate(treap*& o,int k){
	treap* p=o->ch[k];
	o->ch[k]=p->ch[k^1];
	p->ch[k^1]=o;
	o->update();
	p->update();
	o=p;
}
void insert(treap*& o,int key){
	if(!o){
		o=*pm++,o->reset(key);
		return ;
	}
	if(key==o->key){
		o->cnt++;
	}else if(key<o->key){
		insert(o->ch[0],key);
		if(o->ch[0]->ran>o->ran)rotate(o,0);
	} else {
		insert(o->ch[1],key);
		if(o->ch[1]->ran>o->ran)rotate(o,1);
	}
	if(o)o->update();
}
void del(treap*& o,int key){
	if(!o)return ;
	if(o->key==key){
		if(o->cnt>1){
			o->cnt--;
		}else if(!o->ch[0]&&!o->ch[1]){
			*--pm=o,o=0;
		} else if(!o->ch[0]){
			*--pm=o,o=o->ch[1];
		} else if(!o->ch[1]){
			*--pm=o,o=o->ch[0];
		} else {
			if(o->ch[0]->ran>o->ch[1]->ran)rotate(o,1),del(o->ch[0],key);
			else rotate(o,0),del(o->ch[1],key);
		}
	} else {
		if(key<o->key)del(o->ch[0],key);
		else del(o->ch[1],key);
	}
	if(o)o->update();
}
int print(treap* o,int l){
	if(!o)return 0;
	return print(o->ch[0],l)+print(o->ch[1],l)+(o->key<l);
}
int rank(treap* o,int key){
	if(!o)return 0;
	if(o->key==key)return o->ch[0]?o->ch[0]->size:0;
	else if(o->key>key){
		return rank(o->ch[0],key);
	}else {
		return rank(o->ch[1],key)+(o->ch[0]?o->ch[0]->size:0)+o->cnt;
	}
}
bool check(int l,int r,int ans,int k){
	int sum=0;
	for(int i=l;i<=r;++i){
		sum+=rank(st[i],ans-addv[i]);
		if(sum>=k)return true;
	}
	int L=0,R=tp-1;
	if(c[L]>=ans)return false;
	else if(c[R]<ans)sum+=tp;
	else {
		while(L<R){
			int mid=L+R+1>>1;
			if(c[mid]>=ans)R=mid-1;
			else L=mid;
		}
		sum+=L+1;	
	}
	if(sum>=k)return true;
	return false; 
}

int main(){
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	srand(-19260817);
	scanf("%d%d%d",&n,&m,&l);
	for(int i=0;i<=n*2;++i)pool[i]=mem+i;
	for(int i=2,u,w;i<=n;++i)scanf("%d%d",&u,&w),addedge(u,i,w);
	dfs(1);
	int blo=sqrt(n)+1;
	for(int i=0,p=0;i<n;i+=blo,p++)
		for(int j=i;j<blo+i&&j<n;++j)insert(st[p],a[j]);
	for(int i=1,op,x,y;i<=m;++i){
		scanf("%d%d%d",&op,&x,&y);
		if(op==1){
			int l=dfn[x],r=dfn[x]+size[x]-1;tp=0;
			if(r-l+1<y){
				printf("-1\n");
				continue;
			}
			if(l/blo==r/blo){
				int add=addv[l/blo];
				for(int i=l;i<=r;++i)c[tp++]=a[i]+add;
				nth_element(c,c+y-1,c+tp);
				printf("%d\n",c[y-1]);
			} else {
				int kl=l/blo,kr=r/blo;tp=0;
				for(int i=l;i<(kl+1)*blo&&i<n;++i)c[tp++]=a[i]+addv[kl];
				for(int i=r;i>=kr*blo;--i)c[tp++]=a[i]+addv[kr];
				if(kr==kl-1){
					nth_element(c,c+y-1,c+tp);
					printf("%d\n",c[y-1]);
				} else {
					kl++,kr--;
					sort(c,c+tp);
					int L=0,R=mx,ans=0;
					while(L<R){
						int mid=L+R+1>>1;
						if(check(kl,kr,mid,y))R=mid-1;
						else L=mid;
					}
					printf("%d\n",L);
				}
			}
		} else {
			mx+=y;
			int l=dfn[x],r=dfn[x]+size[x]-1;
			int kl=l/blo,kr=r/blo,tp=0;
			if(kl==kr){
				for(int i=l;i<=r;++i)del(st[kl],a[i]),insert(st[kl],a[i]+=y);
			} else {
				for(int i=l;i<(kl+1)*blo&&i<n;++i)del(st[kl],a[i]),insert(st[kl],a[i]+=y);
				for(int i=r;i>=kr*blo;--i)del(st[kr],a[i]),insert(st[kr],a[i]+=y);
				kl++,kr--;
				for(int i=kl;i<=kr;++i)addv[i]+=y;
			}
		}
	}
}
