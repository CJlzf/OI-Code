
/*{{{*/
//#pragma GCC optimize("O3")

#include <bits/stdc++.h>

#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

typedef long long ll;
typedef std::pair<int, int> pii;

std::string Name = __FILE__;
std::string iput = Name.substr(0, Name.length() - 4) + ".in";
std::string oput = Name.substr(0, Name.length() - 4) + ".out";

template <class T> inline bool chkmin(T &x, T y) { return x > y ? x = y, true : false; }
template <class T> inline bool chkmax(T &x, T y) { return x < y ? x = y, true : false; }

template <class T> inline T &read(T &x)
{
    static int f;
    static char c; 
    for (f = 1; !isdigit(c = getchar()); ) {
        if (c == '-')
            f = -1;
    }
    for (x = 0; isdigit(c); c = getchar()) {
        x = x * 10 + c - 48;
    }
    return x *= f;
}
 
template <class T> inline void write(T x, const char p = '\n')
{
    static int top;
    static int s[30];
    if (x < 0) {
        x = -x;
        putchar('-');
    }
    do s[++ top] = x % 10 + 48;
    while (x /= 10);
    while (top)
        putchar(s[top --]);
    putchar(p);
}
/*}}}*/
 
const int maxn = 1e5 + 5;
 
int n;
int m;
pii s[maxn];
int ans;

void dfs(int p, int cnt, int S, int now)
{
    if (__builtin_popcount(S) == cnt) chkmin(ans, now);
    if (p > n) return;
    dfs(p + 1, cnt + 1, (S | s[p].second), now + s[p].first);
    dfs(p + 1, cnt, S, now);
}

void exec()
{
    read(n);
    for (int i = 1, tot; i <= n; ++ i) {
        read(tot);
        for (int j = 1; j <= tot; ++ j) {
            int x;
            read(x);
            s[i].second |= (1 << x - 1);
        }
    }
    int tot = 0;
    for (int i = 1; i <= n; ++ i) {
        read(s[i].first);
        if (s[i].first < 0) tot += s[i].first;
    }
    if (n > 20) write(tot), exit(0);
    std::sort(s + 1, s + n + 1);
    dfs(1, 0, 0, 0);
    write(ans);
}

/*{{{*/
int main() 
{
    if (fopen(iput.c_str(), "r") != NULL) {
        freopen(iput.c_str(), "r", stdin);
        freopen(oput.c_str(), "w", stdout);
    }

    exec();

    fclose(stdin);
    fclose(stdout);

    return 0;
}
/*}}}*/

