
/*{{{*/
//#pragma GCC optimize("O3")

#include <bits/stdc++.h>

#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

typedef long long ll;
typedef std::pair<int, int> pii;

std::string Name = __FILE__;
std::string iput = Name.substr(0, Name.length() - 4) + ".in";
std::string oput = Name.substr(0, Name.length() - 4) + ".out";

template <class T> inline bool chkmin(T &x, T y) { return x > y ? x = y, true : false; }
template <class T> inline bool chkmax(T &x, T y) { return x < y ? x = y, true : false; }

template <class T> inline T &read(T &x)
{
    static int f;
    static char c; 
    for (f = 1; !isdigit(c = getchar()); ) {
        if (c == '-')
            f = -1;
    }
    for (x = 0; isdigit(c); c = getchar()) {
        x = x * 10 + c - 48;
    }
    return x *= f;
}

template <class T> inline void write(T x, const char p = '\n')
{
    static int top;
    static int s[30];
    if (x < 0) {
        x = -x;
        putchar('-');
    }
    do s[++ top] = x % 10 + 48;
    while (x /= 10);
    while (top)
        putchar(s[top --]);
    putchar(p);
}
/*}}}*/

const int maxn = 1e5 + 5;
const int maxv = 1e6 + 5;

int d[maxn];

int TOT_BLOCK;
int BLOCK_SIZE;

int lazy[maxn];
int belong[maxn];
int BL[maxn], BR[maxn];
unsigned short block[maxtot][maxv];

void query(int l, int r, int k)
{
}

inline void rebuild(int b)
{
    block[b].clear();
    for (int i = BL[b]; i <= BR[b]; ++ i) {
        block[b].push_back(d[i]);
    }
    std::sort(block[b].begin(), block[b].end());
}

void modify(int l, int r, int v)
{
    int L = belong[l], R = belong[r];
    if (L == R) {
        for (int i = l; i <= r; ++ i) d[i] += v;
        rebuild(L);
    } else {
        for (int i = l; i <= BR[L]; ++ i) d[i] += v;
        for (int i = BL[R]; i <= r; ++ i) d[i] += v;
        rebuild(L); rebuild(R);
        ++ L, -- R;
        for (int i = L; i <= R; ++ i) lazy[i] += v;
    }
}

std::vector<pii> E[maxn];
int dfn[maxn], end[maxn], TIME;

void dfs(int u, int dep)
{
    dfn[u] = ++ TIME;
    d[TIME] = dep;
    for (int i = 0; i < E[u].size(); ++ i)
        dfs(E[u][i].first, dep + E[u][i].second);
    end[u] = TIME;
}

int n;
int m;
int len;

void exec()
{
    read(n);
    read(m);
    read(len);
    for (int i = 1; i < n; ++ i) {
        int fa, w;
        read(fa), read(w);
        E[fa].push_back(pii(i, w));
    }

    dfs(1, 0);

    BLOCK_SIZE = std::max(n / 255 + 1, sqrt(n)); // debug
    TOT_BLOCK = n / BLOCK_SIZE + (n % BLOCK_SIZE != 0);

    memset(BL, 0x3f, sizeof BL);
    memset(BR, -1, sizeof BR);

    for (int i = 1; i <= n; ++ i) {
        belong[i] = i / BLOCK_SIZE;
        ++ block[belong[i]][d[i]];
        chkmin(BL[belong[i]], i);
        chkmax(BR[belong[i]], i);
    }

    for (int i = 1; i <= TOT_BLOCK; ++ i) {
    }

    for (int i = 1; i <= m; ++ i) {
        int opt, u, v;
        read(opt);
        read(u), read(v);
        if (opt == 1)
            query(dfn[u], end[u], v);
        else
            modify(dfn[u], end[u], v);
    }
}

/*{{{*/
int main() 
{
    if (fopen(iput.c_str(), "r") != NULL) {
        freopen(iput.c_str(), "r", stdin);
        freopen(oput.c_str(), "w", stdout);
    }

    exec();

    fclose(stdin);
    fclose(stdout);

    return 0;
}
/*}}}*/


