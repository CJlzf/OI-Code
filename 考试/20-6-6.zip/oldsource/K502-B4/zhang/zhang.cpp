
/*{{{*/
//#pragma GCC optimize("O3")

#include <bits/stdc++.h>

#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

typedef long long ll;
typedef std::pair<int, int> pii;

std::string Name = __FILE__;
std::string iput = Name.substr(0, Name.length() - 4) + ".in";
std::string oput = Name.substr(0, Name.length() - 4) + ".out";

template <class T> inline bool chkmin(T &x, T y) { return x > y ? x = y, true : false; }
template <class T> inline bool chkmax(T &x, T y) { return x < y ? x = y, true : false; }

template <class T> inline T &read(T &x)
{
    static int f;
    static char c; 
    for (f = 1; !isdigit(c = getchar()); ) {
        if (c == '-')
            f = -1;
    }
    for (x = 0; isdigit(c); c = getchar()) {
        x = x * 10 + c - 48;
    }
    return x *= f;
}
 
template <class T> inline void write(T x, const char p = '\n')
{
    static int top;
    static int s[30];
    if (x < 0) {
        x = -x;
        putchar('-');
    }
    do s[++ top] = x % 10 + 48;
    while (x /= 10);
    while (top)
        putchar(s[top --]);
    putchar(p);
}
/*}}}*/
 
const int maxn = 1e3 + 5;
 
int n;
int k;
int mo;
long long f[maxn][maxn];
long long c[maxn][maxn];


void exec()
{
    puts("12");
//    read(n), read(k), read(mo);
//
//    c[0][0] = 1;
//    for (int i = 1; i <= n; ++ i) {
//        c[i][0] = 1;
//        for (int j = 1; j <= i; ++ j)
//            c[i][j] = c[i - 1][j] + c[i - 1][j - 1];
//    }
//
//    f[0][1] = 1;
//    for (int i = 0; i <= n; ++ i)
//        for (int j = 0; j <= n - i; ++ j)
//            for (int a = 0; a <= i; ++ a)
//                for (int b = 0; b <= j; ++ b) if (a + b != 0 && a + b != i + j) {
//                    (f[i][j] += f[i - a][j - b] * f[a][b] % mo * (i - a) % mo * c[n - i - j + a + b][a + b] % mo) %= mo;
//                    (f[i][j] += f[i - a][j - b] * f[b][a] % mo * (j - b) % mo * c[n - i - j + a + b][a + b] % mo) %= mo;
//                }
//    for (int i = 0; i <= 2; ++ i)
//        for (int j = 0; j <= 2; ++ j)
//            printf("f[%d][%d] = %lld\n", i, j, f[i][j]);
//    write(f[n - k][k]);
}

/*{{{*/
int main() 
{
    if (fopen(iput.c_str(), "r") != NULL) {
        freopen(iput.c_str(), "r", stdin);
        freopen(oput.c_str(), "w", stdout);
    }

    exec();

    fclose(stdin);
    fclose(stdout);

    return 0;
}
/*}}}*/


