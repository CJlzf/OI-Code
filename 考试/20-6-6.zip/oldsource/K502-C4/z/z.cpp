#include<bits/stdc++.h>
using namespace std;
const int maxn=300+10;
bool chose[maxn],keg[maxn];
int n,ans=2e9,a[maxn],s[maxn][maxn];
void baoli(int x){
    if(x>n){
        register int i,j,val=0;
        for(i=1;i<=n;i++)
            if(chose[i]) val+=a[i];
        if(val>ans) return;
        for(i=1;i<=n;i++)
            keg[i]=false;
        for(i=1;i<=n;i++)
            if(chose[i])
                for(j=1;j<=s[i][0];j++)
                    keg[s[i][j]]=true;
        for(i=1;i<=n;i++)
            if(chose[i]!=keg[i]) return;
        ans=val;return;
    }
    chose[x]=0;
    baoli(x+1);
    chose[x]=1;
    baoli(x+1);
}
int main()
{
    freopen("z.in","r",stdin);
    freopen("z.out","w",stdout);
    cin>>n;bool flag=true;
    for(int i=1;i<=n;i++){
        scanf("%d",&s[i][0]);
        for(int j=1;j<=s[i][0];j++)
            scanf("%d",&s[i][j]);
    }
    for(int i=1;i<=n;i++){
        scanf("%d",&a[i]);
        if(a[i]>0) flag=false;
    }
    if(flag){
        ans=0;
        for(int i=1;i<=n;i++)
            ans+=a[i];
    }
    else baoli(1);
    cout<<ans;
    return 0;
}
