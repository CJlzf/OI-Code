#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define ll long long
#define ull unsigned long long
using namespace std;
const int maxn=5e5+10;
int n,k,p,mul[maxn];
int fa[maxn],dep[maxn];
vector<int> son[maxn];
inline int fan(register int x,register int y){
    register int ret=1;
    while(y){
        if(y&1) ret=(ll)ret*x%p;
        x=(ll)x*x%p;
        y>>=1;
    }
    return ret;
}
int deg[maxn];
ull hash[maxn];
tr1::unordered_map<ull,bool> f;
tr1::unordered_map<ull,int> keg[maxn];
int dfs(int u){
    register int i,v,ret=1;keg[u].clear();
    for(i=0;i<son[u].size();i++){
        v=son[u][i];
        ret=(ll)ret*dfs(v)%p;
        hash[u]+=hash[v];
        ++keg[u][hash[v]];
        ret=(ll)ret*keg[u][hash[v]]%p;
    }
    hash[u]*=2333;
    return ret;
}
int baoli(int x,int c){
    if(c>k) return 0;
    if(x==n){
        if(c!=k) return 0;
        register int i,hwq;
        for(i=1;i<=n;i++)
            deg[i]=0,son[i].clear();
        for(i=2;i<=n;i++)
            ++deg[fa[i]],son[fa[i]].push_back(i);
        for(i=1;i<=n;i++)
            if(!deg[i]) hash[i]=1;
            else hash[i]=0;
        hwq=dfs(1);
        if(f[hash[1]]) return 0;
        f[hash[1]]=true;
        return (ll)mul[x-1]*fan(hwq,p-2)%p;
    }
    register int i,ret=0;
    for(i=1;i<=x;i++){
        fa[x+1]=i;
        dep[x+1]=dep[i]+1;
        ret+=baoli(x+1,c+(dep[x+1]&1));
        if(ret>=p) ret-=p;
    }
    return ret;
}
int main()
{
    freopen("zhang.in","r",stdin);
    freopen("zhang.out","w",stdout);
    cin>>n>>k>>p;
    dep[1]=1;mul[0]=1;
    for(int i=1;i<=n;i++)
        mul[i]=(ll)mul[i-1]*i%p;
    cout<<baoli(1,1);
    return 0;
}
