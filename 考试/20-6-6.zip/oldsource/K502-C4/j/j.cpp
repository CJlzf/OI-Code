#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+10;
int n,m,len,a[maxn];
vector<int> G[maxn];
int top,siz[maxn],stk[maxn];
void build(int u){
    siz[u]=1;
    for(int i=0;i<G[u].size();i++){
        int v=G[u][i];
        a[v]+=a[u];
        build(v);
        siz[u]+=siz[v];
    }
}
void dfs(int u){
    stk[++top]=a[u];
    for(int i=0;i<G[u].size();i++){
        int v=G[u][i];
        dfs(v);
    }
}
void add(int u,int z){
    a[u]+=z;
    for(int i=0;i<G[u].size();i++){
        int v=G[u][i];
        add(v,z);
    }
}
int main()
{
    freopen("j.in","r",stdin);
    freopen("j.out","w",stdout);
    cin>>n>>m>>len;
    for(int i=2;i<=n;i++){
        int f,v;
        scanf("%d%d",&f,&v);
        G[f].push_back(i);a[i]=v;
    }
    build(1);
    while(m--){
        int o,x,k;
        scanf("%d%d%d",&o,&x,&k);
        if(o==1){
            if(siz[x]<k) puts("-1");
            else{
                top=0;dfs(x);
                nth_element(stk+1,stk+k,stk+1+top);
                printf("%d\n",stk[k]);
            }
        }
        else add(x,k);
    }
    return 0;
}
