#include <bits/stdc++.h>

#define getchar getchar_unlocked

enum {
  BSIZE = 2000,
  MAXN = 100000 + 5,
  MAXM = MAXN * 2
};

template <typename T> void read(T &x) {
  x = 0;
  int c = getchar(), k = 1;
  for (; !isdigit(c); c=getchar()) k = c == '-'? -1 : +1;
  for (;  isdigit(c); c=getchar()) x = x*10 + c - '0';
  x *= k;
}

int mtop, max;
int *mem[MAXN];

struct block *begin;
struct block {
  int l, r, add;
  int *s, *a, *p;
  block *last, *next;

  block () {
    last = next = NULL;
    s = a = p = NULL;
    l = r = add = 0;
  }
  
  void getm() {
    s = mem[--mtop], a = mem[--mtop], p = mem[--mtop];
  }

  void pushup();
  
  void pushdown() {
    if (add) {
      for (int i=0; i<r-l; ++i) s[i] += add, a[i] += add;
      add = 0;
    }
  }
  void putadd(int x) {
    add += x;
  }
  int sthanx(int x) {
    if (x-add<=s[0]) return 0;
    if (s[r-l-1]<x-add) return r-l;
    return std::lower_bound(s, s+r-l, x-add) - s;
  }
  void split(block *u, block *v, int k) {
    int i, t;
    u->getm(), v->getm();
    u->l = l, u->r = l+k;
    v->l = l+k, v->r = r;
    pushdown();
    for (t=i=0; i<r-l; ++i) if (p[i]<k) u->p[t++] = p[i];
    for (t=i=0; i<r-l; ++i) if (p[i]>=k) v->p[t++] = p[i]-k;
    for (i=0; i<k; ++i) {
      u->a[i] = a[i];
      u->s[i] = a[u->p[i]];
    }
    for (i=0; i<r-l-k; ++i) {
      v->a[i] = a[k+i];
      v->s[i] = a[k+v->p[i]];
    }
    u->last = last; u->next = v;
    v->last = u; v->next = next;
    if (this == begin) begin = u;
    else last->next = u;
    if (next) next->last = v;
    erase();
  }
  void mergenext() {
    assert(next);
    int i, t, q;
    int sz = r-l;
    int rsz = next->r - next->l;
    int nsz = sz + rsz;
    int *ns = mem[--mtop];
    int *na = mem[--mtop];
    int *np = mem[--mtop];
    pushdown();
    next->pushdown();
    for (i=t=q=0; i<nsz; ++i)
      if (t == rsz || (q != sz && next->s[t] > s[q]))
	ns[i] = s[q], np[i] = p[q], ++q;
      else
	ns[i] = next->s[t], np[i] = sz + next->p[t], ++t;
    for (i=0; i<sz; ++i) na[i] = a[i];
    for (i=0; i<rsz; ++i) na[sz+i] = next->a[i];
    erase();
    next->erase();
    s = ns, a = na, p = np;
    r = next->r;
    if (next->next) next->next->last = this;
    next = next->next;
  }
  void erase() {
    mem[mtop++] = s;
    mem[mtop++] = a;
    mem[mtop++] = p;
  }
  void printele() {
    int i;
    for (i=0; i<r-l; ++i)
      printf("%d%c", a[i], " \n"[i+1 == r-l]);
  }
  int size() {
    return r-l;
  }
};

int top;
block *st[MAXN];

void thef(int p) {
  block *it;
  for (it = begin; it; it = it->next)
    if (it->l <= p && p < it->r && p != it->l) {
      it->split(st[top ++] = new block, new block, p-it->l);
    }
}

void perfect(int l, int r) {
  thef(l), thef(r);
}

void putadd(int ql, int qr, int x) {
  perfect(ql, qr);
  for (block *it = begin; it; it = it->next)
    if (ql <= it->l && it->r <= qr)
      it->putadd(x);
}

int getkth(int ql, int qr, int x) {
    int l(0), r(max+1), mid, sum;
    block *fb(NULL), *nb(NULL), *it;
    if (qr-ql <= x) return -1;
    perfect(ql, qr);
    for (it = begin; it; it = it->next)
        if (ql <= it->l && it->r <= qr) {
            nb = it; if (!fb) fb = it;
        }
    while (l+1 < r) {
        mid = (l+r)>>1;
        sum = 0;
        for (it = fb; it != nb->next; it = it->next)
            sum += it->sthanx(mid);
        (sum > x? r : l) = mid;
    }
    return l;
}

struct cmp {
  block *it;
  cmp(block *_it): it(_it) {}
  bool operator () (int x, int y) {
    return it->a[x] < it->a[y];
  }
};

void block::pushup() {
  int i;
  assert(add == 0);
  for (i=0; i<r-l; ++i) s[i] = a[i], p[i] = i;
  std::sort(s, s+r-l);
  std::sort(p, p+r-l, cmp(this));
}

int n;
int a[MAXN];

void buildblock() {
  int i, j;
  block *it = begin = new block, *tmp;
  it->last = it->next = NULL;
  for (i=0; i<n; i+=BSIZE) {
    it->l = i;
    it->r = std::min(i+BSIZE, n);
    it->getm();
    for (j=0; j<it->r - it->l; ++j)
      it->a[j] = a[i+j];
    it->pushup();
    if (it->r != n) {
      tmp = new block;
      tmp->last = it;
      it->next = tmp;
      it = tmp;
    }
  }
}

int m, len;

struct edge {
  int u, v, w, next;
  edge() {
  }
  edge(int _u, int _v, int _w, int _next):
    u(_u), v(_v), w(_w), next(_next) {}
};

int tote;
int head[MAXN];
edge E[MAXM];

int dfc;
int dfn[MAXN];
int edfn[MAXN];

void addedge(int u, int v, int w) {
  E[tote] = edge(u, v, w, head[u]), head[u] = tote++;
}

void dfs(int u, int pa, int d) {
  int e, v;
  dfn[u] = dfc++;
  a[dfn[u]] = d;
  max = std::max(d, max);
  for (e=head[u]; ~e; e=E[e].next) {
    v = E[e].v;
    if (v != pa)
      dfs(v, u, d+E[e].w);
  }
  edfn[u] = dfc;
}

void printseq() {
  for (block *it = begin; it != NULL; it = it->next)
    it->printele();
}

void clear() {
  tote = 0;
  dfc = 0;
  memset(head, -1, sizeof head);
}

void exec() {
  block *it, *tmp;
  int i, v, opt, x, k, w;
  clear();
  read(n), read(m), read(len);
  for (i=1; i<n; ++i) {
    read(v), read(w), --v;
    addedge(v, i, w);
    addedge(i, v, w);
  }
  dfs(0, -1, 0);
  buildblock();
  while (m--) {
    read(opt), read(x), read(k), --x;
    if (opt == 1) printf("%d\n", getkth(dfn[x], edfn[x], k-1));
    else putadd(dfn[x], edfn[x], k), max += k;
    if (top >= 200) {
      for (it = begin; it; ) {
	if (it->r - it->l > BSIZE*1.2) {
	  it->split(new block, tmp = new block, BSIZE);
	  it = tmp;
	} else if (it->r - it->l < BSIZE*0.8 && it->next) {
	  it->mergenext();
	} else
	  it = it->next;
      }
      top = 0;
    }
  }
}

int main() {
  if (fopen("j.in", "r") != NULL) {
    freopen("j.in", "r", stdin);
    freopen("j.out", "w", stdout);
  }
  int i;
  for (i=0; i<3000; ++i)
    mem[mtop++] = new int [BSIZE*2];
  exec();
  return 0;
}

// (auto-judge "j" "~/Tests/2017/03-13/data/j/subtask5/" 5 512 "-O2")
