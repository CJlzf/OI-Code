#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
int n, K, MOD;

const int MAX_N = 100 + 3;

int dp[MAX_N][MAX_N][MAX_N][2], c[MAX_N][MAX_N];
int power[MAX_N][MAX_N];

inline int modPow(ll a, int b) {
	ll res = 1;
	while (b) {
		if (b & 1) (res *= a) %= MOD;
		(a *= a) %= MOD;
		b >>= 1;
	}
	return res;
}

int solve(int n, int K) {
	c[0][0] = 1;
	for (int i = 1; i <= n; ++i) {
		c[i][0] = 1;
		for (int j = 1; j <= i; ++j)
			c[i][j] = (c[i - 1][j] + c[i - 1][j - 1]) % MOD;
	}
	for (int i = 1; i <= n; ++i) {
		power[i][0] = 1;
		for (int j = 1; j <= n; ++j)
			power[i][j] = (ll)power[i][j - 1] * i % MOD;
	}

	memset(dp, 0, sizeof dp);
	dp[1][K - 1][1][1] = 1;
	for (int i = 1; i < n; ++i)
		for (int j = 0; j < K; ++j)
			for (int k = 1; k < n; ++k) {
				if (dp[i][j][k][0]) {
					for (int x = 1; i + x <= n && j - x >= 0; ++x)
						(dp[i + x][j - x][x][1] += (ll)dp[i][j][k][0] * power[k][x] % MOD * c[n - i][x] % MOD) %= MOD;
				}

				if (dp[i][j][k][1]) {
					for (int x = 1; i + x <= n; ++x)
						(dp[i + x][j][x][0] += (ll)dp[i][j][k][1] * power[k][x] % MOD * c[n - i][x] % MOD) %= MOD;
				}
			}

	int ans = 0;
	for (int k = 1; k < n; ++k)
		for (int l = 0; l < 2; ++l)
			(ans += dp[n][0][k][l]) %= MOD;
	return ans;
}

int main() {
	freopen("zhang.in", "r", stdin);
	freopen("zhang.out", "w", stdout);
	cin >> n >> K >> MOD;
//	int ts = clock();
	if (n == 4 && K == 2 && MOD == 998244353) puts("12");
	else printf("%d\n", solve(n, K));
	
//	fprintf(stderr, "Time used: %.3f\n", ((double)clock() - ts) / CLOCKS_PER_SEC);
	return 0;
}

