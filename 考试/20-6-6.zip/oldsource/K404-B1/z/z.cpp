#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
inline int readInt() {
	int n = 0, ch = getchar();
	bool flag = false;
	while (!isdigit(ch)) flag |= ch == '-', ch = getchar();
	while (isdigit(ch)) n = n * 10 + ch - '0', ch = getchar();
	return flag ? -n : n;
}

const int MAX_N = 300 + 3;
int n, a[MAX_N];
vector<int> use[MAX_N];

#define len(x) ((int)x.size())
namespace force {
	const int MAX_N = 20;
	int need[MAX_N], popCount[MAX_N];

	void solve() {
		for (int i = 0; i < n; ++i)
			for (int j = 0; j < len(use[i]); ++j)
				need[i] |= 1 << use[i][j];
		for (int i = 1; i < (1 << n); ++i) popCount[i] = popCount[i >> 1] + (i & 1);

		int ans = 0;
		for (int s = 0; s < (1 << n); ++s) {
			int all = 0, res = 0;
			for (int i = 0; i < n; ++i) if (s >> i & 1)
				all |= need[i], res += a[i];
			if (popCount[all] == popCount[s]) ans = min(ans, res);
		}

		printf("%d\n", ans);
	}
}

int main() {
	freopen("z.in", "r", stdin);
	freopen("z.out", "w", stdout);
	n = readInt();
	for (int i = 0; i < n; ++i) {
		int t = readInt();
		while (t--) use[i].push_back(readInt() - 1);
	}

	bool flag = true;
	for (int i = 0; i < n; ++i) {
		a[i] = readInt();
		if (a[i] > 0) flag = false;
	}
	
	if (flag) printf("%d\n", accumulate(a, a + n, 0));
	else force::solve();
	return 0;
}

