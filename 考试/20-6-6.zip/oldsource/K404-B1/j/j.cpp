#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
inline int readInt() {
	int n = 0, ch = getchar();
	while (!isdigit(ch)) ch = getchar();
	while (isdigit(ch)) n = n * 10 + ch - '0', ch = getchar();
	return n;
}

const int MAX_N = 100000 + 3, MAX_M = 100000 + 3;

struct Edge {
	Edge *next;
	int to, cost;
	Edge(Edge *next = NULL, int to = 0, int cost = 0) : next(next), to(to), cost(cost) {}
} pool[MAX_N], *pit = pool, *first[MAX_N];

int n, m, len, dfn[MAX_N], s[MAX_N], dep[MAX_N], dfnDep[MAX_N];

int dfs(int u) {
	static int ts = 0;
	dfn[u] = ts++, s[u] = 1;
	dfnDep[dfn[u]] = dep[u];
	for (Edge *e = first[u]; e; e = e->next)
		dep[e->to] = dep[u] + e->cost, s[u] += dfs(e->to);
	return s[u];
}

void prepare() {
	dfs(0);
}

namespace force {
	void solve() {
		while (m--) {
			int type = readInt(), u = readInt() - 1, k = readInt();
			if (type == 1) {
				if (s[u] < k) {
					puts("-1");
					continue;
				}
				static int tmp[MAX_N];
				memcpy(tmp, dfnDep + dfn[u], sizeof (int) * s[u]);
				nth_element(tmp, tmp + k - 1, tmp + s[u]);
				printf("%d\n", tmp[k - 1]);
			} else {
				for (int i = dfn[u]; i < dfn[u] + s[u]; ++i) dfnDep[i] += k;
			}
		}
	}
}

int main() {
//	int ts = clock();
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);
	n = readInt(), m = readInt(), len = readInt();
	for (int i = 1; i < n; ++i) {
		int fa = readInt() - 1, val = readInt();
		first[fa] = new Edge(first[fa], i, val);
	}

	prepare();
	force::solve();

//	fprintf(stderr, "Time used: %.3fs\n", ((double)clock() - ts) / CLOCKS_PER_SEC);
	return 0;
}

