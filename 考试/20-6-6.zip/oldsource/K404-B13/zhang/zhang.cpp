#include<cstdio>
#include<iostream>
using namespace std;
int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	puts("12");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
