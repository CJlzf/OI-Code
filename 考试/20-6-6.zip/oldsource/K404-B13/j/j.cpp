#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#define SZ 350
#define maxn 200005
using namespace std;
void read(int &a)
{
	a=0;int f=1;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		a*=10;a+=c-'0';
		c=getchar();
	}a*=f;
}
struct E{
	int to,nxt,d;
}b[maxn];
int fst[maxn],tot;
void build(int f,int t,int d)
{b[++tot]=(E){t,fst[f],d};fst[f]=tot;}
int deep[maxn];
int in[maxn],out[maxn];
int dfn[maxn],dfs_c;
void dfs(int x)
{
	dfn[++dfs_c]=deep[x];
	in[x]=dfs_c;
	for(int i=fst[x];i;i=b[i].nxt)
	{
		int v=b[i].to;
		deep[v]=deep[x]+b[i].d;
		dfs(v);
	}
	out[x]=dfs_c;
}
int add[SZ];
int root[SZ];
int bel[maxn];
int c[maxn],cnt;
int N;
struct Splay{
	int D;
	int fa[maxn];
	int ch[maxn][2];
	int sz[maxn],sum[maxn];
	int key[maxn];
	int S[maxn],top,cnt;
	bool dir(int x)
	{return x==ch[fa[x]][1];}
	void update(int x)
	{sz[x]=sz[ch[x][0]]+sz[ch[x][1]]+sum[x];}
	void rotate(int x)
	{
		bool b=dir(x);
		int y=fa[x],z=fa[y];
		int a=ch[x][!b];
		if(z) ch[z][dir(y)]=x;
		else  root[D]=x;
		fa[x]=z;ch[y][b]=a;
		fa[y]=x;ch[x][!b]=y;
		if(a!=0) fa[a]=y;
		update(y);update(x);
	}
	void splay(int x,int e)
	{
		while(fa[x]!=e)
		{
			int y=fa[x],z=fa[y];
			if(z==e) rotate(x);
			else
			{
				bool b=dir(x),c=dir(y);
				if(b^c) {rotate(x);rotate(x);}
				else	{rotate(y);rotate(x);}
			}
		}
	}
	void del(int x,int k)
	{
		if(key[x]==k)
		{
			if(sum[x]>1)
			{
				sz[x]--;
				sum[x]--;
				return ;
			}
			splay(x,0);
			if(!ch[x][0])
			{
				root[D]=ch[x][1];
				fa[ch[x][1]]=0;
				key[x]=ch[x][1]=sz[x]=sum[x]=0;
				S[++top]=x;
				return ;
			}
			if(!ch[x][1])
			{
				root[D]=ch[x][0];
				fa[ch[x][0]]=0;
				key[x]=ch[x][0]=sz[x]=sum[x]=0;
				S[++top]=x;
				return ;
			}
			int t1=ch[x][0];
			while(ch[t1][1])t1=ch[t1][1];
			splay(t1,x);
			root[D]=t1;fa[t1]=0;
			fa[ch[x][1]]=t1;
			ch[t1][1]=ch[x][1];
			update(t1);
			key[x]=ch[x][0]=ch[x][1]=sz[x]=sum[x]=0;
			S[++top]=x;
			return ;
		}
		if(key[x]<k)del(ch[x][1],k);
		else del(ch[x][0],k);
		update(x);
	}
	void insert(int x,int &k,int last)
	{
		if(k==0)
		{
			if(top) k=S[top--];
			else 	k=++cnt;
			key[k]=x;fa[k]=last;
			sz[k]=sum[k]=1;
			ch[k][0]=ch[k][1]=0;
			splay(k,0);
			return ;
		}
		if(key[k]==x)
		{
			sz[k]++;
			sum[k]++;
			return;
		}
		sz[k]++;
		if(key[k]<x)
			insert(x,ch[k][1],k);
		else insert(x,ch[k][0],k);
	}
	int num_to_rank(int x,int k)
	{
		if(!k) return 0;
		int ans=0;
		if(key[k]<x)
		{
			ans+=sz[ch[k][0]]+sum[k];
			ans+=num_to_rank(x,ch[k][1]);
			return ans;
		}
		return num_to_rank(x,ch[k][0]);
	}
}Spl;
int T=0;
int work(int x,int k)
{
	int l=0,r=2e6+1,mid;
	while(r-l>1)
	{
		mid=l+r>>1;
		int cnt=0;
		int f=bel[in[x]];
		int t=bel[out[x]];
		int p=in[x];bool b=0;
		while(p<=out[x])
		{
			if(add[f]+dfn[p]<mid) cnt++;
			p++;if(bel[p]!=f) break;
			if(cnt>=k)break;
		}
		for(int i=f+1;i<t;i++)
		{
			T++;
			Spl.D=root[i];
			cnt+=Spl.num_to_rank(mid-add[i],root[i]);
			if(cnt>=k)break;
		}
		if(t>f)
		{
			p=(t-1)*N;
			while(p<=out[x])
			{
				if(cnt>=k)break;
				if(add[t]+dfn[p]<mid) cnt++;
				p++;
			}
		}
		if(cnt>=k) r=mid;
		else l=mid;
	}
	return l;
}
void Add(int x,int d)
{
	int f=bel[in[x]];
	int t=bel[out[x]];
	int p=in[x];
	while(p<=out[x])
	{
		Spl.D=f;
		Spl.del(root[f],dfn[p]);
		dfn[p]+=d;
		Spl.insert(dfn[p],root[f],0);
		p++;if(bel[p]!=f) break;
	}
	for(int i=f+1;i<t;i++)
		add[i]+=d;
	if(t>f)
	{
		p=(t-1)*N;
		while(p<=out[x])
		{
			Spl.D=t;
			Spl.del(root[t],dfn[p]);
			dfn[p]+=d;
			Spl.insert(dfn[p],root[t],0);
			p++;
		}
	}
}
int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	int n,m,len;
	scanf("%d%d%d",&n,&m,&len);
	int x,d;
	for(int i=2;i<=n;i++)
	{
		read(x);read(d);
		build(x,i,d);
	}
	dfs(1);
	N=sqrt(n)+1;
	for(int i=1;i<=n;i++)
	{
		bel[i]=i/N+1;
		Spl.D=bel[i];
		Spl.insert(dfn[i],root[bel[i]],0);
	}
	int op,k,del=0;
	for(int i=1;i<=m;i++)
	{
		read(op);
		read(x);read(k);
		if(op==1)
		{
			if(out[x]-in[x]+1<k) puts("-1");
			else printf("%d\n",work(x,k));
		}
		else Add(x,k);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
