#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
struct med{
	int a,w;
}p[305];
bool cmp(med A,med B)
{
	return A.w<B.w;
}
bool use[305];
int ans=0;
int n,cnt;
void dfs(int x,int zt,int tot)
{
	if(tot>ans) return;
	if(x>n)
	{
		int q=0;
		for(int i=0;i<=22;i++)
			if((zt>>i)&1) q++;
		if(q==cnt)ans=min(ans,tot);
		return ;
	}
	use[x]=1;
	dfs(x+1,zt,tot);
	cnt++;
	dfs(x+1,(zt|p[x].a),tot+p[x].w);
	cnt--;
}
int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		int k,x;
		scanf("%d",&k);
		while(k--)
		{
			scanf("%d",&x);
			p[i].a|=(1<<x);
		}
	}
	bool can=1;
	int sum=0;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&p[i].w);
		if(p[i].w>0) can=0;
		sum+=p[i].w;
	}
	sort(p+1,p+n+1,cmp);
	if(can) printf("%d",sum);
	else if(n<=20)
	{
		dfs(1,0,0);
		printf("%d",ans);
	}
	else puts("0");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
