#include<iostream>
#include<cstdio>
#include<cstdlib>
int main()
{
	system("fc std.out z.out");
}
