#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>

using namespace std;
const int N=310;
int k,c,choose,n,m,ans,t,cnt;
int w[N],pill[N][N],vis[N];
int hd[N][N];
inline int F()
{
	register int aa,bb;register char ch;
	while(ch=getchar(),(ch<'0'||ch>'9')&&ch!='-');ch=='-'?aa=bb=0:(aa=ch-'0',bb=1);
	while(ch=getchar(),ch>='0'&&ch<='9')aa=(aa<<3)+(aa<<1)+ch-'0';return bb?aa:-aa;
}
inline void dfs(int x)
{
	if (x==n+1)return ;
	dfs(x+1);
	for (int i=1;i<=pill[x][0];++i)
	{
		if (!vis[pill[x][i]])vis[pill[x][i]]=1,k++,hd[x][++hd[x][0]]=pill[x][i];
	}
	choose++;cnt+=w[x];
	if (choose==k)ans=min(ans,cnt);
	dfs(x+1);
	for (int i=1;i<=hd[x][0];++i)
	vis[hd[x][i]]=0,k--;
	hd[x][0]=0;cnt-=w[x],choose--;
}
int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	n=F();
	for (int i=1;i<=n;++i)
	{
		pill[i][0]=F();
		for(int j=1;j<=pill[i][0];++j)
		pill[i][j]=F();
	}
	for (int i=1;i<=n;++i)
	w[i]=F();
	memset(hd,0,sizeof(hd));
	memset(vis,0,sizeof(vis));
	ans=0;
	if (n<=20)
	{
		dfs(1);
		printf("%d",ans);
	}
}
