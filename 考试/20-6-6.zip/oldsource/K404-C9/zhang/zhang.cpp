#include<cstdio>
#include<cstring>
#include<iostream>
#include<string>
#include<algorithm>

using namespace std;
typedef long long ll;
const int N=500050;
ll n,m,k,mod;
ll A[N];
inline ll fpow(ll a,ll p)
{
	ll ans=1;
	for (;p;p>>=1,a=a*a%mod)
	if (p&1)ans=ans*a%mod;
	return ans;
}
inline void solve()
{
	A[1]=1;
	for (ll i=2;i<=n;++i)
	A[i]=(-(mod/i)*A[mod%i]%mod+mod)%mod;
}
inline ll C(ll a,ll b)
{
	ll ans=1;
	for (ll i=1;i<=b;++i)
	ans=ans*i%mod;
	ll c=b-a;
	for (ll i=1;i<=a;++i)
	ans=ans*A[i]%mod;
	for (ll i=1;i<=c;++i)
	ans=ans*A[i]%mod;
	return ans;
}
int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	scanf("%lld%lld%lld",&n,&k,&mod);
	solve();
//	cout<<C(k-1,n-2)<<endl<<n-1<<endl<<fpow(n-k,n-k-2)<<endl<<fpow(k,n-k-1)<<endl;
	ll ans=C(k-1,n-2)*(n-1)%mod*fpow(n-k,n-k-2)%mod*fpow(k,n-k-1)%mod;
	printf("%lld",ans);
}
