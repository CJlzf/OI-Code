#include<cstdio>
#include<iostream>
#include<cstring>
#include<string>
#include<algorithm>

using namespace std;
const int N=100010;
int len,n,m,te,k,sz;
int num[N],head[N],fa[N],temp[N],size[N],dis[N];
struct edge{
	int u,v,w,next;
}e[200010];
inline int F()
{
	register int aa,bb;register char ch;
	while(ch=getchar(),(ch<'0'||ch>'9')&&ch!='-');ch=='-'?aa=bb=0:(aa=ch-'0',bb=1);
	while(ch=getchar(),ch<='9'&&ch>='0')aa=(aa<<3)+(aa<<1)+ch-'0';return bb?aa:-aa;
}
inline void add(int u,int v,int w)
{
	e[++te].u=u;
	e[te].v=v;
	e[te].w=w;
	e[te].next=head[u];
	head[u]=te;
}
inline void dfs(int x)
{
	size[x]=1;
	num[x]=++sz;
	for (int i=head[x];i;i=e[i].next)
	{
		int v=e[i].v;
		if (v==fa[x])continue;
		fa[v]=x;
		dis[v]=dis[x]+e[i].w;
		dfs(v);
		size[x]+=size[v];
	}
}

int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	int u,v,w,op;
	te=0;
	n=F(),m=F(),len=F();
	for (int i=2;i<=n;++i)
	{
		v=F(),w=F();
		add(i,v,w),add(v,i,w);
	}
	dis[1]=0;
	dfs(1);
	for (int i=1;i<=m;++i)
	{
		op=F(),u=F(),v=F();
		if (op==2)
		{
			for (int j=num[u],i=1;i<=size[u];++i,++j)
			dis[j]+=v;
		}
		else 
		{
			if (v>size[u])
			{
				printf("-1\n");
			}
			else 
			{
				for (int j=num[u],i=1;i<=size[u];++i,++j)
				temp[i]=dis[j];
				sort(temp+1,temp+size[u]+1);
				printf("%d\n",temp[v]);
			}
		}
	}
}
