#include <bits/stdc++.h>

enum {
  BSIZE = 1000,
  MAXN = 100000 + 5,
  MAXM = MAXN * 2
};

struct block *begin;

struct block {
  int l, r, add;
  int *s, *a, *p;
  block *last, *next;

  block () {
    last = next = NULL;
    s = a = p = NULL;
    l = r = add = 0;
  }
  
  void getm(int x) {
    s = new int[x];
    a = new int[x];
    p = new int[x];
  }

  void pushup();
  
  void pushdown() {
    if (add) {
      for (int i=0; i<r-l; ++i) s[i] += add, a[i] += add;
      add = 0;
    }
  }
  void putadd(int x) {
    add += x;
  }
  int sthanx(int x) {
    return std::lower_bound(s, s+r-l, x-add) - s;
  }
  void split(block *u, block *v, int k) {
    int i, t;
    u->getm(k), v->getm(r-l-k);
    u->l = l, u->r = l+k;
    v->l = l+k, v->r = r;
    pushdown();
    for (t=i=0; i<r-l; ++i) if (p[i]<k) u->p[t++] = i;
    for (t=i=0; i<r-l; ++i) if (p[i]>=k) v->p[t++] = p[i]-k;
    for (i=0; i<k; ++i) {
      u->a[i] = a[i];
      u->s[i] = a[u->p[i]];
    }
    for (i=0; i<r-l-k; ++i) {
      v->a[i] = a[k+i];
      v->s[i] = a[k+v->p[i]];
    }
    u->last = last; u->next = v;
    v->last = u; v->next = next;
    if (this == begin) begin = u;
    else last->next = u;
    if (next) next->last = v;
    erase();
  }
  void mergenext() {
    int i, t, q;
    int sz = r-l;
    int rsz = next->r - next->l;
    int nsz = sz + rsz;
    int *ns = new int [nsz];
    int *na = new int [nsz];
    int *np = new int [nsz];
    for (i=t=q=0; i<nsz; ++i)
      if (t == rsz || (q != sz && next->s[t] > s[q])) {
	ns[i] = s[q];
	np[i] = p[q];
	++ q;
      } else {
	ns[i] = next->s[t];
	np[i] = sz + next->p[t];
      }
    erase();
    next->erase();
    s = ns, a = na, p = np;
    r = next->r;
    if (next->next) next->next = this;
    next = next->next;
  }
  void erase() {
    delete s;
    delete a;
    delete p;
  }
};

void thef(int p) {
  block *it;
  for (it = begin; it; it = it->next)
    if (it->l <= p && p < it->r && p != it->l)
      it->split(new block, new block, p-it->l);
}

void perfect(int l, int r) {
  thef(l);
  thef(r);
}

void putadd(int ql, int qr, int x) {
  perfect(ql, qr);
  for (block *it = begin; it; it = it->next)
    if (ql <= it->l && it->r <= qr)
      it->putadd(x);
}

int getkth(int ql, int qr, int x) {
  int l(0), r(1e7), mid, sum;
  perfect(ql, qr);
  while (l+1 < r) {
    mid = (l+r)>>1;
    sum = 0;
    for (block *it = begin; it; it = it->next)
      if (ql <= it->l && it->r <= qr)
	sum += it->sthanx(mid);
    (sum > x? r : l) = mid;
  }
  return l;
}

struct cmp {
  block *it;
  cmp(block *_it): it(_it) {}
  bool operator () (int x, int y) {
    return it->a[x] < it->a[y];
  }
};

void block::pushup() {
  int i;
  assert(add == 0);
  for (i=0; i<r-l; ++i) s[i] = a[i], p[i] = i;
  std::sort(s, s+r-l);
  std::sort(p, p+r-l, cmp(this));
}

int n;
int a[MAXN];

void buildblock() {
  int i, j;
  block *it = begin = new block, *tmp;
  it->last = it->next = NULL;
  for (i=0; i<n; i+=BSIZE) {
    it->l = i;
    it->r = std::min(i+BSIZE, n);
    it->getm(it->r-it->l);
    for (j=0; j<it->r - it->l; ++j)
      it->a[j] = a[i+j];
    it->pushup();    
    if (it->r != n) {
      tmp = new block;
      tmp->last = it;
      it->next = tmp;
      it = tmp;
    }
  }
}

int m, len;

struct edge {
  int u, v, w, next;
  edge() {
  }
  edge(int _u, int _v, int _w, int _next):
    u(_u), v(_v), w(_w), next(_next) {}
};

int tote;
int head[MAXN];
edge E[MAXM];

int dfc;
int dfn[MAXN];
int edfn[MAXN];

void addedge(int u, int v, int w) {
  E[tote] = edge(u, v, w, head[u]), head[u] = tote++;
}

void dfs(int u, int pa, int d) {
  int e, v;
  dfn[u] = dfc++;
  a[dfn[u]] = d;
  for (e=head[u]; ~e; e=E[e].next) {
    v = E[e].v;
    if (v != pa)
      dfs(v, u, d+E[e].w);
  }
  edfn[u] = dfc;
}

void clear() {
  tote = 0;
  dfc = 0;
  memset(head, -1, sizeof head);
}

void exec() {
  int i, v, opt, x, k, w;
  clear();
  scanf("%d%d%d", &n, &m, &len);
  for (i=1; i<n; ++i) {
    scanf("%d%d", &v, &w), --v;
    addedge(v, i, w);
    addedge(i, v, w);
  }
  dfs(0, -1, 0);
  buildblock();
  while (m--) {
    scanf("%d%d%d", &opt, &x, &k), --x;
    if (opt == 1) printf("%d\n", getkth(dfn[x], edfn[x], k-1));
    else putadd(dfn[x], edfn[x], k);
    for (block *it = begin; it; it = it->next)
      if (it->next && it->r - it->l < BSIZE / 2)
	it->mergenext();
  }
}

int main() {
  if (fopen("j.in", "r") != NULL) {
    freopen("j.in", "r", stdin);
    freopen("j.out", "w", stdout);
  }
  exec();
  return 0;
}
