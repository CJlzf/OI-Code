enum {
  MAXN = 100000 + 5,
  MAXM = MAXN * 2 + 5
};

#include <bits/stdc++.h>

int a[MAXN];

void putadd(int l, int r, int x) {
  int i;
  for (i=l; i<r; ++i) a[i] += x;
}

int getkth(int l, int r, int k) {
  static int s[MAXN];
  for (int i=l; i<r; ++i) s[i] = a[i];
  std::sort(s+l, s+r);
  return k<r-l? s[l+k] : -1;
}

int n, m, len;

struct edge {
  int u, v, w, next;
  edge() {
  }
  edge(int _u, int _v, int _w, int _next):
    u(_u), v(_v), w(_w), next(_next) {}
};

int tote;
int head[MAXN];
edge E[MAXM];

int dfc;
int dfn[MAXN];
int edfn[MAXN];

void addedge(int u, int v, int w) {
  E[tote] = edge(u, v, w, head[u]), head[u] = tote++;
}

void dfs(int u, int pa, int d) {
  int e, v;
  dfn[u] = dfc++;
  a[dfn[u]] = d;
  for (e=head[u]; ~e; e=E[e].next) {
    v = E[e].v;
    if (v != pa)
      dfs(v, u, d+E[e].w);
  }
  edfn[u] = dfc;
}

void clear() {
  tote = 0;
  dfc = 0;
  memset(head, -1, sizeof head);
}

void exec() {
  int i, u, v, opt, x, k, w;
  clear();
  scanf("%d%d%d", &n, &m, &len);
  for (i=1; i<n; ++i) {
    scanf("%d%d", &v, &w), --v;
    addedge(v, i, w);
    addedge(i, v, w);
  }
  dfs(0, -1, 0);
  while (m--) {
    scanf("%d%d%d", &opt, &x, &k), --x;
    if (opt == 1) printf("%d\n", getkth(dfn[x], edfn[x], k-1));
    else putadd(dfn[x], edfn[x], k);
  }
}

int main() {
  if (fopen("j.in", "r") != NULL) {
    freopen("j.in", "r", stdin);
    freopen("bf.out", "w", stdout);
  }
  exec();
  return 0;
}
