enum {
  BSIZE = 200,
  MAXN = 100000 + 5,
  MAXM = MAXN * 2 + 5,
  MAXBSIZE = BSIZE + 5,
  TOTB = MAXN / BSIZE + 5
};

#include <bits/stdc++.h>

int a[MAXN];
int s[MAXN];

int n, m, len;

struct edge {
  int u, v, w, next;
  edge() {
  }
  edge(int _u, int _v, int _w, int _next):
    u(_u), v(_v), w(_w), next(_next) {}
};

int tote;
int head[MAXN];
edge E[MAXM];

int dfc;
int dfn[MAXN];
int edfn[MAXN];

struct block {
#define REP(i) for (i = std::max(l, ql); i < std::min(r, qr); ++ i)
  int l, r, add;

  block() {
    l = r = add = 0;
  }

  block(int _l, int _r, int _add):
    l(_l), r(_r), add(_add) {}

  void pushdown() {
    int i;
    for (i=l; i<r; ++i) a[i] += add;
    for (i=l; i<r; ++i) s[i] += add;
    add = 0;
  }

  void pushup() {
    int i;
    for (i=l; i<r; ++i) s[i] = a[i];
    std::sort(s+l, s+r);
  }
  
  void putadd(int ql, int qr, int x) {
    int i;
    if (ql <= l && r <= qr) add += x;
    else {
      pushdown();
      REP (i) a[i] += x;
      pushup();
    }
  }

  int sthanx(int ql, int qr, int x) {
    int i, res(0);
    if (ql <= l && r <= qr)
      return std::lower_bound(s+l, s+r, x-add) - (s+l);
    else {
      REP (i) res += (a[i]+add<x);
      return res;
    }
  }
};

int totb;
block b[TOTB];

void putadd(int l, int r, int x) {
  int i;
  for (i=l/BSIZE; i<(r-1)/BSIZE+1; ++i)
    b[i].putadd(l, r, x);
}

int getkth(int ql, int qr, int x) {
  int l(-1e7), r(1e7), mid, sum, i;
  int fb(ql/BSIZE), nb((qr-1)/BSIZE+1);
  if (qr-ql<=x) return -1;
  while (l+1 < r) {
    mid = l + (r-l) / 2;
    sum = 0;
    for (i=fb; i<nb; ++i) sum += b[i].sthanx(ql, qr, mid);
    (sum > x? r : l) = mid;
  }
  return l;
}

void buildblock() {
  int i;
  totb = 0;
  for (i=0; i<n; i+=BSIZE) {
    b[totb] = block(i, std::min(n, i+BSIZE), 0);
    b[totb].pushup();
    ++totb;
  }
}

void addedge(int u, int v, int w) {
  E[tote] = edge(u, v, w, head[u]), head[u] = tote++;
}

void dfs(int u, int pa, int d) {
  int e, v;
  dfn[u] = dfc++;
  a[dfn[u]] = d;
  for (e=head[u]; ~e; e=E[e].next) {
    v = E[e].v;
    if (v != pa)
      dfs(v, u, d+E[e].w);
  }
  edfn[u] = dfc;
}

void clear() {
  tote = 0;
  dfc = 0;
  memset(head, -1, sizeof head);
}

void exec() {
  int i, v, opt, x, k, w;
  clear();
  scanf("%d%d%d", &n, &m, &len);
  for (i=1; i<n; ++i) {
    scanf("%d%d", &v, &w), --v;
    addedge(v, i, w);
    addedge(i, v, w);
  }
  dfs(0, -1, 0);
  buildblock();
  while (m--) {
    scanf("%d%d%d", &opt, &x, &k), --x;
    if (opt == 1) printf("%d\n", getkth(dfn[x], edfn[x], k-1));
    else putadd(dfn[x], edfn[x], k);
  }
}

int main() {
  if (fopen("j.in", "r") != NULL) {
    freopen("j.in", "r", stdin);
    freopen("j.out", "w", stdout);
  }
  exec();
  return 0;
}
