enum {
  MAXN = 300 + 5
};

#include <bits/stdc++.h>

#define MAX

int rand(int x, int y) {
  return x + rand() % (y-x+1);
}

void exec() {
  int n;
  
#ifdef MAX
  n = rand(1, 300);
#else
  n = rand(1, 20);
#endif

  printf("%d\n", n);
  
  for (int i=0; i<n; ++i) {
    static bool vis[MAXN];
    int sum(0);
    for (int j=0; j<n; ++j)
      vis[j] = rand(1, 3) == 1, sum += vis[j];
    printf("%d ", sum);
    for (int j=0; j<n; ++j)
      if (vis[j])
	printf("%d ", j+1);
    puts("");
  }

  for (int i=0; i<n; ++i) {
    printf("%d%c", rand(-10, 10), " \n"[i+1 == n]);
  }
}

int main(int argc, char **argv) {
  int x;
  assert(argc >= 2);
  sscanf(argv[1], "%d", &x);
  srand(x);
  freopen("z.in", "w", stdout);
  exec();
  return 0;
}
