enum {
  MAXN = 300 + 5
};

#include <bits/stdc++.h>

#define SZ(x) ((int) (x).size())

typedef std::vector<int> vi;

const int oo = 0x3f3f3f3f;

template <typename T> inline bool chkmax(T &x, T y) {
  return x<y? x=y, true : false;
}

int n;
int p[MAXN];
vi s[MAXN];

namespace spj {
  void exec() {
    int i, res(0);
    for (i=0; i<n; ++i) res += p[i];
    printf("%d\n", res);
  }
}

namespace bf {
  int S[MAXN];

  void clear() {
    memset(S, 0, sizeof S);
  }

  inline int bcnt(int x) {
    return x? bcnt(x>>1)+(x&1) : 0;
  }
  
  void exec() {
    int i, j, s0, t, sum;
    int ans(oo);
    clear();
    for (i=0; i<n; ++i)
      for (j=0; j<SZ(s[i]); ++j)
	S[i] |= 1<<s[i][j];
    for (s0=0; s0<1<<n; ++s0) {
      t = sum = 0;
      for (i=0; i<n; ++i) if (s0>>i&1) t |= S[i], sum += p[i];
      if (bcnt(t) == bcnt(s0))
	ans = std::min(ans, sum);
      assert(bcnt(t) >= bcnt(s0));
    }
    printf("%d\n", ans);
  }
}

void exec() {
  int i, t, x;
  bool flag(true);
  scanf("%d", &n);
  for (i=0; i<n; ++i) {
    scanf("%d", &t);
    while (t--) scanf("%d", &x), s[i].push_back(x-1);
  }
  for (i=0; i<n; ++i) scanf("%d", p+i), flag &= p[i]<=0;  
  if (n<=20) bf::exec();
  else assert(false);
}

int main() {
  if (fopen("z.in", "r") != NULL) {
    freopen("z.in", "r", stdin);
    freopen("bf.out", "w", stdout);
  }
  exec();
  return 0;
}


