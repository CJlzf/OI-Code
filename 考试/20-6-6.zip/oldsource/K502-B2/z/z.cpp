enum {
  MAXN = 300 + 5
};

#include <bits/stdc++.h>

#define SZ(x) ((int) (x).size())

typedef std::vector<int> vi;
typedef long long i64;

const int oo = 0x3f3f3f3f;
const i64 OO = 0x3f3f3f3f3f3f3f3fll;

template <typename T> inline bool chkmax(T &x, T y) {
  return x<y? x=y, true : false;
}

template <typename T> inline bool chkmin(T &x, T y) {
  return y<x? x=y, true : false;
}

int n;
int p[MAXN];

namespace dinic {
#define int long long
  enum {
    MAXNODE = MAXN * 2,
    MAXEDGE = MAXNODE * MAXNODE * 2
  };

  struct edge {
    int u, v;
    i64 cap;
    int next;
    edge() {
    }
    edge(int _u, int _v, i64 _cap, int _next):
      u(_u), v(_v), cap(_cap), next(_next) {}
  };

  int tote;
  int head[MAXNODE];
  edge E[MAXEDGE];
  
  void addedge(int u, int v, i64 cap) {
    E[tote] = edge(u, v, cap, head[u]), head[u] = tote++;
    E[tote] = edge(v, u, 0, head[v]), head[v] = tote++;
  }

  int dis[MAXNODE];
  int cur[MAXNODE];

  i64 dfs(int u, i64 all, int T) {
    i64 flow(0), add, v;
    if (u == T || all == 0)
      return all;
    for (int &e=cur[u]; ~e; e=E[e].next) {
      v = E[e].v;
      if (dis[u]+1 == dis[v]) {
	add = dfs(v, std::min(E[e].cap, all), T);
	flow += add;
	E[e].cap -= add;
	E[e^1].cap += add;
	all -= add;
	if (all == 0)
	  break;
      }
    }
    return flow;
  }
  
  bool bfs(int S, int T) {
    static int q[MAXNODE];
    int front(0), rear(0), u, v, e;
    memset(dis, 0x3f, sizeof dis);
    dis[S] = 0;
    q[rear++] = S;
    while (front < rear) {
      u = q[front++];
      for (e=head[u]; ~e; e=E[e].next) {
	v = E[e].v;
	if (E[e].cap && chkmin(dis[v], dis[u]+1))
	  q[rear++] = v;
      }
    }
    return dis[T] < oo;
  }
  
  i64 exec(int S, int T) {
    i64 flow(0);
    while (bfs(S, T)) {
      memcpy(cur, head, sizeof cur);
      flow += dfs(S, OO, T);
    }
    return flow;
  }
  
  void clear() {
    tote = 0;
    memset(head, -1, sizeof head);
  }
#undef int
}

void clear() {
  dinic::clear();
}

void exec() {
  int i, t, x, S, T;
  i64 ans(0);
  clear();
  S = dinic::MAXNODE-1, T = S-1;  
  scanf("%d", &n);
  for (i=0; i<n; ++i) {
    scanf("%d", &t);
    while (t--) {
      scanf("%d", &x), --x;
      dinic::addedge(i, n+x, OO);
    }
  }
  for (i=0; i<n; ++i) scanf("%d", p+i);
  for (i=0; i<n; ++i) {
    dinic::addedge(S, i, oo-p[i]);
    dinic::addedge(n+i, T, oo);
    ans += oo-p[i];
  }
  ans -= dinic::exec(S, T);
  printf("%lld\n", -ans);
}

int main() {
  if (fopen("z.in", "r") != NULL) {
    freopen("z.in", "r", stdin);
    freopen("z.out", "w", stdout);
  }
  exec();
  return 0;
}
