while true
do
    ./gen.exec~ $((RANDOM<<16|RANDOM))
    ./z.exec~
    ./bf.exec~ || continue
    diff bf.out z.out || break
    echo -n "."
    ((++tot))
    if ((tot%40==0))
    then
	echo $((tot))
    fi
done
