enum {
  MAXN = 1000 + 5
};

#include <bits/stdc++.h>

typedef long long i64;

int N, K, MOD;
int dp[MAXN][MAXN];

template <typename T> inline void mod(T &x) {
  if (x >= MOD) x -= MOD;
  if (x < 0) x += MOD;
}

int fpm(int x, int exp) {
  int res(1);
  for (; exp; exp>>=1, x = (i64) x*x % MOD)
    if (exp&1)
      res = (i64) res*x % MOD;
  return res;
}

void exec() {
  int i, j, t;
  scanf("%d%d%d", &N, &K, &MOD);
  dp[1][1] = 1;
  for (i=1; i<N; ++i) {
    for (j=1; j<=i; ++j) {
      mod(dp[i+1][j+1] += (i64) dp[i][j] * (i-j) % MOD);
      mod(dp[i+1][j] += (i64) dp[i][j] * j % MOD);
    }
  }
  t = 1;
  for (i=1; i<N; ++i) t = (i64) t*i % MOD;
  dp[N][K] = (i64) dp[N][K] * fpm(t, MOD-2) % MOD;
  printf("%d\n", dp[N][K]);
}

int main() {
  if (fopen("zhang.in", "r") != NULL) {
    freopen("zhang.in", "r", stdin);
    freopen("zhang.out", "w", stdout);
  }
  exec();
  return 0;
}
