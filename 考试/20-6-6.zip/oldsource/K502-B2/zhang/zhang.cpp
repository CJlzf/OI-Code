enum {
  MAXN = 1000 + 5
};

#include <bits/stdc++.h>

typedef long long i64;

int MOD;

int fpm(int x, int exp) {
  int res(1);
  for (; exp; exp>>=1, x = (i64)x*x % MOD)
    if (exp&1)
      res = (i64) res*x % MOD;
  return res;
}

template <typename T> inline void mod(T &x) {
  if (x >= MOD) x -= MOD;
  if (x < 0) x += MOD;
}

int count;
int C[MAXN][MAXN];
int POW[MAXN][MAXN];
std::map<int, int> dp[MAXN][MAXN];

int DP(int i, int j, int k) {
  int x;
  int res(0);
  if (j>i) return 0;
  if (j == i) return i == k;
  if (i-k == 0) return i == j;
  else if (dp[i][j].count(k)) return dp[i][j][k];
    for (x=1; x<=i-k; ++x)
    mod(res += (i64) DP(i-k, i-j, x) * POW[k][x] % MOD);
  res = (i64) res * C[i][k] % MOD;
  return dp[i][j][k] = res;
}

void clear() {
}

int N, K;

void exec() {
  int i, j;
  clear();
  scanf("%d%d%d", &N, &K, &MOD);
  for (i=0; i<MAXN; ++i) {
    C[i][0] = C[i][i] = 1;
    for (j=1; j<i; ++j)
      mod(C[i][j] = C[i-1][j] + C[i-1][j-1]);
  }
  for (i=0; i<MAXN; ++i) {
    POW[i][0] = 1;
    for (j=1; j<MAXN; ++j)
      POW[i][j] = (i64) POW[i][j-1] * i % MOD;
  }
  printf("%lld\n", (i64) DP(N, K, 1) * fpm(N, MOD-2) % MOD);
}

int main() {
  if (fopen("zhang.in", "r") != NULL) {
    freopen("zhang.in", "r", stdin);
    freopen("zhang.out", "w", stdout);
  }
  exec();
  return 0;
}
