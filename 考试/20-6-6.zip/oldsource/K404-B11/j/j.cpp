#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;
const int N = 100005;
struct E{
	int to,v,next;
}e[2*N];
int node,deep[N],ti,head[N],n,m,len,delta,st[N],ed[N],bu[N],f[N];
void addedge(int from,int to,int v){
	node++;	e[node].to = to;	e[node].v = v;
	e[node].next = head[from];	head[from] = node;
}
void dfs(int now){
	st[now] = ed[now] = ++ti;
	f[ti] = now;
	if (now == 41){
		int pp = 3;
	}
	for (int i = head[now];i;i = e[i].next){
		int p = e[i].to;
		if (deep[p] || p == 1)	continue;
		deep[p] = deep[now] + e[i].v;
		dfs(p);
	}
	ed[now] = ti;
}
int main(){
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	scanf("%d%d%d",&n,&m,&len);
	for (int i = 2;i <= n;i++){
		int a,b;
		scanf("%d%d",&a,&b);
		addedge(i,a,b);	addedge(a,i,b);
	}
	dfs(1);
	for (int i = 1;i <= m;i++){
		int opt,a,b;
		scanf("%d%d%d",&opt,&a,&b);
		if (opt == 2){
			if (a == 1)	delta += b;
			else {
				for (int j = st[a];j <= ed[a];j++){
					deep[f[j]] += b;
				}
			}
		}
		else {
			int pbu = 0;
			if (b > ed[a]-st[a]+1)	{
				cout << "-1" << endl;
				continue;
			}
			for (int j = st[a];j <= ed[a];j++){
				bu[++pbu] = deep[f[j]];
			}
			sort(bu+1,bu+pbu+1);
			cout << bu[b]+delta << endl;
		}
	}
	return 0;
}
