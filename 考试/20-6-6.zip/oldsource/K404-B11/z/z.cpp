#include <cstdio>
#include <iostream>
#include <cmath>
using namespace std;
const int N = 305;
int used[N],now[N],n,val[N],tv,con[N],pc,a[N][N],ans;
bool check(){
	for (int i = 1;i <= n;i++){
		used[i] = 0;
	}
	for (int i = 1;i <= pc;i++){
		for (int j = 1;j <= a[con[i]][0];j++){
			used[a[con[i]][j]] = 1;
		}
	}
	int tot = 0;
	for (int i = 1;i <= n;i++)	if (used[i])	tot++;
	if (tot == pc)	return 1;
	return 0;
}
int cal(){
	int tot = 0;
	for (int i = 1;i <= pc;i++)
	tot += val[con[i]];
	return tot;
}
void dfs(int step){
	if (step == n+1){
		if (check())	ans = min(ans,cal());
		return;
	}
	con[++pc] = step;	dfs(step+1);
	con[pc] = 0;	pc--;	dfs(step+1);
}
int main(){
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	for (int i = 1;i <= n;i++){
		int t;
		cin >> t;
		a[i][0] = t;
		for (int j = 1;j <= t;j++){
			scanf("%d",&a[i][j]);
		}
	}
	bool mark = 0;
	int res = 0;
	for (int i = 1;i <= n;i++){
		scanf("%d",&val[i]);
		res += val[i];
		if (val[i] > 0)
		mark = 1;
	}
	if(mark == 0){
		printf("%d",res);
		return 0;
	}
	dfs(1);
	printf("%d",ans);
	return 0;
}
