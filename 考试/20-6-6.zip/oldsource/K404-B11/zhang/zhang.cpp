#include <cstdio>
#include <iostream>
using namespace std;
int main(){
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	cout << 12;
	return 0;
}
