#include<bits/stdc++.h>
#define MAXN 100005
using namespace std ;	int n, m, len ;
inline int read() {
	register int ch = getchar() ;
	while ((ch^'-')&&!isdigit(ch))	ch = getchar() ;
	register int rtn = 0, f = 1 ;
	if ( ch == '-' )	f = -1, ch = getchar() ;
	while (isdigit(ch))	rtn = rtn*10 + ch - '0', ch = getchar() ;
	return f * rtn ;
}
struct t1 {
	int to, nxt, lth; 
	t1() {}
	t1(int to, int nxt, int lth) : to(to), nxt(nxt), lth(lth) {}
}edge[MAXN] ;	int cnt_edge = 0 ;
int fst[MAXN] ;
inline void addedge(int x, int y) {
	edge[ ++cnt_edge ].to = y ;
	edge[ cnt_edge ].nxt = fst[x] ;
	edge[ cnt_edge ].lth = read() ;
	fst[x] = cnt_edge ;
}

int fth[MAXN] ;
int dis[MAXN], siz[MAXN] ;
void dfs0(int now) {
	siz[now] = 1 ;
	for ( int tmp = fst[now]; tmp; tmp = edge[tmp].nxt) {
		int aim = edge[tmp].to ;
		dis[aim] = dis[now] + edge[tmp].lth ;
		dfs0(aim) ;
		siz[now] += siz[aim] ;
	}
}

void dfs1(int now, int k) {
	dis[now] += k ;
	for (int tmp = fst[now]; tmp; tmp = edge[tmp].nxt)
		dfs1( edge[tmp].to , k ) ;
}

int rec[MAXN], cnt_rec ;
void dfs2(int now) {
	rec[ ++cnt_rec ] = dis[now] ;
	for (int tmp = fst[now]; tmp; tmp = edge[tmp].nxt)
		dfs2( edge[tmp].to ) ;
}
inline void inqry(int now, int k) {
	if ( siz[now] < k )	return void ( puts("-1") ) ;
	cnt_rec = 0 ;
	dfs2(now) ;
	sort(rec+1,rec+cnt_rec+1) ;
	printf("%d\n",rec[k]) ;
}

int main() {
	freopen("j.in","r",stdin) ;
	freopen("j.out","w",stdout) ;

	n = read(), m = read(), len = read() ;
	for (int i=1; i^n; ++i)	addedge(read(), i+1) ;
	dfs0(1) ;
	for (; m; --m) {
		int opt = read(), x = read(), y = read() ;
		if ( opt == 1 )	inqry(x,y) ;
		else dfs1(x,y) ;
	}

	return 0 ;
}
