#include<bits/stdc++.h>
#define MAXN 305
#define MAXM 1000006
using namespace std ;	int n ;
inline int read() {
	register int ch = getchar() ;
	while ( (ch^'-') && !isdigit(ch))	ch = getchar() ;
	register int rtn = 0 , f = 1 ;
	if ( ch == '-' )	f = -1, ch = getchar() ;
	while (isdigit(ch))	rtn = rtn*10 + ch - '0', ch = getchar() ;
	return f * rtn ;
}

struct t1 {
	int to, nxt ;
}edge[MAXM] ;	int cnt_edge = 0 ;
int fst[MAXN] ;
inline void addedge(int x, int y) {
	edge[ ++cnt_edge ].to = y ;
	edge[ cnt_edge ].nxt = fst[x] ;
	fst[x] = cnt_edge ;
}

int val[MAXN] ;

int main() {
	freopen("z.in","r",stdin) ;
	freopen("z.out","w",stdout) ;

	n = read() ;
	for (int i=1; i<=n; ++i) {
		int t = read() ;
		for (int j=1; j<=t; ++j)	addedge(i, n + read()) ;
	}
	long long ans = 0 ;
	for (int i=1; i<=n; ++i)
		ans += read() ;
	
	printf("%lld\n",ans) ;

	return 0 ;
}
