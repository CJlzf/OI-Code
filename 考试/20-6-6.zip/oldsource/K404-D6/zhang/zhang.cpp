#include<bits/stdc++.h>
using namespace std ;
int main() {
	freopen("zhang.out","w",stdout) ;
	puts("12") ;
}
