/*
	Problem:
	Programed By Harry��Shaun��Wang
	Forever youthful,forever weeping.
	2017.3.13
*/
#include <iostream>
#include <cstring>
#include <cstdio>
#define INF 0x7f7f7f7f
#define MAXN 305
inline int getint()
{
	int x=0,f=1;
	char c=getchar();
	while(c<'0' || c>'9')
	{
		if(c=='-') f=0;
		c=getchar();
	}
	while(c>='0' && c<='9') x=x*10+c-48,c=getchar();
	return f?x:-x;
}
using namespace std;
int n,flag;
int a[MAXN][MAXN],p[MAXN];
namespace Solve1
{
	bool use[MAXN],c[MAXN];
	int ans=0;
	void update()
	{
		memset(c,0,sizeof(c));
		int sum=0,cnt1=0,cnt2=0;
		for(int i=1; i<=n; ++i)
			if(use[i])
			{
				sum+=p[i];
				++cnt1;
				for(int j=1; j<=a[i][0]; ++j)
					if(!c[a[i][j]])
					{
						++cnt2;
						c[a[i][j]]=1;
					}
			}
		if(cnt1==cnt2) ans=min(ans,sum);
	}
	void dfs(int x)
	{
		if(x>n) update();
		else
		{
			dfs(x+1);
			use[x]=true;
			dfs(x+1);
		}
	}
	int main()
	{
		dfs(1);
		printf("%d\n",ans);
		return 0;
	}
}
namespace Solve2
{
	int main()
	{
		int ans=0;
		for(int i=1; i<=n; ++i)
			if(p[i]<0)
				ans+=p[i];
		cout<<ans;
		return 0;
	}
}
namespace Solve3
{
	int match[MAXN],vis[MAXN];
	int find(int x)
	{
		for(int i=1; i<=a[x][0]; ++i)
		{
			int y=a[x][i];
			if(!vis[y])
			{
				vis[y]=1;
				if(!match[y] || find(match[y]))
				{
					match[y]=x;
					return true;
				}
			}
		}
		return false;
	}
	int main()
	{
		for(int i=1; i<=n; ++i)
		{
			memset(vis,0,sizeof(vis));
			find(i);
		}
		
		return 0;
	}
}
int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	n=getint();
	for(int i=1; i<=n; ++i)
	{
		a[i][0]=getint();
		for(int j=1; j<=a[i][0]; ++j) a[i][j]=getint();
	}
	for(int i=1; i<=n; ++i) if((p[i]=getint())>0) flag=false;
	if(n<=20) Solve1::main();
	else 
	//if(flag) 
	Solve2::main();
	//else Solve3::main();
	return 0;
}
