/*
	Problem:j
	Programed By Harry��Shaun��Wang
	Forever youthful,forever weeping.
	2017.3.13
*/
#include <algorithm>
#include <iostream>
#include <cstdio>
#define MAXN 100005
namespace IO
{
	inline int getint()
	{
		int x=0,f=1;
		char c=getchar();
		while(c<'0' || c>'9')
		{
			if(c=='-') f=0;
			c=getchar();
		}
		while(c>='0' && c<='9') x=x*10+c-48,c=getchar();
		return f?x:-x;
	}
	char c[12];
	inline void putint(int x)
	{
		int k=0;
		if(x<0) putchar('-'),x=-x;
		do
		{
			c[++k]=x%10+48;
			x/=10;
		}
		while(x);
		while(k) putchar(c[k--]);
		putchar('\n');
	}
}
using namespace std;
using namespace IO;
struct Edge
{
	int to,w,next;
	Edge(int t=0,int w=0,int n=0):to(t),w(w),next(n) {};
};
int n,m;
int vcnt,ecnt;
int head[MAXN],in[MAXN],out[MAXN];
int a[MAXN],b[MAXN];
//Edge e[MAXN];
int to[MAXN],w[MAXN],next[MAXN];
inline void AddEdge(int u,int v,int w)
{
	//e[++ecnt]=Edge(v,w,head[u]),head[u]=ecnt;
}
/*void dfs(int x,int w)
{
	in[x]=++vcnt,a[vcnt]=w;
	for(int i=head[x]; i; i=e[i].next)
		dfs(e[i].to,w+e[i].w);
	out[x]=vcnt;
}*/
void qsort(int l,int r)
{
	int i=l,j=r,mid=b[i+j>>1];
	while(i<=j)
	{
		while(b[i]<mid) ++i;
		while(b[j]>mid) --j;
		if(i<=j) swap(b[i++],b[j--]);
	}
	if(l<j) qsort(l,j);
	if(i<r) qsort(i,r);
}
void dfs(int x,int v)
{
	in[x]=++vcnt,a[vcnt]=v;
	for(int i=head[x]; i; i=next[i])
		dfs(to[i],v+w[i]);
	out[x]=vcnt;
}
int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	n=getint(),m=getint(),getint();
	for(int i=2; i<=n; ++i)
	{
		int f=getint();
		//AddEdge(f,i,getint());
		to[++ecnt]=i,w[ecnt]=getint(),next[ecnt]=head[f],head[f]=ecnt;
		//e[++ecnt].to=i,e[ecnt].w=getint(),e[ecnt].next=head[f],head[f]=ecnt;
	}
	dfs(1,0);
	//for(int i=1; i<=n; ++i) cout<<i<<" : "<<in[i]<<" "<<out[i]<<endl;
	while(m--)
	{
		int opt=getint(),x=getint(),k=getint();
		if(opt==1)
		{
			if(out[x]-in[x]+1<k) puts("-1");
			else
			{
				for(int i=in[x]; i<=out[x]; ++i) b[i-in[x]]=a[i];
				sort(b,b+out[x]-in[x]+1);
				//qsort(0,out[x]-in[x]);
				putint(b[k-1]);
				//printf("%d\n",b[k-1]);
			}
		}
		else for(int i=in[x]; i<=out[x]; ++i) a[i]+=k;
	}
	return 0;
}
