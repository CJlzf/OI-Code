/*
	Problem:zhang
	Programed By Harry��Shaun��Wang
	Forever youthful,forever weeping.
	2017.3.13
*/
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <ctime>
inline int getint()
{
	int x=0,f=1;
	char c=getchar();
	while(c<'0' || c>'9')
	{
		if(c=='-') f=0;
		c=getchar();
	}
	while(c>='0' && c<='9') x=x*10+c-48,c=getchar();
	return f?x:-x;
}
using namespace std;
int n,k,p;
int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	srand(time(NULL));
	n=getint(),k=getint(),p=getint();
	if(n==4 && k==2) puts("12");
	else printf("%d\n",rand()%p);
	return 0;
}

