#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;

const int maxn = 305;
int n;
int w[maxn],v[maxn];
int ans;
bool flag = 0;

int check(int x) {
	int ans = 0;
	for (int i = 1; i <= x; i <<= 1) {
		if(x & i) ans++;
	}
	return ans;
}

void dfs(int pos, int sta, int pre, int id) {
	if(pos == check(sta)) {
		ans = min(ans, pre);
	}
	if(id > n) return;
	dfs(pos+1, sta|w[id], pre+v[id], id+1);
	dfs(pos, sta, pre, id+1);
}

int main() {
	freopen("z.in","r",stdin); freopen("z.out","r",stdout);
	scanf("%d", &n);
	int t, x;
	for (int i = 1; i <= n; i++) {
		scanf("%d", &t);
		for (int j = 1; j <= t; j++) {
			scanf("%d", &x);
			w[i] |= (1<<(x-1));
		}
	}
	for (int i = 1; i <= n; i++) {
		scanf("%d", &v[i]);
		if(v[i] >= 0) flag = 1;
	}
	if(flag) dfs(0, 0, 0, 1);
	else {
		for (int i = 1; i <= n; i++) {
			ans += v[i];
		}
	}
	printf("%d", ans);
	return 0;
}
/*
3
2 1 2
2 1 2
1 3
-10 20 -3
*/
