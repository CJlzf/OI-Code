#include<ext/pb_ds/tree_policy.hpp>
#include<ext/pb_ds/assoc_container.hpp>
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<queue>
#include<ctime>

using namespace std;
using namespace __gnu_pbds;
const int mxn=1e5+5;

vector<int>ch[mxn];
int l[mxn],r[mxn],p[mxn],bt;
int f[mxn],d[mxn];

__gnu_pbds::tree<int,null_type>t[400];
//int a[400],b[400],p[400][305];

void dfs(int x,int c){
	l[x]=bt;
	for(int i=0;i<ch[x].size();i++)
		dfs(ch[x][i],d[x]+c);
	p[bt]=d[x]+c;
//	p[bt/300][bt%300]=d[x]+c;
//	t[bt/300].insert(d[x]+c);
	r[x]=bt++;
}

void add(int l,int r,int k){
	/*if(l%300)for(int i=l%300;i<300;i++){
		t[l/300].erase(p[l/300][i]);
		p[l/300][i]+=k;
		t[l/300].insert(p[l/300][i]);
	}*/
	for(int i=l;i<=r;i++)p[i]+=k;
	
}
int ask(int l,int r,int k){
	for(int i=l;i<=r;i++)d[i]=p[i];
	sort(d+l,d+r+1);
	return d[l+k-1];
}
int main(){
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	int n,m,len;
	cin>>n>>m>>len;
	for(int i=2;i<=n;i++){
		scanf("%d%d",f+i,d+i);
		ch[f[i]].push_back(i);
	}
	dfs(1,0);
	while(m--){
		int o,x,k;
		scanf("%d%d%d",&o,&x,&k);
		if(o==1)cout<<ask(l[x],r[x],k)<<'\n';
		else add(l[x],r[x],k);
	}
	
	fclose(stdin);fclose(stdout);
	return 0;
}
