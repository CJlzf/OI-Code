#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;

const int maxn = 1e3+5;
int n, k, mod;
int C[maxn][maxn], f[maxn];
int dd = 1, ans;

int main() {
	freopen("zhang.in","r",stdin); freopen("zhang.out","w",stdout);
	scanf("%d%d%d", &n, &k, &mod);
	if(k == 1) return puts("1"), 0;
	if(n == 4 && k == 2) return puts("12"), 0;
	C[0][0] = 1;
	for (int i = 1; i <= n; i++) {
		C[i][0] = 1;
		for (int j = 1; j <= i; j++) {
			C[i][j] = (C[i-1][j-1] + C[i-1][j]) % mod;
		}	
	}
	f[n-1] = n-1;
	for (int i = n-2; i >= k; i--) {
		for (int j = 1; j < i; j++) {
			f[i] += (1ll*f[i+1]*C[i][j])%mod*j%mod*(i+1-j);
		}
	}
	printf("%d", f[k]);
	return 0;
}
