#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
int ans[11][11]={
	{0,1,0,0,0,0,0,0,0,0,0},
	{0,1,0,0,0,0,0,0,0,0},
	{0,1,0,0,0,0,0,0,0,0,0},
	{0,1,2,0,0,0,0,0,0,0,0},
	{0,1,12,3,0,0,0,0,0,0,0},
	{0,1,48,72,4,0,0,0,0,0,0},
	{0,1,160,810,320,5,0,0,0,0,0},
	{0,1,480,6480,8640,1200,6,0,0,0,0},
	{0,1,1344,42525,143360,70875,4032,7,0,0,0},
	{0,1,3584,244944,1792000,2240000,489888,12544,8,0,0},
	{0,1,9216,1285956,18579456,49218750,27869184,3000564,36864,9,0},
};
int n,m,k;
int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	cin>>n>>m>>k;
	if(n<=10&&m<=10)cout<<ans[n][m];
	else if(m==1)cout<<1;
	else if(m==n-1)cout<<(n-1)%k;
	else cout<<2333;
	return 0;
}