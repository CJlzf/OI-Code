#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#define N 100010
using namespace std;
inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
struct node{int to,next,len;}table[N];
int tot,head[N];
void add(int a,int b,int c){table[++tot]=(node){b,head[a],c};head[a]=tot;}
int n,m,len,f[N],dep[N];
int pos[N],w[N],cnt,siz[N],mx;
void dfs(int x)
{
	w[pos[x]=++cnt]=dep[x];
	siz[x]=1;
	mx=max(mx,dep[x]);
	for(int i=head[x];i;i=table[i].next)
	{
		dep[table[i].to]=dep[x]+table[i].len;
		dfs(table[i].to);
		siz[x]+=siz[table[i].to];
	}
}
int q[N],t;
int num[10010],ww[2010][1010];
void dfs1(int x,int tar)
{
	w[pos[x]=++cnt]=dep[x];
	dep[x]+=tar;
	for(int i=head[x];i;i=table[i].next)
	dfs1(table[i].to,tar);
}
void dfs2(int x)
{
	q[++t]=x;
	for(int i=head[x];i;i=table[i].next)dfs2(table[i].to);
}
bool cmp2(int a,int b)
{
	return dep[a]<dep[b];
}
int ss,id[N],ad[N];
int be(int x)
{
	return (x-1)/ss;
}
int ed(int x)
{
	return (be(x)+1)*ss;	
}
int fr(int x)
{
	return be(x)*ss+1;
}
bool cmp(int a,int b)
{
	return w[a]<w[b];
}
int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	scanf("%d%d%d",&n,&m,&len);
	int c;
	for(int i=2;i<=n;i++)
	{
		f[i]=read(),c=read();
		add(f[i],i,c);
	}
	dfs(1);
	if(n<=000&&m<=1000)
	{
		int opt,x,k;
		while(m--)
		{
			opt=read(),x=read(),k=read();
			t=0;
			if(opt==1)
			{
				dfs2(x);
				if(t<k)puts("-1");
				else
				{
					sort(q+1,q+t+1,cmp2);
					printf("%d\n",dep[q[k]]);
				}
			}
			else dfs1(x,k);
		}
	}
	else
	{
		ss=sqrt(n/log2(n));
		for(int i=1;i<=n;i++)id[i]=i;
		for(int i=1;i<=n;i+=ss)
		{
			int ed=min(i+ss-1,n);
			sort(id+i,id+ed+1,cmp);
			int p=i/ss;
			for(int j=1;j<=ed;j++)ww[p][j]=id[j];
		}
		int opt,x,k;
		while(m--)
		{
			opt=read(),x=read(),k=read();
			if(opt==1)
			{
				if(siz[x]<k)puts("-1");
				else{
					int a=pos[x],b=pos[x]+siz[x]-1;
					int p=be(a),q=be(b);
					int l=1,r=mx,tmp=0;
					while(l<=r)
					{
						int midd=l+r>>1;
						int num=0;
						if(p==q)
						{
							for(int i=a;i<=b;i++)
							if(ad[p]+w[i]<=midd)num++;
						}
						else
						{
							int del=midd-ad[p];
							for(int i=a;i<=ed(a);i++)
							if(w[i]<=del)num++;
							del=midd-ad[q];
							for(int i=fr(b);i<=b;i++)
							if(w[i]<=del)num++;
							for(int i=p+1;i<q;i++)
							{
								del=midd-ad[i];
								int l=1,r=ss,tmp=0;
								while(l<=r)
								{
									int mid=l+r>>1;
									if(ww[i][mid]<=del)tmp=mid,l=mid+1;
									else r=mid-1;
								}
								num+=tmp;
							}
						}
						if(num>=k)tmp=midd,r=midd-1;
						else l=midd+1;
					}
					printf("%d\n",tmp);
				}
			}
			else
			{
				int a=pos[x],b=pos[x]+siz[x]-1;
				int p=be(a),q=be(b);
				if(k>0)mx+=k;
				if(p==q)
				{
					int nd=min(n,ed(a));
					for(int i=a;i<=b;i++)w[i]+=k;
					sort(id+fr(a),id+nd+1,cmp);
					int hh=fr(a)-1;
					for(int j=1;j<=ss;j++)ww[p][j]=id[j+hh];
				}
				else{
					for(int i=p+1;i<q;i++)ad[i]+=k;
					for(int i=a;i<=ed(a);i++)w[i]+=k;
					for(int i=fr(b);i<=b;i++)w[i]+=k;
					sort(id+fr(a),id+ed(a)+1,cmp);
					sort(id+fr(b),id+min(ed(b),n)+1,cmp);
				}
			}
		}
	}
	return 0;
}