#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#define N 330
using namespace std;
struct node{int to,next;}table[N*N<<1],tb[N*N<<1];
int tot,head[N];
void add(int a,int b){table[++tot]=(node){b,head[a]};head[a]=tot;}
int tt,hd[N];
void ad(int a,int b){tb[++tt]=(node){b,hd[a]};hd[a]=tt;}
int n,pre[N],a[N][N],sm,mp[N][N],fa[N],son[N];
bool use[N];
int find(int x)
{
	for(int i=1;i<=n;i++)
	if(mp[x][i]&&!use[i])
	{
		use[i]=1;
		if(!fa[i]||find(fa[i]))
		{
			fa[i]=x;
			return 1;
		}
	}
	return 0;
}
int dfn[N],low[N],s[N],tp,cnt,num,be[N],c[N],wi[N],d[N];
int q[N],h,t,f[N];
bool ins[N];
void tarjan(int x)
{
	low[x]=dfn[x]=++cnt;
	s[++tp]=x,ins[x]=1;
	for(int i=head[x];i;i=table[i].next)
	{
		int j=table[i].to;
		if(!dfn[j])
		{
			tarjan(j);
			low[x]=min(low[x],low[j]);
		}
		else if(ins[j])low[x]=min(low[x],low[j]);
	}
	if(low[x]==dfn[x])
	{
		num++;
		while(s[tp]!=x)
		{
			ins[s[tp]]=0;
			be[s[tp]]=num;
			c[num]+=wi[s[tp]];
			tp--;
		}
		ins[s[tp]]=0;
		be[s[tp]]=num;
		c[num]+=wi[s[tp]];
		tp--;
	}
}
int line[N][N],ci[N];
int vis[N],T;
struct bit{
	int c[12];
	void insert(int x)
	{
		int a=(x-1)/30,b=x-30*a;
		c[a]|=(1<<b);
	}
	bool ins(int x)
	{
		int a=(x-1)/30,b=x-30*a;
		return (c[a]&(1<<b));
	}
	bool ok(bit d)
	{
		for(int i=0;i<10;i++)if(c[i]&d.c[i])return 0;
		return 1;
	}
}bi[N];
bit merge(bit a,bit b)
{
	for(int i=0;i<10;i++)a.c[i]|=b.c[i];
	return a;
}
int delta,ans;
void dfs(int x,int as)
{
	bi[as].insert(x);
	ci[as]+=c[x];
	for(int i=hd[x];i;i=tb[i].next)
	if(vis[tb[i].to]!=T) dfs(vis[tb[i].to],as);
}
void dfss(bit k,int now,int x)
{
	if(now<ans)ans=now;
	if(++delta>=5000000)
	{
		cout<<ans;
		exit(0);
	}
	for(int i=x+1;i<=num;i++)
	if(c[i]<0)
	{
		if(k.ok(bi[i]))
		dfss(merge(k,bi[i]),now+ci[i],i);
	}
}
int bin[25],siz[N];
int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	bool flag=1;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&pre[i]);
		for(int j=1;j<=pre[i];j++)
		{
			scanf("%d",&a[i][j]);
			if(a[i][j]>0)flag=0;
			mp[i][a[i][j]]=1;
		}
	}
	for(int i=1;i<=n;i++)scanf("%d",&wi[i]),sm+=wi[i];
	if(flag){cout<<sm;return 0;}
	ans=min(sm,0);
	if(n<=20)
	{
		bin[0]=1;
		for(int i=1;i<=n;i++)bin[i]=bin[i-1]*2;
		for(int i=1;i<=n;i++)
		for(int j=1;j<=pre[i];j++)
		siz[i]|=bin[a[i][j]-1];
		for(int i=1;i<(1<<n);i++)
		{
			int yy=0,t=0;bool flag=1;
			int c1=0,c2=0;
			for(int j=1;j<=n;j++)
			if((i&(1<<j-1)))
			{
				yy+=wi[j];
				if((t&siz[j]))flag=0;
				t|=siz[j];
				c1++;
			}
			if(yy>ans||!flag)continue;
			for(;t;t&=(t-1))c2++;	
			if(c1==c2)ans=yy;
		}
		cout<<ans;
		return 0;
	}
	for(int i=n;i;i--)
	{
		for(int j=1;j<=n;j++)use[j]=0;
		find(i);
	}
	for(int i=1;i<=n;i++)son[fa[i]]=i;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=pre[i];j++)
		if(son[a[i][j]]!=i)add(i,son[a[i][j]]);
	}
	for(int i=1;i<=n;i++)if(!dfn[i])tarjan(i);
	for(int x=1;x<=n;x++)
	for(int i=head[x];i;i=table[i].next)
	if(be[x]!=be[table[i].to])ad(be[x],be[table[i].to]);
	for(int i=1;i<=num;i++)T++,dfs(i,i);
	for(int i=1;i<=num;i++)
	if(c[i]<0)dfss(bi[i],ci[i],i);
	cout<<ans;
	return 0;
}