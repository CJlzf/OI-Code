// Copyright (C) 2017 __debug.

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; version 3

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program; If not, see <http://www.gnu.org/licenses/>.


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cctype>
#include <climits>
#include <cassert>
#include <ctime>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <functional>
#include <vector>
#include <string>

#define x first
#define y second
#define MP std::make_pair
#define SZ(x) ((int)(x).size())
#define ALL(x) (x).begin(), (x).end()
#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define IMPLIES(x, y) (!(x) || (y))
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

using std::pair;
using std::vector;
using std::string;

typedef long long LL;
typedef pair<int, int> Pii;

const int oo = 0x3f3f3f3f;

template<typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, true : false; }
template<typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, true : false; }
string procStatus()
{
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}
template<typename T> T read(T &x)
{
    int f = 1;
    char ch = getchar();
    for (; !isdigit(ch); ch = getchar())
        if (ch == '-')
            f = -1;
    for (x = 0; isdigit(ch); ch = getchar())
        x = 10 * x + ch - '0';
    return x *= f;
}
template<typename T> void write(T x)
{
    if (x == 0) {
        putchar('0');
        return;
    }
    if (x < 0) {
        putchar('-');
        x = -x;
    }
    static char s[20];
    int top = 0;
    for (; x; x /= 10)
        s[++top] = x % 10 + '0';
    while (top)
        putchar(s[top--]);
}
// EOT

const int MAXN = 305;

int N;
vector<int> G[MAXN];
int P[MAXN];

void input()
{
    read(N);
    for (int i = 1; i <= N; ++i) {
        int t;
        read(t);
        while (t--) {
            int x;
            read(x);
            G[i].push_back(x);
        }
    }
    for (int i = 1; i <= N; ++i) {
        read(P[i]);
    }
}

namespace Bipartite
{

int match[MAXN];
bool vis[MAXN];

bool augment(int u)
{
    for (int i = 0; i < SZ(G[u]); ++i) {
        int v = G[u][i];
        if (vis[v]) continue;
        vis[v] = true;
        if (!match[v] || augment(match[v])) {
            match[v] = u;
            return true;
        }
    }
    return false;
}

void getMaxMatch()
{
    for (int i = 1; i <= N; ++i) {
        memset(vis, 0, sizeof(vis));
        bool ret = augment(i);
        assert(ret);
    }
}

}

namespace DAG
{

vector<int> G[MAXN], Gr[MAXN];
int dfsclock, dfn[MAXN], low[MAXN];
int totscc, sccid[MAXN];
int st[MAXN], top;
int val[MAXN];
int indeg[MAXN];

void dfs(int u)
{
    dfn[u] = low[u] = ++dfsclock;
    st[++top] = u;
    for (int i = 0; i < SZ(G[u]); ++i) {
        int v = G[u][i];
        if (!dfn[v]) {
            dfs(v);
            chkmin(low[u], low[v]);
        } else if (!sccid[v])
            chkmin(low[u], dfn[v]);
    }
    if (low[u] == dfn[u]) {
        ++totscc;
        do {
            sccid[st[top]] = totscc;
        } while (st[top--] != u);
    }
}

void shrink()
{
    for (int i = 1; i <= N; ++i) {
        if (!dfn[i])
            dfs(i);
    }

    for (int u = 1; u <= N; ++u) {
        printf("sccid(%d)=%d\n", u, sccid[u]);
        val[sccid[u]] += P[u];
        for (int i = 0; i < SZ(G[u]); ++i) {
            int v = G[u][i];
            if (sccid[u] != sccid[v]) {
                Gr[sccid[v]].push_back(sccid[u]);
                ++indeg[sccid[u]];
            }
        }
    }
}

int DP()
{
    static int q[MAXN];
    int front = 0, rear = 0;

    for (int i = 1; i <= totscc; ++i) {
        if (!indeg[i])
            q[rear++] = i;
    }
    while (front != rear) {
        int u = q[front++];
        for (int i = 0; i < SZ(Gr[u]); ++i) {
            int v = Gr[u][i];
            val[v] += val[u];
            if (--indeg[v] == 0)
                q[rear++] = v;
        }
    }

    for (int i = 1; i <= totscc; ++i) {
        printf("val(%d)=%d\n", i, val[i]);
    }

    int ret = std::min(0, *std::min_element(val + 1, val + totscc + 1));
    return ret;
}

}

void solve()
{
    Bipartite::getMaxMatch();
    for (int i = 1; i <= N; ++i) {
        printf("%d\n", Bipartite::match[i]);
    }

    for (int u = 1; u <= N; ++u) {
        for (int i = 0; i < SZ(G[u]); ++i) {
            int v = G[u][i];
            if (Bipartite::match[v] != u) {
                DAG::G[u].push_back(Bipartite::match[v]);
                printf("%d %d\n", u, Bipartite::match[v]);
            }
        }
    }
    DAG::shrink();
    int ans = DAG::DP();

    printf("%d\n", ans);
}

int main()
{
    freopen("z.in", "r", stdin);
    freopen("z.out", "w", stdout);

    input();
    solve();

    return 0;
}

// 人生得意须尽欢，莫使金樽空对月。
//     -- 李白《将进酒》
