// Copyright (C) 2017 __debug.

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; version 3

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program; If not, see <http://www.gnu.org/licenses/>.


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cctype>
#include <climits>
#include <cassert>
#include <ctime>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <functional>
#include <vector>
#include <string>

#define x first
#define y second
#define MP std::make_pair
#define SZ(x) ((int)(x).size())
#define ALL(x) (x).begin(), (x).end()
#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define IMPLIES(x, y) (!(x) || (y))
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

using std::pair;
using std::vector;
using std::string;

typedef long long LL;
typedef pair<int, int> Pii;

const int oo = 0x3f3f3f3f;

template<typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, true : false; }
template<typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, true : false; }
string procStatus()
{
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}
template<typename T> T read(T &x)
{
    int f = 1;
    char ch = getchar();
    for (; !isdigit(ch); ch = getchar())
        if (ch == '-')
            f = -1;
    for (x = 0; isdigit(ch); ch = getchar())
        x = 10 * x + ch - '0';
    return x *= f;
}
template<typename T> void write(T x)
{
    if (x == 0) {
        putchar('0');
        return;
    }
    if (x < 0) {
        putchar('-');
        x = -x;
    }
    static char s[20];
    int top = 0;
    for (; x; x /= 10)
        s[++top] = x % 10 + '0';
    while (top)
        putchar(s[top--]);
}
// EOT

const int MAXN = 305;

inline int randint(int l, int r)
{
    // DEBUG("l=%d, r=%d\n", l, r);
    assert(l <= r);
    return rand() % (r - l + 1) + l;
}

int N;
int match[MAXN];
bool G[MAXN][MAXN];

namespace Hungary
{

int rt;
int vis[MAXN];

bool dfs(int u)
{
    for (int v = 1; v <= N; ++v) {
        if (G[u][v] && vis[v] < rt) {
            vis[v] = rt;
            if (match[v] == 0 || dfs(match[v])) {
                match[v] = u;
                return true;
            }
        }
    }
    return false;
}

int exec()
{
    int res = 0;
    memset(vis, 0, sizeof(vis));
    memset(match, 0, sizeof(match));
    for (rt = 1; rt <= N; ++rt) {
        if (dfs(rt))
            ++res;
    }
    return res;
}

}

int main()
{
    srand(time(NULL));

    freopen("z.in", "w", stdout);

    vector<int> list[MAXN];

    N = randint(2, 20);
    int ebnd = randint(2, N);
    printf("%d\n", N);
    for (;;) {
        memset(G, 0, sizeof(G));
        for (int i = 1; i <= N; ++i) {
            int cnt = randint(1, ebnd);
            list[i].clear();
            for (int j = 0; j < cnt; ++j) {
                list[i].push_back(randint(1, N));
            }
            std::sort(ALL(list[i]));
            list[i].resize(std::unique(ALL(list[i])) - list[i].begin());
            std::random_shuffle(ALL(list[i]));
            for (auto x : list[i]) {
                G[i][x] = true;
            }
        }
        if (Hungary::exec() == N)
            break;
    }

    for (int i = 1; i <= N; ++i) {
        printf("%d ", SZ(list[i]));
        for (auto x : list[i]) {
            printf("%d ", x);
        }
        puts("");
    }

    int rng = randint(1, 10);
    for (int i = 1; i <= N; ++i) {
        printf("%d ", randint(-rng, rng));
    }
    puts("");

    return 0;
}

//                  画蛇添足
//                [两汉] 刘向
// 楚有祠者，赐其舍人卮酒，舍人相谓曰：
// “数人饮之不足，一人饮之有余。请画地为蛇，先成者饮酒。”
// 一人蛇先成，引酒且饮之，乃左手持卮，右手画蛇，
// 曰：“吾能为之足。”
// 未成，一人之蛇成，夺其卮曰：“蛇固无足，子安能为之足？”
// 遂饮其酒。为蛇足者，终亡其酒。
