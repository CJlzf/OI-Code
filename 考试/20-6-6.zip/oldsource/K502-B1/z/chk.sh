while true; do
    ./gen || break
    ./z || break
    ./bf || break
    diff z.out bf.out || break
    echo -n '.'
done
