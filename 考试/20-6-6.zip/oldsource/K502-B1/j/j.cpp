// Copyright (C) 2017 __debug.

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation; version 3

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program; If not, see <http://www.gnu.org/licenses/>.


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cctype>
#include <climits>
#include <cassert>
#include <ctime>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <functional>
#include <vector>
#include <string>

#define x first
#define y second
#define MP std::make_pair
#define SZ(x) ((int)(x).size())
#define ALL(x) (x).begin(), (x).end()
#define DEBUG(...) fprintf(stderr, __VA_ARGS__)
#define IMPLIES(x, y) (!(x) || (y))
#ifdef __linux__
#define getchar getchar_unlocked
#define putchar putchar_unlocked
#endif

using std::pair;
using std::vector;
using std::string;

typedef long long LL;
typedef pair<int, int> Pii;

const int oo = 0x3f3f3f3f;

template<typename T> inline bool chkmax(T &a, T b) { return a < b ? a = b, true : false; }
template<typename T> inline bool chkmin(T &a, T b) { return b < a ? a = b, true : false; }
string procStatus()
{
    std::ifstream t("/proc/self/status");
    return string(std::istreambuf_iterator<char>(t), std::istreambuf_iterator<char>());
}
template<typename T> T read(T &x)
{
    int f = 1;
    char ch = getchar();
    for (; !isdigit(ch); ch = getchar())
        if (ch == '-')
            f = -1;
    for (x = 0; isdigit(ch); ch = getchar())
        x = 10 * x + ch - '0';
    return x *= f;
}
template<typename T> void write(T x)
{
    if (x == 0) {
        putchar('0');
        return;
    }
    if (x < 0) {
        putchar('-');
        x = -x;
    }
    static char s[20];
    int top = 0;
    for (; x; x /= 10)
        s[++top] = x % 10 + '0';
    while (top)
        putchar(s[top--]);
}
// EOT

const int MAXN = 2e5 + 5;

int N, M, L;
vector<Pii> G[MAXN];

void input()
{
    read(N); read(M); read(L);
    for (int i = 2; i <= N; ++i) {
        int f, w;
        read(f); read(w);
        G[f].push_back(MP(i, w));
    }
}

int dep[MAXN];
int dfsclock, dfnL[MAXN], dfnR[MAXN];
int seq[MAXN];

void dfs(int u)
{
    dfnL[u] = ++dfsclock;
    seq[dfsclock] = dep[u];
    for (int i = 0; i < SZ(G[u]); ++i) {
        int v = G[u][i].x, w = G[u][i].y;
        dep[v] = dep[u] + w;
        dfs(v);
    }
    dfnR[u] = dfsclock;
}

namespace BA
{

int totblk, blksz;
int A[MAXN], B[MAXN];
int blkid[MAXN];
int bnd[MAXN];
int addt[MAXN];

inline void rebuild(int p)
{
    for (int i = bnd[p - 1]; i < bnd[p]; ++i) B[i] = (A[i] += addt[p]);
    addt[p] = 0;
    std::sort(B + bnd[p - 1], B + bnd[p]);
}

void build()
{
    blksz = sqrt(N);
    memcpy(A, seq, sizeof(seq));
    bnd[0] = 1;
    for (int i = 1; i <= N; i += blksz) {
        bnd[++totblk] = std::min(N + 1, i + blksz);
        std::fill(blkid + bnd[totblk - 1], blkid + bnd[totblk], totblk);
        rebuild(totblk);
    }
}

inline void add(int l, int r, int x)
{
    int p = blkid[l], q = blkid[r];
    if (p == q) {
        for (int i = l; i <= r; ++i) A[i] += x;
        rebuild(p);
        return;
    }
    for (int i = l; i < bnd[p]; ++i) A[i] += x;
    rebuild(p++);
    for (int i = bnd[q - 1]; i <= r; ++i) A[i] += x;
    rebuild(q--);
    for (int i = p; i <= q; ++i) addt[i] += x;
}

inline int query(int l, int r, int k)
{
    int len = r - l + 1;
    if (len < k)
        return -1;
    --k;

    int p = blkid[l], q = blkid[r];
    if (p == q) {
        static int tmp[MAXN];
        for (int i = 0; i < len; ++i) {
            tmp[i] = A[l + i] + addt[p];
        }
        std::sort(tmp, tmp + len);
        return tmp[k];
    }

    int l_ = 0, r_ = 2e6 + 5;
    while (l_ + 1 < r_) {
        int mid_ = (l_ + r_) >> 1;

        int cnt = 0;
        for (int i = l; i < bnd[p]; ++i) cnt += (A[i] + addt[p] < mid_);
        for (int i = bnd[q - 1]; i <= r; ++i) cnt += (A[i] + addt[q] < mid_);
        for (int i = p + 1; i < q; ++i) {
            int *b = B + bnd[i - 1];
            int _l = 0, _r = bnd[i] - bnd[i - 1], x = mid_ - addt[i];
            if (b[_l] >= x) continue;
            if (b[_r] < x) { cnt += _r; continue; }
            while (_l + 1 < _r) {
                int _mid = (_l + _r) >> 1;
                (b[_mid] >= x ? _r : _l) = _mid;
            }
            cnt += _r;
        }

        (cnt <= k ? l_ : r_) = mid_;
    }

    return l_;
}

}

void solve()
{
    dep[1] = 0;
    dfs(1);

    BA::build();
    int alladdt = 0;

    while (M--) {
        int opt, x, k;
        read(opt); read(x); read(k);

        if (opt == 1) {
            int ans = BA::query(dfnL[x], dfnR[x], k);
            if (ans != -1) ans += alladdt;
            write(ans); putchar('\n');
        } else {
            if (x != 1)
                BA::add(dfnL[x], dfnR[x], k);
            else
                alladdt += k;
        }
    }
}

int main()
{
    freopen("j.in", "r", stdin);
    freopen("j.out", "w", stdout);

    input();
    solve();

    return 0;
}

// 去年花里逢君别，今日花开已一年。
//     -- 韦应物《寄李儋元锡》
