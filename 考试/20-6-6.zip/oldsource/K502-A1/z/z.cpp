#include<cstdio>
#include<cstring>
#include<algorithm>
#include<bitset>
using namespace std;
const int maxn=300+10;
bitset<maxn> owo[maxn];
int n;
int p[maxn];
bool used[maxn];
int ans;
inline void check()
{
    static bitset<maxn> tmp;
    for (int i=1;i<=n;i++)
        tmp[i]=0;
    int cnt=0,res=0;
    for (int i=1;i<=n;i++)
        if (used[i])
        {
            tmp|=owo[i];
            cnt++;
            res+=p[i];
        }
    if ((int)tmp.count()!=cnt) return ;
    ans=min(ans,res);
}
void dfs(int u)
{
    if (u>n) return check();
    used[u]=1;
    dfs(u+1);
    used[u]=0;
    dfs(u+1);
}
int main()
{
    if (fopen("z.in","r")!=NULL)
    {
        freopen("z.in","r",stdin);
        freopen("z.out","w",stdout);
    }
    scanf("%d",&n);
    for (int i=1,k;i<=n;i++)
    {
        scanf("%d",&k);
        for (int j=1,x;j<=k;j++)
        {
            scanf("%d",&x);
            owo[i].set(x);
        }
    }
    bool flag=1;
    for (int i=1;i<=n;i++)
    {
        scanf("%d",&p[i]);
        ans+=p[i];
        if (p[i]>0) flag=0;
    }
    if (flag)
    {
        printf("%d\n",ans);
        return 0;
    }
    ans=0;
    dfs(1);
    printf("%d\n",ans);
    return 0;
}
