#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=100000+10;
struct Edge{
    int next,v,w;
    Edge(){}
    Edge(int next,int v,int w): next(next),v(v),w(w){}
}e[maxn<<1];
int n,m;
int head[maxn],cnt;
int dfn[maxn],last[maxn],timer;
int dep[maxn];
int val[maxn];
inline void AddEdge(int u,int v,int w)
{
    e[++cnt]=Edge(head[u],v,w);
    head[u]=cnt;
    e[++cnt]=Edge(head[v],u,w);
    head[v]=cnt;
}
void dfs(int u)
{
    dfn[u]=++timer;
    for (int i=head[u];i;i=e[i].next)
    {
        int v=e[i].v;
        if (!dfn[v])
        {
            dep[v]=dep[u]+e[i].w;
            dfs(v);
        }
    }
    last[u]=timer;
}
int main()
{
    if (fopen("j.in","r")!=NULL)
    {
        freopen("j.in","r",stdin);
        freopen("j.out","w",stdout);
    }
    int len,m;
    scanf("%d%d%d",&n,&m,&len);
    for (int u=2,v,w;u<=n;u++)
    {
        scanf("%d%d",&v,&w);
        AddEdge(u,v,w);
    }
    dfs(1);
    for (int i=1;i<=n;i++)
        val[dfn[i]]=dep[i];
    for (int kase=1,op,u,v;kase<=m;kase++)
    {
        scanf("%d%d%d",&op,&u,&v);
        if (op==1)
        {
            static int st[maxn],top;
            top=0;
            for (int i=dfn[u];i<=last[u];i++)
                st[++top]=val[i];
            sort(st+1,st+top+1);
            printf("%d\n",st[v]);
        }
        else for (int i=dfn[u];i<=last[u];i++)
                 val[i]+=v;
    }
    return 0;
}
