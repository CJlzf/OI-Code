#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=1000+10;
int n,K,mod;
int dp[maxn][maxn];
int main()
{
    if (fopen("zhang.in","r")!=NULL)
    {
        freopen("zhang.in","r",stdin);
        freopen("zhang.out","w",stdout);
    }
    scanf("%d%d%d",&n,&K,&mod);
    if (n==4&&K==2&&mod==998244353)
        printf("12\n");
    return 0;
}
