#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;

int read() {
	char c=getchar();int x=0;
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9') x=x*10+c-'0',c=getchar();
	return x;
}
const int N=1e5+7;
struct edge {
	int v,next;
}e[N];
int head[N],pos[N],a[N],c[N],in[N],out[N],w[N],ad[N];
int T_cnt,n,m,k,x,len,block,op,num,kk;

void adde(int u,int v) {
	e[kk].v=v;e[kk].next=head[u];head[u]=kk++;
}

struct B {
	int l,r,cnt;
	int v[1005];
	void Sort() {
		cnt=0;v[++cnt]=1e9+7;
		for (int i=l;i<=r;i++) v[++cnt]=a[i];
		sort(v+1,v+cnt+1);
	}
	int lower(int x) {
		return upper_bound(v+1,v+cnt+1,x)-v-1;
	}
}b[1005];

void dfs(int u,int f) {
	c[u]+=c[f];
	a[in[u]=++T_cnt]=c[u];
	for (int i=head[u];~i;i=e[i].next) {
		int v=e[i].v;
		if (v==f) continue;
		dfs(v,u);
	}
	out[u]=T_cnt;
}

void pre() {
	int t;
	for (t=0;1<<t<sqrt(n);t++);
	block=sqrt(n*t);
	for (int i=1;i<=n;i++) pos[i]=(i-1)/block+1;
	num=n/block+(n%block!=0);
	for (int i=1;i<=num;i++) {
		b[i].l=b[i-1].r+1;b[i].r=min(b[i-1].r+block,n);
		b[i].Sort();
	}
}

void add(int l,int r,int x) {
	if (pos[l]==pos[r]) {
		for (int i=l;i<=r;i++) {
			a[i]+=x;
			b[pos[l]].Sort();
		}
	}else {
		for (int i=l;i<=b[pos[l]].r;i++) a[i]+=x;
		for (int i=b[pos[r]].l;i<=r;i++) a[i]+=x;
		b[pos[l]].Sort();b[pos[r]].Sort();
		for (int i=pos[l]+1;i<pos[r];i++) ad[i]+=x;
	}
}

void ask(int l,int r,int k) {
	if (r-l+1<k) {
		puts("-1");return;
	}
	if (pos[l]==pos[r]) {
		w[0]=0;
		for (int i=l;i<=r;i++) w[++w[0]]=a[i]+ad[pos[l]];
		sort(w+1,w+w[0]+1);
		printf("%d\n",w[k]);
	}else {
		w[0]=0;w[++w[0]]=1e9+7;
		for (int i=l;i<=b[pos[l]].r;i++) w[++w[0]]=a[i]+ad[pos[l]];
		for (int i=b[pos[r]].l;i<=r;i++) w[++w[0]]=a[i]+ad[pos[r]];
		sort(w+1,w+w[0]+1);
		int L=0,R=2e6;
		while (L<R) {
			int mid=(L+R) >> 1;
			int ret=0;
			for (int i=pos[l]+1;i<pos[r];i++) {
				ret+=b[i].lower(mid-ad[i]);
			}
			ret+=upper_bound(w+1,w+w[0]+1,mid)-w-1;
			if (ret>=k) R=mid;
			else L=mid+1;
		}
		printf("%d\n",R);
	}
}

int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	memset(head,-1,sizeof(head));
	n=read();m=read();len=read();
	for (int i=2;i<=n;i++) {
		x=read();c[i]=read();
		adde(x,i);
	}
	dfs(1,0);pre();
	while (m--) {
		op=read();x=read();k=read();
		if (op==1) ask(in[x],out[x],k);
		else add(in[x],out[x],k);
	}
	return 0;
}
