#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;

const int N=305;
int s[N],p[N],t[N],n,x,ans;

void solve_30() {
	for (int i=1;i<(1<<n);i++) {
		int cnt=0,st=0,ret=0,_cnt=0;
		for (int j=1;j<=n;j++) {
			if (i>>(j-1)&1) {
				cnt++;st|=s[j];ret+=p[j];
			}
		}
		for (int j=1;j<=n;j++) {
			if (st>>(j-1)&1) _cnt++;
		}
		if (cnt==_cnt) ans=min(ans,ret);
	}
	printf("%d\n",ans);
}

int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++) {
		scanf("%d",&t[i]);
		for (int j=1;j<=t[i];j++) {
			scanf("%d",&x);
			s[i]|=1<<(x-1);
		}
	}
	bool flag=false;
	for (int i=1;i<=n;i++) {
		scanf("%d",&p[i]);
		if (p[i]>0) flag=true;
	}
	if (!flag) {
		for (int i=1;i<=n;i++) ans+=p[i];
		printf("%d\n",ans);
		return 0;
	}
	if (n<=20) {
		solve_30();
		return 0;
	}
	
	return 0;
}
