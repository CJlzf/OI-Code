#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;

int n,k,p;


int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	scanf("%d%d",&n,&k,&p);
	cout << 12 << endl;
	
	return 0;
}
