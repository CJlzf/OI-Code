#define FIO "j"
#include <cstdio>
#include <cctype>
#include <algorithm>
#define N_MAX 100000
typedef bool bnt;
typedef void vnt;
struct buf
{
	operator int()
	{
		register int c = getchar(), x = 0; register bnt s = false;
		for (;!isdigit(c); c = getchar()) s = c == '-';
		for (; isdigit(c); c = getchar()) x = x * 10 - '0' + c;
		return s ? -x : x;
	}
} fio;
struct edg
{
	int v; edg * e;
} ES[N_MAX], * ER = ES, * EA[N_MAX + 1];
inline vnt edg_ins(int u, int v)
{
	*ER = (edg) {v, EA[u]}, EA[u] = ER++;
}
int l, x[N_MAX], f[N_MAX + 1], w[N_MAX + 1];
inline vnt dfs(int u, int d)
{
	x[++l] = d;
	for (edg * e = EA[u]; e; e = e->e)
		dfs(e->v, d + w[e->v]);
}
int n, m, o, u, v, k, s;
int main()
{
	freopen(FIO ".in", "r", stdin);
	freopen(FIO ".out", "w", stdout);
	n = fio, m = fio, k = fio;
	for (u = 2; u <= n; ++u)
		edg_ins(f[u] = fio, u), w[u] = fio;
	while (m--)
	{
		o = fio, u = fio, k = fio;
		switch (o)
		{
		case 1:
			s = 0;
			for (v = u; v; v = f[v])
				s += w[v];
			l = 0, dfs(u, s);
			if (l < k) puts("-1");
			else std::nth_element(x + 1, x + l + 1, x + k), printf("%d\n", x[k]);
			break;
		case 2:
			w[u] += k;
			break;
		}
	}
	return 0;
}
