#define FIO "zhang"
#include <cstdio>
#define N_MAX 100
#define lld "%lld"
typedef long long lnt;
int N, n, m, p, i, j, k, u, v;
inline lnt mod(lnt x) { return x < p ? x : x % p; }
inline lnt pow(lnt a, int k)
{
	lnt w;
	for (w = 1; k; a = mod(a * a), k >>= 1)
		if (k & 1) w = mod(w * a);
	return w;
}
lnt ans, C[N_MAX + 1][N_MAX + 1], h[N_MAX + 1], f[N_MAX + 1][N_MAX + 1][N_MAX + 1], g[N_MAX + 1][N_MAX + 1];
int main()
{
	freopen(FIO ".in", "r", stdin);
	freopen(FIO ".out", "w", stdout);
	scanf("%d %d %d", &n, &m, &p);
	for (i = 0; i <= n; ++i)
		C[i][0] = 1;
	for (i = 1; i <= n; ++i)
		for (j = 1; j <= i; ++j)
			C[i][j] = mod(C[i - 1][j - 1] + C[i - 1][j]);
	h[1] = 1;
	for (i = 2; i <= n; ++i)
		h[i] = mod((p - p / i) * h[p % i]);
	h[0] = 1;
	for (i = 1; i <= n; ++i)
		h[i] = mod(h[i - 1] * h[i]);
	f[0][0][0] = 1;
	for (i = 1; i <= n; ++i)
	{
		for (u = 1; u <= i; ++u)
			for (k = 0; k < i; ++k)
				g[i][u] = mod(g[i][u] + f[i - 1][i - u][k] * mod(h[k] * i));
		for (u = 1; u <= i; ++u)
			for (k = 1; k <= i; ++k)
				for (j = 1; j <= i; ++j)
					for (v = 1; v <= u; ++v)
						f[i][u][k] = mod(f[i][u][k] + f[i - j][u - v][k - 1] * mod(g[j][v] * C[i][j]));
	}
	for (k = 0; k < n; ++k)
		ans = mod(ans + f[n - 1][n - m][k] * h[k]);
	printf(lld "\n", ans);
	return 0;
}
