#define FIO "z"
#include <cstdio>
#include <cstring>
#include <algorithm>
#define N_MAX 300
#define V_MAX (N_MAX * 2 + 2)
#define E_MAX (N_MAX * N_MAX + N_MAX * 2)
#define lld "%lld"
typedef long long lnt;
typedef bool bnt;
typedef void vnt;
const lnt inf = 0x7F7F7F7FLL, lnf = 0x3F3F3F3F3F3F3F3FLL;
struct edg
{
	int v; lnt c; edg * e, * f;
} ES[E_MAX * 2], * ER = ES, * EA[V_MAX], * EC[V_MAX];
inline vnt edg_ins(int u, int v, lnt c)
{
	*ER = (edg) {v, c, EA[u], ER + 1}, EA[u] = ER++;
	*ER = (edg) {u, 0, EA[v], ER - 1}, EA[v] = ER++;
}
int V, dis[V_MAX], Ql, Qr, Q[V_MAX];
inline bnt bfs(int s, int t)
{
	int u, v; edg * e;
	for (u = 0; u < V; ++u)
		dis[u] = -1;
	Ql = Qr = -1, dis[Q[++Qr] = t] = 0;
	while (Ql < Qr)
		for (e = EA[u = Q[++Ql]]; e; e = e->e)
			if (e->f->c && !~dis[v = e->v])
				dis[Q[++Qr] = v] = dis[u] + 1;
	return dis[s] != -1;
}
inline lnt dfs(int u, int t, lnt c = lnf)
{
	if (u == t || c == 0) return c;
	lnt f = 0, d;
	for (edg * e = EC[u]; e && c; e = e->e)
		if (EC[u] = e, dis[u] == dis[e->v] + 1 && (d = dfs(e->v, t, std::min(c, e->c))))
			e->c -= d, e->f->c += d, c -= d, f += d;
	return f;
}
inline lnt dnc(int s, int t)
{
	lnt f = 0;
	while (bfs(s, t))
		memcpy(EC, EA, V * sizeof (edg *)), f += dfs(s, t);
	return f;
}
int n, m, i, j, p, s, t;
int main()
{
	freopen(FIO ".in", "r", stdin);
	freopen(FIO ".out", "w", stdout);
	scanf("%d", &n);
	s = 0, t = n * 2 + 1, V = t + 1;
	for (i = 1; i <= n; ++i)
	{
		scanf("%d", &m);
		while (m--)
			scanf("%d", &j), edg_ins(i, n + j, lnf);
	}
	for (i = 1; i <= n; ++i)
		scanf("%d", &p), edg_ins(s, i, inf + p), edg_ins(n + i, t, inf);
	printf(lld "\n", dnc(s, t) - n * inf);
	return 0;
}
