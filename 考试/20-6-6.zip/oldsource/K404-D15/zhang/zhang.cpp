#include<bits/stdc++.h>
using namespace std;

int main()
{
	freopen("zhang.out","w",stdout);
	cout<<12<<endl;
	return 0;
}

