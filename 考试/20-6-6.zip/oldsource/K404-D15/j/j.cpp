#include<bits/stdc++.h>
using namespace std;

int n,m,len;

namespace solve1
{
	#define maxn 31010
	typedef pair<int,int> pii;
	vector<pii> g[maxn];
	int w[maxn];
	int a[maxn];
	int fa[maxn];
	
	vector<int> tmp;
	
	void dfs(int v,int p)
	{
		fa[v]=p;
		for(int i=0;i<g[v].size();i++)
		{
			int u=g[v][i].first;
			if (u==p) continue;
			w[u]=w[v]+g[v][i].second;
			dfs(u,v);
		}
	}
	
	void dfs1(int v,int p,int k)
	{
		w[v]+=k;
		for(int i=0;i<g[v].size();i++)
		{
			int u=g[v][i].first;
			if (u==p) continue;
			dfs1(u,v,k);
		}
	}
	
	void dfs2(int v,int p)
	{
		tmp.push_back(w[v]);
		for(int i=0;i<g[v].size();i++)
		{
			int u=g[v][i].first;
			if (u==p) continue;
			dfs2(u,v);
		}
	}
	
	void Solve()
	{
		for(int i=2;i<=n;i++)
		{
			int x,y;
			scanf("%d%d",&x,&y);
			g[i].push_back(make_pair(x,y));
			g[x].push_back(make_pair(i,y));
		}
		dfs(1,0);
		while (m--)
		{
			int op,x,k;
			scanf("%d%d%d",&op,&x,&k);
			if (op==2)
			{
				dfs1(x,fa[x],k);
			}
			else
			{
				tmp.clear();
				dfs2(x,fa[x]);
				if (tmp.size()<k) puts("-1");
				else
				{
					sort(tmp.begin(),tmp.end());
					printf("%d\n",tmp[k-1]);
				}
			}
		}
	}
	#undef maxn
}

int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	scanf("%d%d%d",&n,&m,&len);
	solve1::Solve();
	return 0;
}

