#include<bits/stdc++.h>
using namespace std;

#define maxn 666
typedef long long ll;
ll inf=1000000000000000ll;

struct edge
{
	int to;
	ll cap;
	int rev;
	edge(int to=0,ll cap=0,int rev=0):to(to),cap(cap),rev(rev){}
};

vector<edge> g[maxn];
int level[maxn],iter[maxn];
int S,T,n;

void add_edge(int from,int to,ll cap)
{
//	cerr<<from<<' '<<to<<' '<<cap<<endl;
	g[from].push_back(edge(to,cap,g[to].size()));
	g[to].push_back(edge(from,0,g[from].size()-1));
}

bool bfs()
{
	memset(level,-1,sizeof(level));
	level[S]=0;
	queue<int> q;
	q.push(S);
	while (!q.empty())
	{
		int v=q.front();q.pop();
		for(int i=0;i<g[v].size();i++)
		{
			edge &e=g[v][i];
			if (e.cap && level[e.to]==-1)
			{
				level[e.to]=level[v]+1;
				q.push(e.to);
			}
		}
	}
	return level[T]!=-1;
}

ll dfs(int v,ll f)
{
	if (v==T) return f;
	for(int &i=iter[v];i<g[v].size();i++)
	{
		edge &e=g[v][i];
		if (e.cap && level[e.to]>level[v])
		{
			ll d=dfs(e.to,min(f,e.cap));
			if (d>0)
			{
				e.cap-=d;
				g[e.to][e.rev].cap+=d;
				return d;
			}
		}
	}
	return 0;
}

ll max_flow()
{
	ll ans=0,f;
	while (bfs())
	{
		memset(iter,0,sizeof(iter));
		while (true)
		{
			f=dfs(S,inf);
			if (f<=0) break;
			ans+=f;
		}
	}
	return ans;
}

int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	
	ios::sync_with_stdio(false);
	cin>>n;
	S=n+n+1;T=S+1;
	for(int i=1;i<=n;i++)
	{
		int x,y;
		cin>>x;
		while (x--)
		{
			cin>>y;
			add_edge(i,n+y,inf);
		}
	}
	ll p=10000000;
	ll tot=0;
	for(int i=1;i<=n;i++)
	{
		int x;
		cin>>x;
//		cerr<<x<<endl;
		tot+=x;
		add_edge(S,i,p-x);
		add_edge(i+n,T,p);
	}
	ll flow=max_flow();
	ll ans=flow+tot-p*n;
	cout<<ans<<endl;
	return 0;
}

