#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<queue>
#include<ctime>

using namespace std;


int main(){
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	int n,k,p,ans=0;
	cin>>n>>k>>p;
	puts("12");
	
	fclose(stdin);fclose(stdout);
	return 0;
}
