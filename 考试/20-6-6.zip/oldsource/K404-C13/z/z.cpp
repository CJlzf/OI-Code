#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<queue>
#include<ctime>

using namespace std;

int p[310],n,ans;
vector<int>t[310];
bool b[30],d[30];

void dfs(int c){
	if(c>n){
		memset(d,0,sizeof d);
		int cnt=0,a=0;
		for(int i=1;i<=n;i++)if(b[i]){
			cnt++;
			a+=p[i];
			for(int j=0;j<t[i].size();j++)
				d[t[i][j]]=1;
		}
		for(int i=1;i<=n;i++)
			cnt-=d[i];
		if(!cnt)ans=min(ans,a);
		return;
	}
	b[c]=0;dfs(c+1);
	b[c]=1;dfs(c+1);
}
int main(){
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		int x,y;cin>>x;
		for(int j=0;j<x;j++){
			scanf("%d",&y);
			t[i].push_back(y);
		}
	}
	for(int i=1;i<=n;i++){
		cin>>p[i];
		ans+=p[i];
	}
	ans=min(ans,0);
	if(n<=20)dfs(1);
	cout<<ans;
	fclose(stdin);fclose(stdout);
	return 0;
}
