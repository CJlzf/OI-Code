/*
* @Author: wjh
* @Date:   2017-03-13 10:27:00
* @Last Modified by:   wjh
* @Last Modified time: 2017-03-13 12:12:22
*/

#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
#include <map>
#include <set>
#include <utility>

#ifdef DEBUG
    const int MAXN = 110;
#else
    const int MAXN = 1010;
#endif

using namespace std;
typedef long long LL;

inline void open_file() {
    freopen("zhang.in", "r", stdin);
    freopen("zhang.out", "w", stdout);
}

int main() {

    open_file();

    LL n, k, p;
    scanf("%lld%lld%lld", &n, &k, &p);

    printf("12\n");

    return 0;
}