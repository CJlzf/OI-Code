/*
* @Author: wjh
* @Date:   2017-03-13 11:08:04
* @Last Modified by:   wjh
* @Last Modified time: 2017-03-13 12:12:32
*/

#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
#include <map>
#include <set>
#include <utility>

#ifdef DEBUG
    const int MAXN = 25;
#else
    const int MAXN = 25;
#endif

using namespace std;

int n;
vector<int> m[MAXN];
int p[MAXN];

bool vis[MAXN];
inline int test(int x) {
    int sump = 0, cntm = 0, cntk = 0;
    memset(vis, 0, sizeof(vis));
    for (int i = 0; i < n; i++, x >>= 1) {
        if (x & 1) {
            sump += p[i];
            cntk++;
            for (vector<int>::iterator it = m[i].begin(); it != m[i].end(); it++) {
                if (!vis[*it]) cntm++;
                vis[*it] = true;
            }
        }
    }
    return cntk == cntm ? sump : 0;
}

inline void open_file() {
    freopen("z.in", "r", stdin);
    freopen("z.out", "w", stdout);
}

int main() {

    open_file();

    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        int t;
        scanf("%d", &t);
        for (int j = 0; j < t; j++) {
            int tm;
            scanf("%d", &tm);
            m[i].push_back(tm);
        }
    }
    for (int i = 0; i < n; i++) {
        scanf("%d", &p[i]);
    }
    int ans = 0;
    for (int i = 0; i < (1<<n); i++) {
        ans = min(ans, test(i));
    }
    printf("%d\n", ans);

    return 0;
}
