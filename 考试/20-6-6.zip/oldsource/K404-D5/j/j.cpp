/*
* @Author: wjh
* @Date:   2017-03-13 11:19:33
* @Last Modified by:   wjh
* @Last Modified time: 2017-03-13 12:12:39
*/

#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
#include <map>
#include <set>
#include <utility>

#ifdef DEBUG
    const int MAXN = 100;
#else
    const int MAXN = 100010;
#endif

using namespace std;

int n, m, len;
int max_size;

int a[MAXN];

inline void modify(int l, int r, int d) {
    for (int i = l; i <= r; i++) {
        a[i] += d;
    }
}

int t[MAXN];
inline int query(int l, int r, int k) {
    if (r - l + 1 < k) return -1;
    for (int i = l; i <= r; i++) {
        t[i] = a[i];
    }
    sort(t + l, t + r + 1);
    return a[l + k - 1];
}

struct Edge {
    int to, d;
    Edge() {}
    Edge(int _to, int _d): to(_to), d(_d) {}
};
vector<Edge> g[MAXN];

struct D {
    int l, r;
} dfn[MAXN];
int dfs_clock = 0;
inline void dfs(int now, int d) {
    modify(now, now, d);
    dfn[now].l = ++dfs_clock;
    for (vector<Edge>::iterator it = g[now].begin(); it != g[now].end(); it++) {
        dfs(it->to, d + it->d);
    }
    dfn[now].r = dfs_clock;
}

inline void open_file() {
    freopen("j.in", "r", stdin);
    freopen("j.out", "w", stdout);
}

int main() {

    open_file();

    scanf("%d%d%d", &n, &m, &len);
    max_size = len * (n + m);
    for (int i = 2; i <= n; i++) {
        int f, l;
        scanf("%d%d", &f, &l);
        g[f].push_back(Edge(i, l));
    }
    dfs(1, 0);
    for (int i = 0; i < m; i++) {
        int op, x, k;
        scanf("%d%d%d", &op, &x, &k);
        if (op == 1) {
            printf("%d\n", query(dfn[x].l, dfn[x].r, k));
        } else {
            modify(dfn[x].l, dfn[x].r, k);
        }
    }

    return 0;
}
