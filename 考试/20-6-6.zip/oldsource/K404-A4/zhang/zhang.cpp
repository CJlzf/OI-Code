#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
long long mod;
long long jc[1000005],njc[1000005];
long long n,k;
long long pow(long long a,long long b)
{
	long long nv=1;
	while(b)
	{
		if(b%2==1)
			nv=nv*a%mod;
		a=a*a%mod;
		b/=2;
	}
	return nv;
}
long long getc(int a,int b)
{
	return jc[a]*njc[b]%mod*njc[a-b]%mod;
}
int main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	int i;
	scanf("%lld%lld%lld",&n,&k,&mod);
	if(k==1)
	{
		printf("1\n");
		return 0;
	}
	jc[0]=1;
	for(i=1;i<=1000000;i++)
		jc[i]=jc[i-1]*i%mod;
	njc[1000000]=pow(jc[1000000],mod-2);
	for(i=1000000;i>=1;i--)
		njc[i-1]=njc[i]*i%mod;
	long long ans=1;
	ans=pow(k,n-k);
	ans=ans*pow(n-k,k-2)%mod;
	ans=ans*getc(n-1,n-k-1)%mod;
	printf("%lld\n",ans);
	return 0;
}
