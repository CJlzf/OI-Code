#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
long long inf=1e9,INF=1e18;
int v[1000005];
struct node{
	int fr,tt;
	long long siz;
}s[2000005];
int head[1000005],cnte=0;
int t[1000005];
int S,T;
void adde(int a,int b,long long c)
{
	s[cnte].fr=head[a];
	head[a]=cnte;
	s[cnte].tt=b;
	s[cnte].siz=c;
	cnte++;
	s[cnte].fr=head[b];
	head[b]=cnte;
	s[cnte].tt=a;
	s[cnte].siz=0;
	cnte++;
}
int head1=0,tail=0,z[1000005],dis[1000005];
int start[1000005];
bool bfs(int st,int tt)
{
	int i;
	for(i=st;i<=tt;i++)
		dis[i]=0;
	dis[st]=1;
	head1=0,tail=1,z[tail]=st;
	while(head1<tail)
		{
			head1++;
			for(i=head[z[head1]];i!=-1;i=s[i].fr)
				if(s[i].siz&&!dis[s[i].tt])
					{
						dis[s[i].tt]=dis[z[head1]]+1;
						tail++;
						z[tail]=s[i].tt;
					}
		}
	if(!dis[tt])
		return 0;
	return 1;
}
long long dfs(int pos,long long mi)
{
	long long a=0,flow=0;
	int i;
	if(pos==T||mi==0)
		return mi;
	for(i=start[pos];i!=-1;i=s[i].fr)
	{
		if(s[i].siz&&dis[s[i].tt]==dis[pos]+1)
		{
			a=dfs(s[i].tt,min(mi-flow,s[i].siz));
			s[i].siz-=a;
			s[i^1].siz+=a;
			flow+=a;
			if(flow==mi)
				return flow;
		}
		start[pos]=i;
	}
	return flow;
}
int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	int i,a,n,j;
	scanf("%d",&n);
	S=0,T=n*2+1;
	for(i=S;i<=T;i++)
		head[i]=-1;
	cnte=0;
	for(i=1;i<=n;i++)
	{
		scanf("%d",&t[i]);
		for(j=1;j<=t[i];j++)
		{
			scanf("%d",&a);
			adde(i,a+n,INF);
//			adde(a+n,i,INF);
		}
		adde(i+n,T,inf);
	}
	for(i=1;i<=n;i++)
		scanf("%d",&v[i]),adde(S,i,inf-v[i]);
	while(bfs(S,T))
	{
		for(i=S;i<=T;i++)
			start[i]=head[i];
		dfs(S,INF);
	}
	int sum=0;
	for(i=head[S];i!=-1;i=s[i].fr)
	{
//		printf("%d %lld\n",s[i].tt,s[i].siz);
		sum+=s[i].siz;
	}
	/*for(i=head[T];i!=-1;i=s[i].fr)
	{
		printf("%d %lld\n",s[i].tt,s[i^1].siz);
	}*/
	printf("%d\n",-sum);
	return 0;
}
