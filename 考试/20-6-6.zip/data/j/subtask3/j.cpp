#include <bits/stdc++.h>

using namespace std;

const int maxn = 100005,L = 1000;

struct block
{
	int delta,siz,lis[L + 5],en;
}B[maxn / L + 5];


int to[maxn * 2],nex[maxn * 2],final[maxn],cost[maxn * 2];
int a[maxn],dfn[maxn],r[maxn],dfn_cnt,n,tot,m,len;

void Sort(int* l,int n)
{
	static int cnt[128],rk[2 * L + 5],v[2 * L + 5];
	for(int i = 0;i < n;i ++) v[i] = l[i];
	int B = 128;
	for(int i = 0,BIT = 0;i < 3;i ++)
	{
		memset(cnt,0,sizeof cnt);
		for(int i = 0;i < n;i ++) cnt[((v[i]) >> BIT) & 127] ++;
		for(int j = 0;j < B;j ++) cnt[j] += cnt[j - 1];
		for(int i = n - 1;i >= 0;i --) rk[-- cnt[(v[i] >> BIT) & 127]] = v[i];
		swap(v,rk); 
		BIT += 7;
	} 
	for(int i = 0;i < n;i ++) l[i] = v[i];
}

void rebuild(int b)
{
	int s = 0;
	for(int i = b * L,en = B[b].en;i < en;i ++) B[b].lis[s ++] = (a[i] += B[b].delta);
	B[b].delta = 0;
	B[b].siz = s;
	Sort(B[b].lis,s);
}

void link(int u,int v,int c)
{
	to[++ tot] = v,nex[tot] = final[u],cost[tot] = c,final[u] = tot;
}

void dfs(int now,int pre,int dep)
{
	a[dfn[now] = dfn_cnt ++] = dep;
	for(int i = final[now];i;i = nex[i])
		if (to[i] != pre) dfs(to[i],now,dep + cost[i]);
	r[now] = dfn_cnt;
}

void add(int l,int r,int k)
{
	int lb = l / L,rb = r / L;
	if (lb == rb)
		for(;l < r;l ++) a[l] += k; else
		{
			for(int bk = B[lb].en;l < bk;l ++) a[l] += k;
			for(int fr = rb * L;fr < r;fr ++) a[fr] += k;
			rebuild(rb);
		}
	rebuild(lb);
	for(++ lb;lb < rb;lb ++) B[lb].delta += k;
}

void kth_query(int l,int r,int k)
{
	int lb = l / L,rb = r / L;
	static int lis[maxn];
	int cnt = 0;
	if (lb == rb)
		for(;l < r;l ++) lis[cnt ++] = a[l] + B[lb].delta; else	
		{
			for(int bk = B[lb].en;l < bk;l ++) lis[cnt ++] = a[l] + B[lb].delta;
			for(int fr = rb * L;fr < r;fr ++) lis[cnt ++] = a[fr] + B[rb].delta;
		}
	Sort(lis,cnt);
	int lv = 0,rv = 2000000,tmp = -1;
	for(int mid;lv <= rv;)
	{
		mid = lv + rv >> 1;
		int co = upper_bound(lis,lis + cnt,mid) - lis;
		for(int j = lb + 1;j < rb;j ++)
			co += upper_bound(B[j].lis,B[j].lis + B[j].siz,mid - B[j].delta) - B[j].lis;
		if (co >= k) tmp = mid,rv = mid - 1; else lv = mid + 1;
	}
	printf("%d\n", tmp);
}

int main()
{
	//freopen("rhmbwt40.in","r",stdin),freopen("test.out","w",stdout);
	scanf("%d%d%d", &n, &m, &len);
	for(int i = 2;i <= n;i ++)
	{
		int u,c;
		scanf("%d%d", &u,&c);
		link(u,i,c);
	}
	dfs(1,0,0);
	for(int i = 0;i <= dfn_cnt / L;i ++)
	{
		int l = i * L,r = min(dfn_cnt,(i + 1) * L);
		B[i].en = r;
		for(int j = l;j < r;j ++)
			B[i].lis[B[i].siz ++] = a[j];
		Sort(B[i].lis,B[i].siz);
	}
	for(int i = 1;i <= m;i ++)
	{
		int opt,x,k;
		scanf("%d%d%d", &opt, &x, &k);
		if (opt == 1) kth_query(dfn[x],r[x],k);
		if (opt == 2) add(dfn[x],r[x],k);
	}
	cerr << clock() << endl;
	return 0;
}
