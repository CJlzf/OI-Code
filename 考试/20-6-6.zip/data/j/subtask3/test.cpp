#include <iostream>
#include <stdio.h>
#include <vector>
#include <math.h>
#define MAXN 100005
#define SQRT 333
#define LEN 10

using namespace std;

int n , m , len , dep[ MAXN ] , a[ MAXN ] , x[ MAXN ] , z[ MAXN ] , L[ MAXN ] , R[ MAXN ] , tag[ MAXN ] , lim_size , lim_value;
int num = 2147483647 , tot , l[ MAXN ] , r[ MAXN ] , pos[ MAXN ] , minnum[ MAXN ] , maxnum[ MAXN ] , maxdep , mod;
vector < int > linker[ MAXN ] , di[ MAXN ];
unsigned short pre[ SQRT * 4 ][ SQRT * LEN << 2 ];
int des;

struct io_t
{
	char op[1 << 22] , * s , ed[1 << 20] , * t;
	int a[20];
	io_t() : s( op ) , t( ed )
	{
	//	freopen( "rhmbwt36.in" , "r" , stdin );
	//	freopen( "test.out" , "w" , stdout );
		fread( s , 1 , sizeof op , stdin );
	}
	~io_t()
	{
		fwrite( ed , 1 , t - ed , stdout );
	}
	inline int scan()
	{
		static int v;
		v = 0;
		while( * s < 48 ) s++;
		do
			v = v * 10 + * s++ - 48;
		while( * s > 32 );
		return v;
	}
	inline void print( int v )
	{
		static int * q = a;
		if( !v ) * t++ = 48;
		else
		{
			if( v < 0 ) * t++ = '-' , v = -v;
			while( v )
				* q++ = v % 10 + 48 , v /= 10;
			while( q != a )
				* t++ = *--q;
		}
		* t++ = 10;
	}
} io;

#define read io.scan
#define print io.print

inline int update( int & x , int y )
{
	if( x < y ) x = y;
}

#define cur linker[x][i]
#define v di[x][i]

void dfs( int x )
{
	L[x] = ++tot;
	for( int i = 0 ; i < linker[x].size() ; i++ )
		dep[ cur ] = dep[x] + v , dfs( cur );
	R[x] = tot;
}

inline void rebuild( int x )
{
	/*for( register int i = 0 ; i <= lim_value ; i++ ) pre[x][i] = 0;
	maxnum[x] = 0;
	for( register int i = l[x] ; i <= r[x] ; i++ ) pre[x][ a[i] ]++ , update( maxnum[x] , a[i] );
	for( register int i = 1 ; i <= maxnum[x] ; i++ ) pre[x][i] += pre[x][i - 1];*/
	maxnum[x] = 0;
	for( register int i = l[x] ; i <= r[x] ; i++ ) pre[x][ a[i] ] += 1 << 8 , update( maxnum[x] , a[i] );
	pre[x][0] >>= 8;
	for( register int i = 1 ; i <= maxnum[x] ; i++ ) pre[x][i] = ( pre[x][i] >> 8 ) + pre[x][i - 1];
}

inline void build_block()
{
	register int cnt = 0;
	lim_size = min( n , 252 ) , lim_value = n * len / lim_size;
	for( register int i = 1 ; i <= n ; )
	{
		cnt++;
		l[ cnt ] = r[ cnt ] = i;
		minnum[ cnt ] = maxnum[ cnt ] = a[i];
		while( i <= n && max( a[i] , maxnum[ cnt ] ) - min( a[i] , minnum[ cnt ] ) <= lim_value && r[ cnt ] - l[ cnt ] + 1 <= lim_size )
		{
			r[ cnt ] = i , pos[i] = cnt;
			minnum[ cnt ] = min( minnum[ cnt ] , a[i] ) , maxnum[ cnt ] = max( maxnum[ cnt ] , a[i] );
			i++;
		}
	}
	for( int i = 1 ; i <= cnt ; i++ )
	{
		maxnum[i] -= ( tag[i] = minnum[i] );
		for( register int j = l[i] ; j <= r[i] ; j++ ) a[j] -= tag[i];
		rebuild( i );
	}
}

inline int rank( int x , int y , int k )
{
	int ans = 0;
	if( pos[x] == pos[y] )
		for( register int i = x ; i <= y ; i++ )
			ans += a[i] + tag[ pos[i] ] <= k , des++;
	else
	{
		for( register int i = x ; i <= r[ pos[x] ] ; i++ )
			ans += a[i] + tag[ pos[x] ] <= k , des++;
		for( register int i = l[ pos[y] ] ; i <= y ; i++ )
			ans += a[i] + tag[ pos[y] ] <= k , des++;
		for( register int i = pos[x] + 1 ; i <= pos[y] - 1 ; i++ )
			if( k >= tag[i] )
				ans += pre[i][ min( maxnum[i] , k - tag[i] ) ] , des++;
		//cerr << " " << r[ pos[x] ] - x << " " << y - l[ pos[y] ] << " " << pos[y] - 1 - pos[x] - 1 << endl;;
	}
	return ans;
}

inline void modify( int x , int y , int k )
{
	lim_value += k , maxdep += k;
	if( pos[x] == pos[y] )
	{
		for( register int i = x ; i <= y ; i++ ) a[i] += k;
		rebuild( pos[x] );
	}
	else
	{
		for( register int i = x ; i <= r[ pos[x] ] ; i++ ) a[i] += k;
		for( register int i = l[ pos[y] ] ; i <= y ; i++ ) a[i] += k;
		rebuild( pos[x] ) , rebuild( pos[y] );
		for( register int i = pos[x] + 1 ; i <= pos[y] - 1 ; i++ )
			tag[i] += k;
	}
}

inline int find( int x , int y , int k )
{
	if( k > y - x + 1 ) return -1;
	int l = 0 , r = maxdep , ans = -1 , mid;
	while( l <= r )
	{
		mid = l + r >> 1;
		if( rank( x , y , mid - 1 ) + 1 <= k ) l = mid + 1 , ans = mid;
		else r = mid - 1;
	}
	return ans;
}

inline void addedge( int x , int y , int z )
{
	linker[x].push_back( y );
	di[x].push_back( z );
}

#undef v
#include <time.h>
int main()
{
	n = read() , m = read() , len = read();
	for( register int i = 2 ; i <= n ; i++ ) x[i] = read() , z[i] = read() , addedge( x[i] , i , z[i] );
	mod = sqrt( m ) * 3 + 1;
	dfs( 1 );
	for( int i = 1 ; i <= m ; i++ )
	{
		if( num > mod )
		{
			maxdep = num = 0;
			for( register int j = 1 ; j <= n ; j++ ) dep[j] = dep[ x[j] ] + z[j];
			for( register int j = 1 ; j <= n ; j++ ) maxdep = max( maxdep , a[ L[j] ] = dep[j] );
			build_block();
		}
		if( read() == 1 )
		{
			int x = read() , k = read();
			print( find( L[x] , R[x] , k ) );
		}
		else
		{
			int x = read() , k = read();
			z[x] += k , modify( L[x] , R[x] , k );
			num++;
		}
	}
	cerr << clock() << endl;
	//cerr << "  " << des << endl;
	return 0;
}

