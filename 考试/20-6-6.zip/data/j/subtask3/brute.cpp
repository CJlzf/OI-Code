#include <iostream>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <algorithm>
#define MAXN 100005
#define SQRT 2000
#define LEN 10

using namespace std;

int n , m , len , dep[ MAXN ] , a[ MAXN ] , x[ MAXN ] , z[ MAXN ] , L[ MAXN ] , R[ MAXN ] , tag[ MAXN ] , lim_size , lim_value;
int tot , l[ MAXN ] , r[ MAXN ] , pos[ MAXN ] , minnum[ MAXN ] , maxnum[ MAXN ] , maxdep , mod;
vector < int > linker[ MAXN ] , di[ MAXN ];
int pre[ SQRT ][ SQRT ];

inline int read()
{
	register int x = 0 , ch = getchar();
	while( !isdigit( ch ) ) ch = getchar();
	while( isdigit( ch ) ) x = x * 10 + ch - '0' , ch = getchar();
	return x;
}

#define cur linker[x][i]
#define v di[x][i]

void dfs( int x )
{
	L[x] = ++tot;
	for( int i = 0 ; i < linker[x].size() ; i++ )
		dep[ cur ] = dep[x] + v , dfs( cur );
	R[x] = tot;
}

inline void rebuild( int x )
{
	int cnt = 0;
	for( register int i = l[x] ; i <= r[x] ; i++ ) pre[x][ ++cnt ] = a[i];
	sort( pre[x] + 1 , pre[x] + cnt + 1 );
}

inline void build_block()
{
	lim_size = sqrt( n * 15 );
	for( register int i = 1 ; i <= n / lim_size + 1 ; i++ )
	{
		l[i] = ( i - 1 ) * lim_size + 1 , r[i] = min( n , i * lim_size );
		for( register int j = l[i] ; j <= r[i] ; j++ )
			pos[j] = i;
	}
	for( register int i = 1 ; i <= n / lim_size + 1 ; i++ ) rebuild( i );
}

inline int rank( int x , int p )
{
	int L = 1 , R = r[p] - l[p] + 1 , mid , ans = 0;
	while( L <= R )
	{
		mid = L + R >> 1;
		if( pre[p][ mid ] + tag[p] < x ) L = mid + 1 , ans = mid;
		else R = mid - 1;
	}
	return ans;
}

inline int rank( int x , int y , int k )
{
	int ans = 0;
	if( pos[x] == pos[y] )
		for( register int i = x ; i <= y ; i++ )
			ans += ( a[i] + tag[ pos[x] ] ) < k;
	else
	{
		for( register int i = x ; i <= r[ pos[x] ] ; i++ )
			ans += ( a[i] + tag[ pos[x] ] ) < k;
		for( register int i = l[ pos[y] ] ; i <= y ; i++ )
			ans += ( a[i] + tag[ pos[y] ] ) < k;
		for( register int i = pos[x] + 1 ; i <= pos[y] - 1 ; i++ )
			ans += rank( k , i );
	}
	return ans;
}

inline void modify( int x , int y , int k )
{
	maxdep += k;
	if( pos[x] == pos[y] )
	{
		for( register int i = x ; i <= y ; i++ ) a[i] += k;
		rebuild( pos[x] );
	}
	else
	{
		for( register int i = x ; i <= r[ pos[x] ] ; i++ ) a[i] += k;
		for( register int i = l[ pos[y] ] ; i <= y ; i++ ) a[i] += k;
		rebuild( pos[x] ) , rebuild( pos[y] );
		for( register int i = pos[x] + 1 ; i <= pos[y] - 1 ; i++ )
			tag[i] += k;
	}
}

inline int find( int x , int y , int k )
{
	if( k > y - x + 1 ) return -1;
	int l = 0 , r = maxdep , ans = -1 , mid;
	while( l <= r )
	{
		mid = l + r >> 1;
		if( rank( x , y , mid ) + 1 <= k ) l = mid + 1 , ans = mid;
		else r = mid - 1;
	}
	return ans;
}

inline void addedge( int x , int y , int z )
{
	linker[x].push_back( y );
	di[x].push_back( z );
}

#undef v
#include <time.h>
int main()
{
	//freopen( "rhmbwt27.in" , "r" , stdin );
	//freopen( "std.out" , "w" , stdout );
	n = read() , m = read() , len = read();
	for( register int i = 2 ; i <= n ; i++ ) x[i] = read() , z[i] = read() , addedge( x[i] , i , z[i] );
	mod = sqrt( m ) + 1;
	dfs( 1 );
	for( register int j = 1 ; j <= n ; j++ ) dep[j] = dep[ x[j] ] + z[j];
	for( register int j = 1 ; j <= n ; j++ ) maxdep = max( maxdep , a[ L[j] ] = dep[j] );
	build_block();
	for( int i = 1 ; i <= m ; i++ )
		if( read() == 1 )
		{
			int x = read() , k = read();
			printf( "%d\n" , find( L[x] , R[x] , k ) );
		}
		else
		{
			int x = read() , k = read();
			z[x] += k , modify( L[x] , R[x] , k );
		}
	cerr << clock() << endl;
	return 0;
}

