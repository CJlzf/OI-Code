#include <bits/stdc++.h>

using namespace std ; 


int main() { 
		freopen(".cnt", "r", stdin) ; 
		int kkk ;
		scanf("%d", &kkk) ;
		srand(time(0) + kkk * 10000) ; 
		int n = rand() % 201 + 499800 ;
		int k = rand() % (n - 1) + 1 ; 
		printf("%d %d %d\n", n, k, 998244353) ; 
		freopen(".cnt", "w", stdout) ; 
		printf("%d\n", kkk + 5) ; 
}
