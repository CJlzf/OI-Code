#include <bits/stdc++.h>

using namespace std ; 

#define Rand() ((rand() << 15) | rand())

string s1, s2 ;

char sr[1010], sw[1010] ; 
int main() { 
		freopen(".tmp", "r", stdin) ; 
		cin >> s1 >> s2 ; 
		int a = 0 ;
		for (int i = 0; i < s1.length(); i ++) a = a * 10 + s1[i] - '0' ; 
		int b= 0 ;
		for (int i = 0; i < s2.length(); i ++) b = b * 10 + s2[i] - '0' ; 
		sr[0] = 'z' ; 
		int cur = 1 ; 
		for (int i = 0; i < s1.length(); i ++) sr[cur ++] = s1[i] ;  
		sr[cur ++] = '.', sr[cur ++] = 'i', sr[cur ++] = 'n' ; 
		sw[0] = 'z' ; 
		cur = 1 ; 
		for (int i = 0; i < s2.length(); i ++) sw[cur ++] = s2[i] ;  
		sw[cur ++] = '.', sw[cur ++] = 'i', sw[cur ++] = 'n' ; 

		srand(time(0) + a * 10000000) ; 
		freopen(sr, "r", stdin) ; 
		freopen(sw, "w", stdout) ; 
		int n ; 
		scanf("%d", &n) ; 
		printf("%d\n", n) ; 
		for (int i = 1; i <= n; i ++) { 
				int k ; 
				scanf("%d", &k) ;
				printf("%d ", k) ;
				while (k --) { 
						int x ; 
						scanf("%d", &x) ;
						printf("%d ", x) ; 
				}
				putchar(10) ;
		}
		for (int i = 1; i <= n; i ++) printf("%d ", Rand() % 1000001 * ((rand() & 1 )? 1 : -1) ) ; 
		freopen(".tmp", "w", stdout) ; 
		printf("%d %d\n", ++a, ++b) ; 
}

		
