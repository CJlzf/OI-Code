// ====================================
//   author: M_sea
//   website: https://m-sea-blog.com/
// ====================================
#include <bits/stdc++.h>
#define file(x) freopen(#x".in","r",stdin); freopen(#x".out","w",stdout)
using namespace std;
typedef long long ll;

int read() {
	int X=0,w=1; char c=getchar();
	while (c<'0'||c>'9') { if (c=='-') w=-1; c=getchar(); }
	while (c>='0'&&c<='9') X=X*10+c-'0',c=getchar();
	return X*w;
}

int n,k,mod;
int qpow(int a,int b) { int c=1;
	for (;b;b>>=1,a=1ll*a*a%mod) if (b&1) c=1ll*c*a%mod;
	return c;
}

namespace brute {
const int N=100+10;

int C[N][N],pw[N][N],dp[N][N][2][N];

void main() {
	for (int i=C[0][0]=1;i<=n;++i)
		for (int j=C[i][0]=1;j<=n;++j)
			C[i][j]=(C[i-1][j-1]+C[i-1][j])%mod;
	for (int i=1;i<=n;++i)
		for (int j=pw[i][0]=1;j<=n;++j)
			pw[i][j]=1ll*pw[i][j-1]*i%mod;
	dp[1][1][1][1]=1;
	for (int i=1;i<=n;++i)
		for (int j=1;j<=n;++j)
			for (int k=1;k<=i;++k) {
				if (!dp[i][j][0][k]&&!dp[i][j][1][k]) continue;
				for (int l=1;i+l<=n;++l) {
					dp[i+l][l][1][k+l]=(dp[i+l][l][1][k+l]+1ll*dp[i][j][0][k]*pw[j][l]%mod*C[n-i][l])%mod;
					dp[i+l][l][0][k]=(dp[i+l][l][0][k]+1ll*dp[i][j][1][k]*pw[j][l]*C[n-i][l])%mod;
				}
			}
	int ans=0;
	for (int i=1;i<=n;++i) {
		ans=(ans+dp[n][i][0][k])%mod;
		ans=(ans+dp[n][i][1][k])%mod;
	}
	printf("%d\n",ans);	
}
} // namespace brute

int main() {
	file(zhang);
	n=read(),k=read(),mod=read();
	brute::main();
	return 0;
}
