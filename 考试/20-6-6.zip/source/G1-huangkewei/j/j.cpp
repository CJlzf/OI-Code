// ====================================
//   author: M_sea
//   website: https://m-sea-blog.com/
// ====================================
#include <bits/stdc++.h>
#define file(x) freopen(#x".in","r",stdin); freopen(#x".out","w",stdout)
using namespace std;
typedef long long ll;

int read() {
	int X=0,w=1; char c=getchar();
	while (c<'0'||c>'9') { if (c=='-') w=-1; c=getchar(); }
	while (c>='0'&&c<='9') X=X*10+c-'0',c=getchar();
	return X*w;
}

const int N=100000+10;

int n,m,w[N],a[N];
vector<int> E[N];

int dep[N],dfn[N],low[N],tim=0;
void dfs(int u,int f) {
	dep[u]=dep[f]+w[u],dfn[u]=++tim;
	for (int i=0;i<E[u].size();++i) dfs(E[u][i],u);
	low[u]=tim;
}

int main() {
	file(j);
	n=read(),m=read(); read();
	for (int i=2;i<=n;++i) E[read()].push_back(i),w[i]=read();
	dfs(1,0);
	while (m--) {
		int op=read(),x=read(),k=read();
		if (op==2)
			for (int i=dfn[x];i<=low[x];++i) dep[i]+=k;
		else {
			if (low[x]-dfn[x]+1>k) { puts("-1"); continue; }
			for (int i=dfn[x];i<=low[x];++i) a[i-dfn[x]+1]=dep[i];
			nth_element(a+1,a+k,a+n+1);
			printf("%d\n",a[k]);
		}
	}
	return 0;
}