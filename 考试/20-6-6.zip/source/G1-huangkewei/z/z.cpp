// ====================================
//   author: M_sea
//   website: https://m-sea-blog.com/
// ====================================
#include <bits/stdc++.h>
#define file(x) freopen(#x".in","r",stdin); freopen(#x".out","w",stdout)
using namespace std;
typedef long long ll;

int read() {
	int X=0,w=1; char c=getchar();
	while (c<'0'||c>'9') { if (c=='-') w=-1; c=getchar(); }
	while (c>='0'&&c<='9') X=X*10+c-'0',c=getchar();
	return X*w;
}

int n;

namespace task1 {
const int N=20+10;

int p[N];
bitset<N> bit[N];

int calc(int S) {
	bit[0].reset(); int c=0,s=0;
	for (int i=1;i<=n;++i)
		if (S&(1<<(i-1))) bit[0]|=bit[i],++c,s+=p[i];
	return (c!=(int)bit[0].count())?1e9:s;
}

void main() {
	for (int i=1;i<=n;++i) {
		int t=read();
		while (t--) bit[i].set(read());
	}
	for (int i=1;i<=n;++i) p[i]=read();
	int ans=0;
	for (int S=1;S<1<<n;++S) ans=min(ans,calc(S));
	printf("%d\n",ans);
}
} // namespace task1

namespace task2 {
const int N=300+10;

int p[N];

void main() {
	int ans=0;
	for (int i=1;i<=n;++i) {
		int t=read();
		while (t--) read();
	}
	for (int i=1;i<=n;++i) ans+=read();
	printf("%d\n",ans);
}
} // namespace task2

int main() {
	file(z);
	n=read();
	if (n<=20) task1::main();
	else task2::main();
	return 0;
}
