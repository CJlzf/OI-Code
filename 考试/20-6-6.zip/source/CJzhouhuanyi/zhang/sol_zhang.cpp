 #include<iostream>
#include<cstdio>
using namespace std;
long long dp[1001][1001],n,k,mod;
int read()
{
  char c=0;
  int sum=0;
  while (c<'0'||c>'9')
    c=getchar();
  while ('0'<=c&&c<='9')
    {
      sum=sum*10+c-'0';
      c=getchar();
    }
  return sum;
}
int main()
{
  //freopen("zhang.in","r",stdin);
  //freopen("zhang.out","w",stdout);
  n=read(),k=read(),mod=read();
  dp[0][0]=1,dp[1][0]=1;
  for (int i=2;i<=n;++i)
    for (int j=0;j<=i;j+=2)
      {
        dp[i][j]=dp[i-1][j]*(i+j-2)%mod;
 	if (j>=2)
	  dp[i][j]=(dp[i][j]+dp[i-1][j-2]*(i-j+1)%mod)%mod;
      }
  printf("%lld\n",dp[n][k]);
  return 0;
}
