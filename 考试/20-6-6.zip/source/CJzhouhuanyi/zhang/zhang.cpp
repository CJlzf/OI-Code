#include<iostream>
#include<cstdio>
using namespace std;
int n,k,mod,ans,fa[11],rt[11][11],s[11],res;
void dfs(int x)
{
  if (x==n+1)
    {
      for (int i=1;i<=n;++i)
	for (int j=1;j<=n;++j)
	  rt[i][j]=0;
      for (int i=1;i<=n;++i)
	rt[i][fa[i]]=1;
      for (int i=1;i<=n;++i)
	for (int j=1;j<=n;++j)
	  for (int k=1;k<=n;++k)
	    rt[j][k]=rt[j][k]|(rt[j][i]&rt[i][k]);
      for (int i=1;i<=n;++i)
	for (int j=i;j<=n;++j)
	  if (rt[i][j]&&rt[j][i])
	    return;
      res=0;
      for (int i=1;i<=n;++i)
	s[i]=0;
      for (int i=2;i<=n;++i)
	{
	  s[i]^=1;
	  s[fa[i]]^=1;
	}
      for (int i=1;i<=n;++i)
        res+=(s[i]==1);
      if (res==k)
	ans=(ans+1)%mod;
      return;
    }
  for (int i=1;i<=n;++i)
      {
	fa[x]=i;
	dfs(x+1);
      }
  return;
}
int main()
{
  freopen("zhang.in","r",stdin);
  freopen("zhang.out","w",stdout);
  scanf("%d%d%d",&n,&k,&mod);
  dfs(2);
  printf("%d\n",ans);
  return 0;
}
