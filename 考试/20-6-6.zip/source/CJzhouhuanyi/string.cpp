#include<iostream>
#include<cstdio>
using namespace std;
int n=10,S[11][11],mod=998244353;
int main()
{
  S[0][0]=1;
  for (int i=1;i<=n;++i)
    for (int j=1;j<=i;++j)
      S[i][j]=(S[i-1][j]*j%mod+S[i-1][j-1])%mod;
  for (int i=1;i<=n;++i)
    {
      for (int j=1;j<=i;++j)
	cout<<S[i][j]<<' ';
      cout<<endl;
    }
  return 0;
}
