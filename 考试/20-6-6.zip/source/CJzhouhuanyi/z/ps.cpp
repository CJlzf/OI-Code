#include<iostream>
#include<bitset>
#include<cstdio>
using namespace std;
bitset<200000>V[21];
bitset<200000>T;
bitset<200000>em;
long long res=0,n,t,x,p[21];
bool used[21];
void dfs(int x,int u,long long A)
{
  if (x==n+1)
    {
      T=em;
      for (int i=1;i<=n;++i)
	if (used[i])
	    T=T|V[i];
      if (T.count()==u)
	res=min(res,A);
      return;
    }
  dfs(x+1,u,A);
  used[x]=1;
  dfs(x+1,u+1,A+p[x]);
  used[x]=0;
  return;
}
int main()
{
  freopen("z.in","r",stdin);
  freopen("z.ans","w",stdout);
  cin>>n;
  for (int i=1;i<=n;++i)
    {
      cin>>t;
      while (t--)
	{
	  cin>>x;
	  V[i][x]=1;
	}
    }
  for (int i=1;i<=n;++i)
    cin>>p[i];
  dfs(1,0,0);
  printf("%lld\n",res);
  return 0;
}
