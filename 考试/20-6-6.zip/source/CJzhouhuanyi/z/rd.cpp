#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<ctime>
using namespace std;
int n=20,f[21],s,t;
bool used[21];
int main()
{
  srand(time(0));
  freopen("z.in","w",stdout);
  cout<<n<<endl;
  for (int i=1;i<=n;++i)
    f[i]=n-(i+3)%n;
  for (int i=1;i<=n;++i)
    {
      for (int j=1;j<=n;++j)
	used[j]=0;
      s=rand()%n+1;
      cout<<s<<' ';
      cout<<f[i]<<' ';
      for (int ty=1;ty<=s-1;++ty)
	cout<<rand()%10000<<' ';
      cout<<endl;
    }
  for (int i=1;i<=n;++i)
    cout<<rand()*((rand()%2)*2-1)<<' ';
  cout<<endl;
  return 0;
}
