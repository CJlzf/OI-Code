#include<iostream>
#include<cstdio>
#include<map>
#include<queue>
#define int long long
using namespace std;
struct node
{
  int v,data,cost,nxt;
};
node edge[2][500001];
int s,t,n,head[2][4001],p[4001],len[2];
int read()
{
  char c=0;
  int sum=0;
  while (c<'0'||c>'9')
    c=getchar();
  while ('0'<=c&&c<='9')
    {
      sum=sum*10+c-'0';
      c=getchar();
    }
  return sum;
}
void add(int k,int x,int y,int z)
{
  edge[k][++len[k]].v=y,edge[k][len[k]].data=z,edge[k][len[k]].nxt=head[k][x],head[k][x]=len[k];
  return;
}
int ans,matched[4001],length;
bool vis[4001];
bool dfs(int x)
{
  for (int i=head[0][x];i>0;i=edge[0][i].nxt)
    if (!vis[edge[0][i].v])
      {
	vis[edge[0][i].v]=1;
	if (matched[edge[0][i].v]==0||dfs(matched[edge[0][i].v]))
	  {
	    matched[edge[0][i].v]=x;
	    return 1;
	  }
      }
   return 0;
}
map<int,int>P;
int depth[4001],cur[4001];
bool bfs()
{
  int top;
  queue<int>q;
  for (int i=s;i<=t;++i)
    depth[i]=0;
  depth[s]=1;
  q.push(s);
  while (!q.empty())
    {
      top=q.front();
      q.pop();
      for (int i=head[1][top];i>0;i=edge[1][i].nxt)
	if (edge[1][i].data&&!depth[edge[1][i].v])
	  {
	    depth[edge[1][i].v]=depth[top]+1;
	    q.push(edge[1][i].v);
	    if (edge[1][i].v==t)
	      return 1;
	  }
    }
  return 0;
}
int dinic(int x,int flow)
{
  if (x==t)
    return flow;
  int k;
  for (int &i=cur[x];i>0;i=edge[1][i].nxt)
    if (edge[1][i].data&&depth[edge[1][i].v]==depth[x]+1)
      {
	k=dinic(edge[1][i].v,min(flow,edge[1][i].data));
	if (k==0)
	  depth[edge[1][i].v]=0;
	else
	  {
	    edge[1][i].data-=k;
	    edge[1][i^1].data+=k;
	    return k;
	  }
      }
  return 0;
}
signed main()
{
  freopen("z.in","r",stdin);
  freopen("z.out","w",stdout);
  len[1]=1;
  int T,x;
  n=read();
  for (int i=1;i<=n;++i)
    {
      T=read();
      while (T--)
	{
	  x=read();
	  if (P.find(x)!=P.end())
	    add(0,i,P[x],0);
	  else
	    {
	      add(0,i,++length,0);
	      P.insert(make_pair(x,length));
	    }
	}
    }
  for (int i=1;i<=n;++i)
    {
      for (int j=1;j<=length;++j)
	vis[j]=0;
      dfs(i);
    }
  for (int i=1;i<=n;++i)
      for (int j=head[0][i];j>0;j=edge[0][j].nxt)
	{
	  add(1,i,matched[edge[0][j].v],1e9);
	  add(1,matched[edge[0][j].v],i,0);
	}
  s=0,t=n+1;
  for (int i=1;i<=n;++i)
    scanf("%lld",&p[i]);
  for (int i=1;i<=n;++i)
    {
      if (p[i]<0)
	{
	  ans+=p[i];
	  add(1,s,i,-p[i]);
	  add(1,i,s,p[i]);
	}
      else
	{
	  add(1,i,t,p[i]);
	  add(1,t,i,-p[i]);
	}
    }
  int flow;
  while (bfs())
    {
      for (int i=s;i<=t;++i)
	cur[i]=head[1][i];
      while (flow=dinic(s,1e9))
	  ans+=flow;
    }
  printf("%lld\n",ans);
  return 0;
}
