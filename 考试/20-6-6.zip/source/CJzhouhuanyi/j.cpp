#include<iostream>
#include<cstdio>
using namespace std;
struct node
{
  int v,nxt;
};
node edge[100001];
int n,m,len,len,dfn[100001],sz[100001],length;
int read()
{
  char c=0;
  int sum=0;
  while (c<'0'||c>'9')
    c=getchar();
  while ('0'<=c&&c<='9')
    {
      sum=sum*10+c-'0';
      c=getchar();
    }
  return sum;
}
void add(int x,int y)
{
  edge[++len].v=y;
  edge[len].nxt=head[x];
  head[x]=len;
  return;
}
void dfs(int x)
{
  dfn[x]=++length,sz[x]=1;
  for (int i=head[x];i>0;i=edge[i].nxt)
      {
	dfs(edge[i].v);
	sz[x]+=sz[edge[i].v];
      }
  return;
}
int main()
{
  int op;
  int x;
  n=read(),m=read(),len=read();
  for (int i=1;i<=n;++i)
    {
      x=read();
      add(x,i);
    }
  dfs(1);
  for (int i=1;i<=m;++i)
    {
      op=read();
    }
  return 0;
}
