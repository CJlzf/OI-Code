#include<bits/stdc++.h>
using namespace std;
int n,t[303],vis[303],p[303],a[303][303],s1,s2,sum,b[303],ans,che;
void dfs(int x)
{
	if(x==n+1)
	{
		for(int i=1;i<=n;i++)
			b[i]=0;
		sum=0,s1=0,s2=0;
		for(int i=1;i<=n;i++)
			if(vis[i]==1)
			{
				for(int j=1;j<=t[i];j++)
					b[a[i][j]]=1;
				s1++,sum+=p[i];
			}
		for(int i=1;i<=n;i++)
			s2+=b[i];
		if(s1==s2)
			ans=min(ans,sum);
		return;
	}
	vis[x]=1;
	dfs(x+1);
	vis[x]=0;
	dfs(x+1);
}
int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&t[i]);
		for(int j=1;j<=t[i];j++)
			scanf("%d",&a[i][j]);
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&p[i]);
		sum+=p[i];
		if(p[i]>0)
			che=1;
	}
	if(che==0)
	{
		cout<<sum;
		return 0;
	}
	dfs(1);
	cout<<ans;
	return 0;
}
