#include<bits/stdc++.h>
#define int long long 
using namespace std;
int n,k,mod,sum,sq,ans,fa[500003];
void df(int x,int nu)
{
	sum++;
	if(nu%2==1)
		sq++;
	for(int i=1;i<=n;i++)
		if(fa[i]==x)
			df(i,nu+1);
}
void dfs(int x)
{
	if(x==n+1)
	{
		sum=0,sq=0;
		df(1,1);
		if(sum==n&&sq==k)
			ans++;
		return;
	}
	for(int i=1;i<=n;i++)
		if(i!=x)
		{
			fa[x]=i;
			dfs(x+1);
		}
}
signed main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	scanf("%lld%lld%lld",&n,&k,&mod);
	dfs(2);
	cout<<ans%mod;
	return 0;
}
