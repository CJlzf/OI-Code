#include<bits/stdc++.h>
using namespace std;
const int N=200010;
int n,m,len;
int head[N],cnt;
struct edge
{
	int to,next;
}e[N<<1];
void adde(int a,int b)
{
	e[++cnt].to=b; e[cnt].next=head[a]; head[a]=cnt;
}
int fa[N],dis[N],a[N],tot;
void dfs(int k)
{
	a[++tot]=dis[k];
	for(int i=head[k];i;i=e[i].next)
		dfs(e[i].to);
}
void pushdown(int k,int x)
{
	dis[k]+=x;
	for(int i=head[k];i;i=e[i].next)
		pushdown(e[i].to,x);
}
int main()
{
	freopen("j.in","r",stdin);freopen("j.out","w",stdout);
	scanf("%d%d%d",&n,&m,&len);
	for(int i=2;i<=n;i++)
	{
		int x;
		scanf("%d%d",&fa[i],&x);
		adde(fa[i],i); dis[i]=dis[fa[i]]+x;
	}
	int op,x,k;
	while(m--)
	{
		scanf("%d%d%d",&op,&x,&k);
		if(op==1)
		{
			tot=0;
			dfs(x);
			sort(a+1,a+tot+1);
			printf("%d\n",a[k]);
		}
		else
			pushdown(x,k);
	}
	return 0;
}
