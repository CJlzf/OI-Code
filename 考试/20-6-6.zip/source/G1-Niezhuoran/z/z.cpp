#include<bits/stdc++.h>
using namespace std;
const int N=200010,inf=1e9;
int n;
int head[N],cnt=1,cur[N];
struct edge
{
	int to,next,f;
}e[N<<3];
void adde(int a,int b,int c)
{
	e[++cnt]=(edge){b,head[a],c}; head[a]=cnt;
	e[++cnt]=(edge){a,head[b],0}; head[b]=cnt;
}
int s,t,tot;
vector<int>d[N];
int dep[N];
queue<int>q;
bool bfs()
{
	for(int i=0;i<=tot;i++)
		dep[i]=0;
	dep[s]=1;
	q.push(s);
	while(!q.empty())
	{
		int u=q.front(); q.pop();
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(!dep[v] && e[i].f)
			{
				dep[v]=dep[u]+1;
				q.push(v); 
			}
		}
	}
	return dep[t];
}
int ans;
int dfs(int u,int f)
{
	if(u==t || !f)return f;
	int d=0;
	for(int &i=cur[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(dep[v]==dep[u]+1 && e[i].f)
		{
			int x=dfs(v,min(f,e[i].f));
			if(!x)continue;
			f-=x; d+=x; e[i].f-=x; e[i^1].f+=x;
			if(!f)break;
		}
	}
	return d;
}
int dinic()
{
	int res=0,x;
	while(bfs())
	{
		for(int i=0;i<=tot;i++)
			cur[i]=head[i];
		while((x=dfs(s,inf)))res+=x;
	}
	return res;
}
int a[N],v[N],dfn[N],low[N],dfc,col[N],cn,sum[N];
int st[N],top;
void tarjan(int k)
{
	dfn[k]=low[k]=++dfc;
	st[++top]=k;
	for(int i=head[k];i;i=e[i].next)
	{
		if(!e[i].f)continue;
		int v=e[i].to;
		if(!dfn[v])
		{
			tarjan(v);
			low[k]=min(low[k],low[v]);
		}
		else
			if(!col[v])
				low[k]=min(low[k],dfn[v]);
	}
	if(dfn[k]==low[k])
	{
		cn++; col[k]=cn;
		sum[cn]+=v[k];
		while(st[top]!=k)
		{
			col[st[top]]=cn;
			sum[cn]+=v[st[top]];
			top--;
		}
		top--;
	}
}
int main()
{
	freopen("z.in","r",stdin);freopen("z.out","w",stdout);
	scanf("%d",&n);
	int ct,x;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&ct);
		for(int j=1;j<=ct;j++)
		{
			scanf("%d",&x);
			d[i].push_back(x);
			adde(i,x+n,1);
		}
	}
	s=0; t=2*n+1; tot=2*n+1;
	for(int i=1;i<=n;i++)
		adde(s,i,1),adde(i+n,t,1);
	dinic();
	for(int i=1;i<=n;i++)
		for(int j=head[i];j;j=e[j].next)
		{
			int v=e[j].to;
			if(!e[j].f)
			{
				a[i]=v-n;
				break;
			}
		}
	for(int i=1;i<=n;i++)
		scanf("%d",&v[i]),v[i]=-v[i];
	memset(head,0,sizeof(head)); cnt=1;
	for(int i=1;i<=n;i++)
		for(int j=0;j<d[i].size();j++)
			if(d[i][j]!=a[i])
				adde(a[i],d[i][j],inf);
	for(int i=1;i<=n;i++)
		if(!dfn[i])
			tarjan(i);
	memset(head,0,sizeof(head)); cnt=1; s=0; t=cn+1; tot=cn+1;
	for(int i=1;i<=n;i++)
		for(int j=0;j<d[i].size();j++)
			if(d[i][j]!=a[i] && col[d[i][j]]!=col[a[i]])
				adde(col[a[i]],col[d[i][j]],inf);
	for(int i=1;i<=cn;i++)
		if(sum[i]>0)adde(s,i,sum[i]),ans+=sum[i];
		else
			adde(i,t,-sum[i]);
	printf("%d\n",-(ans-dinic()));
	return 0;
}
