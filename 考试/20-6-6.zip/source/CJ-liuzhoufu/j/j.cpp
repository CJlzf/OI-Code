#include <iostream>
#include <cstdio>
#include <algorithm>
#define N 1002
using namespace std;
int head[N],ver[N*2],nxt[N*2],edge[N*2],l;
int n,m,len,i,fa[N],dep[N],flag,cnt,ans[N];
int read()
{
	char c=getchar();
	int w=0;
	while(c<'0'||c>'9') c=getchar();
	while(c<='9'&&c>='0'){
		w=w*10+c-'0';
		c=getchar();
	}
	return w;
}
void insert(int x,int y,int z)
{
	l++;
	ver[l]=y;
	edge[l]=z;
	nxt[l]=head[x];
	head[x]=l;
}
void dfs(int x)
{
	for(int i=head[x];i;i=nxt[i]){
		int y=ver[i];
		dep[y]=dep[x]+edge[i];
		dfs(y);
	}
}
void get(int x)
{
	ans[++cnt]=dep[x];
	for(int i=head[x];i;i=nxt[i]) get(ver[i]);
}
int main()
{
	freopen("j.in","r",stdin);
	freopen("j.out","w",stdout);
	n=read();m=read();len=read();
	for(i=2;i<=n;i++){
		int x=read(),w=read();
		insert(x,i,w);
		fa[i]=x;
	}
	dfs(1);
	while(m--){
		int op=read(),x=read(),k=read();
		if(op==1){
			cnt=0;
			get(x);
			sort(ans+1,ans+cnt+1);
			printf("%d\n",ans[k]);
		}
		else{
			if(x==1){
				dep[x]+=k;
				dfs(x);
			}
			else{
				for(int i=head[fa[x]];i;i=nxt[i]){
					if(ver[i]==x) edge[i]+=k;
				}
				dfs(fa[x]);
			}
		}
	}
	return 0;
}
