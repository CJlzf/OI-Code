#include <iostream>
#include <cstdio>
#include <cstring>
#define N 102
using namespace std;
int n,m,mod,i,j,k,l,d,x;
long long f[2][N][N][N],p[N][N],c[N][N],ans;
long long poww(long long a,long long b)
{
	long long ans=1,base=a;
	while(b){
		if(b&1) ans=ans*base%mod;
		base=base*base%mod;
		b>>=1;
	}
	return ans;
}
signed main()
{
	freopen("zhang.in","r",stdin);
	freopen("zhang.out","w",stdout);
	scanf("%d%d%d",&n,&m,&mod);
	for(i=1;i<=n;i++){
		for(j=1;j<=n;j++) p[i][j]=poww(i,j);
	}
	c[0][0]=1;
	for(i=1;i<=n;i++){
		c[i][0]=1;
		for(j=1;j<=n;j++) c[i][j]=(c[i-1][j-1]+c[i-1][j])%mod;
	}
	f[x][1][1][1]=1;
	for(i=2;i<=n;i++){
		x^=1;
		memset(f[x],0,sizeof(f[x]));
		for(j=1;j<=n-i+1;j++){
			for(k=1;k<=n;k++){
				for(l=1;l<=n;l++){
					for(d=j+1;d<=n;d++){
						if(n-d+j<0) continue;
						if(i%2&&l>=j) f[x][j][l][d]=(f[x][j][l][d]+f[x^1][k][l-j][d-j]*p[k][j]%mod*c[n-d+j][j]%mod)%mod;
						else if(i%2==0) f[x][j][l][d]=(f[x][j][l][d]+f[x^1][k][l][d-j]*p[k][j]%mod*c[n-d+j][j]%mod)%mod;
					}
				}
			}
		}
		for(j=1;j<=n;j++) ans=(ans+f[x][j][m][n])%mod;
	}
	if(n==1&&m==1) puts("1");
	else printf("%lld\n",ans);
	return 0;
}
