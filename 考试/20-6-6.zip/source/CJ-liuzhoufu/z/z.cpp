#include <iostream>
#include <cstdio>
#include <set>
#define N 302
using namespace std;
set<int> s;
int n,m,i,j,a[N][N],t[N],p[N],ans=1<<30;
bool vis[N],use[N],flag=1;
int read()
{
	char c=getchar();
	int w=0,f=1;
	while(c<'0'||c>'9'){
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0'){
		w=w*10+c-'0';
		c=getchar();
	}
	return w*f;
}
void dfs(int x)
{
	if(x==n+1){
		int cnt1=0,cnt2=0,sum=0;
		for(int i=1;i<=n;i++){
			if(vis[i]){
				cnt1++;sum+=p[i];
				for(int j=1;j<=t[i];j++){
					if(!use[a[i][j]]) use[a[i][j]]=1,cnt2++;
				}
			}
		}
		for(int i=1;i<=m;i++) use[i]=0;
		if(cnt1==cnt2) ans=min(ans,sum);
		return;
	}
	vis[x]=1;
	dfs(x+1);
	vis[x]=0;
	dfs(x+1);
}
int main()
{
	freopen("z.in","r",stdin);
	freopen("z.out","w",stdout);
	n=read();
	for(i=1;i<=n;i++){
		t[i]=read();
		for(j=1;j<=t[i];j++) a[i][j]=read();
		m+=t[i];
	}
	for(i=1;i<=n;i++){
		p[i]=read();
		if(p[i]>0) flag=0;
	}
	if(flag){
		int ans=0;
		for(int i=1;i<=n;i++) ans+=p[i];
		printf("%d\n",ans);
		return 0;
	}
	dfs(1);
	printf("%d\n",ans);
	return 0;
}
