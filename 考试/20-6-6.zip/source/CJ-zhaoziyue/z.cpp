#include<bits/stdc++.h>

#define LL long long
#define RG register

using namespace std;
template<class T> T gi() {
	T x = 0; bool f = 0; char c = getchar();
	while (c != '-' && (c < '0' || c > '9')) c = getchar();
	if (c == '-') f = 1, c = getchar();
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return f ? -x : x;
}
const int N = 5010, inf = 1e9;
struct node { int to, nxt, w; } g[2000010];
int lst[N], gl = 1;
void add(int x, int y, int z) {
	g[++gl] = (node) {y, lst[x], z}; lst[x] = gl;
	g[++gl] = (node) {x, lst[y], 0}; lst[y] = gl;
}
int dep[N], S, T;
bool bfs() {
	memset(dep, 0, sizeof(dep));
	dep[S] = 1; static queue<int> q; q.push(S);
	while (!q.empty()) {
		int u = q.front(); q.pop();
		for (int i = lst[u]; i; i = g[i].nxt) {
			int v = g[i].to;
			if (!dep[v] && g[i].w) {
				dep[v] = dep[u] + 1;
				q.push(v);
			}
		}
	}
	return dep[T];
}
int dfs(int u, int flow) {
	if (u == T) return flow;
	int fl = 0;
	for (int i = lst[u]; i; i = g[i].nxt) {
		int v = g[i].to;
		if (dep[v] == dep[u] + 1 && g[i].w) {
			int d = dfs(v, min(g[i].w, flow));
			g[i].w -= d; g[i ^ 1].w += d; fl += d;
			flow -= d; if (!flow) break;
		}
	}
	return fl;
}
int dinic() {
	int res = 0;
	while (bfs()) res += dfs(S, inf);
	return res;
}
int a[N], t[N][N];
int main() {
	freopen("z.in", "r", stdin);
	freopen("z.out", "w", stdout);
	int n = gi<int>();
	for (int i = 1; i <= n; i++) {
		t[i][0] = gi<int>();
		for (int j = 1; j <= t[i][0]; j++)
			t[i][j] = gi<int>();
	}
	for (int i = 1; i <= n; i++) a[i] = -gi<int>();
	S = 2 * n + 1, T = S + 1;
	int sum = 0;
	for (int i = 1; i <= n; i++) {
		if (a[i] > 0) {
			add(S, i, a[i]), sum += a[i];
			for (int j = 1; j <= t[i][0]; j++)
				add(i, t[i][j] + n, inf);
		}
		else {
			add(i, T, -a[i]);
			for (int j = 1; j <= t[i][0]; j++)
				add(t[i][j] + n, i, inf), add(i, t[i][j] + n, inf);
		}
	}
	printf("%d\n", dinic() - sum);
	return 0;
}
