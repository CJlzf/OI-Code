#include<bits/stdc++.h>

#define LL long long
#define RG register

using namespace std;
template<class T> T gi() {
	T x = 0; bool f = 0; char c = getchar();
	while (c != '-' && (c < '0' || c > '9')) c = getchar();
	if (c == '-') f = 1, c = getchar();
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return f ? -x : x;
}
const int N = 1e5 + 10;
int n, m, T;
struct node { int to, nxt, w; } g[N];
int lst[N], gl;
void add(int x, int y, int z) { g[++gl] = (node) {y, lst[x], z}; lst[x] = gl; }
int tim, dep[N], a[N], siz[N], L[N], R[N];
void dfs(int u) {
	a[++tim] = dep[u]; L[u] = tim; siz[u] = 1;
	for (int i = lst[u]; i; i = g[i].nxt) {
		int v = g[i].to; dep[v] = dep[u] + g[i].w;
		dfs(v); siz[u] += siz[v];
	}
	R[u] = tim;
}
vector<int> v[500];
int pls[500], bel[N], lim;
void modify(int l, int r, int k) {
	for (int i = bel[l] + 1; i < bel[r]; i++) 
		pls[i] += k, lim = max(lim, *v[i].rbegin() + pls[i]);	
	for (int i = l; i <= min(bel[l] * T, r); i++)
		a[i] += k;
	v[bel[l]].clear();
	for (int i = (bel[l] - 1) * T + 1; i <= min(n, bel[l] * T); i++)
		a[i] += pls[bel[l]], v[bel[l]].push_back(a[i]);
	sort(v[bel[l]].begin(), v[bel[l]].end()); pls[bel[l]] = 0;
	lim = max(lim, *v[bel[l]].rbegin());

	if (bel[l] != bel[r]) {
		for (int i = (bel[r] - 1) * T + 1; i <= r; i++)
			a[i] += k;
		v[bel[r]].clear();
		for (int i = (bel[r] - 1) * T + 1; i <= min(n, bel[r] * T); i++)
			a[i] += pls[bel[r]], v[bel[r]].push_back(a[i]);
		sort(v[bel[r]].begin(), v[bel[r]].end()); pls[bel[r]] = 0;
		lim = max(lim, *v[bel[r]].rbegin());
	}
}
int check(int l, int r, int x) {
	int cnt = 0;
	for (int i = bel[l] + 1; i < bel[r]; i++)
		cnt += upper_bound(v[i].begin(), v[i].end(), x - pls[i]) - v[i].begin();
	for (int i = l; i <= min(bel[l] * T, r); i++)
		if (a[i] + pls[bel[l]] <= x) cnt++;
	if (bel[l] != bel[r]) 
		for (int i = (bel[r] - 1) * T + 1; i <= r; i++)
			if (a[i] + pls[bel[r]] <= x) cnt++;
	return cnt; 
}
int main() {
	freopen("j.in", "r", stdin);
	freopen("j.out", "w", stdout);
	n = gi<int>(), m = gi<int>(); gi<int>();
	for (int i = 2, x; i <= n; i++) {
		x = gi<int>();
		add(x, i, gi<int>());
	}
	dfs(1);
	T = sqrt(n);
	for (int i = 1; i <= n; i++)
		bel[i] = (i - 1) / T + 1;
	for (int i = 1; i <= bel[n]; i++) {
		for (int j = (i - 1) * T + 1; j <= min(i * T, n); j++)
			v[i].push_back(a[j]), lim = max(lim, a[j]);
		sort(v[i].begin(), v[i].end());
	}
	while (m--) {
		int op = gi<int>(), x = gi<int>(), k = gi<int>();
		if (op == 1) {
			if (siz[x] < k) { puts("-1"); continue; }
			int l = 0, r = lim;
			//	printf("%d %d\n", L[x], R[x]);
			while (l <= r) {
				int mid = (l + r) >> 1;
				if (check(L[x], R[x], mid) >= k) r = mid - 1;
				else l = mid + 1;
			}
			printf("%d\n", r + 1);
		}
		else modify(L[x], R[x], k);
	}
	return 0;
}
